#!/usr/bin/env python3

"""
Portal connectivity heartbeat sender.

Each run posts the host heartbeat (CPU,
memory, disk, load from /proc) and probes
the local services - PostgreSQL, the
Uvicorn API and Technitium DNS - posting a
service heartbeat for each. A probe that
finds a service down reports it offline
immediately.

Local use (systemd timer) posts to the API
on this machine; remote servers run:

    python3 heartbeat.py \\
        --url https://pihole.chriscoetzer.co.za \\
        --insecure

(--insecure trusts the portal's own
certificate; drop it once the portal serves
a certificate your machine trusts.)

Only the Python standard library is used.
"""

import json
import os
import socket
import ssl
import sys
import time
import urllib.request


SERVICES = [
    ("PostgreSQL", "127.0.0.1", 5432),
    ("Uvicorn API", "127.0.0.1", 8000),
]


def backend_services(base_url, insecure):
    """The local services every portal host reports, plus the
    network services backend when one is configured: Technitium
    DNS on 5380 or the NetFortress appliance on 8080. A portal
    without a backend reports no backend row at all.

    The provider comes from the portal API, so this follows
    whatever backend the portal selected; when the lookup fails
    (API down, bad URL) only the portal-core services report.
    """

    try:
        request = urllib.request.Request(
            base_url + "/api/backends/capabilities"
        )

        context = None
        if insecure:
            context = ssl._create_unverified_context()

        with urllib.request.urlopen(
            request,
            timeout=5,
            context=context
        ) as response:
            provider = (
                json.load(response)
                .get("provider")
            )

    except Exception:
        provider = None

    if provider == "technitium":
        return SERVICES + [
            ("Technitium DNS", "127.0.0.1", 5380)
        ]

    if provider == "firewall":
        return SERVICES + [
            ("NetFortress Appliance", "127.0.0.1", 8080)
        ]

    return SERVICES


def read_cpu_percent(interval=0.4):
    """CPU busy percent measured over a
    short /proc/stat sample."""

    def sample():
        with open("/proc/stat") as handle:
            parts = handle.readline().split()
        values = [int(p) for p in parts[1:]]
        idle = values[3] + values[4]
        total = sum(values)
        return idle, total

    idle_a, total_a = sample()
    time.sleep(interval)
    idle_b, total_b = sample()

    delta = total_b - total_a

    if delta <= 0:
        return 0.0

    return round(
        100.0 * (1 - (idle_b - idle_a) / delta),
        2,
    )


def read_memory_percent():
    """Used memory percent from
    /proc/meminfo."""

    info = {}

    with open("/proc/meminfo") as handle:
        for line in handle:
            key, _, value = line.partition(":")
            info[key.strip()] = int(
                value.split()[0]
            )

    total = info.get("MemTotal", 0)
    available = info.get("MemAvailable", 0)

    if total <= 0:
        return 0.0

    return round(
        100.0 * (total - available) / total,
        2,
    )


def read_disk_percent(path="/"):
    """Used space percent of the root
    filesystem."""

    stats = os.statvfs(path)

    if stats.f_blocks <= 0:
        return 0.0

    used = stats.f_blocks - stats.f_bfree

    return round(
        100.0 * used / stats.f_blocks,
        2,
    )


def read_loads():
    """1/5/15 minute load averages."""

    with open("/proc/loadavg") as handle:
        parts = handle.read().split()

    return (
        float(parts[0]),
        float(parts[1]),
        float(parts[2]),
    )


def primary_ip():
    """The outbound IPv4 address - the
    UDP connect trick sends no packets."""

    sock = socket.socket(
        socket.AF_INET,
        socket.SOCK_DGRAM,
    )

    try:
        sock.connect(("10.255.255.255", 1))
        return sock.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        sock.close()


def probe(host, port, timeout=3):
    """TCP connect probe - online when the
    port answers."""

    try:
        with socket.create_connection(
            (host, port),
            timeout=timeout,
        ):
            return "online"
    except OSError:
        return "offline"


def post(url, insecure, payload):
    """Posts one heartbeat."""

    context = None

    if url.startswith("https://") and insecure:
        context = ssl._create_unverified_context()

    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode(),
        headers={
            "Content-Type": "application/json"
        },
    )

    handlers = []

    if context is not None:
        handlers.append(
            urllib.request.HTTPSHandler(
                context=context
            )
        )

    opener = urllib.request.build_opener(
        *handlers
    )

    return (
        opener.open(request, timeout=10)
        .read()
        .decode()
    )


def main():
    heartbeat_url = (
        "http://127.0.0.1:8000"
        "/api/monitoring/heartbeat"
    )

    insecure = False
    host_only = False

    args = sys.argv[1:]
    index = 0

    while index < len(args):

        if (
            args[index] == "--url"
            and index + 1 < len(args)
        ):
            heartbeat_url = (
                args[index + 1].rstrip("/")
                + "/api/monitoring/heartbeat"
            )
            index += 2
            continue

        if args[index] == "--insecure":
            insecure = True

        if args[index] == "--host-only":
            host_only = True

        index += 1

    load_1m, load_5m, load_15m = read_loads()

    results = [
        post(
            heartbeat_url,
            insecure,
            {
                "hostname": os.uname().nodename,
                "ip_address": primary_ip(),
                "cpu_percent":
                    read_cpu_percent(),
                "memory_percent":
                    read_memory_percent(),
                "disk_percent":
                    read_disk_percent(),
                "load_1m": load_1m,
                "load_5m": load_5m,
                "load_15m": load_15m,
            },
        )
    ]

    if not host_only:

        base_url = (
            heartbeat_url
            .split("/api/monitoring/heartbeat")[0]
            .split("/monitoring/heartbeat")[0]
        )

        for name, host, port in backend_services(
            base_url,
            insecure
        ):

            results.append(
                post(
                    heartbeat_url,
                    insecure,
                    {
                        "hostname": name,
                        "ip_address": "127.0.0.1",
                        "status": probe(host, port),
                    },
                )
            )

    for result in results:
        print(result)


if __name__ == "__main__":
    main()
