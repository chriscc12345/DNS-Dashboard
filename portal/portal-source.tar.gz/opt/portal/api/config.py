# Portal configuration. The installer writes the generated
# database credentials into this file; backend integration
# values are filled in when a backend is provisioned from
# Settings -> System Status.

POSTGRES_HOST = "127.0.0.1"
POSTGRES_DB = "dnsapproval"
POSTGRES_USER = "dnsapp"
POSTGRES_PASSWORD = ''

MONITORING_POSTGRES_HOST = "127.0.0.1"
MONITORING_POSTGRES_DB = "monitoring_db"
MONITORING_POSTGRES_USER = "monitoring_user"
MONITORING_POSTGRES_PASSWORD = ''

# Technitium DNS backend (set by the Technitium provisioning)
TECHNITIUM_HOST = "127.0.0.1"
TECHNITIUM_TOKEN = ''
TECHNITIUM_SSL_PASSWORD = ''

# NetFortress Firewall Appliance backend (set by the appliance provisioning)
FIREWALL_API_URL = "http://127.0.0.1:8080"
FIREWALL_API_TOKEN = ''
