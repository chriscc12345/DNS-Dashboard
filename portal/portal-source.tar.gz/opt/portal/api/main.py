import subprocess
import asyncio
import psycopg2
import requests
from config import *
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, WebSocket
from datetime import datetime
from fastapi import UploadFile, File
import shutil
import os

app = FastAPI()


# WebSocket Connection Manager
class ConnectionManager:

    def __init__(self):
        self.connections = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.connections.remove(websocket)

    async def broadcast(self, message: str):
        for connection in self.connections:
            await connection.send_text(message)


manager = ConnectionManager()

class LoginRequest(BaseModel):
    username: str
    password: str
    
    
@app.post("/login")
def login(login: LoginRequest):

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/user/login",
        params={
            "user": login.username,
            "pass": login.password
        }
    )
    
    return response.json()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):

    await manager.connect(websocket)

    try:

        while True:
            await websocket.receive_text()

    except Exception:

        manager.disconnect(websocket)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class SiteRequest(BaseModel):
    domain: str
    client_ip: str
    reason: str
    
class AllowRequest(BaseModel):
    allow_type: str
    duration: int | None = None

@app.get("/requests")
def get_requests():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id,
               domain,
               client_ip,
               reason,
               status,
               requested_at
        FROM requests
        ORDER BY id DESC
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows

@app.post("/request")
async def request_access(request: SiteRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    # Check if request already exists
    cur.execute("""
        SELECT id
        FROM requests
        WHERE domain = %s
        AND status = 'Pending'
    """, (request.domain,))

    existing_request = cur.fetchone()

    if existing_request:

        cur.close()
        conn.close()

        return {
            "success": False,
            "message": "Request already pending"
        }

    # Create request
    cur.execute(
        """
        INSERT INTO requests
        (domain, client_ip, reason)
        VALUES
        (%s, %s, %s)
        """,
        (
            request.domain,
            request.client_ip,
            request.reason
        )
    )

    conn.commit()
    
    print("Broadcasting refresh from request")
    await manager.broadcast("refresh")

    cur.close()
    conn.close()

    return {
        "success": True
    }

@app.get("/pending")
def pending_requests():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id,
               domain,
               client_ip,
               reason,
               status,
               requested_at
        FROM requests
        WHERE status = 'Pending'
        ORDER BY id DESC
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows

@app.get("/approved")
def approved_requests():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id,
               domain,
               client_ip,
               reason,
               status,
               approved_at,
               allowed_until
        FROM requests
        WHERE status = 'Approved'
        ORDER BY approved_at DESC
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows

@app.post("/approve/{request_id}")
async def approve_request(request_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    # Get domain from request
    cur.execute("""
        SELECT domain
        FROM requests
        WHERE id = %s
    """, (request_id,))

    row = cur.fetchone()

    if row is None:
        cur.close()
        conn.close()

        return {
            "success": False,
            "message": "Request not found"
        }

    domain = row[0]

    print("Domain:", domain)

    # Call Technitium
    technitium_response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/blocked/delete",
        params={
            "token": TECHNITIUM_TOKEN,
            "domain": domain
        }
    )

    print("Status Code:", technitium_response.status_code)
    print("Response:", technitium_response.text)

    if technitium_response.status_code != 200:
        return {"success": False}

    # Update status
    cur.execute("""
        UPDATE requests
        SET status = 'Approved',
		        approved_at = NOW(),
            allowed_until = NULL
        WHERE id = %s
    """, (request_id,))

    conn.commit()
    
    print("Broadcasting refresh from approve")
    await manager.broadcast("refresh")

    cur.close()
    conn.close()

    return {
        "success": True,
        "request_id": request_id,
        "domain": domain
    }

@app.post("/deny/{request_id}")
async def deny_request(request_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        UPDATE requests
        SET status = 'Denied',
		        denied_at = NOW(),
            deny_reason = 'Manual Deny'
        WHERE id = %s
    """, (request_id,))

    conn.commit()
    
    print("Broadcasting refresh from deny")
    await manager.broadcast("refresh")

    cur.close()
    conn.close()

    return {
        "success": True,
        "request_id": request_id
    }

@app.get("/status/{domain}")
def request_status(domain: str):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT status
        FROM requests
        WHERE domain = %s
        ORDER BY id DESC
        LIMIT 1
    """, (domain,))

    row = cur.fetchone()

    cur.close()
    conn.close()

    if row:
        return {"status": row[0]}

    return {"status": "None"}

@app.get("/denied")
def denied_requests():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id,
               domain,
               client_ip,
               reason,
               status,
               denied_at,
               deny_reason
        FROM requests
        WHERE status = 'Denied'
        ORDER BY denied_at DESC
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows

@app.get("/stats")
def stats():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute(
        "SELECT COUNT(*) FROM requests WHERE status = 'Pending'"
    )
    pending = cur.fetchone()[0]

    cur.execute(
        "SELECT COUNT(*) FROM requests WHERE status = 'Approved'"
    )
    approved = cur.fetchone()[0]

    cur.execute(
        "SELECT COUNT(*) FROM requests WHERE status = 'Denied'"
    )
    denied = cur.fetchone()[0]

    cur.close()
    conn.close()

    return {
        "pending": pending,
        "approved": approved,
        "denied": denied
    }

@app.post("/reblock/{request_id}")
async def reblock(request_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT domain
        FROM requests
        WHERE id = %s
    """, (request_id,))

    row = cur.fetchone()

    if row is None:
        cur.close()
        conn.close()

        return {
            "success": False,
            "message": "Request not found"
        }

    domain = row[0]

    print("Domain:", domain)

    technitium_response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/blocked/add",
        params={
            "token": TECHNITIUM_TOKEN,
            "domain": domain
        }
    )

    print("Status Code:", technitium_response.status_code)
    print("Response:", technitium_response.text)

    if technitium_response.status_code != 200:

        cur.close()
        conn.close()

        return {
            "success": False,
            "message": "Technitium block failed"
        }

    cur.execute("""
        UPDATE requests
        SET status = 'Denied',
            denied_at = NOW(),
            deny_reason = 'Manual Re-Block'
        WHERE id = %s
    """, (request_id,))

    conn.commit()

    print("Broadcasting refresh from reblock")
    await manager.broadcast("refresh")

    cur.close()
    conn.close()

    return {
        "success": True,
        "request_id": request_id,
        "domain": domain
    }
    
@app.post("/allow/{request_id}")
async def allow_request(
    request_id: int,
    allow: AllowRequest
):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT domain
        FROM requests
        WHERE id = %s
    """, (request_id,))

    row = cur.fetchone()

    if row is None:
        cur.close()
        conn.close()

        return {
            "success": False,
            "message": "Request not found"
        }

    domain = row[0]
    

    technitium_response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/blocked/delete",
        params={
            "token": TECHNITIUM_TOKEN,
            "domain": domain
        }
    )

    if technitium_response.status_code != 200:

        cur.close()
        conn.close()

        return {
            "success": False
        }

    if allow.allow_type == "timed":
    
        cur.execute("""
            UPDATE requests
            SET status = 'Approved',
                approved_at = NOW(),
                allowed_until =
                    NOW() + (%s * INTERVAL '1 minute')
            WHERE id = %s
        """, (allow.duration, request_id))
    
    else:
    
        cur.execute("""
            UPDATE requests
            SET status = 'Approved',
                approved_at = NOW(),
                allowed_until = NULL
            WHERE id = %s
        """, (request_id,))


    conn.commit()

    await manager.broadcast("refresh")

    cur.close()
    conn.close()

    return {
        "success": True,
        "request_id": request_id,
        "domain": domain
    } 
    
async def process_expired_allows():

    print("Checking expired approvals...")

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id, domain
        FROM requests
        WHERE status = 'Approved'
        AND allowed_until IS NOT NULL
        AND allowed_until <= NOW()
    """)

    rows = cur.fetchall()

    for request_id, domain in rows:

        print("Auto Re-Blocking:", domain)

        technitium_response = requests.get(
            f"http://{TECHNITIUM_HOST}:5380/api/blocked/add",
            params={
                "token": TECHNITIUM_TOKEN,
                "domain": domain
            }
        )

        if technitium_response.status_code == 200:

            cur.execute("""
                UPDATE requests
                SET status = 'Denied',
                    denied_at = NOW(),
                    allowed_until = NULL,
                    deny_reason = 'Timer Expired'
                WHERE id = %s
            """, (request_id,))

            conn.commit()

            await manager.broadcast("refresh")

    cur.close()
    conn.close()
    
@app.get("/users")
def list_users():

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/admin/users/list",
        params={
            "token": TECHNITIUM_TOKEN
        }
    )

    return response.json()

class CreateUserRequest(BaseModel):
    display_name: str
    username: str
    password: str


@app.post("/users/create")
def create_user(user: CreateUserRequest):

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/admin/users/create",
        params={
            "token": TECHNITIUM_TOKEN,
            "displayName": user.display_name,
            "user": user.username,
            "pass": user.password
        }
    )

    return response.json()
    
class UpdateUserRequest(BaseModel):
    username: str
    display_name: str


@app.post("/users/update")
def update_user(user: UpdateUserRequest):

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/admin/users/set",
        params={
            "token": TECHNITIUM_TOKEN,
            "user": user.username,
            "displayName": user.display_name
        }
    )

    return response.json()
    
class UserStatusRequest(BaseModel):
    username: str


@app.post("/users/disable")
def disable_user(user: UserStatusRequest):

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/admin/users/set",
        params={
            "token": TECHNITIUM_TOKEN,
            "user": user.username,
            "disabled": "true"
        }
    )

    return response.json()


@app.post("/users/enable")
def enable_user(user: UserStatusRequest):

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/admin/users/set",
        params={
            "token": TECHNITIUM_TOKEN,
            "user": user.username,
            "disabled": "false"
        }
    )

    return response.json()

class DeleteUserRequest(BaseModel):
    username: str


@app.post("/users/delete")
def delete_user(user: DeleteUserRequest):

    if user.username.lower() in ["admin", "api"]:
        return {
            "status": "error",
            "message": "System users cannot be deleted"
        }

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/admin/users/delete",
        params={
            "token": TECHNITIUM_TOKEN,
            "user": user.username
        }
    )

    return response.json()
    
class ResetPasswordRequest(BaseModel):
    username: str
    password: str


@app.post("/users/reset-password")
def reset_password(user: ResetPasswordRequest):

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/admin/users/set",
        params={
            "token": TECHNITIUM_TOKEN,
            "user": user.username,
            "newPass": user.password
        }
    )

    return response.json()
    
class CreateGroupRequest(BaseModel):
    group_name: str
    description: str = ""

@app.post("/groups/create")
def create_group(group: CreateGroupRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        INSERT INTO groups
        (
            group_name,
            description
        )
        VALUES
        (
            %s,
            %s
        )
        RETURNING id
    """,
    (
        group.group_name,
        group.description
    ))
    group_id = cur.fetchone()[0]
    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True,
        "group_id": group_id
    }

@app.get("/groups")
def list_groups():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            id,
            group_name,
            description,
            created_at
        FROM groups
        ORDER BY group_name
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows
    
class UpdateGroupRequest(BaseModel):
    id: int
    group_name: str
    description: str
    
@app.post("/groups/update")
def update_group(group: UpdateGroupRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        UPDATE groups
        SET group_name = %s,
            description = %s
        WHERE id = %s
    """,
    (
        group.group_name,
        group.description,
        group.id
    ))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }

class DeleteGroupRequest(BaseModel):
    id: int

@app.post("/groups/delete")
def delete_group(group: DeleteGroupRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        DELETE
        FROM groups
        WHERE id = %s
    """, (group.id,))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }

@app.get("/permissions")
def get_permissions():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            id,
            permission_name,
            parent_id
        FROM permissions
        ORDER BY parent_id NULLS FIRST, id
    """)

    permissions = cur.fetchall()

    cur.close()
    conn.close()

    return permissions

@app.get("/groups/{group_id}/permissions")
def get_group_permissions(group_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT permission_id
        FROM group_permissions
        WHERE group_id = %s
    """, (group_id,))

    rows = cur.fetchall()
    
    cur.close()
    conn.close()
    
    return [row[0] for row in rows]

class GroupPermissionRequest(BaseModel):
    group_id: int
    permissions: list[int]
    
@app.post("/groups/permissions/save")
def save_group_permissions(
    request: GroupPermissionRequest
):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        DELETE
        FROM group_permissions
        WHERE group_id = %s
    """,
    (
        request.group_id,
    ))

    for permission_id in request.permissions:

        cur.execute("""
            INSERT INTO group_permissions
            (
                group_id,
                permission_id
            )
            VALUES
            (
                %s,
                %s
            )
        """,
        (
            request.group_id,
            permission_id
        ))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }
  
@app.get("/permissions/tree")
def get_permissions_tree():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            id,
            permission_name,
            parent_id
        FROM permissions
        ORDER BY id
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    permissions = {}

    for row in rows:

        permission_id = row[0]
        permission_name = row[1]
        parent_id = row[2]

        permissions[permission_id] = {
            "id": permission_id,
            "name": permission_name,
            "children": []
        }

    tree = []

    for row in rows:

        permission_id = row[0]
        parent_id = row[2]

        if parent_id is None:

            tree.append(
                permissions[permission_id]
            )

        else:

            permissions[parent_id][
                "children"
            ].append(
                permissions[permission_id]
            )

    return tree
    
@app.get("/users/{username}/group")
def get_user_group(username: str):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT group_id
        FROM user_groups
        WHERE username = %s
    """, (username,))

    row = cur.fetchone()

    cur.close()
    conn.close()

    if row:
        return {
            "group_id": row[0]
        }

    return {
        "group_id": None
    }

class UserGroupRequest(BaseModel):
    username: str
    group_id: int
    
@app.get("/users/groups")
def get_user_groups():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            ug.username,
            g.group_name
        FROM user_groups ug
        JOIN groups g
            ON ug.group_id = g.id
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return {
        row[0]: row[1]
        for row in rows
    }


@app.post("/users/group/save")
def save_user_group(request: UserGroupRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        INSERT INTO user_groups
        (
            username,
            group_id
        )
        VALUES
        (
            %s,
            %s
        )
        ON CONFLICT (username)
        DO UPDATE
        SET group_id = EXCLUDED.group_id
    """,
    (
        request.username,
        request.group_id
    ))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }


@app.on_event("startup")
async def startup_scheduler():

    async def run():

        while True:

            await process_expired_allows()

            await asyncio.sleep(15)

    asyncio.create_task(run())
    
@app.get("/users/{username}/permissions")
def get_user_permissions(username: str):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            p.permission_name
        FROM user_groups ug
        JOIN group_permissions gp
            ON ug.group_id = gp.group_id
        JOIN permissions p
            ON gp.permission_id = p.id
        WHERE ug.username = %s
        ORDER BY p.permission_name
    """,
    (
        username,
    ))

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return [
        row[0]
        for row in rows
    ]
    
class UserProfileCreate(BaseModel):
    username: str
    display_name: str
    surname: str | None = None
    email_address: str | None = None
    country_code: str | None = None
    mobile_number: str | None = None
    department: str | None = None
    photo: str | None = None
    group_id: int | None = None
    
@app.post("/user-profiles/create")
def create_user_profile(profile: UserProfileCreate):

    print("PROFILE CREATE HIT")
    print(profile)

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )
    cur = conn.cursor()

    cur.execute(
        """
        INSERT INTO user_profiles
        (
            username,
            display_name,
            surname,
            email_address,
            country_code,
            mobile_number,
            department,
            photo,
            group_id
        )
        VALUES
        (%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """,
        (
            profile.username,
            profile.display_name,
            profile.surname,
            profile.email_address,
            profile.country_code,
            profile.mobile_number,
            profile.department,
            profile.photo,
            profile.group_id
        )
    )

    conn.commit()

    cur.close()
    conn.close()

    return {"success": True}
    
@app.get("/user-profiles")
def get_user_profiles():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            username,
            display_name,
            surname,
            department,
            email_address,
            country_code,
            mobile_number,
            photo,
            group_id
        FROM user_profiles
    """)

    rows = cur.fetchall()

    profiles = []

    for row in rows:
        profiles.append({
            "username": row[0],
            "display_name": row[1],
            "surname": row[2],
            "department": row[3],
            "email_address": row[4],
            "country_code": row[5],
            "mobile_number": row[6],
            "photo": row[7],
            "group_id": row[8]
        })

    cur.close()
    conn.close()

    return profiles
    
class DeleteUserProfileRequest(BaseModel):
    username: str


@app.post("/user-profiles/delete")
def delete_user_profile(user: DeleteUserProfileRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    # Remove profile
    cur.execute("""
        DELETE
        FROM user_profiles
        WHERE username = %s
    """, (user.username,))

    # Remove group assignment
    cur.execute("""
        DELETE
        FROM user_groups
        WHERE username = %s
    """, (user.username,))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }
    
@app.get("/user-profiles/{username}")
def get_user_profile(username: str):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            username,
            display_name,
            surname,
            department,
            email_address,
            country_code,
            mobile_number,
            photo,
            group_id
        FROM user_profiles
        WHERE username = %s
    """, (username,))

    row = cur.fetchone()

    cur.close()
    conn.close()

    if not row:
        return {}

    return {
        "username": row[0],
        "display_name": row[1],
        "surname": row[2],
        "department": row[3],
        "email_address": row[4],
        "country_code": row[5],
        "mobile_number": row[6],
        "photo": row[7],
        "group_id": row[8]
    }
    
class UserProfileUpdate(BaseModel):
    username: str
    display_name: str
    surname: str | None = None
    department: str | None = None
    email_address: str | None = None
    country_code: str | None = None
    mobile_number: str | None = None
    group_id: int | None = None


@app.post("/user-profiles/update")
def update_user_profile(profile: UserProfileUpdate):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        UPDATE user_profiles
        SET
            display_name = %s,
            surname = %s,
            department = %s,
            email_address = %s,
            country_code = %s,
            mobile_number = %s,
            group_id = %s
        WHERE username = %s
    """,
    (
        profile.display_name,
        profile.surname,
        profile.department,
        profile.email_address,
        profile.country_code,
        profile.mobile_number,
        profile.group_id,
        profile.username
    ))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }

class HttpsPortRequest(BaseModel):
    https_port: int

@app.post("/ssl/portal/save")
def save_https_port(
    request: HttpsPortRequest
):

    port = request.https_port

    if port < 1 or port > 65535:
        return {
            "success": False,
            "message": "Invalid port"
        }

    command = f"""
    /usr/bin/sed -i 's/listen [0-9]\\+ ssl;/listen {port} ssl;/' /etc/nginx/sites-available/default &&
    /usr/bin/sed -i 's/listen \\[::\\]:[0-9]\\+ ssl;/listen [::]:{port} ssl;/' /etc/nginx/sites-available/default &&
    /usr/sbin/nginx -t
    """

    result = subprocess.run(
        command,
        shell=True,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        return {
            "success": False,
            "message": result.stderr
        }

    reload_result = subprocess.run(
        [
            "/usr/bin/systemctl",
            "reload",
            "nginx"
        ],
        capture_output=True,
        text=True
    )

    if reload_result.returncode != 0:
        return {
            "success": False,
            "message": reload_result.stderr
        }

    return {
        "success": True,
        "https_port": port
    }

@app.get("/ssl/portal")
def ssl_portal():

    output = subprocess.check_output(
        [
            "/usr/bin/openssl",
            "x509",
            "-in",
            "/etc/ssl/portal/server.crt",
            "-noout",
            "-issuer",
            "-enddate"
        ],
        text=True
    )

    issuer = "Unknown"
    expires = "Unknown"

    for line in output.splitlines():

        if line.startswith("issuer="):

            issuer_raw = line.replace(
                "issuer=",
                ""
            ).strip()

            issuer = issuer_raw

            for part in issuer_raw.split(","):

                part = part.strip()

                if part.startswith("OU="):
                    issuer = part.replace(
                        "OU=",
                        ""
                    )
                    break

        elif line.startswith("notAfter="):

            raw_date = line.replace(
                "notAfter=",
                ""
            )

            dt = datetime.strptime(
                raw_date,
                "%b %d %H:%M:%S %Y %Z"
            )

            expires = dt.strftime(
                "%d %B %Y"
            )

    https_enabled = False
    https_port = 443

    https_result = subprocess.run(
        [
            "/usr/sbin/nginx",
            "-T"
        ],
        capture_output=True,
        text=True
    )

    if https_result.returncode == 0:

        for line in https_result.stdout.splitlines():

            line = line.strip()

            if (
                line.startswith("listen ")
                and "ssl" in line
                and "[::]" not in line
            ):

                parts = line.split()

                if len(parts) >= 2:

                    try:
                        https_port = int(parts[1])
                    except:
                        pass

                https_enabled = True
                break

    return {
        "status": "Configured",
        "issuer": issuer,
        "expires": expires,
        "https_enabled": https_enabled,
        "https_port": https_port
    }
    
@app.post("/ssl/portal/upload")
async def upload_portal_certificate(
    certificate: UploadFile = File(...),
    private_key: UploadFile = File(...)
):

    if certificate.filename != "server.crt":
        return {
            "success": False,
            "message": "Certificate file must be named server.crt"
        }

    if private_key.filename != "server.key":
        return {
            "success": False,
            "message": "Private key file must be named server.key"
        }
        
    # Backup SSL First
    
    if os.path.exists("/etc/ssl/portal/server.crt"):
        shutil.copy(
            "/etc/ssl/portal/server.crt",
            "/etc/ssl/portal/server.crt.bak"
    )

    if os.path.exists("/etc/ssl/portal/server.key"):
        shutil.copy(
            "/etc/ssl/portal/server.key",
            "/etc/ssl/portal/server.key.bak"
    )

    with open(
        "/etc/ssl/portal/server.crt",
        "wb"
    ) as crt:

        shutil.copyfileobj(
            certificate.file,
            crt
        )

    with open(
        "/etc/ssl/portal/server.key",
        "wb"
    ) as key:

        shutil.copyfileobj(
            private_key.file,
            key
        )

    test = subprocess.run(
        [
            "/usr/sbin/nginx",
            "-t"
        ],
        capture_output=True,
        text=True
    )

    if test.returncode != 0:

        return {
            "success": False,
            "message": test.stderr
        }

    subprocess.run(
        [
            "/usr/bin/systemctl",
            "reload",
            "nginx"
        ]
    )

    return {
        "success": True
    }

@app.post("/ssl/dns/upload")
async def upload_dns_certificate(
    certificate: UploadFile = File(...),
    private_key: UploadFile = File(...)
):

    if certificate.filename != "server.crt":
        return {
            "success": False,
            "message": "Certificate file must be named server.crt"
        }

    if private_key.filename != "server.key":
        return {
            "success": False,
            "message": "Private key file must be named server.key"
        }

    if os.path.exists("/etc/ssl/dns/server.pfx"):
        shutil.copy(
            "/etc/ssl/dns/server.pfx",
            "/etc/ssl/dns/server.pfx.bak"
        )


    with open(
        "/etc/ssl/dns/server.crt",
        "wb"
    ) as crt:

        shutil.copyfileobj(
            certificate.file,
            crt
        )

    with open(
        "/etc/ssl/dns/server.key",
        "wb"
    ) as key:

        shutil.copyfileobj(
            private_key.file,
            key
        )
        
    convert = subprocess.run(
        [
            "/usr/bin/openssl",
            "pkcs12",
            "-export",
            "-out",
            "/etc/ssl/dns/server.pfx",
            "-inkey",
            "/etc/ssl/dns/server.key",
            "-in",
            "/etc/ssl/dns/server.crt",
            "-password",
            f"pass:{TECHNITIUM_SSL_PASSWORD}"
        ],
        capture_output=True,
        text=True
    )

    if convert.returncode != 0:

        return {
            "success": False,
            "message": convert.stderr
        }
    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/settings/set",
        params={
            "token": TECHNITIUM_TOKEN,
    
            "webServiceEnableTls": "true",
    
            "webServiceUseSelfSignedTlsCertificate": "false",
    
            "webServiceTlsCertificatePath":
                "/etc/ssl/dns/server.pfx",
    
            "webServiceTlsCertificatePassword":
                TECHNITIUM_SSL_PASSWORD
        }
    )
    
    if response.status_code != 200:
    
        return {
            "success": False,
            "message": response.text
        }
    
    subprocess.run(
        [
            "/usr/bin/systemctl",
            "restart",
            "dns"
        ]
    )
    
    return {
        "success": True
    }


   
@app.get("/ssl/dns")
def dns_certificate():

    output = subprocess.check_output(
        [
            "/usr/bin/openssl",
            "x509",
            "-in",
            "/etc/ssl/dns/server.crt",
            "-noout",
            "-issuer",
            "-enddate"
        ],
        text=True
    )

    issuer = "Unknown"
    expires = "Unknown"

    for line in output.splitlines():

        if line.startswith("issuer="):

            issuer_raw = line.replace(
                "issuer=",
                ""
            ).strip()

            issuer = issuer_raw

            for part in issuer_raw.split(","):

                part = part.strip()

                if part.startswith("OU="):

                    issuer = part.replace(
                        "OU=",
                        ""

                    )
                    break

        elif line.startswith("notAfter="):

            raw_date = line.replace(
                "notAfter=",
                ""
            )

            dt = datetime.strptime(
                raw_date,
                "%b %d %H:%M:%S %Y %Z"
            )

            expires = dt.strftime(
                "%d %B %Y"
            )

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/settings/get",
        params={
            "token": TECHNITIUM_TOKEN
        }
    )

    data = response.json()

    https_enabled = data["response"].get(
        "webServiceEnableTls",
        False
    )

    https_port = data["response"].get(
        "webServiceTlsPort",
        53443
    )

    return {
        "status": "Configured",
        "issuer": issuer,
        "expires": expires,
        "https_enabled": https_enabled,
        "https_port": https_port
    }
    
class DnsHttpsPortRequest(BaseModel):
    https_port: int
    
@app.post("/ssl/dns/save")
def save_dns_https_port(
    request: DnsHttpsPortRequest
):

    port = request.https_port

    if port < 1 or port > 65535:
        return {
            "success": False,
            "message": "Invalid port"
        }

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/settings/set",
        params={
            "token": TECHNITIUM_TOKEN,

            "webServiceEnableTls": "true",

            "webServiceTlsPort": port,

            "webServiceUseSelfSignedTlsCertificate": "false",

            "webServiceTlsCertificatePath":
                "/etc/ssl/dns/server.pfx",

            "webServiceTlsCertificatePassword":
                TECHNITIUM_SSL_PASSWORD
        }
    )

    if response.status_code != 200:
        return {
            "success": False,
            "message": response.text
        }

    subprocess.run(
        [
            "/usr/bin/systemctl",
            "restart",
            "dns"
        ]
    )

    return {
        "success": True,
        "https_port": port
    }
    
class DnsHttpsStatusRequest(BaseModel):
    enabled: bool
    
    
@app.post("/ssl/dns/https")
def dns_https_status(
    request: DnsHttpsStatusRequest
):

    current = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/settings/get",
        params={
            "token": TECHNITIUM_TOKEN
        }
    ).json()
    
    tls_port = current["response"].get(
        "webServiceTlsPort",
        53443
    )
    
    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/settings/set",
        params={
            "token": TECHNITIUM_TOKEN,
    
            "webServiceEnableTls":
                str(request.enabled).lower(),
    
            "webServiceTlsPort": tls_port,
    
            "webServiceUseSelfSignedTlsCertificate":
                "false",
    
            "webServiceTlsCertificatePath":
                "/etc/ssl/dns/server.pfx",
    
            "webServiceTlsCertificatePassword":
                TECHNITIUM_SSL_PASSWORD
        }
    )
    
    try:
    
        data = response.json()
    
    except Exception:
    
        return {
            "success": False,
            "message": "Invalid response from Technitium"
        }
    
    if data.get("status") != "ok":
    
        return {
            "success": False,
            "message": data.get(
                "errorMessage",
                "Technitium returned an error"
            )
        }
    
    return {
        "success": True
    }