import subprocess
import asyncio
import psycopg2
import requests
import time
import bcrypt
import secrets
import base64
import io
import pyotp
import qrcode
from config import *
from providers import get_provider

TECHNITIUM_HEADERS = {"Authorization": f"Bearer {TECHNITIUM_TOKEN}"}

# Service accounts that live on Technitium only: they never
# appear in the portal user list, can never sign in to the
# portal, and can not be created or deleted from the portal.
PORTAL_SYSTEM_USERS = {"api", "portal-api"}
RESERVED_USERNAMES = {"admin"} | PORTAL_SYSTEM_USERS
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, WebSocket, HTTPException
from datetime import datetime, date
from fastapi import UploadFile, File
import shutil
import os
import re

app = FastAPI()

def monitoring_db():

    return psycopg2.connect(
        host=MONITORING_POSTGRES_HOST,
        database=MONITORING_POSTGRES_DB,
        user=MONITORING_POSTGRES_USER,
        password=MONITORING_POSTGRES_PASSWORD
    )


# WebSocket Connection Manager
class ConnectionManager:

    def __init__(self):
        self.connections = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.connections.remove(websocket)

    async def broadcast(self, message: str):
        for connection in self.connections:
            await connection.send_text(message)


manager = ConnectionManager()

class LoginRequest(BaseModel):
    username: str
    password: str


# ============================================================
# UPDATE - Portal-owned authentication (portal_auth table)
#
# The portal is now the source of truth for user credentials.
# Technitium accounts are kept in sync as shadow accounts so
# the DNS admin console keeps working with the same logins.
# Existing users migrate transparently: on their first login
# the portal verifies via Technitium one last time and then
# stores a local bcrypt hash (migrated_from_technitium).
# ============================================================

def portal_auth_connect():
    return psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )


def hash_portal_password(password: str) -> str:
    return bcrypt.hashpw(
        password.encode("utf-8"),
        bcrypt.gensalt(rounds=12)
    ).decode("utf-8")


def get_portal_auth_row(username: str):
    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT username, password_hash, is_disabled
            FROM portal_auth
            WHERE LOWER(username) = LOWER(%s)
            LIMIT 1
        """, (username,))
        return cur.fetchone()
    finally:
        cur.close()
        conn.close()


def store_portal_auth(
    username: str,
    password: str,
    disabled: bool = False,
    migrated: bool = False
):
    pw_hash = hash_portal_password(password)
    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            INSERT INTO portal_auth
                (username, password_hash, is_disabled,
                 migrated_from_technitium)
            VALUES (%s, %s, %s, %s)
        """, (username, pw_hash, disabled, migrated))
        conn.commit()
    finally:
        cur.close()
        conn.close()


def update_portal_auth(
    username: str,
    password: str
):
    pw_hash = hash_portal_password(password)
    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            UPDATE portal_auth
            SET password_hash = %s,
                updated_at = now()
            WHERE LOWER(username) = LOWER(%s)
        """, (pw_hash, username))
        return cur.rowcount > 0
    finally:
        conn.commit()
        cur.close()
        conn.close()


def set_portal_auth_disabled(username: str, disabled: bool):
    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            UPDATE portal_auth
            SET is_disabled = %s,
                updated_at = now()
            WHERE LOWER(username) = LOWER(%s)
        """, (disabled, username))
        return cur.rowcount > 0
    finally:
        conn.commit()
        cur.close()
        conn.close()


def delete_portal_auth(username: str):
    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            DELETE FROM portal_auth
            WHERE LOWER(username) = LOWER(%s)
        """, (username,))
        return cur.rowcount > 0
    finally:
        conn.commit()
        cur.close()
        conn.close()


def portal_auth_exists(username: str) -> bool:
    return get_portal_auth_row(username) is not None


def portal_display_name(username: str) -> str:
    try:
        conn = portal_auth_connect()
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT display_name
                FROM user_profiles
                WHERE LOWER(username) = LOWER(%s)
                LIMIT 1
            """, (username,))
            row = cur.fetchone()
            return (row[0] if row and row[0] else username)
        finally:
            cur.close()
            conn.close()
    except Exception:
        return username


# ============================================================
# UPDATE - Portal-owned two-factor authentication (TOTP)
#
# RFC 6238, 30-second windows, 6 digits. Secrets live in the
# portal_auth table (totp_secret / totp_pending_secret) and
# verified codes are replay-protected via totp_last_timestep.
# The login flow gains a two-step challenge: when a user has
# 2FA enabled, /login answers with a one-time nonce and the
# /login/2fa endpoint completes the sign-in with the code.
# ============================================================

TWO_FA_CHALLENGES = {}
TWO_FA_CHALLENGE_TTL = 300


def twofa_state(username: str):
    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT totp_enabled, totp_secret,
                   totp_pending_secret, totp_last_timestep
            FROM portal_auth
            WHERE LOWER(username) = LOWER(%s)
            LIMIT 1
        """, (username,))
        return cur.fetchone()
    finally:
        cur.close()
        conn.close()


def twofa_enabled(username: str) -> bool:
    row = twofa_state(username)
    return bool(row and row[0] and row[1])


def verify_totp_code(
    secret: str,
    code: str,
    last_timestep
):
    """
    Verify a 6-digit TOTP code against the current and
    neighbouring 30-second windows. A code from a window
    that was already accepted is rejected (replay guard).
    Returns (ok, matched_timestep).
    """
    code = str(code).strip()
    if not code.isdigit() or len(code) != 6:
        return False, None

    totp = pyotp.TOTP(secret)

    # pyotp.at() takes a UNIX TIMESTAMP (it divides by the
    # interval itself); totp_last_timestep stores the
    # 30-second STEP number for the replay guard.

    now_ts = int(time.time())
    previous = last_timestep if last_timestep is not None else -1

    for offset in (0, -1, 1):

        candidate_ts = now_ts + (offset * 30)
        step = candidate_ts // 30

        if step <= previous:
            continue

        if secrets.compare_digest(totp.at(candidate_ts), code):
            return True, step

    return False, None


def store_totp_timestep(username: str, step):
    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            UPDATE portal_auth
            SET totp_last_timestep = %s,
                updated_at = now()
            WHERE LOWER(username) = LOWER(%s)
        """, (step, username))
        conn.commit()
    finally:
        cur.close()
        conn.close()


def prune_twofa_challenges():
    now = time.time()
    expired = [
        nonce for nonce, entry in TWO_FA_CHALLENGES.items()
        if entry["expires"] < now
    ]
    for nonce in expired:
        TWO_FA_CHALLENGES.pop(nonce, None)


def issue_twofa_challenge(username: str) -> str:
    prune_twofa_challenges()
    nonce = secrets.token_urlsafe(24)
    TWO_FA_CHALLENGES[nonce] = {
        "username": username,
        "expires": time.time() + TWO_FA_CHALLENGE_TTL
    }
    return nonce


def twofa_qr_data_url(otpauth_uri: str) -> str:
    image = qrcode.make(otpauth_uri)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return (
        "data:image/png;base64,"
        + base64.b64encode(buffer.getvalue()).decode("utf-8")
    )


class TwoFaSetupRequest(BaseModel):
    username: str


class TwoFaCodeRequest(BaseModel):
    username: str
    code: str


@app.post("/2fa/setup")
def twofa_setup(request: TwoFaSetupRequest):

    """Generate a pending TOTP secret + QR for enrollment."""

    row = twofa_state(request.username)
    if row is None:
        return {
            "status": "error",
            "message": "User not found"
        }

    if row[0]:
        return {
            "status": "error",
            "message": "Two-factor authentication is already enabled"
        }

    secret = pyotp.random_base32()

    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            UPDATE portal_auth
            SET totp_pending_secret = %s,
                updated_at = now()
            WHERE LOWER(username) = LOWER(%s)
        """, (secret, request.username))
        conn.commit()
    finally:
        cur.close()
        conn.close()

    totp = pyotp.TOTP(secret)
    otpauth_uri = totp.provisioning_uri(
        name=request.username,
        issuer_name="Portal"
    )

    return {
        "status": "ok",
        "secret": secret,
        "otpauth_url": otpauth_uri,
        "qr_png": twofa_qr_data_url(otpauth_uri)
    }


@app.post("/2fa/enable")
def twofa_enable(request: TwoFaCodeRequest):

    """Confirm a pending enrollment with a live code."""

    row = twofa_state(request.username)
    if row is None:
        return {
            "status": "error",
            "message": "User not found"
        }

    if row[0]:
        return {
            "status": "error",
            "message": "Two-factor authentication is already enabled"
        }

    pending_secret = row[2]
    if not pending_secret:
        return {
            "status": "error",
            "message": "Start the setup first"
        }

    ok, step = verify_totp_code(pending_secret, request.code, None)
    if not ok:
        return {
            "status": "error",
            "message": "Invalid verification code"
        }

    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            UPDATE portal_auth
            SET totp_secret = %s,
                totp_enabled = TRUE,
                totp_pending_secret = NULL,
                totp_last_timestep = %s,
                updated_at = now()
            WHERE LOWER(username) = LOWER(%s)
        """, (pending_secret, step, request.username))
        conn.commit()
    finally:
        cur.close()
        conn.close()

    return {"status": "ok"}


@app.post("/2fa/disable")
def twofa_disable(request: TwoFaCodeRequest):

    """Turn 2FA off; requires a live code from the app."""

    row = twofa_state(request.username)
    if row is None:
        return {
            "status": "error",
            "message": "User not found"
        }

    if not (row[0] and row[1]):
        return {
            "status": "error",
            "message": "Two-factor authentication is not enabled"
        }

    ok, _step = verify_totp_code(row[1], request.code, None)
    if not ok:
        return {
            "status": "error",
            "message": "Invalid verification code"
        }

    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            UPDATE portal_auth
            SET totp_secret = NULL,
                totp_enabled = FALSE,
                totp_pending_secret = NULL,
                totp_last_timestep = NULL,
                updated_at = now()
            WHERE LOWER(username) = LOWER(%s)
        """, (request.username,))
        conn.commit()
    finally:
        cur.close()
        conn.close()

    return {"status": "ok"}


@app.post("/2fa/reset")
def twofa_reset(request: TwoFaSetupRequest):

    """Admin recovery: clear 2FA for a locked-out user."""

    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            UPDATE portal_auth
            SET totp_secret = NULL,
                totp_enabled = FALSE,
                totp_pending_secret = NULL,
                totp_last_timestep = NULL,
                updated_at = now()
            WHERE LOWER(username) = LOWER(%s)
        """, (request.username,))
        conn.commit()
    finally:
        cur.close()
        conn.close()

    return {"status": "ok"}


@app.get("/2fa/status/{username}")
def twofa_status(username: str):
    row = twofa_state(username)
    if row is None:
        return {
            "status": "error",
            "message": "User not found"
        }
    return {
        "status": "ok",
        "enabled": bool(row[0] and row[1]),
        "pending": bool(row[2])
    }


@app.post("/login")
def login(login: LoginRequest):

    if login.username.strip().lower() in PORTAL_SYSTEM_USERS:
        return {
            "status": "error",
            "message": "Service accounts can not sign in to the portal"
        }

    auth_row = get_portal_auth_row(login.username)

    if auth_row is not None:

        # Portal-owned credential - the local store decides.
        if auth_row[2]:
            return {
                "status": "error",
                "message": "Account is disabled"
            }

        try:
            matches = bcrypt.checkpw(
                login.password.encode("utf-8"),
                auth_row[1].encode("utf-8")
            )
        except ValueError:
            matches = False

        if matches:

            if twofa_enabled(login.username):
                return {
                    "status": "2fa_required",
                    "nonce": issue_twofa_challenge(login.username)
                }

            return {
                "status": "ok",
                "username": login.username,
                "displayName": portal_display_name(login.username),
                "token": secrets.token_urlsafe(32)
            }

        return {
            "status": "error",
            "message": "Invalid username or password"
        }

    # No local credential yet (pre-migration user): verify via
    # Technitium one last time, then migrate transparently so
    # this user logs in locally from now on.
    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/user/login",
        params={
            "user": login.username,
            "pass": login.password
        }
    )

    try:
        result = response.json()
    except ValueError:
        result = {"status": "error"}

    if (
        isinstance(result, dict)
        and result.get("status") == "ok"
    ):
        try:
            store_portal_auth(
                login.username,
                login.password,
                migrated=True
            )
        except Exception:
            pass

        if twofa_enabled(login.username):
            return {
                "status": "2fa_required",
                "nonce": issue_twofa_challenge(login.username)
            }

        return {
            "status": "ok",
            "username": login.username,
            "displayName": (
                result.get("displayName")
                or portal_display_name(login.username)
            ),
            "token": secrets.token_urlsafe(32)
        }

    return {
        "status": "error",
        "message": "Invalid username or password"
    }


class TwoFaLoginRequest(BaseModel):
    nonce: str
    code: str


@app.post("/login/2fa")
def login_twofa(request: TwoFaLoginRequest):

    """Complete a sign-in that answered 2fa_required."""

    prune_twofa_challenges()

    entry = TWO_FA_CHALLENGES.get(request.nonce)

    if entry is None:
        return {
            "status": "error",
            "message": "Verification session expired. Please sign in again."
        }

    username = entry["username"]

    ok, step = False, None
    state = twofa_state(username)

    if state and state[0] and state[1]:
        ok, step = verify_totp_code(
            state[1],
            request.code,
            state[3]
        )

    if not ok:
        return {
            "status": "error",
            "message": "Invalid verification code"
        }

    # Single-use challenge + replay guard
    TWO_FA_CHALLENGES.pop(request.nonce, None)
    store_totp_timestep(username, step)

    auth_row = get_portal_auth_row(username)
    if auth_row is not None and auth_row[2]:
        return {
            "status": "error",
            "message": "Account is disabled"
        }

    return {
        "status": "ok",
        "username": username,
        "displayName": portal_display_name(username),
        "token": secrets.token_urlsafe(32)
    }


APPLIANCE_SETUP_CREDENTIALS = "/var/lib/portal/appliance-setup-credentials"
APPLIANCE_MIN_PASSWORD = 12


@app.get("/initial-setup-info")
def initial_setup_info():
    """The setup page asks what shape the initial setup takes: on
    the NetFortress deployment the administrator account covers both
    the Portal and the local appliance."""
    installed_at = "/var/lib/portal/installed-at"
    setup_complete = "/var/lib/portal/initial-setup-complete"
    provider_name = get_provider().name
    return {
        "required": os.path.isfile(installed_at) and not os.path.isfile(setup_complete),
        "provider": provider_name,
        "min_password_length": APPLIANCE_MIN_PASSWORD if provider_name == "firewall" else 6,
    }


def _switch_provider_token(new_token: str) -> None:
    """Persist the appliance provider token in config.py and apply it to
    the running process. The provider module binds the token at import
    time, so both the config module and the provider module are updated
    in place."""
    import config as portal_config
    import providers.firewall as firewall_provider_module

    config_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.py")
    with open(config_file, "r", encoding="utf-8") as handle:
        text = handle.read()
    if not re.search(r"(?m)^FIREWALL_API_TOKEN\s*=\s*['\"].*['\"]$", text):
        raise RuntimeError("FIREWALL_API_TOKEN not found in config.py")
    updated = re.sub(
        r"(?m)^FIREWALL_API_TOKEN\s*=\s*['\"].*['\"]$",
        "FIREWALL_API_TOKEN = '%s'" % new_token,
        text,
    )
    temp_file = config_file + ".tmp"
    with open(temp_file, "w", encoding="utf-8") as handle:
        handle.write(updated)
    os.replace(temp_file, config_file)

    portal_config.FIREWALL_API_TOKEN = new_token
    firewall_provider_module.FIREWALL_API_TOKEN = new_token


def _initial_setup_firewall(setup) -> dict:
    """Deployment option 2 (NetFortress): the setup page configures
    one administrator account for BOTH the Portal and the local
    Firewall Appliance. The installer provisioned a temporary
    appliance setup account (credentials in a root-only file); it is
    used to create or configure the real administrator, then
    removed."""
    username = (getattr(setup, "username", "") or "admin").strip()
    new_password = setup.new_password or ""

    if not username:
        return {"status": "error", "message": "Administrator username is required"}

    if len(new_password) < APPLIANCE_MIN_PASSWORD:
        return {
            "status": "error",
            "message": f"Password must be at least {APPLIANCE_MIN_PASSWORD} characters",
        }

    if new_password == (setup.current_password or ""):
        return {"status": "error", "message": "New password must be different"}

    # -- appliance side -------------------------------------------------
    try:
        with open(APPLIANCE_SETUP_CREDENTIALS, "r", encoding="utf-8") as handle:
            parts = handle.read().strip().split(":", 1)
        if len(parts) != 2:
            raise ValueError("malformed setup credentials")
        setup_user, setup_pass = parts

        login = requests.post(
            f"{FIREWALL_API_URL}/api/v1/auth/login",
            json={"username": setup_user, "password": setup_pass},
            timeout=10,
        )
        if login.status_code != 200:
            return {
                "status": "error",
                "message": (
                    "The temporary appliance setup account could not "
                    "authenticate. Re-run the Portal installer and try again."
                ),
            }
        session_headers = {
            "Authorization": "Bearer " + (login.json().get("access_token") or "")
        }

        existing_user = None
        setup_account = None

        users = requests.get(
            f"{FIREWALL_API_URL}/api/v1/users",
            headers=session_headers,
            timeout=10,
        )
        if users.status_code == 200:
            for user in users.json():
                if user.get("username") == username:
                    existing_user = user
                elif user.get("username") == setup_user:
                    setup_account = user

        if existing_user is not None:
            change = requests.put(
                f"{FIREWALL_API_URL}/api/v1/users/{existing_user['id']}/password",
                headers=session_headers,
                json={"new_password": new_password},
                timeout=10,
            )
            if change.status_code != 200:
                return {
                    "status": "error",
                    "message": "The appliance administrator password could not be set.",
                }
        else:
            create = requests.post(
                f"{FIREWALL_API_URL}/api/v1/users",
                headers=session_headers,
                json={
                    "username": username,
                    "password": new_password,
                    "role": "admin",
                },
                timeout=10,
            )
            if create.status_code != 201:
                return {
                    "status": "error",
                    "message": "The appliance administrator account could not be created.",
                }

        # -- provider token re-mint -------------------------------------
        # The installer minted the portal provider token under the
        # temporary setup account, and the appliance refuses API tokens
        # that belong to disabled users. Re-create the token under the
        # real administrator before the setup account is disabled, and
        # switch the running provider to it.
        admin_login = requests.post(
            f"{FIREWALL_API_URL}/api/v1/auth/login",
            json={"username": username, "password": new_password},
            timeout=10,
        )
        if admin_login.status_code != 200:
            return {
                "status": "error",
                "message": "The appliance administrator account could not be verified.",
            }
        admin_session = {
            "Authorization": "Bearer " + (admin_login.json().get("access_token") or "")
        }
        mint = requests.post(
            f"{FIREWALL_API_URL}/api/v1/auth/tokens",
            headers=admin_session,
            json={
                "name": "portal-provider",
                "scopes": ["dns:read", "dns:write", "users:read", "users:write"],
            },
            timeout=10,
        )
        if mint.status_code != 201:
            return {
                "status": "error",
                "message": "The Portal provider token could not be re-created on the appliance.",
            }
        _switch_provider_token(mint.json().get("token") or "")

        # The temporary setup account is no longer needed. Disabling is
        # best-effort: the appliance refuses to disable the last enabled
        # full-access account, in which case it simply remains.
        if setup_account is not None and username != setup_user:
            try:
                requests.put(
                    f"{FIREWALL_API_URL}/api/v1/users/{setup_account['id']}",
                    headers=session_headers,
                    json={
                        "role": setup_account.get("role") or "admin",
                        "enabled": False,
                    },
                    timeout=10,
                )
            except requests.RequestException:
                pass

        try:
            os.remove(APPLIANCE_SETUP_CREDENTIALS)
        except OSError:
            pass
    except FileNotFoundError:
        # No setup credentials: the appliance administrator was already
        # configured (for example by the installer on a rerun). Only the
        # Portal side needs to be set.
        pass
    except Exception:
        return {
            "status": "error",
            "message": (
                "The appliance configuration step failed. Re-run the "
                "Portal installer and try again."
            ),
        }

    # -- portal side ----------------------------------------------------
    password_hash = hash_portal_password(new_password)

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )
    cur = conn.cursor()
    try:
        cur.execute(
            "SELECT id FROM portal_auth WHERE username = %s",
            (username,)
        )
        row = cur.fetchone()

        if row:
            cur.execute(
                """
                UPDATE portal_auth
                SET password_hash = %s,
                    is_disabled = FALSE,
                    must_change_password = FALSE,
                    updated_at = NOW()
                WHERE username = %s
                """,
                (password_hash, username)
            )
        else:
            cur.execute(
                """
                INSERT INTO portal_auth
                    (username, password_hash, technitium_synced, migrated_from_technitium)
                VALUES (%s, %s, TRUE, FALSE)
                """,
                (username, password_hash)
            )
        conn.commit()
    finally:
        cur.close()
        conn.close()

    # -- completion marker ----------------------------------------------
    temp_marker = "/var/lib/portal/initial-setup-complete.tmp"
    with open(temp_marker, "w", encoding="utf-8") as marker_file:
        marker_file.write(
            datetime.now()
            .astimezone()
            .isoformat(timespec="seconds")
            + "\n"
        )
    os.chmod(temp_marker, 0o644)
    os.replace(temp_marker, "/var/lib/portal/initial-setup-complete")

    return {
        "status": "ok",
        "message": "Administrator configured for the Portal and the Firewall Appliance",
    }


class InitialSetupRequest(BaseModel):
    current_password: str
    new_password: str
    username: str = "admin"


def _initial_setup_unconfigured(setup) -> dict:
    """A clean portal (no network services backend provisioned yet):
    the setup page only creates the Portal administrator account.
    The backend is selected later in Settings -> System Status."""
    username = (getattr(setup, "username", "") or "admin").strip()
    new_password = setup.new_password or ""

    if not username:
        return {
            "status": "error",
            "message": "Administrator username is required",
        }

    if len(new_password) < 6:
        return {
            "status": "error",
            "message": "Password must be at least 6 characters",
        }

    if new_password == (setup.current_password or ""):
        return {"status": "error", "message": "New password must be different"}

    password_hash = hash_portal_password(new_password)

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )
    cur = conn.cursor()
    try:
        cur.execute(
            "SELECT id FROM portal_auth WHERE username = %s",
            (username,)
        )
        row = cur.fetchone()

        if row:
            cur.execute(
                """
                UPDATE portal_auth
                SET password_hash = %s,
                    is_disabled = FALSE,
                    must_change_password = FALSE,
                    updated_at = NOW()
                WHERE username = %s
                """,
                (password_hash, username)
            )
        else:
            cur.execute(
                """
                INSERT INTO portal_auth
                    (username, password_hash, technitium_synced, migrated_from_technitium)
                VALUES (%s, %s, TRUE, FALSE)
                """,
                (username, password_hash)
            )
        conn.commit()
    finally:
        cur.close()
        conn.close()

    temp_marker = "/var/lib/portal/initial-setup-complete.tmp"
    with open(temp_marker, "w", encoding="utf-8") as marker_file:
        marker_file.write(
            datetime.now()
            .astimezone()
            .isoformat(timespec="seconds")
            + "\n"
        )
    os.chmod(temp_marker, 0o644)
    os.replace(temp_marker, "/var/lib/portal/initial-setup-complete")

    return {
        "status": "ok",
        "message": "Administrator configured for the Portal",
    }


@app.post("/initial-setup")
def initial_setup(setup: InitialSetupRequest):

    installed_at = "/var/lib/portal/installed-at"
    setup_complete = "/var/lib/portal/initial-setup-complete"

    if not os.path.isfile(installed_at):
        return {
            "status": "error",
            "message": "Initial setup is not required"
        }

    if os.path.isfile(setup_complete):
        return {
            "status": "error",
            "message": "Initial setup has already been completed"
        }

    # Deployment option 2 (NetFortress appliance): one administrator
    # account for both the Portal and the local appliance. There is
    # no current-password step on this deployment - the account is
    # being created, not changed - so this branch must run before
    # the Technitium-era current-password gate below.
    if get_provider().name == "none":
        return _initial_setup_unconfigured(setup)

    if get_provider().name == "firewall":
        return _initial_setup_firewall(setup)

    if not setup.current_password:
        return {
            "status": "error",
            "message": "Current password is required"
        }

    if not setup.new_password:
        return {
            "status": "error",
            "message": "New password is required"
        }

    if setup.current_password == setup.new_password:
        return {
            "status": "error",
            "message": "New password must be different"
        }

    # Recovery path:
    # If Technitium has already returned to port 5380 but the setup
    # completion marker was not written, do not repeat the password
    # change. Prove both the Portal API token and the new administrator
    # password before completing setup.
    setup_port_available = False

    try:
        setup_port_check = requests.get(
            f"http://{TECHNITIUM_HOST}:65432/api/user/profile/get",
            headers=TECHNITIUM_HEADERS,
            timeout=3
        )

        setup_port_result = setup_port_check.json()

        setup_port_username = (
            setup_port_result
            .get("response", {})
            .get("username")
            or setup_port_result
            .get("response", {})
            .get("user")
        )

        if (
            setup_port_result.get("status") == "ok"
            and setup_port_username == "portal-api"
        ):
            setup_port_available = True

    except (requests.RequestException, ValueError):
        pass

    if not setup_port_available:
        normal_port_valid = False

        try:
            normal_port_check = requests.get(
                f"http://{TECHNITIUM_HOST}:5380/api/user/profile/get",
                headers=TECHNITIUM_HEADERS,
                timeout=3
            )

            normal_port_result = normal_port_check.json()

            normal_port_username = (
                normal_port_result
                .get("response", {})
                .get("username")
                or normal_port_result
                .get("response", {})
                .get("user")
            )

            if (
                normal_port_result.get("status") == "ok"
                and normal_port_username == "portal-api"
            ):
                normal_port_valid = True

        except (requests.RequestException, ValueError):
            pass

        if normal_port_valid:
            try:
                recovery_login = requests.get(
                    f"http://{TECHNITIUM_HOST}:5380/api/user/login",
                    params={
                        "user": "admin",
                        "pass": setup.new_password
                    },
                    timeout=10
                )

                recovery_result = recovery_login.json()

            except (requests.RequestException, ValueError):
                return {
                    "status": "error",
                    "message": (
                        "Technitium is restored to port 5380, but "
                        "administrator password verification failed"
                    )
                }

            if recovery_result.get("status") != "ok":
                return {
                    "status": "error",
                    "message": (
                        "Technitium is restored to port 5380. "
                        "Enter the new administrator password that "
                        "was set during the previous setup attempt"
                    )
                }

            try:
                temp_marker = setup_complete + ".tmp"

                with open(temp_marker, "w", encoding="utf-8") as marker_file:
                    marker_file.write(
                        datetime.now()
                        .astimezone()
                        .isoformat(timespec="seconds")
                        + "\n"
                    )

                os.chmod(temp_marker, 0o644)
                os.replace(temp_marker, setup_complete)

            except Exception:
                return {
                    "status": "error",
                    "message": (
                        "Administrator password verified, but the Portal "
                        "could not record setup completion"
                    )
                }

            return {
                "status": "ok",
                "message": "Initial administrator setup completed"
            }

        return {
            "status": "error",
            "message": (
                "Technitium initial setup service is unavailable"
            )
        }

    # Verify the existing administrator password first.
    try:
        verify_current = requests.get(
            f"http://{TECHNITIUM_HOST}:65432/api/user/login",
            params={
                "user": "admin",
                "pass": setup.current_password
            },
            timeout=10
        )

        current_result = verify_current.json()

    except (requests.RequestException, ValueError):
        return {
            "status": "error",
            "message": "Unable to verify current administrator password"
        }

    if current_result.get("status") != "ok":
        return {
            "status": "error",
            "message": "Current administrator password is incorrect"
        }

    # Change the Technitium administrator password using the
    # dedicated Portal API administrative credentials.
    try:
        change_password = requests.get(
            f"http://{TECHNITIUM_HOST}:65432/api/admin/users/set",
            headers=TECHNITIUM_HEADERS,
            params={
                "user": "admin",
                "newPass": setup.new_password
            },
            timeout=10
        )

        change_result = change_password.json()

    except (requests.RequestException, ValueError):
        return {
            "status": "error",
            "message": "Unable to change administrator password"
        }

    if change_result.get("status") != "ok":
        return {
            "status": "error",
            "message": "Technitium rejected the password change"
        }

    # Verify the new password before marking initial setup complete.
    try:
        verify_new = requests.get(
            f"http://{TECHNITIUM_HOST}:65432/api/user/login",
            params={
                "user": "admin",
                "pass": setup.new_password
            },
            timeout=10
        )

        new_result = verify_new.json()

    except (requests.RequestException, ValueError):
        return {
            "status": "error",
            "message": "Password changed but verification failed"
        }

    if new_result.get("status") != "ok":
        return {
            "status": "error",
            "message": "Password changed but verification failed"
        }

    # Restore the normal Technitium HTTP port before completing setup.
    try:
        requests.post(
            f"http://{TECHNITIUM_HOST}:65432/api/settings/set",
            headers=TECHNITIUM_HEADERS,
            params={
                "type": "General",
                "webServiceHttpPort": 5380
            },
            timeout=10
        )
    except requests.RequestException:
        # Technitium may close the connection while moving the listener.
        pass

    # Prove that Technitium is available again on the normal port.
    technitium_restored = False

    for _ in range(10):
        try:
            restored = requests.get(
                f"http://{TECHNITIUM_HOST}:5380/api/user/profile/get",
                headers=TECHNITIUM_HEADERS,
                timeout=3
            )

            restored_result = restored.json()

            restored_username = (
                restored_result
                .get("response", {})
                .get("username")
                or restored_result
                .get("response", {})
                .get("user")
            )

            if (
                restored_result.get("status") == "ok"
                and restored_username == "portal-api"
            ):
                technitium_restored = True
                break

        except Exception:
            pass

        time.sleep(1)

    if not technitium_restored:
        return {
            "status": "error",
            "message": (
                "Administrator password changed, but Technitium "
                "could not be restored to port 5380"
            )
        }

    # Only mark setup complete after the new credentials are proven
    # and Technitium is confirmed operational again on port 5380.
    try:
        temp_marker = setup_complete + ".tmp"

        with open(temp_marker, "w", encoding="utf-8") as marker:
            marker.write(
                datetime.now().astimezone().isoformat(timespec="seconds")
                + "\n"
            )

        os.chmod(temp_marker, 0o644)
        os.replace(temp_marker, setup_complete)

    except Exception:
        return {
            "status": "error",
            "message": (
                "Password changed successfully, but the Portal "
                "could not record setup completion"
            )
        }

    return {
        "status": "ok",
        "message": "Initial administrator setup completed"
    }


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):

    await manager.connect(websocket)

    try:

        while True:
            await websocket.receive_text()

    except Exception:

        manager.disconnect(websocket)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class SiteRequest(BaseModel):
    domain: str
    client_ip: str
    reason: str
    requested_by: str = ""
    submitted_by: str = ""
    allow_minutes: int | None = None
    
class AllowRequest(BaseModel):
    allow_type: str
    duration: int | None = None

@app.get("/requests")
def get_requests():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id,
               domain,
               client_ip,
               reason,
               status,
               requested_at
        FROM requests
        ORDER BY id DESC
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows

@app.get("/requests/by-user/{username}")
def requests_by_user(username: str):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id,
               domain,
               client_ip,
               reason,
               status,
               requested_at,
               allow_minutes,
               allowed_until
        FROM requests
        WHERE submitted_by = %s
        ORDER BY id DESC
        LIMIT 10
    """, (username,))

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows

# ============================================================
# PORTAL MONITOR EVENT ENGINE
# Every reportable portal action fires its event here once
# the action reports success; the matching notification rules
# each send through their channel. A monitoring failure can
# never break the action that triggered it.
# ============================================================

def fire_portal_event(
    function_name,
    event_name
):
    """Sends the notification rules that
    watch this function + event."""

    fired = 0

    try:
        conn = monitoring_db()
        cur = conn.cursor()

        try:
            cur.execute("""
                SELECT id,
                       notification_channel,
                       login_custom_message
                FROM monitoring.login_notification_rules
                WHERE enabled
                  AND rule_function = %s
                  AND (
                      notification_type = %s
                      OR notification_type = 'All'
                  )
                  AND lower(target_username)
                      = 'all'
            """, (function_name, event_name))

            rules = cur.fetchall()

        finally:
            cur.close()
            conn.close()

        for rule in rules:

            message = (
                (rule[2] or "").strip()
                or (
                    "Portal monitor: "
                    + function_name
                    + " - "
                    + event_name
                    + "."
                )
            )

            send_notification(
                (rule[1] or "").strip().lower(),
                "Portal Monitor Alert",
                message,
                ""
            )

            fired += 1

    except Exception as error:
        print(
            "[monitor] %s / %s failed: %s"
            % (function_name, event_name, error),
            flush=True
        )

    if fired:
        print(
            "[monitor] %s / %s fired %d rule(s)"
            % (function_name, event_name, fired),
            flush=True
        )

    return fired


def fires_portal_event(function_name, event_name):
    """Marks an endpoint as a reportable
    portal action: when the endpoint reports
    success the matching rules fire. Works
    for sync and async endpoints."""

    import functools
    import inspect

    def decorator(endpoint):

        def succeeded(response):

            # Endpoints answer in three
            # shapes: portal dicts (success:
            # True), user endpoints (status:
            # success) and raw Technitium
            # responses (response.status: ok).

            if not isinstance(response, dict):
                return False

            if response.get("success"):
                return True

            # Technitium answers with a
            # top-level status: ok.

            if response.get("status") in (
                "success",
                "ok"
            ):
                return True

            inner = response.get("response")

            return (
                isinstance(inner, dict)
                and inner.get("status") == "ok"
            )

        if inspect.iscoroutinefunction(endpoint):

            @functools.wraps(endpoint)
            async def async_wrapper(*args, **kwargs):

                response = await endpoint(
                    *args,
                    **kwargs
                )

                try:
                    if succeeded(response):
                        fire_portal_event(
                            function_name,
                            event_name
                        )
                except Exception:
                    pass

                return response

            return async_wrapper

        @functools.wraps(endpoint)
        def sync_wrapper(*args, **kwargs):

            response = endpoint(*args, **kwargs)

            try:
                if succeeded(response):
                    fire_portal_event(
                        function_name,
                        event_name
                    )
            except Exception:
                pass

            return response

        return sync_wrapper

    return decorator


@app.post("/request")
@fires_portal_event(
    "Request Approvals",
    "Request Submitted"
)
async def request_access(request: SiteRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    # Check if request already exists
    cur.execute("""
        SELECT id
        FROM requests
        WHERE domain = %s
        AND status = 'Pending'
    """, (request.domain,))

    existing_request = cur.fetchone()

    if existing_request:

        cur.close()
        conn.close()

        return {
            "success": False,
            "message": "Request already pending"
        }

    # Create request
    cur.execute(
        """
        INSERT INTO requests
        (domain, client_ip, reason,
         requested_by, submitted_by,
         allow_minutes)
        VALUES
        (%s, %s, %s, %s, %s, %s)
        """,
        (
            request.domain,
            request.client_ip,
            request.reason,
            request.requested_by,
            request.submitted_by,
            request.allow_minutes
        )
    )

    conn.commit()
    
    print("Broadcasting refresh from request")
    await manager.broadcast("refresh")

    cur.close()
    conn.close()

    return {
        "success": True
    }

def _import_backend_access_requests():
    """Pull pending client access requests submitted on the backend's
    block page into the portal request list, so administrators review
    everything in one place. Each imported row is tagged
    'appliance:<backend request id>' in submitted_by; approvals and
    denials applied in the portal are sent back to the backend."""
    try:
        rows = get_provider().access_requests()
    except Exception:
        rows = None
    if not rows:
        return

    try:
        conn = psycopg2.connect(
            host=POSTGRES_HOST,
            database=POSTGRES_DB,
            user=POSTGRES_USER,
            password=POSTGRES_PASSWORD
        )
    except Exception:
        return
    cur = conn.cursor()
    try:
        for row in rows:
            if not isinstance(row, dict):
                continue
            if (row.get("status") or "pending").lower() != "pending":
                continue
            tag = "appliance:%s" % row.get("id")
            cur.execute(
                "SELECT id FROM requests WHERE submitted_by = %s LIMIT 1",
                (tag,),
            )
            if cur.fetchone():
                continue

            domain = (row.get("requested_host") or "").strip().lower()
            if not domain:
                continue

            when = None
            raw_when = row.get("created_at")
            if raw_when:
                try:
                    when = datetime.fromisoformat(
                        str(raw_when).replace("Z", "+00:00")
                    ).replace(tzinfo=None)
                except ValueError:
                    when = None

            reason = (row.get("reason") or "Appliance block page request")[:255]
            client_ip = row.get("source_ip") or row.get("client_ip") or ""

            try:
                cur.execute(
                    """
                    INSERT INTO requests
                        (domain, client_ip, reason, status, requested_at, submitted_by)
                    VALUES (%s, %s, %s, 'Pending', %s, %s)
                    """,
                    (domain, client_ip, reason, when or datetime.now(), tag),
                )
            except Exception:
                # A single bad row must never break the import loop
                # (it also runs inside the periodic expiry task).
                conn.rollback()
                continue
        conn.commit()
    except Exception:
        conn.rollback()
    finally:
        cur.close()
        conn.close()


@app.get("/pending")
def pending_requests():

    _import_backend_access_requests()

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id,
               domain,
               client_ip,
               reason,
               status,
               requested_at,
               requested_by,
               allow_minutes
        FROM requests
        WHERE status = 'Pending'
        ORDER BY id DESC
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows

@app.get("/approved")
def approved_requests():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id,
               domain,
               client_ip,
               reason,
               status,
               approved_at,
               allowed_until
        FROM requests
        WHERE status = 'Approved'
        ORDER BY approved_at DESC
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows

@app.post("/approve/{request_id}")
@fires_portal_event(
    "Request Approvals",
    "Request Approved"
)
async def approve_request(request_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    # Get domain from request
    cur.execute("""
        SELECT domain, submitted_by, allow_minutes
        FROM requests
        WHERE id = %s
    """, (request_id,))

    row = cur.fetchone()

    if row is None:
        cur.close()
        conn.close()

        return {
            "success": False,
            "message": "Request not found"
        }

    domain = row[0]
    submitted_by = row[1] or ""
    allow_minutes = row[2]

    print("Domain:", domain)

    if submitted_by.startswith("appliance:"):

        # Imported from the backend's block page: the decision is sent
        # back to the backend, whose allow rules can override category
        # blocklists (service-level allows), unlike a plain unblock.
        backend_request_id = submitted_by.split(":", 1)[1]
        if not get_provider().review_access_request(
            backend_request_id, "approved", allow_minutes
        ):
            cur.close()
            conn.close()
            return {
                "success": False,
                "message": "The backend could not apply the approval"
            }

    # Unblock through the network services provider
    elif not get_provider().unblock_domain(domain):
        cur.close()
        conn.close()
        return {"success": False}

    # Update status
    cur.execute("""
        UPDATE requests
        SET status = 'Approved',
		        approved_at = NOW(),
            allowed_until =
                CASE
                    WHEN allow_minutes IS NOT NULL
                    THEN NOW()
                        + (allow_minutes
                            * INTERVAL '1 minute')
                    ELSE NULL
                END
        WHERE id = %s
    """, (request_id,))

    conn.commit()
    
    print("Broadcasting refresh from approve")
    await manager.broadcast("refresh")

    cur.close()
    conn.close()

    return {
        "success": True,
        "request_id": request_id,
        "domain": domain
    }

@app.post("/deny/{request_id}")
@fires_portal_event(
    "Request Approvals",
    "Request Denied"
)
async def deny_request(request_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT submitted_by
        FROM requests
        WHERE id = %s
    """, (request_id,))

    deny_row = cur.fetchone()

    if deny_row and (deny_row[0] or "").startswith("appliance:"):

        # Imported from the backend's block page: send the decision back
        get_provider().review_access_request(
            deny_row[0].split(":", 1)[1], "denied"
        )

    cur.execute("""
        UPDATE requests
        SET status = 'Denied',
		        denied_at = NOW(),
            deny_reason = 'Manual Deny'
        WHERE id = %s
    """, (request_id,))

    conn.commit()
    
    print("Broadcasting refresh from deny")
    await manager.broadcast("refresh")

    cur.close()
    conn.close()

    return {
        "success": True,
        "request_id": request_id
    }

@app.get("/status/{domain}")
def request_status(domain: str):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT status
        FROM requests
        WHERE domain = %s
        ORDER BY id DESC
        LIMIT 1
    """, (domain,))

    row = cur.fetchone()

    cur.close()
    conn.close()

    if row:
        return {"status": row[0]}

    return {"status": "None"}

@app.get("/denied")
def denied_requests():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id,
               domain,
               client_ip,
               reason,
               status,
               denied_at,
               deny_reason
        FROM requests
        WHERE status = 'Denied'
        ORDER BY denied_at DESC
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows

@app.get("/stats")
def stats():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute(
        "SELECT COUNT(*) FROM requests WHERE status = 'Pending'"
    )
    pending = cur.fetchone()[0]

    cur.execute(
        "SELECT COUNT(*) FROM requests WHERE status = 'Approved'"
    )
    approved = cur.fetchone()[0]

    cur.execute(
        "SELECT COUNT(*) FROM requests WHERE status = 'Denied'"
    )
    denied = cur.fetchone()[0]

    cur.close()
    conn.close()

    return {
        "pending": pending,
        "approved": approved,
        "denied": denied
    }

@app.post("/reblock/{request_id}")
@fires_portal_event(
    "Domain Controls",
    "Domain Re-blocked"
)
async def reblock(request_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT domain, submitted_by
        FROM requests
        WHERE id = %s
    """, (request_id,))

    row = cur.fetchone()

    if row is None:
        cur.close()
        conn.close()

        return {
            "success": False,
            "message": "Request not found"
        }

    domain = row[0]
    submitted_by = row[1] or ""

    print("Domain:", domain)

    if submitted_by.startswith("appliance:"):

        # Imported from the backend's block page: its service-level
        # allow rules would override a plain block entry - revoke the
        # allow group first so the re-block takes effect immediately.
        get_provider().revoke_domain_allows(domain)

    # Block through the network services provider
    if not get_provider().block_domain(domain):

        cur.close()
        conn.close()

        return {
            "success": False,
            "message": "Domain block failed"
        }

    cur.execute("""
        UPDATE requests
        SET status = 'Denied',
            denied_at = NOW(),
            deny_reason = 'Manual Re-Block'
        WHERE id = %s
    """, (request_id,))

    conn.commit()

    print("Broadcasting refresh from reblock")
    await manager.broadcast("refresh")

    cur.close()
    conn.close()

    return {
        "success": True,
        "request_id": request_id,
        "domain": domain
    }
    
@app.post("/allow/{request_id}")
@fires_portal_event(
    "Domain Controls",
    "Domain Allowed"
)
async def allow_request(
    request_id: int,
    allow: AllowRequest
):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT domain, submitted_by
        FROM requests
        WHERE id = %s
    """, (request_id,))

    row = cur.fetchone()

    if row is None:
        cur.close()
        conn.close()

        return {
            "success": False,
            "message": "Request not found"
        }

    domain = row[0]
    submitted_by = row[1] or ""

    if submitted_by.startswith("appliance:"):

        # Imported from the backend's block page: the decision is sent
        # back to the backend, whose allow rules can override category
        # blocklists. The backend applies timed allows in fixed steps
        # (1h ... 30d, permanent): a shorter request is rounded UP to
        # the next step and the portal timer is aligned with it, so
        # both systems agree on when the allow ends.
        backend_request_id = submitted_by.split(":", 1)[1]
        requested_minutes = allow.duration if allow.allow_type == "timed" else None

        effective_minutes = None
        if requested_minutes:
            for step in (60, 240, 480, 1440, 4320, 10080, 43200):
                if requested_minutes <= step:
                    effective_minutes = step
                    break

        if not get_provider().review_access_request(
            backend_request_id, "approved", requested_minutes
        ):

            # The backend's review is one-shot: re-allows from the
            # denied list (a request it already reviewed) apply the
            # allow directly, with the exact requested duration.
            if not get_provider().allow_domain_timed(domain, requested_minutes):
                cur.close()
                conn.close()

                return {
                    "success": False,
                    "message": "The backend could not apply the approval"
                }

        # The portal keeps the REQUESTED duration: its own expiry timer
        # re-blocks the domain when the admin's chosen time is up; the
        # stepped backend allow is only the backend-side application.
        if allow.allow_type == "timed" and allow.duration:

            cur.execute("""
                UPDATE requests
                SET status = 'Approved',
                    approved_at = NOW(),
                    allowed_until =
                        NOW() + (%s * INTERVAL '1 minute')
                WHERE id = %s
            """, (allow.duration, request_id))

        else:

            cur.execute("""
                UPDATE requests
                SET status = 'Approved',
                    approved_at = NOW(),
                    allowed_until = NULL
                WHERE id = %s
            """, (request_id,))

        conn.commit()

        await manager.broadcast("refresh")

        cur.close()
        conn.close()

        return {
            "success": True,
            "request_id": request_id,
            "domain": domain
        }

    if not get_provider().unblock_domain(domain):

        cur.close()
        conn.close()

        return {
            "success": False
        }

    if allow.allow_type == "timed":
    
        cur.execute("""
            UPDATE requests
            SET status = 'Approved',
                approved_at = NOW(),
                allowed_until =
                    NOW() + (%s * INTERVAL '1 minute')
            WHERE id = %s
        """, (allow.duration, request_id))
    
    else:
    
        cur.execute("""
            UPDATE requests
            SET status = 'Approved',
                approved_at = NOW(),
                allowed_until = NULL
            WHERE id = %s
        """, (request_id,))


    conn.commit()

    await manager.broadcast("refresh")

    cur.close()
    conn.close()

    return {
        "success": True,
        "request_id": request_id,
        "domain": domain
    } 
    
async def process_expired_allows():

    print("Checking expired approvals...")

    _import_backend_access_requests()

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT id, domain, submitted_by
        FROM requests
        WHERE status = 'Approved'
        AND allowed_until IS NOT NULL
        AND allowed_until <= NOW()
    """)

    rows = cur.fetchall()

    for request_id, domain, submitted_by in rows:

        print("Auto Re-Blocking:", domain)

        if (submitted_by or "").startswith("appliance:"):

            # The backend applies its allow in fixed steps that can
            # outlive the portal's requested duration; revoke the
            # service-level allow group so the re-block takes effect
            # at the admin's chosen time.
            get_provider().revoke_domain_allows(domain)

        if get_provider().block_domain(domain):

            cur.execute("""
                UPDATE requests
                SET status = 'Denied',
                    denied_at = NOW(),
                    allowed_until = NULL,
                    deny_reason = 'Timer Expired'
                WHERE id = %s
            """, (request_id,))

            conn.commit()

            await manager.broadcast("refresh")

    cur.close()
    conn.close()
    
@app.get("/users")
def list_users():
    """The portal's own credential store is the source of truth for
    user accounts; the network services backend (Technitium or the
    NetFortress appliance) only holds shadow copies pushed from here.
    The list is therefore always built from the portal database and
    annotated with portal-owned 2FA and sign-in tracking."""

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT a.username,
                   a.is_disabled,
                   COALESCE(p.display_name, a.username)
            FROM portal_auth a
            LEFT JOIN user_profiles p
                ON LOWER(p.username) = LOWER(a.username)
            ORDER BY a.id
        """)

        users = [
            {
                "username": row[0],
                "displayName": row[2],
                "disabled": bool(row[1]),
            }
            for row in cur.fetchall()
        ]
    finally:
        cur.close()
        conn.close()

    data = {"status": "ok", "response": {"users": users}}

    # Service accounts live on Technitium only and are never
    # shown or managed from the portal.
    # The 2FA status is portal-owned (portal_auth), so the
    # Technitium totpEnabled field is stripped and replaced.
    try:
        users = data.get("response", {}).get("users", [])
    except (AttributeError, TypeError):
        return data

    conn = portal_auth_connect()
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT LOWER(username), totp_enabled
            FROM portal_auth
        """)
        twofa_map = {
            str(row[0]).strip(): bool(row[1])
            for row in cur.fetchall()
        }
    finally:
        cur.close()
        conn.close()

    #
    # UPDATE - Last Login / Source IP are portal-owned.
    #
    # The sign-in tracking lives in monitoring.login_events
    # (recorded by the login notification engine with the
    # client IP); the Technitium session fields are replaced
    # so the Users page no longer depends on Technitium.
    #

    last_login_map = {}

    try:
        mon_conn = monitoring_db()
        mon_cur = mon_conn.cursor()
        try:
            mon_cur.execute("""
                SELECT DISTINCT ON (username)
                    username,
                    created_at,
                    source_ip
                FROM monitoring.login_events
                WHERE event = 'Successful Login'
                ORDER BY username, created_at DESC
            """)
            for row in mon_cur.fetchall():
                last_login_map[
                    str(row[0]).strip().lower()
                ] = (
                    row[1].isoformat()
                    if row[1] is not None
                    else "",
                    (row[2] or "").strip()
                )
        finally:
            mon_cur.close()
            mon_conn.close()
    except Exception:
        pass

    filtered = []
    for user in users:
        uname = str(user.get("username", "")).strip()
        if uname.lower() in PORTAL_SYSTEM_USERS:
            continue
        user.pop("totpEnabled", None)
        user.pop("previousSessionLoggedOn", None)
        user.pop("previousSessionRemoteAddress", None)
        user["twoFactorEnabled"] = twofa_map.get(
            uname.lower(),
            False
        )
        last_login, source_ip = last_login_map.get(
            uname.lower(),
            ("", "")
        )
        user["recentSessionLoggedOn"] = last_login
        user["recentSessionRemoteAddress"] = source_ip
        filtered.append(user)

    data["response"]["users"] = filtered

    return data

class CreateUserRequest(BaseModel):
    display_name: str
    username: str
    password: str


@app.get("/users/username-available/{username}")
def username_available(username: str):

    username = username.strip()

    if not username:
        return {
            "available": False,
            "message": "Username is required"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT 1
            FROM user_profiles
            WHERE LOWER(username) = LOWER(%s)
            LIMIT 1
        """, (username,))

        exists = cur.fetchone() is not None

    finally:
        cur.close()
        conn.close()

    if exists:
        return {
            "available": False,
            "message": "Username is not available"
        }

    return {
        "available": True,
        "message": "Username is available"
    }


@app.post("/users/create")
@fires_portal_event(
    "Account Activity",
    "User Created"
)
def create_user(user: CreateUserRequest):

    username = user.username.strip()

    if not username:
        return {
            "status": "error",
            "message": "Username is required"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT 1
            FROM user_profiles
            WHERE LOWER(username) = LOWER(%s)
            LIMIT 1
        """, (username,))

        exists = cur.fetchone() is not None

    finally:
        cur.close()
        conn.close()

    if username.lower() in RESERVED_USERNAMES:
        return {
            "status": "error",
            "message": "Username is reserved"
        }

    if exists:
        return {
            "status": "error",
            "message": "Username is not available"
        }

    if portal_auth_exists(username):
        return {
            "status": "error",
            "message": "Username is not available"
        }

    # Portal-owned credential - local store is created first
    # and is the source of truth for this account.
    try:
        store_portal_auth(username, user.password)
    except psycopg2.errors.UniqueViolation:
        return {
            "status": "error",
            "message": "Username is not available"
        }

    # Shadow account on the network services backend (best-effort
    # push, never blocks the creation; reported separately).
    sync_ok = get_provider().create_account_shadow(
        username,
        user.display_name,
        user.password
    )

    return {
        "status": "ok",
        "message": (
            "User created"
            if sync_ok
            else "User created (Technitium sync pending)"
        ),
        "technitium_sync": "ok" if sync_ok else "pending"
    }


class UpdateUserRequest(BaseModel):
    username: str
    display_name: str


@app.post("/users/update")
def update_user(user: UpdateUserRequest):

    get_provider().set_user_display_name(
        user.username,
        user.display_name
    )

    return {"status": "ok"}
    
class UserStatusRequest(BaseModel):
    username: str


@app.post("/users/disable")
def disable_user(user: UserStatusRequest):

    # Local store first - the portal blocks the login even if
    # the Technitium sync below fails.
    set_portal_auth_disabled(user.username, True)

    sync_ok = get_provider().set_user_enabled(user.username, False)

    return {
        "status": "ok",
        "technitium_sync": "ok" if sync_ok else "pending"
    }


@app.post("/users/enable")
def enable_user(user: UserStatusRequest):

    set_portal_auth_disabled(user.username, False)

    sync_ok = get_provider().set_user_enabled(user.username, True)

    return {
        "status": "ok",
        "technitium_sync": "ok" if sync_ok else "pending"
    }

class DeleteUserRequest(BaseModel):
    username: str


@app.post("/users/delete")
@fires_portal_event(
    "Account Activity",
    "User Deleted"
)
def delete_user(user: DeleteUserRequest):

    if user.username.strip().lower() in RESERVED_USERNAMES:
        return {
            "status": "error",
            "message": "System users cannot be deleted"
        }

    # Remove the portal-owned credential first.
    delete_portal_auth(user.username)

    # Shadow account removal (best-effort push to the backend).
    sync_ok = get_provider().delete_user(user.username)

    return {
        "status": "ok",
        "technitium_sync": "ok" if sync_ok else "pending"
    }
    
class ResetPasswordRequest(BaseModel):
    username: str
    password: str


@app.post("/users/reset-password")
def reset_password(user: ResetPasswordRequest):

    # Portal-owned credential first (upsert: also migrates a
    # user who has not logged in since the auth switch).
    if not update_portal_auth(user.username, user.password):
        store_portal_auth(user.username, user.password)

    # Shadow password push (best-effort).
    sync_ok = get_provider().set_user_password(
        user.username,
        user.password
    )

    return {
        "status": "ok",
        "technitium_sync": "ok" if sync_ok else "pending"
    }
    
class CreateGroupRequest(BaseModel):
    group_name: str
    description: str = ""

@app.post("/groups/create")
@fires_portal_event(
    "Group Activity",
    "Group Created"
)
def create_group(group: CreateGroupRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        INSERT INTO groups
        (
            group_name,
            description
        )
        VALUES
        (
            %s,
            %s
        )
        RETURNING id
    """,
    (
        group.group_name,
        group.description
    ))
    group_id = cur.fetchone()[0]
    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True,
        "group_id": group_id
    }

@app.get("/groups")
def list_groups():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            id,
            group_name,
            description,
            created_at
        FROM groups
        ORDER BY group_name
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return rows
    
class UpdateGroupRequest(BaseModel):
    id: int
    group_name: str
    description: str
    
@app.post("/groups/update")
@fires_portal_event(
    "Group Activity",
    "Group Updated"
)
def update_group(group: UpdateGroupRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        UPDATE groups
        SET group_name = %s,
            description = %s
        WHERE id = %s
    """,
    (
        group.group_name,
        group.description,
        group.id
    ))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }

class DeleteGroupRequest(BaseModel):
    id: int

@app.post("/groups/delete")
def delete_group(group: DeleteGroupRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        DELETE
        FROM groups
        WHERE id = %s
    """, (group.id,))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }

class SettingsFieldSectionCreateRequest(BaseModel):
    section_name: str
    sort_order: int = 0

class SettingsFieldSectionUpdateRequest(BaseModel):
    section_name: str
    sort_order: int = 0

class SettingsFieldCreateRequest(BaseModel):
    section_id: int
    field_name: str
    field_href: str = ""
    field_permission: str = ""
    sort_order: int = 0

class SettingsFieldUpdateRequest(BaseModel):
    field_name: str
    field_href: str = ""
    field_permission: str = ""
    sort_order: int = 0

@app.get("/settings-field-sections")
def get_settings_field_sections():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT
                id,
                section_name,
                sort_order,
                created_at
            FROM settings_field_sections
            ORDER BY
                sort_order,
                id
        """)

        rows = cur.fetchall()

        return [
            {
                "id": row[0],
                "section_name": row[1],
                "sort_order": row[2],
                "created_at": (
                    row[3].isoformat()
                    if row[3]
                    else None
                )
            }
            for row in rows
        ]

    finally:
        cur.close()
        conn.close()

@app.post("/settings-field-sections/create")
@fires_portal_event(
    "Settings Changes",
    "Section Added"
)
def create_settings_field_section(
    request: SettingsFieldSectionCreateRequest
):

    section_name = request.section_name.strip()

    if not section_name:
        return {
            "success": False,
            "message": "Section name is required"
        }

    if len(section_name) > 100:
        return {
            "success": False,
            "message": "Section name is too long"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            INSERT INTO settings_field_sections
            (
                section_name,
                sort_order
            )
            VALUES
            (%s,%s)
            RETURNING id
        """, (
            section_name,
            request.sort_order
        ))

        section_id = cur.fetchone()[0]
        conn.commit()

        return {
            "success": True,
            "section_id": section_id
        }

    finally:
        cur.close()
        conn.close()

@app.post("/settings-field-sections/{section_id}/update")
@fires_portal_event(
    "Settings Changes",
    "Section Updated"
)
def update_settings_field_section(
    section_id: int,
    request: SettingsFieldSectionUpdateRequest
):

    section_name = request.section_name.strip()

    if not section_name:
        return {
            "success": False,
            "message": "Section name is required"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            UPDATE settings_field_sections
            SET section_name = %s,
                sort_order = %s
            WHERE id = %s
        """, (
            section_name,
            request.sort_order,
            section_id
        ))

        conn.commit()

        return {
            "success": cur.rowcount > 0
        }

    finally:
        cur.close()
        conn.close()

@app.post("/settings-field-sections/{section_id}/delete")
def delete_settings_field_section(section_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            DELETE FROM settings_field_sections
            WHERE id = %s
        """, (section_id,))

        conn.commit()

        return {
            "success": cur.rowcount > 0
        }

    finally:
        cur.close()
        conn.close()

@app.get("/settings-fields")
def get_settings_fields():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT
                id,
                section_id,
                field_name,
                field_href,
                field_permission,
                sort_order,
                created_at
            FROM settings_fields
            ORDER BY
                sort_order,
                id
        """)

        rows = cur.fetchall()

        return [
            {
                "id": row[0],
                "section_id": row[1],
                "field_name": row[2],
                "field_href": row[3],
                "field_permission": row[4],
                "sort_order": row[5],
                "created_at": (
                    row[6].isoformat()
                    if row[6]
                    else None
                )
            }
            for row in rows
        ]

    finally:
        cur.close()
        conn.close()

def generate_settings_page(
    field_href,
    field_name,
    field_permission,
    section_name,
    hub_label=""
):
    """Create the target page for a settings field
    when it does not exist yet. The page title is
    the field name, page security is the field
    permission, and the basic portal style carries
    the editable section tab bar so the page can
    be managed from inside."""

    import os
    import re as _re

    href = (field_href or "").strip()

    if not _re.fullmatch(r"[a-z0-9-]+\.php", href):
        return

    page_path = "/opt/portal/web/" + href

    if os.path.exists(page_path):
        return

    def clean(value):
        allowed = set(
            "abcdefghijklmnopqrstuvwxyz"
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            "0123456789 .,_-()/&+:;"
        )
        return "".join(
            ch
            for ch in str(value or "")
            if ch in allowed
        )

    name = clean(field_name)
    permission = clean(field_permission)
    section = clean(section_name)

    # Tab pages open on their hub's name
    # (Monitor Alerts, Appearance, ...);
    # the active tab shows the page
    # itself. Pages created straight from
    # a settings field keep their own
    # name.

    heading = name
    page_title = name

    if hub_label:
        heading = hub_label
        page_title = (
            hub_label + " - " + name
        )

    gate = ""

    if permission:
        gate = (
            "if (\n"
            "    !hasPermission(\n"
            "        '" + permission + "'\n"
            "    )\n"
            ") {\n"
            "    include 'includes/access-denied.php';\n"
            "    exit;\n"
            "}\n"
        )

    page = (
        "<?php\n"
        "\n"
        "require_once 'auth.php';\n"
        "require_once 'config.php';\n"
        "\n"
        "// Must run before any output so the\n"
        "// section tabs POST redirects work\n"
        "// cleanly.\n"
        "require_once __DIR__\n"
        "    . '/includes/page-tabs-head.php';\n"
        "\n"
        + gate +
        "\n"
        "$currentSection = 'settings';\n"
        "$currentPage = '" + href[:-4] + "';\n"
        "$pageHeading = '" + section + "';\n"
        "$showSidebarPageHeading = true;\n"
        "\n"
        "?>\n"
        "<!DOCTYPE html>\n"
        "<html>\n"
        "<head>\n"
        "    <title>" + page_title + "</title>\n"
        "\n"
        "    <link\n"
        "        rel=\"stylesheet\"\n"
        "        href=\"css/style.css\">\n"
        "\n"
        "<?php include __DIR__ . '/includes/favicon.php'; ?>\n"
        "\n"
        "    <link href=\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined\" rel=\"stylesheet\" />\n"
        "\n"
        "</head>\n"
        "\n"
        "<body>\n"
        "\n"
        "<?php include 'includes/banner.php'; ?>\n"
        "\n"
        "<?php include 'includes/sidebar.php'; ?>\n"
        "\n"
        "<div class=\"content appearance-page\">\n"
        "\n"
        "    <div class=\"appearance-page-header\">\n"
        "\n"
        "        <div>\n"
        "            <h1>" + heading + "</h1>\n"
        "\n"
        "            <p>\n"
        "                Manage " + name + ".\n"
        "            </p>\n"
        "        </div>\n"
        "\n"
        "    </div>\n"
        "\n"
        "    <?php include __DIR__ . '/includes/page-tabs.php'; ?>\n"
        "\n"
        + (
            # Monitor channel pages carry the
            # per-channel notification rules
            # (Add User styled popup and rules
            # table); every other generated
            # page keeps the placeholder
            # heading.
            "    <div class=\"appearance-panel\">\n"
            "\n"
            "        <?php\n"
            "        $monitorChannelName = '"
            + name + "';\n"
            "        include __DIR__\n"
            "            . '/includes/monitor-channel-rules.php';\n"
            "        ?>\n"
            "\n"
            "    </div>\n"
            if (
                href.startswith("monitor-")
                and href != "monitor-login.php"
            )
            else
            "    <div class=\"appearance-panel\">\n"
            "\n"
            "        <div class=\"appearance-panel-heading\">\n"
            "\n"
            "            <div>\n"
            "                <h2>" + name + "</h2>\n"
            "\n"
            "                <p>\n"
            "                    This page has no content yet.\n"
            "                </p>\n"
            "            </div>\n"
            "\n"
            "        </div>\n"
            "\n"
            "    </div>\n"
        )
        +
        "\n"
        "</div>\n"
        "\n"
        "</body>\n"
        "\n"
        "</html>\n"
    )

    with open(page_path, "w") as f:
        f.write(page)

    os.chmod(page_path, 0o644)


@app.post("/settings-fields/create")
@fires_portal_event(
    "Settings Changes",
    "Field Added"
)
def create_settings_field(
    request: SettingsFieldCreateRequest
):

    field_name = request.field_name.strip()

    if not field_name:
        return {
            "success": False,
            "message": "Field name is required"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            INSERT INTO settings_fields
            (
                section_id,
                field_name,
                field_href,
                field_permission,
                sort_order
            )
            VALUES
            (%s,%s,%s,%s,%s)
            RETURNING id
        """, (
            request.section_id,
            field_name,
            request.field_href.strip(),
            request.field_permission.strip(),
            request.sort_order
        ))

        field_id = cur.fetchone()[0]
        conn.commit()

        cur.execute("""
            SELECT section_name
            FROM settings_field_sections
            WHERE id = %s
        """, (request.section_id,))

        section_row = cur.fetchone()

        generate_settings_page(
            request.field_href.strip(),
            field_name,
            request.field_permission.strip(),
            section_row[0] if section_row else ""
        )

        return {
            "success": True,
            "field_id": field_id
        }

    finally:
        cur.close()
        conn.close()

@app.post("/settings-fields/{field_id}/update")
@fires_portal_event(
    "Settings Changes",
    "Field Updated"
)
def update_settings_field(
    field_id: int,
    request: SettingsFieldUpdateRequest
):

    field_name = request.field_name.strip()

    if not field_name:
        return {
            "success": False,
            "message": "Field name is required"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            UPDATE settings_fields
            SET field_name = %s,
                field_href = %s,
                field_permission = %s,
                sort_order = %s
            WHERE id = %s
        """, (
            field_name,
            request.field_href.strip(),
            request.field_permission.strip(),
            request.sort_order,
            field_id
        ))

        updated = cur.rowcount > 0

        conn.commit()

        if updated:

            cur.execute("""
                SELECT s.section_name
                FROM settings_fields f
                JOIN settings_field_sections s
                    ON s.id = f.section_id
                WHERE f.id = %s
            """, (field_id,))

            section_row = cur.fetchone()

            generate_settings_page(
                request.field_href.strip(),
                field_name,
                request.field_permission.strip(),
                section_row[0] if section_row else ""
            )

        return {
            "success": updated
        }

    finally:
        cur.close()
        conn.close()

@app.post("/settings-fields/{field_id}/delete")
def delete_settings_field(field_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            DELETE FROM settings_fields
            WHERE id = %s
        """, (field_id,))

        conn.commit()

        return {
            "success": cur.rowcount > 0
        }

    finally:
        cur.close()
        conn.close()

class UserManagementTabCreateRequest(BaseModel):
    tab_name: str
    tab_href: str = ""
    tab_permission: str = ""
    sort_order: int = 0

class UserManagementTabUpdateRequest(BaseModel):
    tab_name: str
    tab_href: str = ""
    tab_permission: str = ""
    sort_order: int = 0

@app.get("/user-management-tabs")
def get_user_management_tabs():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT
                id,
                tab_name,
                tab_href,
                tab_permission,
                sort_order,
                created_at
            FROM user_management_tabs
            ORDER BY
                sort_order,
                id
        """)

        rows = cur.fetchall()

        return [
            {
                "id": row[0],
                "tab_name": row[1],
                "tab_href": row[2],
                "tab_permission": row[3],
                "sort_order": row[4],
                "created_at": (
                    row[5].isoformat()
                    if row[5]
                    else None
                )
            }
            for row in rows
        ]

    finally:
        cur.close()
        conn.close()

@app.post("/user-management-tabs/create")
def create_user_management_tab(
    request: UserManagementTabCreateRequest
):

    tab_name = request.tab_name.strip()

    if not tab_name:
        return {
            "success": False,
            "message": "Tab name is required"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            INSERT INTO user_management_tabs
            (
                tab_name,
                tab_href,
                tab_permission,
                sort_order
            )
            VALUES
            (%s,%s,%s,%s)
            RETURNING id
        """, (
            tab_name,
            request.tab_href.strip(),
            request.tab_permission.strip(),
            request.sort_order
        ))

        tab_id = cur.fetchone()[0]
        conn.commit()

        return {
            "success": True,
            "tab_id": tab_id
        }

    finally:
        cur.close()
        conn.close()

@app.post("/user-management-tabs/{tab_id}/update")
def update_user_management_tab(
    tab_id: int,
    request: UserManagementTabUpdateRequest
):

    tab_name = request.tab_name.strip()

    if not tab_name:
        return {
            "success": False,
            "message": "Tab name is required"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            UPDATE user_management_tabs
            SET tab_name = %s,
                tab_href = %s,
                tab_permission = %s,
                sort_order = %s
            WHERE id = %s
        """, (
            tab_name,
            request.tab_href.strip(),
            request.tab_permission.strip(),
            request.sort_order,
            tab_id
        ))

        conn.commit()

        return {
            "success": cur.rowcount > 0
        }

    finally:
        cur.close()
        conn.close()

@app.post("/user-management-tabs/{tab_id}/delete")
def delete_user_management_tab(tab_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            DELETE FROM user_management_tabs
            WHERE id = %s
        """, (tab_id,))

        conn.commit()

        return {
            "success": cur.rowcount > 0
        }

    finally:
        cur.close()
        conn.close()

class PageTabCreateRequest(BaseModel):
    tab_group: str
    tab_name: str
    tab_href: str = ""
    tab_permission: str = ""
    sort_order: int = 0

class PageTabUpdateRequest(BaseModel):
    tab_name: str
    tab_href: str = ""
    tab_permission: str = ""
    sort_order: int = 0

@app.get("/page-tabs")
def get_page_tabs():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT id,
                   tab_group,
                   tab_name,
                   tab_href,
                   tab_permission,
                   tab_alternates,
                   sort_order
            FROM page_tabs
            ORDER BY tab_group,
                     sort_order,
                     id
        """)

        rows = cur.fetchall()

        # Backend-owned tabs only render when the Technitium backend
        # is active (clean portal v2): the base install has no backend
        # and the NetFortress integration does not use the
        # Technitium-era service pages.
        backend_provider = _portal_setting_get("dns_provider")
        if backend_provider != "technitium":
            rows = [
                r for r in rows
                if r[1] != "technitium.php"
                and r[3] != "https-ssl-dns.php"
            ]
        if backend_provider != "firewall":
            rows = [
                r for r in rows
                if r[1] != "netfortress.php"
                and r[3] != "netfortress-network.php"
            ]

        return [
            {
                "id": r[0],
                "tab_group": r[1],
                "tab_name": r[2],
                "tab_href": r[3],
                "tab_permission": r[4],
                "tab_alternates": r[5],
                "sort_order": r[6]
            }
            for r in rows
        ]

    finally:
        cur.close()
        conn.close()

def page_tabs_hub_label(tab_group):
    """The settings field name for a tab group, used
    as the hub label when generating tab pages."""

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT field_name
            FROM settings_fields
            WHERE field_href = %s
        """, (tab_group,))

        row = cur.fetchone()

        return row[0] if row else tab_group[:-4]

    finally:
        cur.close()
        conn.close()

def page_tabs_section_label(tab_group):
    """The settings section a tab group's hub
    field belongs to. Generated tab pages show
    this as their sidebar heading label - the
    same way every other settings page shows
    the section it lives under. Falls back to
    the hub label when the field has no
    section."""

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT s.section_name
            FROM settings_fields f
            JOIN settings_field_sections s
                ON s.id = f.section_id
            WHERE f.field_href = %s
        """, (tab_group,))

        row = cur.fetchone()

        if row:
            return row[0]

        return page_tabs_hub_label(tab_group)

    finally:
        cur.close()
        conn.close()


@app.post("/page-tabs/create")
@fires_portal_event(
    "Settings Changes",
    "Tab Added"
)
def create_page_tab(
    request: PageTabCreateRequest
):

    tab_name = request.tab_name.strip()

    if not tab_name:
        return {
            "success": False,
            "message": "Tab name is required"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            INSERT INTO page_tabs
            (
                tab_group,
                tab_name,
                tab_href,
                tab_permission,
                sort_order
            )
            VALUES
            (%s,%s,%s,%s,%s)
            RETURNING id
        """, (
            request.tab_group.strip(),
            tab_name,
            request.tab_href.strip(),
            request.tab_permission.strip(),
            request.sort_order
        ))

        tab_id = cur.fetchone()[0]

        conn.commit()

        generate_settings_page(
            request.tab_href.strip(),
            tab_name,
            request.tab_permission.strip(),
            page_tabs_section_label(
                request.tab_group.strip()
            ),
            page_tabs_hub_label(
                request.tab_group.strip()
            )
        )

        return {
            "success": True,
            "tab_id": tab_id
        }

    finally:
        cur.close()
        conn.close()

@app.post("/page-tabs/{tab_id}/update")
@fires_portal_event(
    "Settings Changes",
    "Tab Updated"
)
def update_page_tab(
    tab_id: int,
    request: PageTabUpdateRequest
):

    tab_name = request.tab_name.strip()

    if not tab_name:
        return {
            "success": False,
            "message": "Tab name is required"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            UPDATE page_tabs
            SET tab_name = %s,
                tab_href = %s,
                tab_permission = %s,
                sort_order = %s
            WHERE id = %s
        """, (
            tab_name,
            request.tab_href.strip(),
            request.tab_permission.strip(),
            request.sort_order,
            tab_id
        ))

        updated = cur.rowcount > 0

        conn.commit()

        if updated:

            cur.execute("""
                SELECT tab_group
                FROM page_tabs
                WHERE id = %s
            """, (tab_id,))

            row = cur.fetchone()

            if row:
                generate_settings_page(
                    request.tab_href.strip(),
                    tab_name,
                    request.tab_permission.strip(),
                    page_tabs_section_label(row[0]),
                    page_tabs_hub_label(row[0])
                )

        return {
            "success": updated
        }

    finally:
        cur.close()
        conn.close()

@app.post("/page-tabs/{tab_id}/delete")
def delete_page_tab(tab_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            DELETE FROM page_tabs
            WHERE id = %s
        """, (tab_id,))

        conn.commit()

        return {
            "success": cur.rowcount > 0
        }

    finally:
        cur.close()
        conn.close()


class LoginNotificationRequest(BaseModel):
    notification_channel: str
    notification_type: str
    target_username: str
    enabled: bool = True
    rule_function: str = "Login Notification"
    login_custom_message: str = ""
    logout_custom_message: str = ""
    failed_custom_message: str = ""


@app.get("/monitor/login-notifications")
def get_login_notifications():

    conn = monitoring_db()
    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT id,
                   rule_function,
                   notification_channel,
                   notification_type,
                   target_username,
                   enabled,
                   created_at,
                   login_custom_message,
                   logout_custom_message,
                   failed_custom_message
            FROM monitoring.login_notification_rules
            ORDER BY id
        """)

        rows = cur.fetchall()

        return [
            {
                "id": r[0],
                "rule_function": r[1],
                "notification_channel": r[2],
                "notification_type": r[3],
                "target_username": r[4],
                "enabled": r[5],
                "created_at": str(r[6]),
                "login_custom_message": r[7],
                "logout_custom_message": r[8],
                "failed_custom_message": r[9]
            }
            for r in rows
        ]

    finally:
        cur.close()
        conn.close()

@app.post("/monitor/login-notifications/create")
def create_login_notification(
    request: LoginNotificationRequest
):

    conn = monitoring_db()
    cur = conn.cursor()

    try:
        cur.execute("""
            INSERT INTO monitoring.login_notification_rules
            (
                notification_channel,
                notification_type,
                target_username,
                enabled,
                rule_function,
                login_custom_message,
                logout_custom_message,
                failed_custom_message
            )
            VALUES
            (%s,%s,%s,%s,%s,%s,%s,%s)
            RETURNING id
        """, (
            request.notification_channel.strip(),
            request.notification_type.strip(),
            request.target_username.strip(),
            request.enabled,
            request.rule_function.strip(),
            request.login_custom_message.strip(),
            request.logout_custom_message.strip(),
            request.failed_custom_message.strip()
        ))

        rule_id = cur.fetchone()[0]
        conn.commit()

        return {
            "success": True,
            "rule_id": rule_id
        }

    finally:
        cur.close()
        conn.close()

@app.post("/monitor/login-notifications/{rule_id}/update")
def update_login_notification(
    rule_id: int,
    request: LoginNotificationRequest
):

    conn = monitoring_db()
    cur = conn.cursor()

    try:
        cur.execute("""
            UPDATE monitoring.login_notification_rules
            SET notification_channel = %s,
                notification_type = %s,
                target_username = %s,
                enabled = %s,
                rule_function = %s,
                login_custom_message = %s,
                logout_custom_message = %s,
                failed_custom_message = %s
            WHERE id = %s
        """, (
            request.notification_channel.strip(),
            request.notification_type.strip(),
            request.target_username.strip(),
            request.enabled,
            request.rule_function.strip(),
            request.login_custom_message.strip(),
            request.logout_custom_message.strip(),
            request.failed_custom_message.strip(),
            rule_id
        ))

        conn.commit()

        return {
            "success": cur.rowcount > 0
        }

    finally:
        cur.close()
        conn.close()

@app.post("/monitor/login-notifications/{rule_id}/delete")
def delete_login_notification(rule_id: int):

    conn = monitoring_db()
    cur = conn.cursor()

    try:
        cur.execute("""
            DELETE FROM monitoring.login_notification_rules
            WHERE id = %s
        """, (rule_id,))

        conn.commit()

        return {
            "success": cur.rowcount > 0
        }

    finally:
        cur.close()
        conn.close()


from notifier import send_test, send_notification


class NotificationTestRequest(BaseModel):
    channel: str
    to: str = ""


@app.post("/notifications/test")
def test_notification(
    request: NotificationTestRequest
):

    """
    Sends a test notification through a
    channel using its stored settings so the
    backend path to the channel service can
    be verified end to end.
    """

    return send_test(
        request.channel,
        {"to": request.to}
    )



def login_notification_target_contact(
    username,
    kind
):

    """
    Resolves the contact details of a login
    notification rule's target user from the
    portal user profiles.
    """

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT email_address,
                   country_code,
                   mobile_number
            FROM user_profiles
            WHERE lower(username) = lower(%s)
        """, (username,))

        row = cur.fetchone()

        if not row:
            return {
                "success": False,
                "message": (
                    "Target user '%s' has no "
                    "portal profile." % username
                )
            }

        email, country_code, mobile = row

        if kind == "email":

            if not (email or "").strip():
                return {
                    "success": False,
                    "message": (
                        "Target user '%s' has no "
                        "email address on their "
                        "profile." % username
                    )
                }

            return {
                "success": True,
                "recipient": email.strip()
            }

        if kind == "whatsapp":

            number = (mobile or "").strip()

            if not number:
                return {
                    "success": False,
                    "message": (
                        "Target user '%s' has no "
                        "mobile number on their "
                        "profile." % username
                    )
                }

            cc = (country_code or "").strip()

            digits = "".join(
                ch
                for ch in number
                if ch.isdigit()
            )

            if cc:
                cc_digits = "".join(
                    ch
                    for ch in cc
                    if ch.isdigit()
                )

                if digits.startswith("0"):
                    digits = cc_digits + digits[1:]
                elif not digits.startswith(cc_digits):
                    digits = cc_digits + digits

            return {
                "success": True,
                "recipient": digits
            }

        return {"success": True, "recipient": ""}

    finally:
        cur.close()
        conn.close()


@app.post(
    "/monitor/login-notifications/{rule_id}/test"
)
def test_login_notification_rule(rule_id: int):

    """
    Fires a test alert through a configured
    login notification rule so the whole path
    - rule, channel settings and the target
    user - can be verified end to end.
    """

    conn = monitoring_db()
    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT notification_channel,
                   notification_type,
                   target_username,
                   enabled,
                   login_custom_message,
                   logout_custom_message,
                   failed_custom_message
            FROM monitoring.login_notification_rules
            WHERE id = %s
        """, (rule_id,))

        row = cur.fetchone()

        if not row:
            return {
                "success": False,
                "message": "Rule not found."
            }

        channel = (row[0] or "").strip().lower()
        rule_type = (row[1] or "").strip()
        target = (row[2] or "").strip()
        enabled = row[3]
        login_message = (row[4] or "").strip()
        logout_message = (row[5] or "").strip()
        failed_message = (row[6] or "").strip()

        if not enabled:
            return {
                "success": False,
                "message": (
                    "This rule is disabled."
                )
            }

        recipient = ""

        if channel in ("email", "whatsapp"):

            # An All Users rule has no single
            # target user; the test alert is
            # delivered to the admin profile
            # so the path can still be
            # verified.
            contact_target = (
                "admin"
                if target.lower() == "all"
                else target
            )

            contact = (
                login_notification_target_contact(
                    contact_target,
                    channel
                )
            )

            if not contact.get("success"):
                return contact

            recipient = contact["recipient"]

        default_message = (
            "Test alert for the Login "
            "Notification rule (%s - %s). "
            "If you received this, the rule "
            "works." % (rule_type, target)
        )

        # The message shown/fired follows
        # the rule type; All falls back
        # through the fields in order.

        if rule_type == "Failed Login":
            message = (
                failed_message
                if failed_message
                else default_message
            )

        elif rule_type == "Logout":
            message = (
                logout_message
                if logout_message
                else default_message
            )

        else:
            message = (
                login_message
                or failed_message
                or logout_message
                or default_message
            )

        return send_notification(
            channel,
            "Portal Test Alert",
            message,
            recipient
        )

    finally:
        cur.close()
        conn.close()


# ============================================================
# MONITOR BOARD FEEDS: the login feed, the merged live
# activity ticker, and the portal unblock request queue.
# ============================================================

@app.get("/api/monitoring/logins")
def list_login_events(limit: int = 20):

    """The monitor board login feed: the
    most recent sign-in / sign-out
    events, newest first."""

    limit = max(1, min(limit, 100))

    conn = monitoring_db()
    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT username,
                   event,
                   created_at
            FROM monitoring.login_events
            ORDER BY created_at DESC
            LIMIT %s
        """, (limit,))

        return [
            {
                "username": r[0],
                "event": r[1],
                "created_at": str(r[2]),
            }
            for r in cur.fetchall()
        ]
    finally:
        cur.close()
        conn.close()


@app.get("/api/monitoring/events")
def list_activity_events(
    limit: int = 30,
    include_logins: int = 0,
    include_requests: int = 1
):

    """The monitor board live ticker: login
    events merged with DNS request activity
    into one time ordered feed. The caller
    only receives the parts its portal
    permissions allow."""

    limit = max(1, min(limit, 100))
    events = []

    if include_logins:
        try:
            conn = monitoring_db()
            cur = conn.cursor()
            try:
                cur.execute("""
                    SELECT username,
                           event,
                           created_at
                    FROM monitoring.login_events
                    ORDER BY created_at DESC
                    LIMIT %s
                """, (limit,))
                for r in cur.fetchall():
                    events.append({
                        "time": str(r[2]),
                        "kind": "login",
                        "text": (
                            str(r[1] or "Event")
                            + " - "
                            + str(r[0] or "?")
                        )
                    })
            finally:
                cur.close()
                conn.close()
        except Exception:
            pass

    if include_requests:
        try:
            conn = psycopg2.connect(
                host=POSTGRES_HOST,
                database=POSTGRES_DB,
                user=POSTGRES_USER,
                password=POSTGRES_PASSWORD
            )
            cur = conn.cursor()
            try:
                cur.execute("""
                    SELECT domain,
                           status,
                           requested_at,
                           approved_at,
                           denied_at,
                           submitted_by
                    FROM requests
                    ORDER BY id DESC
                    LIMIT %s
                """, (limit,))
                for r in cur.fetchall():
                    if r[5]:
                        events.append({
                            "time": str(r[2]),
                            "kind": "unblock",
                            "text": "Unblock request - "
                                + str(r[0])
                        })
                    else:
                        events.append({
                            "time": str(r[2]),
                            "kind": "request",
                            "text": "Site request - "
                                + str(r[0])
                        })
                    if r[1] == "Approved" and r[3]:
                        events.append({
                            "time": str(r[3]),
                            "kind": "approved",
                            "text": "Approved - "
                                + str(r[0])
                        })
                    if r[1] == "Denied" and r[4]:
                        events.append({
                            "time": str(r[4]),
                            "kind": "denied",
                            "text": "Denied - "
                                + str(r[0])
                        })
            finally:
                cur.close()
                conn.close()
        except Exception:
            pass

    events.sort(
        key=lambda e: e["time"],
        reverse=True
    )

    return events[:limit]


@app.get("/unblocks")
def unblock_queue(limit: int = 20):

    """The monitor board unblock card: the
    site unblock requests that portal
    users submitted from the Request
    Unblock page that are still waiting
    for a decision."""

    limit = max(1, min(limit, 100))

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )
    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT id,
                   domain,
                   requested_by,
                   requested_at,
                   allow_minutes
            FROM requests
            WHERE status = 'Pending'
              AND submitted_by IS NOT NULL
            ORDER BY requested_at DESC
            LIMIT %s
        """, (limit,))

        return [
            {
                "id": r[0],
                "domain": r[1],
                "requested_by": r[2],
                "requested_at": str(r[3]),
                "allow_minutes": r[4],
            }
            for r in cur.fetchall()
        ]
    finally:
        cur.close()
        conn.close()


class LoginEventRequest(BaseModel):
    event: str
    username: str
    source_ip: str = ""


@app.post("/monitor/login-notifications/dispatch")
def dispatch_login_event(
    request: LoginEventRequest
):

    """
    The login notification engine. Fired by the
    portal sign-in and sign-out pages: finds the
    enabled rules that watch this user for this
    event and sends each one through its channel
    with the rule's custom message.
    """

    event = (request.event or "").strip().lower()
    username = (request.username or "").strip()

    events = {
        "successful_login": "Successful Login",
        "failed_login": "Failed Login",
        "logout": "Logout"
    }

    if event not in events or not username:
        return {
            "success": False,
            "fired": 0,
            "message": (
                "Unknown event or empty username."
            )
        }

    type_name = events[event]

    custom_column = {
        "successful_login": 4,
        "failed_login": 6,
        "logout": 5
    }[event]

    default_message = {
        "successful_login": (
            "User %s signed in to the "
            "portal." % username
        ),
        "failed_login": (
            "Failed portal sign-in attempt "
            "for %s." % username
        ),
        "logout": (
            "User %s signed out of the "
            "portal." % username
        )
    }[event]

    # keep the login feed on the monitor
    # board up to date; a failure here
    # must never break the notification

    try:
        event_conn = monitoring_db()
        event_cur = event_conn.cursor()
        try:
            event_cur.execute(
                """
                INSERT INTO monitoring.login_events
                (username, event, source_ip)
                VALUES (%s, %s, %s)
                """,
                (
                    username,
                    type_name,
                    (request.source_ip or "").strip() or None
                )
            )
            event_conn.commit()
        finally:
            event_cur.close()
            event_conn.close()
    except Exception as error:
        print(
            "[monitor] login event log "
            "failed: %s" % error,
            flush=True
        )

    conn = monitoring_db()
    cur = conn.cursor()

    fired = 0

    try:
        cur.execute("""
            SELECT id,
                   notification_channel,
                   notification_type,
                   target_username,
                   login_custom_message,
                   logout_custom_message,
                   failed_custom_message
            FROM monitoring.login_notification_rules
            WHERE enabled
              AND rule_function
                  = 'Login Notification'
              AND (
                  lower(target_username)
                      = lower(%s)
                  OR lower(target_username)
                      = 'all'
              )
        """, (username,))

        rules = cur.fetchall()

        for rule in rules:

            rule_type = (rule[2] or "").strip()

            if (
                rule_type != "All"
                and rule_type != type_name
            ):
                continue

            channel = (
                rule[1] or ""
            ).strip().lower()

            custom_message = (
                rule[custom_column] or ""
            ).strip()

            message = (
                custom_message
                if custom_message
                else default_message
            )

            recipient = ""

            if channel in ("email", "whatsapp"):

                contact = (
                    login_notification_target_contact(
                        username,
                        channel
                    )
                )

                if not contact.get("success"):
                    continue

                recipient = contact["recipient"]

            send_notification(
                channel,
                "Portal Monitor Alert",
                message,
                recipient
            )

            fired += 1

        return {
            "success": True,
            "fired": fired
        }

    finally:
        cur.close()
        conn.close()


@app.get("/permissions")
def get_permissions():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            id,
            permission_name,
            parent_id
        FROM permissions
        ORDER BY parent_id NULLS FIRST, id
    """)

    permissions = cur.fetchall()

    cur.close()
    conn.close()

    return permissions

@app.get("/groups/{group_id}/permissions")
def get_group_permissions(group_id: int):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT permission_id
        FROM group_permissions
        WHERE group_id = %s
    """, (group_id,))

    rows = cur.fetchall()
    
    cur.close()
    conn.close()
    
    return [row[0] for row in rows]

class GroupPermissionRequest(BaseModel):
    group_id: int
    permissions: list[int]
    
@app.post("/groups/permissions/save")
@fires_portal_event(
    "Group Activity",
    "Group Updated"
)
def save_group_permissions(
    request: GroupPermissionRequest
):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        DELETE
        FROM group_permissions
        WHERE group_id = %s
    """,
    (
        request.group_id,
    ))

    for permission_id in request.permissions:

        cur.execute("""
            INSERT INTO group_permissions
            (
                group_id,
                permission_id
            )
            VALUES
            (
                %s,
                %s
            )
        """,
        (
            request.group_id,
            permission_id
        ))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }
  
@app.get("/permissions/tree")
def get_permissions_tree():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            id,
            permission_name,
            parent_id
        FROM permissions
        ORDER BY id
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    # Clean portal v2: the Technitium permission subtree only appears
    # when the Technitium backend is active. The Services section and
    # the Network permission are portal-native and always shown.
    if _portal_setting_get("dns_provider") != "technitium":
        by_id = {row[0]: (row[1], row[2]) for row in rows}

        def technitium_owned(row):
            current = (row[1], row[2])
            while current:
                name, parent_id = current
                if name in ("Technitium", "DNS Server Status"):
                    return True
                current = by_id.get(parent_id) if parent_id else None
            return False

        rows = [row for row in rows if not technitium_owned(row)]

    # Symmetric: the NetFortress permission only appears when the
    # NetFortress backend is active.
    if _portal_setting_get("dns_provider") != "firewall":

        by_id = {row[0]: (row[1], row[2]) for row in rows}

        def netfortress_owned(row):
            current = (row[1], row[2])
            while current:
                name, parent_id = current
                if name == "NetFortress":
                    return True
                current = by_id.get(parent_id) if parent_id else None
            return False

        rows = [row for row in rows if not netfortress_owned(row)]

    permissions = {}

    for row in rows:

        permission_id = row[0]
        permission_name = row[1]
        parent_id = row[2]

        permissions[permission_id] = {
            "id": permission_id,
            "name": permission_name,
            "children": []
        }

    tree = []

    for row in rows:

        permission_id = row[0]
        parent_id = row[2]

        if parent_id is None:

            tree.append(
                permissions[permission_id]
            )

        else:

            permissions[parent_id][
                "children"
            ].append(
                permissions[permission_id]
            )

    return tree
    
@app.get("/users/{username}/group")
def get_user_group(username: str):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT group_id
        FROM user_groups
        WHERE LOWER(username) = LOWER(%s)
    """, (username,))

    row = cur.fetchone()

    cur.close()
    conn.close()

    if row:
        return {
            "group_id": row[0]
        }

    return {
        "group_id": None
    }

class UserGroupRequest(BaseModel):
    username: str
    group_id: int
    
@app.get("/users/groups")
def get_user_groups():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            ug.username,
            g.group_name
        FROM user_groups ug
        JOIN groups g
            ON ug.group_id = g.id
    """)

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return {
        row[0]: row[1]
        for row in rows
    }


@app.post("/users/group/save")
def save_user_group(request: UserGroupRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        UPDATE user_groups
        SET group_id = %s
        WHERE LOWER(username) = LOWER(%s)
    """,
    (
        request.group_id,
        request.username
    ))

    if cur.rowcount == 0:
        cur.execute("""
            INSERT INTO user_groups
            (
                username,
                group_id
            )
            VALUES
            (
                %s,
                %s
            )
        """,
        (
            request.username,
            request.group_id
        ))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }


@app.on_event("startup")
async def startup_scheduler():

    async def run():

        while True:

            await process_expired_allows()

            await asyncio.sleep(15)

    asyncio.create_task(run())
    
@app.get("/users/{username}/permissions")
def get_user_permissions(username: str):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            p.permission_name
        FROM user_groups ug
        JOIN group_permissions gp
            ON ug.group_id = gp.group_id
        JOIN permissions p
            ON gp.permission_id = p.id
        WHERE LOWER(ug.username) = LOWER(%s)
        ORDER BY p.permission_name
    """,
    (
        username,
    ))

    rows = cur.fetchall()

    cur.close()
    conn.close()

    return [
        row[0]
        for row in rows
    ]
    
def provider_account_limit_message():
    """Return an error message if the deployment licence does not
    allow another user account, else None.

    Deployment option 2 pairs the portal with the NetFortress
    Firewall Appliance, and the appliance licence is the
    deployment's licence - so its account limit applies to
    portal accounts (the portal owns all user management).
    Providers without licensing (Technitium) report no limit.

    Fails open: if the limit cannot be determined, user
    management continues; the engine still enforces its own
    licence where it applies."""
    try:
        limit = get_provider().account_limit()
        if limit is None:
            return None

        conn = psycopg2.connect(
            host=POSTGRES_HOST,
            database=POSTGRES_DB,
            user=POSTGRES_USER,
            password=POSTGRES_PASSWORD
        )
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM user_profiles")
        count = cur.fetchone()[0]
        cur.close()
        conn.close()

        if count >= limit:
            return (
                "Your licence allows "
                f"{limit} account{'s' if limit != 1 else ''}. "
                "Upgrade to add more."
            )
        return None
    except Exception:
        return None


class UserProfileCreate(BaseModel):
    username: str
    display_name: str
    surname: str | None = None
    email_address: str | None = None
    country_code: str | None = None
    mobile_number: str | None = None
    department: str | None = None
    photo: str | None = None
    group_id: int | None = None
    
@app.post("/user-profiles/create")
def create_user_profile(profile: UserProfileCreate):

    username = profile.username.strip()

    if not username:
        return {
            "success": False,
            "message": "Username is required"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT 1
            FROM user_profiles
            WHERE LOWER(username) = LOWER(%s)
            LIMIT 1
        """, (username,))

        if cur.fetchone():
            return {
                "success": False,
                "message": "Username is not available"
            }

        licence_message = provider_account_limit_message()
        if licence_message:
            return {
                "success": False,
                "message": licence_message
            }

        import secrets as _secrets

        sync_result = get_provider().create_user(
            username, _secrets.token_hex(16)
        )

        if not sync_result.get("ok"):
            return {
                "success": False,
                "message": sync_result.get(
                    "message", "Maximum user count reached on the Firewall Appliance licence"
                )
            }

        cur.execute("""
            INSERT INTO user_profiles
            (
                username,
                display_name,
                surname,
                email_address,
                country_code,
                mobile_number,
                department,
                photo,
                group_id
            )
            VALUES
            (%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """, (
            username,
            profile.display_name,
            profile.surname,
            profile.email_address,
            profile.country_code,
            profile.mobile_number,
            profile.department,
            profile.photo,
            profile.group_id
        ))

        conn.commit()

        return {
            "success": True
        }

    except psycopg2.IntegrityError:
        conn.rollback()

        return {
            "success": False,
            "message": "Username is not available"
        }

    finally:
        cur.close()
        conn.close()


@app.get("/user-profiles")
def get_user_profiles():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            id,
            username,
            display_name,
            surname,
            department,
            email_address,
            country_code,
            mobile_number,
            photo,
            group_id
        FROM user_profiles
    """)

    rows = cur.fetchall()

    profiles = []

    for row in rows:
        profiles.append({
            "id": row[0],
            "username": row[1],
            "display_name": row[2],
            "surname": row[3],
            "department": row[4],
            "email_address": row[5],
            "country_code": row[6],
            "mobile_number": row[7],
            "photo": row[8],
            "group_id": row[9]
        })

    cur.close()
    conn.close()

    return profiles
    
class DeleteUserProfileRequest(BaseModel):
    username: str


@app.post("/user-profiles/delete")
def delete_user_profile(user: DeleteUserProfileRequest):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    # Remove profile
    cur.execute("""
        DELETE
        FROM user_profiles
        WHERE LOWER(username) = LOWER(%s)
    """, (user.username,))

    # Remove group assignment
    cur.execute("""
        DELETE
        FROM user_groups
        WHERE LOWER(username) = LOWER(%s)
    """, (user.username,))

    conn.commit()

    cur.close()
    conn.close()

    return {
        "success": True
    }
    
@app.get("/user-profiles/{username}")
def get_user_profile(username: str):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute("""
        SELECT
            id,
            username,
            display_name,
            surname,
            department,
            email_address,
            country_code,
            mobile_number,
            photo,
            group_id
        FROM user_profiles
        WHERE LOWER(username) = LOWER(%s)
    """, (username,))

    row = cur.fetchone()

    cur.close()
    conn.close()

    if not row:
        return {}

    return {
        "id": row[0],
        "username": row[1],
        "display_name": row[2],
        "surname": row[3],
        "department": row[4],
        "email_address": row[5],
        "country_code": row[6],
        "mobile_number": row[7],
        "photo": row[8],
        "group_id": row[9]
    }
    

PROFILE_IMAGE_ROOT = "/opt/portal/web/uploads/profiles"


def controlled_profile_photo_path(
    photo: str | None
) -> str | None:

    if not photo:
        return None

    match = re.fullmatch(
        r"uploads/profiles/(profile_[a-f0-9]{32}\.webp)",
        photo
    )

    if not match:
        return None

    return os.path.join(
        PROFILE_IMAGE_ROOT,
        match.group(1)
    )


def delete_unreferenced_profile_photo(
    photo: str | None
) -> None:

    path = controlled_profile_photo_path(photo)

    if path is None:
        return

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute(
            """
            SELECT COUNT(*)
            FROM user_profiles
            WHERE photo = %s
            """,
            (photo,)
        )

        row = cur.fetchone()

        reference_count = (
            int(row[0])
            if row
            else 0
        )

    finally:
        cur.close()
        conn.close()

    if reference_count != 0:
        return

    try:
        os.unlink(path)
    except FileNotFoundError:
        pass
    except OSError:
        # Photo cleanup must never roll back or falsely report
        # failure after the database profile was committed.
        pass


class UserProfileUpdate(BaseModel):
    username: str
    display_name: str
    surname: str | None = None
    department: str | None = None
    email_address: str | None = None
    country_code: str | None = None
    mobile_number: str | None = None
    photo: str | None = None
    group_id: int | None = None


@app.post("/user-profiles/update")
def update_user_profile(profile: UserProfileUpdate):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    cur.execute(
        """
        SELECT photo
        FROM user_profiles
        WHERE LOWER(username) = LOWER(%s)
        LIMIT 1
        """,
        (profile.username,)
    )

    previous_row = cur.fetchone()

    previous_photo = (
        previous_row[0]
        if previous_row
        else None
    )

    cur.execute("""
        UPDATE user_profiles
        SET
            display_name = %s,
            surname = %s,
            department = %s,
            email_address = %s,
            country_code = %s,
            mobile_number = %s,
            photo = %s,
            group_id = %s
        WHERE LOWER(username) = LOWER(%s)
    """,
    (
        profile.display_name,
        profile.surname,
        profile.department,
        profile.email_address,
        profile.country_code,
        profile.mobile_number,
        profile.photo,
        profile.group_id,
        profile.username
    ))

    if cur.rowcount == 0:
        licence_message = provider_account_limit_message()
        if licence_message:
            cur.close()
            conn.close()

            return {
                "success": False,
                "message": licence_message
            }

        import secrets as _secrets

        sync_result = get_provider().create_user(
            profile.username, _secrets.token_hex(16)
        )

        if not sync_result.get("ok"):
            cur.close()
            conn.close()

            return {
                "success": False,
                "message": sync_result.get(
                    "message", "Maximum user count reached on the Firewall Appliance licence"
                )
            }

        cur.execute("""
            INSERT INTO user_profiles
            (
                username,
                display_name,
                surname,
                department,
                email_address,
                country_code,
                mobile_number,
                photo,
                group_id
            )
            VALUES
            (%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """,
        (
            profile.username,
            profile.display_name,
            profile.surname,
            profile.department,
            profile.email_address,
            profile.country_code,
            profile.mobile_number,
            profile.photo,
            profile.group_id
        ))

    conn.commit()

    cur.close()
    conn.close()

    new_photo = (
        profile.photo.strip()
        if profile.photo
        else ""
    )

    old_photo = (
        previous_photo.strip()
        if previous_photo
        else ""
    )

    if (
        old_photo
        and
        old_photo != new_photo
    ):
        # The profile database transaction has already committed.
        # Previous-image cleanup is best-effort only. A cleanup
        # problem must never turn a committed update into HTTP 500.
        try:
            delete_unreferenced_profile_photo(
                old_photo
            )
        except Exception:
            pass

    return {
        "success": True
    }


# ------------------------------------------------------------
# Custom User Fields
# ------------------------------------------------------------


CUSTOM_FIELD_TYPES = {
    "text",
    "textarea",
    "email",
    "number",
    "date",
    "checkbox"
}


def make_custom_field_key(
    field_name: str
) -> str:

    key = field_name.strip().lower()

    key = re.sub(
        r"[^a-z0-9]+",
        "_",
        key
    )

    key = key.strip("_")

    if not key:
        raise ValueError(
            "Field name must contain letters or numbers"
        )

    if not key[0].isalpha():
        key = "field_" + key

    return key


class CustomFieldSectionCreateRequest(BaseModel):
    section_name: str
    sort_order: int = 0


class CustomFieldSectionUpdateRequest(BaseModel):
    section_name: str
    sort_order: int = 0


@app.get("/user-custom-field-sections")
def get_user_custom_field_sections():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        cur.execute("""
            SELECT
                id,
                section_name,
                sort_order,
                created_at
            FROM user_custom_field_sections
            ORDER BY
                sort_order,
                id
        """)

        rows = cur.fetchall()

        return [
            {
                "id": row[0],
                "section_name": row[1],
                "sort_order": row[2],
                "created_at": (
                    row[3].isoformat()
                    if row[3]
                    else None
                )
            }
            for row in rows
        ]

    finally:

        cur.close()
        conn.close()


@app.post("/user-custom-field-sections/create")
def create_user_custom_field_section(
    request: CustomFieldSectionCreateRequest
):

    section_name = request.section_name.strip()

    if not section_name:
        return {
            "success": False,
            "message": "Section name is required"
        }

    if len(section_name) > 100:
        return {
            "success": False,
            "message": "Section name is too long"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        cur.execute("""
            INSERT INTO user_custom_field_sections
            (
                section_name,
                sort_order
            )
            VALUES
            (%s,%s)
            RETURNING id
        """, (
            section_name,
            request.sort_order
        ))

        section_id = cur.fetchone()[0]

        conn.commit()

        return {
            "success": True,
            "id": section_id,
            "section_name": section_name,
            "sort_order": request.sort_order
        }

    except psycopg2.IntegrityError:

        conn.rollback()

        return {
            "success": False,
            "message": (
                "A custom field section with this name "
                "already exists"
            )
        }

    finally:

        cur.close()
        conn.close()


@app.post("/user-custom-field-sections/{section_id}/update")
def update_user_custom_field_section(
    section_id: int,
    request: CustomFieldSectionUpdateRequest
):

    section_name = request.section_name.strip()

    if not section_name:
        return {
            "success": False,
            "message": "Section name is required"
        }

    if len(section_name) > 100:
        return {
            "success": False,
            "message": "Section name is too long"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        cur.execute("""
            UPDATE user_custom_field_sections
            SET
                section_name = %s,
                sort_order = %s
            WHERE id = %s
            RETURNING id
        """, (
            section_name,
            request.sort_order,
            section_id
        ))

        row = cur.fetchone()

        if not row:

            conn.rollback()

            return {
                "success": False,
                "message": "Custom field section not found"
            }

        conn.commit()

        return {
            "success": True,
            "id": row[0],
            "section_name": section_name,
            "sort_order": request.sort_order
        }

    except psycopg2.IntegrityError:

        conn.rollback()

        return {
            "success": False,
            "message": (
                "A custom field section with this name "
                "already exists"
            )
        }

    finally:

        cur.close()
        conn.close()


@app.post("/user-custom-field-sections/{section_id}/delete")
def delete_user_custom_field_section(
    section_id: int
):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        cur.execute("""
            SELECT COUNT(*)
            FROM user_custom_fields
            WHERE section_id = %s
        """, (
            section_id,
        ))

        field_count = cur.fetchone()[0]

        if field_count > 0:

            return {
                "success": False,
                "message": (
                    "This section still contains custom fields. "
                    "Delete or move those fields first."
                )
            }

        cur.execute("""
            DELETE
            FROM user_custom_field_sections
            WHERE id = %s
            RETURNING id
        """, (
            section_id,
        ))

        row = cur.fetchone()

        if not row:

            conn.rollback()

            return {
                "success": False,
                "message": "Custom field section not found"
            }

        conn.commit()

        return {
            "success": True,
            "id": row[0]
        }

    finally:

        cur.close()
        conn.close()


class CustomFieldCreateRequest(BaseModel):
    field_name: str
    field_type: str = "text"
    required: bool = False
    sort_order: int = 0
    section_id: int
    prepend: str = ""


class CustomFieldUpdateRequest(BaseModel):
    field_name: str
    field_type: str
    required: bool = False
    sort_order: int = 0
    section_id: int
    prepend: str = ""


@app.post("/user-custom-fields/create")
def create_user_custom_field(
    request: CustomFieldCreateRequest
):

    field_name = request.field_name.strip()
    field_type = request.field_type.strip().lower()
    prepend = request.prepend.strip()

    if not field_name:
        return {
            "success": False,
            "message": "Field name is required"
        }

    if len(field_name) > 100:
        return {
            "success": False,
            "message": "Field name is too long"
        }

    if field_type not in CUSTOM_FIELD_TYPES:
        return {
            "success": False,
            "message": "Invalid field type"
        }

    if len(prepend) > 50:
        return {
            "success": False,
            "message": "Prepend is too long"
        }

    try:
        field_key = make_custom_field_key(
            field_name
        )
    except ValueError as error:
        return {
            "success": False,
            "message": str(error)
        }

    if len(field_key) > 100:
        return {
            "success": False,
            "message": "Generated field key is too long"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        cur.execute("""
            SELECT 1
            FROM user_custom_field_sections
            WHERE id = %s
            LIMIT 1
        """, (
            request.section_id,
        ))

        if not cur.fetchone():
            return {
                "success": False,
                "message": "Custom field section not found"
            }

        cur.execute("""
            INSERT INTO user_custom_fields
            (
                field_name,
                field_key,
                field_type,
                required,
                sort_order,
                section_id,
                prepend
            )
            VALUES
            (%s,%s,%s,%s,%s,%s,%s)
            RETURNING id
        """, (
            field_name,
            field_key,
            field_type,
            request.required,
            request.sort_order,
            request.section_id,
            prepend
        ))

        field_id = cur.fetchone()[0]

        conn.commit()

        return {
            "success": True,
            "id": field_id,
            "field_name": field_name,
            "field_key": field_key,
            "section_id": request.section_id,
            "prepend": prepend
        }

    except psycopg2.IntegrityError:

        conn.rollback()

        return {
            "success": False,
            "message": (
                "A custom field with this internal "
                "field key already exists"
            )
        }

    finally:

        cur.close()
        conn.close()


@app.post("/user-custom-fields/{field_id}/update")
def update_user_custom_field(
    field_id: int,
    request: CustomFieldUpdateRequest
):

    field_name = request.field_name.strip()
    field_type = request.field_type.strip().lower()
    prepend = request.prepend.strip()

    if not field_name:
        return {
            "success": False,
            "message": "Field name is required"
        }

    if len(field_name) > 100:
        return {
            "success": False,
            "message": "Field name is too long"
        }

    if field_type not in CUSTOM_FIELD_TYPES:
        return {
            "success": False,
            "message": "Invalid field type"
        }

    if len(prepend) > 50:
        return {
            "success": False,
            "message": "Prepend is too long"
        }

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        # field_key is intentionally NOT updated.
        # It is the permanent internal identity of
        # the custom field.

        cur.execute("""
            SELECT 1
            FROM user_custom_field_sections
            WHERE id = %s
            LIMIT 1
        """, (
            request.section_id,
        ))

        if not cur.fetchone():
            return {
                "success": False,
                "message": "Custom field section not found"
            }

        cur.execute("""
            UPDATE user_custom_fields
            SET
                field_name = %s,
                field_type = %s,
                required = %s,
                sort_order = %s,
                section_id = %s,
                prepend = %s
            WHERE id = %s
            RETURNING
                id,
                field_key
        """, (
            field_name,
            field_type,
            request.required,
            request.sort_order,
            request.section_id,
            prepend,
            field_id
        ))

        row = cur.fetchone()

        if not row:

            conn.rollback()

            return {
                "success": False,
                "message": "Custom field not found"
            }

        conn.commit()

        return {
            "success": True,
            "id": row[0],
            "field_name": field_name,
            "field_key": row[1],
            "section_id": request.section_id,
            "prepend": prepend
        }

    finally:

        cur.close()
        conn.close()


@app.post("/user-custom-fields/{field_id}/delete")
def delete_user_custom_field(
    field_id: int
):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        cur.execute("""
            DELETE
            FROM user_custom_fields
            WHERE id = %s
            RETURNING
                id,
                field_key
        """, (
            field_id,
        ))

        row = cur.fetchone()

        if not row:

            conn.rollback()

            return {
                "success": False,
                "message": "Custom field not found"
            }

        conn.commit()

        return {
            "success": True,
            "id": row[0],
            "field_key": row[1]
        }

    finally:

        cur.close()
        conn.close()


@app.get("/user-custom-fields")
def get_user_custom_fields():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        cur.execute("""
            SELECT
                f.id,
                f.field_name,
                f.field_key,
                f.field_type,
                f.required,
                f.sort_order,
                f.created_at,
                f.section_id,
                s.section_name,
                s.sort_order,
                COALESCE(f.prepend, '')
            FROM user_custom_fields f
            JOIN user_custom_field_sections s
                ON s.id = f.section_id
            ORDER BY
                s.sort_order,
                s.id,
                f.sort_order,
                f.id
        """)

        rows = cur.fetchall()

        return [
            {
                "id": row[0],
                "field_name": row[1],
                "field_key": row[2],
                "field_type": row[3],
                "required": row[4],
                "sort_order": row[5],
                "created_at": (
                    row[6].isoformat()
                    if row[6]
                    else None
                ),
                "section_id": row[7],
                "section_name": row[8],
                "section_sort_order": row[9],
                "prepend": row[10]
            }
            for row in rows
        ]

    finally:

        cur.close()
        conn.close()



class CustomFieldValueItem(BaseModel):
    field_id: int
    value: str | None = None


class CustomFieldValuesSaveRequest(BaseModel):
    values: list[CustomFieldValueItem]


@app.post("/user-custom-fields/user/{user_id}/save")
def save_user_custom_field_values(
    user_id: int,
    request: CustomFieldValuesSaveRequest
):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        cur.execute("""
            SELECT 1
            FROM user_profiles
            WHERE id = %s
            LIMIT 1
        """, (
            user_id,
        ))

        if not cur.fetchone():

            return {
                "success": False,
                "message": "User profile not found"
            }


        cur.execute("""
            SELECT
                id,
                field_name,
                field_type,
                required
            FROM user_custom_fields
            ORDER BY
                sort_order,
                id
        """)

        field_rows = cur.fetchall()

        fields = {
            row[0]: {
                "field_name": row[1],
                "field_type": row[2],
                "required": row[3]
            }
            for row in field_rows
        }


        submitted = {}

        for item in request.values:

            if item.field_id not in fields:

                return {
                    "success": False,
                    "message": (
                        "Unknown custom field ID: "
                        + str(item.field_id)
                    )
                }

            if item.field_id in submitted:

                return {
                    "success": False,
                    "message": (
                        "Duplicate custom field ID: "
                        + str(item.field_id)
                    )
                }

            value = (
                item.value
                if item.value is not None
                else ""
            )

            if fields[item.field_id]["field_type"] == "checkbox":

                value = (
                    "1"
                    if str(value).strip().lower()
                    in {
                        "1",
                        "true",
                        "yes",
                        "on"
                    }
                    else "0"
                )

            else:

                value = str(value).strip()


            field = fields[item.field_id]
            field_type = field["field_type"]
            field_name = field["field_name"]


            #
            # Empty optional values are valid and will be
            # removed from user_custom_field_values below.
            #
            # Required validation is performed separately
            # after all submitted fields are normalized.
            #
            if value and field_type == "email":

                #
                # Deliberately use practical structural
                # validation rather than attempting to
                # reproduce the complete email RFC.
                #
                if (
                    len(value) > 254
                    or not re.fullmatch(
                        r"[^@\s]+@[^@\s]+\.[^@\s]+",
                        value
                    )
                ):

                    return {
                        "success": False,
                        "message": (
                            field_name
                            + " must contain a valid email address"
                        )
                    }


            if value and field_type == "number":

                if not re.fullmatch(
                    r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)",
                    value
                ):

                    return {
                        "success": False,
                        "message": (
                            field_name
                            + " must contain a valid number"
                        )
                    }


            if value and field_type == "date":

                if not re.fullmatch(
                    r"\d{4}-\d{2}-\d{2}",
                    value
                ):

                    return {
                        "success": False,
                        "message": (
                            field_name
                            + " must contain a valid date"
                        )
                    }

                try:

                    date.fromisoformat(value)

                except ValueError:

                    return {
                        "success": False,
                        "message": (
                            field_name
                            + " must contain a valid date"
                        )
                    }


            submitted[item.field_id] = value


        for field_id, field in fields.items():

            if not field["required"]:
                continue

            value = submitted.get(
                field_id,
                ""
            )

            if (
                field["field_type"] == "checkbox"
                and value != "1"
            ):

                return {
                    "success": False,
                    "message": (
                        field["field_name"]
                        + " is required"
                    )
                }

            if (
                field["field_type"] != "checkbox"
                and not value
            ):

                return {
                    "success": False,
                    "message": (
                        field["field_name"]
                        + " is required"
                    )
                }


        for field_id, value in submitted.items():

            field = fields[field_id]

            should_delete = (
                value == ""
                or (
                    field["field_type"] == "checkbox"
                    and value == "0"
                )
            )

            if should_delete:

                cur.execute("""
                    DELETE
                    FROM user_custom_field_values
                    WHERE user_id = %s
                      AND field_id = %s
                """, (
                    user_id,
                    field_id
                ))

                continue


            cur.execute("""
                INSERT INTO user_custom_field_values
                (
                    user_id,
                    field_id,
                    field_value,
                    updated_at
                )
                VALUES
                (%s,%s,%s,CURRENT_TIMESTAMP)

                ON CONFLICT
                    (user_id, field_id)

                DO UPDATE SET
                    field_value = EXCLUDED.field_value,
                    updated_at = CURRENT_TIMESTAMP
            """, (
                user_id,
                field_id,
                value
            ))


        conn.commit()

        return {
            "success": True,
            "user_id": user_id
        }

    except Exception:

        conn.rollback()
        raise

    finally:

        cur.close()
        conn.close()


@app.get("/user-custom-fields/user/{user_id}")
def get_user_custom_field_values(
    user_id: int
):

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        cur.execute("""
            SELECT 1
            FROM user_profiles
            WHERE id = %s
            LIMIT 1
        """, (
            user_id,
        ))

        if not cur.fetchone():

            return {
                "success": False,
                "message": "User profile not found"
            }


        cur.execute("""
            SELECT
                f.id,
                f.field_name,
                f.field_key,
                f.field_type,
                f.required,
                f.sort_order,
                v.field_value,
                f.section_id,
                s.section_name,
                s.sort_order,
                COALESCE(f.prepend, '')
            FROM user_custom_fields f
            JOIN user_custom_field_sections s
                ON s.id = f.section_id
            LEFT JOIN user_custom_field_values v
                ON v.field_id = f.id
               AND v.user_id = %s
            ORDER BY
                s.sort_order,
                s.id,
                f.sort_order,
                f.id
        """, (
            user_id,
        ))

        rows = cur.fetchall()

        return {
            "success": True,
            "user_id": user_id,
            "fields": [
                {
                    "id": row[0],
                    "field_name": row[1],
                    "field_key": row[2],
                    "field_type": row[3],
                    "required": row[4],
                    "sort_order": row[5],
                    "value": (
                        row[6]
                        if row[6] is not None
                        else ""
                    ),
                    "section_id": row[7],
                    "section_name": row[8],
                    "section_sort_order": row[9],
                    "prepend": row[10]
                }
                for row in rows
            ]
        }

    finally:

        cur.close()
        conn.close()


class HttpsPortRequest(BaseModel):
    https_port: int

@app.post("/ssl/portal/save")
def save_https_port(
    request: HttpsPortRequest
):

    port = request.https_port

    if port < 1 or port > 65535:
        return {
            "success": False,
            "message": "Invalid port"
        }

    command = f"""
    /usr/bin/sed -i 's/listen [0-9]\\+ ssl;/listen {port} ssl;/' /etc/nginx/sites-available/default &&
    /usr/bin/sed -i 's/listen \\[::\\]:[0-9]\\+ ssl;/listen [::]:{port} ssl;/' /etc/nginx/sites-available/default &&
    /usr/sbin/nginx -t
    """

    result = subprocess.run(
        command,
        shell=True,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        return {
            "success": False,
            "message": result.stderr
        }

    reload_result = subprocess.run(
        [
            "/usr/bin/systemctl",
            "reload",
            "nginx"
        ],
        capture_output=True,
        text=True
    )

    if reload_result.returncode != 0:
        return {
            "success": False,
            "message": reload_result.stderr
        }

    return {
        "success": True,
        "https_port": port
    }

@app.get("/ssl/portal")
def ssl_portal():

    output = subprocess.check_output(
        [
            "/usr/bin/openssl",
            "x509",
            "-in",
            "/etc/ssl/portal/server.crt",
            "-noout",
            "-issuer",
            "-enddate"
        ],
        text=True
    )

    issuer = "Unknown"
    expires = "Unknown"

    for line in output.splitlines():

        if line.startswith("issuer="):

            issuer_raw = line.replace(
                "issuer=",
                ""
            ).strip()

            issuer = issuer_raw

            for part in issuer_raw.split(","):

                part = part.strip()

                if part.startswith("OU="):
                    issuer = part.replace(
                        "OU=",
                        ""
                    )
                    break

        elif line.startswith("notAfter="):

            raw_date = line.replace(
                "notAfter=",
                ""
            )

            dt = datetime.strptime(
                raw_date,
                "%b %d %H:%M:%S %Y %Z"
            )

            expires = dt.strftime(
                "%d %B %Y"
            )

    https_enabled = False
    https_port = 443

    https_result = subprocess.run(
        [
            "/usr/sbin/nginx",
            "-T"
        ],
        capture_output=True,
        text=True
    )

    if https_result.returncode == 0:

        for line in https_result.stdout.splitlines():

            line = line.strip()

            if (
                line.startswith("listen ")
                and "ssl" in line
                and "[::]" not in line
            ):

                parts = line.split()

                if len(parts) >= 2:

                    try:
                        https_port = int(parts[1])
                    except:
                        pass

                https_enabled = True
                break

    return {
        "status": "Configured",
        "issuer": issuer,
        "expires": expires,
        "https_enabled": https_enabled,
        "https_port": https_port
    }
    
@app.post("/ssl/portal/upload")
async def upload_portal_certificate(
    certificate: UploadFile = File(...),
    private_key: UploadFile = File(...)
):

    if certificate.filename != "server.crt":
        return {
            "success": False,
            "message": "Certificate file must be named server.crt"
        }

    if private_key.filename != "server.key":
        return {
            "success": False,
            "message": "Private key file must be named server.key"
        }
        
    # Backup SSL First
    
    if os.path.exists("/etc/ssl/portal/server.crt"):
        shutil.copy(
            "/etc/ssl/portal/server.crt",
            "/etc/ssl/portal/server.crt.bak"
    )

    if os.path.exists("/etc/ssl/portal/server.key"):
        shutil.copy(
            "/etc/ssl/portal/server.key",
            "/etc/ssl/portal/server.key.bak"
    )

    with open(
        "/etc/ssl/portal/server.crt",
        "wb"
    ) as crt:

        shutil.copyfileobj(
            certificate.file,
            crt
        )

    with open(
        "/etc/ssl/portal/server.key",
        "wb"
    ) as key:

        shutil.copyfileobj(
            private_key.file,
            key
        )

    test = subprocess.run(
        [
            "/usr/sbin/nginx",
            "-t"
        ],
        capture_output=True,
        text=True
    )

    if test.returncode != 0:

        return {
            "success": False,
            "message": test.stderr
        }

    subprocess.run(
        [
            "/usr/bin/systemctl",
            "reload",
            "nginx"
        ]
    )

    return {
        "success": True
    }

@app.post("/ssl/dns/upload")
async def upload_dns_certificate(
    certificate: UploadFile = File(...),
    private_key: UploadFile = File(...)
):

    if certificate.filename != "server.crt":
        return {
            "success": False,
            "message": "Certificate file must be named server.crt"
        }

    if private_key.filename != "server.key":
        return {
            "success": False,
            "message": "Private key file must be named server.key"
        }

    # A fresh backend provisioning has no certificate directory yet.
    os.makedirs("/etc/ssl/dns", exist_ok=True)

    if os.path.exists("/etc/ssl/dns/server.pfx"):
        shutil.copy(
            "/etc/ssl/dns/server.pfx",
            "/etc/ssl/dns/server.pfx.bak"
        )


    with open(
        "/etc/ssl/dns/server.crt",
        "wb"
    ) as crt:

        shutil.copyfileobj(
            certificate.file,
            crt
        )

    with open(
        "/etc/ssl/dns/server.key",
        "wb"
    ) as key:

        shutil.copyfileobj(
            private_key.file,
            key
        )
        
    convert = subprocess.run(
        [
            "/usr/bin/openssl",
            "pkcs12",
            "-export",
            "-out",
            "/etc/ssl/dns/server.pfx",
            "-inkey",
            "/etc/ssl/dns/server.key",
            "-in",
            "/etc/ssl/dns/server.crt",
            "-password",
            f"pass:{TECHNITIUM_SSL_PASSWORD}"
        ],
        capture_output=True,
        text=True
    )

    if convert.returncode != 0:

        return {
            "success": False,
            "message": convert.stderr
        }
    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/settings/set",
        headers=TECHNITIUM_HEADERS,
        params={
            
    
            "webServiceEnableTls": "true",
    
            "webServiceUseSelfSignedTlsCertificate": "false",
    
            "webServiceTlsCertificatePath":
                "/etc/ssl/dns/server.pfx",
    
            "webServiceTlsCertificatePassword":
                TECHNITIUM_SSL_PASSWORD
        }
    )
    
    if response.status_code != 200:
    
        return {
            "success": False,
            "message": response.text
        }
    
    subprocess.run(
        [
            "/usr/bin/systemctl",
            "restart",
            "dns"
        ]
    )
    
    return {
        "success": True
    }


   
@app.get("/ssl/dns")
def dns_certificate():

    if not os.path.isfile("/etc/ssl/dns/server.crt"):

        # No DNS certificate has been configured yet (fresh backend
        # provisioning). The SSL page shows the Not Configured state
        # instead of a server error.

        response = requests.get(
            f"http://{TECHNITIUM_HOST}:5380/api/settings/get",
            headers=TECHNITIUM_HEADERS,
            params={
            }
        )

        data = response.json()

        return {
            "status": "Not Configured",
            "issuer": "",
            "expires": "",
            "https_enabled": data["response"].get(
                "webServiceEnableTls",
                False
            ),
            "https_port": data["response"].get(
                "webServiceTlsPort",
                53443
            )
        }

    output = subprocess.check_output(
        [
            "/usr/bin/openssl",
            "x509",
            "-in",
            "/etc/ssl/dns/server.crt",
            "-noout",
            "-issuer",
            "-enddate"
        ],
        text=True
    )

    issuer = "Unknown"
    expires = "Unknown"

    for line in output.splitlines():

        if line.startswith("issuer="):

            issuer_raw = line.replace(
                "issuer=",
                ""
            ).strip()

            issuer = issuer_raw

            for part in issuer_raw.split(","):

                part = part.strip()

                if part.startswith("OU="):

                    issuer = part.replace(
                        "OU=",
                        ""

                    )
                    break

        elif line.startswith("notAfter="):

            raw_date = line.replace(
                "notAfter=",
                ""
            )

            dt = datetime.strptime(
                raw_date,
                "%b %d %H:%M:%S %Y %Z"
            )

            expires = dt.strftime(
                "%d %B %Y"
            )

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/settings/get",
        headers=TECHNITIUM_HEADERS,
        params={
            }
    )

    data = response.json()

    https_enabled = data["response"].get(
        "webServiceEnableTls",
        False
    )

    https_port = data["response"].get(
        "webServiceTlsPort",
        53443
    )

    return {
        "status": "Configured",
        "issuer": issuer,
        "expires": expires,
        "https_enabled": https_enabled,
        "https_port": https_port
    }
    
class DnsHttpsPortRequest(BaseModel):
    https_port: int
    
@app.post("/ssl/dns/save")
def save_dns_https_port(
    request: DnsHttpsPortRequest
):

    port = request.https_port

    if port < 1 or port > 65535:
        return {
            "success": False,
            "message": "Invalid port"
        }

    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/settings/set",
        headers=TECHNITIUM_HEADERS,
        params={
            

            "webServiceEnableTls": "true",

            "webServiceTlsPort": port,

            "webServiceUseSelfSignedTlsCertificate": "false",

            "webServiceTlsCertificatePath":
                "/etc/ssl/dns/server.pfx",

            "webServiceTlsCertificatePassword":
                TECHNITIUM_SSL_PASSWORD
        }
    )

    if response.status_code != 200:
        return {
            "success": False,
            "message": response.text
        }

    subprocess.run(
        [
            "/usr/bin/systemctl",
            "restart",
            "dns"
        ]
    )

    return {
        "success": True,
        "https_port": port
    }
    
class DnsHttpsStatusRequest(BaseModel):
    enabled: bool
    
    
@app.post("/ssl/dns/https")
def dns_https_status(
    request: DnsHttpsStatusRequest
):

    current = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/settings/get",
        headers=TECHNITIUM_HEADERS,
        params={
            }
    ).json()
    
    tls_port = current["response"].get(
        "webServiceTlsPort",
        53443
    )
    
    response = requests.get(
        f"http://{TECHNITIUM_HOST}:5380/api/settings/set",
        headers=TECHNITIUM_HEADERS,
        params={
            
    
            "webServiceEnableTls":
                str(request.enabled).lower(),
    
            "webServiceTlsPort": tls_port,
    
            "webServiceUseSelfSignedTlsCertificate":
                "false",
    
            "webServiceTlsCertificatePath":
                "/etc/ssl/dns/server.pfx",
    
            "webServiceTlsCertificatePassword":
                TECHNITIUM_SSL_PASSWORD
        }
    )
    
    try:
    
        data = response.json()
    
    except Exception:
    
        return {
            "success": False,
            "message": "Invalid response from Technitium"
        }
    
    if data.get("status") != "ok":
    
        return {
            "success": False,
            "message": data.get(
                "errorMessage",
                "Technitium returned an error"
            )
        }
    
    return {
        "success": True
    }

# ============================================================
# Portal Settings
# ============================================================

@app.get("/portal-settings")
def get_portal_settings():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        cur.execute("""
            SELECT
                setting_key,
                setting_value
            FROM portal_settings
            ORDER BY setting_key
        """)

        rows = cur.fetchall()

        return {
            row[0]: row[1]
            for row in rows
        }

    finally:

        cur.close()
        conn.close()


# ============================================================
# Update003 - Portal Appearance Settings
# ============================================================

from pydantic import BaseModel


class PortalAppearanceSettingsUpdate(BaseModel):
    settings: dict[str, str]


PORTAL_APPEARANCE_SETTING_KEYS = {
    "theme",
    "monitor_background_color",
    "monitor_background_image",
    "monitor_card_background",
    "monitor_card_opacity",
    "monitor_table_color",
    "monitor_table_alt_color",
    "monitor_table_grid_color",
    "monitor_text_color",
    "monitor_table_opacity",
    "monitor_table_grid_enabled",
    "monitor_card_styles",
    "theme_basic_page_background",
    "theme_basic_content_background",
    "theme_basic_text_primary",
    "theme_basic_text_secondary",
    "theme_basic_border",
    "theme_basic_accent",
    "theme_basic_accent_bright",
    "theme_basic_success",
    "theme_basic_warning",
    "theme_basic_error",
    "theme_basic_sidebar_background_top",
    "theme_basic_sidebar_background_bottom",
    "theme_basic_sidebar_text",
    "theme_basic_sidebar_icon",
    "theme_basic_sidebar_hover",
    "theme_basic_sidebar_active",
    "theme_basic_sidebar_active_text",
    "theme_basic_sidebar_active_accent",
    "theme_basic_sidebar_profile_background",
    "theme_basic_banner_fallback",
    "theme_basic_banner_text",
    "theme_basic_banner_secondary_text",
    "theme_basic_banner_accent",
    "theme_basic_card_background",
    "theme_basic_card_background_alt",
    "theme_basic_card_border",
    "theme_basic_card_text",
    "theme_basic_input_background",
    "theme_basic_input_background_readonly",
    "theme_basic_input_text",
    "theme_basic_input_border",
    "theme_basic_input_focus",
    "theme_basic_input_placeholder",
    "theme_basic_button_primary",
    "theme_basic_button_primary_hover",
    "theme_basic_button_primary_text",
    "theme_basic_button_secondary",
    "theme_basic_button_secondary_hover",
    "theme_basic_button_secondary_text",
    "theme_basic_table_header",
    "theme_basic_table_row",
    "theme_basic_table_row_alt",
    "theme_basic_table_hover",
    "theme_basic_table_border",
    "theme_basic_table_text",
    "theme_basic_modal_background",
    "theme_basic_modal_header",
    "theme_basic_modal_border",
    "theme_basic_modal_text",
    "theme_basic_login_card_background",
    "theme_basic_login_text",
    "theme_basic_login_secondary_text",
    "theme_basic_login_input_background",
    "theme_basic_login_input_border",
    "theme_basic_login_button",
    "theme_basic_login_button_text",
    "theme_basic_control_accent",
    "theme_basic_control_hover",
    "theme_basic_control_focus",
    "company_logo",
    "portal_favicon",
    "show_logo_banner",
    "show_logo_sidebar",
    "banner_logo_size",
    "sidebar_logo_size",
    "sidebar_width",
    "sidebar_avatar_size",
    "sidebar_nav_text_size",
    "sidebar_collapse_button_size",
    "user_disclaimer_enabled",
    "user_disclaimer_title",
    "user_disclaimer_text",
    "user_disclaimer_checklist",
    "user_disclaimer_note",
    "banner_image",
    "banner_zoom",
    "banner_position_x",
    "banner_position_y",
    "banner_fit_mode",
    "banner_animation_enabled",
    "banner_animation_style",
    "banner_animation_intensity",
    "login_title",
    "login_subtitle",
    "login_logo_size",
    "login_background_image",
    "login_background_overlay",
    "login_card_position",
    "show_logo_login",
    "show_login_footer",
    "login_footer_text",
    "login_animation_enabled",
    "login_animation_style",
    "login_animation_intensity",
    "portal_timezone",
    "weather_latitude",
    "weather_longitude",
    "notify_email_host",
    "notify_email_port",
    "notify_email_encryption",
    "notify_email_username",
    "notify_email_password",
    "notify_email_from",
    "notify_push_subject",
    "notify_push_public_key",
    "notify_push_private_key",
    "notify_whatsapp_url",
    "notify_whatsapp_token",
    "notify_whatsapp_number_id",
    "notify_telegram_token",
    "notify_telegram_chat_id",
    "notify_pushbullet_token",
    "notify_pushbullet_channel",
}


@app.post("/portal-settings/appearance")
def update_portal_appearance_settings(
    request: PortalAppearanceSettingsUpdate
):

    supplied_keys = set(request.settings.keys())

    invalid_keys = (
        supplied_keys
        - PORTAL_APPEARANCE_SETTING_KEYS
    )

    if invalid_keys:

        raise HTTPException(
            status_code=400,
            detail=(
                "Unsupported appearance setting: "
                + ", ".join(sorted(invalid_keys))
            )
        )


    validated = {}

    for key, raw_value in request.settings.items():

        value = str(raw_value).strip()


        if key.startswith("theme_basic_"):

            if not re.fullmatch(
                r"#[0-9A-Fa-f]{6}",
                value
            ):

                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Invalid Basic theme colour for {key}. "
                        "Expected #RRGGBB."
                    )
                )

            value = value.lower()


        elif key == "theme":

            if (
                value.lower()
                not in ("basic", "firewall")
            ):

                raise HTTPException(
                    status_code=400,
                    detail="Unsupported portal theme."
                )

            value = value.lower()


        elif key == "portal_favicon":

            if (
                value != ""
                and not re.fullmatch(
                    r"uploads/appearance/favicon_[a-f0-9]{32}\.webp",
                    value
                )
            ):

                raise HTTPException(
                    status_code=400,
                    detail="Invalid managed favicon path."
                )


        elif key in {
            "show_logo_banner",
            "show_logo_sidebar",
            "show_logo_login",
            "show_login_footer",
            "login_animation_enabled",
            "banner_animation_enabled",
        }:

            value = value.lower()

            if value not in {"true", "false"}:

                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Invalid boolean value for {key}."
                    )
                )


        elif key in {
            "banner_logo_size",
            "sidebar_logo_size",
            "login_logo_size",
        }:

            if not re.fullmatch(r"\d+", value):

                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid logo size for {key}."
                )

            numeric_value = int(value)

            if key == "banner_logo_size":

                minimum = 100
                maximum = 350

            elif key == "login_logo_size":

                minimum = 60
                maximum = 300

            else:

                minimum = 40
                maximum = 180

            if (
                numeric_value < minimum
                or numeric_value > maximum
            ):

                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"{key} must be between "
                        f"{minimum} and {maximum}."
                    )
                )

            value = str(numeric_value)


        elif key in {
            "sidebar_width",
            "sidebar_avatar_size",
            "sidebar_nav_text_size",
            "sidebar_collapse_button_size",
        }:

            if not re.fullmatch(r"\d+", value):

                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid sidebar value for {key}."
                )

            numeric_value = int(value)

            if key == "sidebar_width":

                minimum = 220
                maximum = 340

            elif key == "sidebar_avatar_size":

                minimum = 36
                maximum = 90

            elif key == "sidebar_nav_text_size":

                minimum = 13
                maximum = 20

            else:

                minimum = 36
                maximum = 64

            if (
                numeric_value < minimum
                or numeric_value > maximum
            ):

                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"{key} must be between "
                        f"{minimum} and {maximum}."
                    )
                )

            value = str(numeric_value)


        elif key == "user_disclaimer_enabled":

            if value not in {"true", "false"}:

                raise HTTPException(
                    status_code=400,
                    detail="Invalid User Disclaimer enabled value."
                )


        elif key == "user_disclaimer_title":

            if len(value) > 120:

                raise HTTPException(
                    status_code=400,
                    detail="User Disclaimer title is too long."
                )


        elif key == "user_disclaimer_text":

            if len(value) > 1500:

                raise HTTPException(
                    status_code=400,
                    detail="User Disclaimer text is too long."
                )


        elif key == "user_disclaimer_checklist":

            if len(value) > 3000:

                raise HTTPException(
                    status_code=400,
                    detail="User Disclaimer checklist is too long."
                )


        elif key == "user_disclaimer_note":

            if len(value) > 1000:

                raise HTTPException(
                    status_code=400,
                    detail="User Disclaimer note is too long."
                )


        elif key == "company_logo":

            if (
                value != ""
                and
                not re.fullmatch(
                    r"uploads/appearance/"
                    r"logo_[a-f0-9]{32}\.webp",
                    value
                )
            ):

                raise HTTPException(
                    status_code=400,
                    detail="Invalid company logo path."
                )


        elif key == "banner_image":

            if (
                value != "images/banner.jpg"
                and
                not re.fullmatch(
                    r"uploads/appearance/"
                    r"banner_[a-f0-9]{32}\.(?:webp|webm)",
                    value
                )
            ):

                raise HTTPException(
                    status_code=400,
                    detail="Invalid banner image path."
                )


        elif key == "banner_fit_mode":

            value = value.lower()

            if value not in {"fit", "cover"}:

                raise HTTPException(
                    status_code=400,
                    detail="Banner fit mode must be fit or cover."
                )


        elif key == "banner_zoom":

            if not re.fullmatch(r"\d+", value):

                raise HTTPException(
                    status_code=400,
                    detail="Invalid banner zoom."
                )

            numeric_value = int(value)

            if (
                numeric_value < 60
                or numeric_value > 500
            ):

                raise HTTPException(
                    status_code=400,
                    detail=(
                        "banner_zoom must be between "
                        "60 and 500."
                    )
                )

            value = str(numeric_value)


        elif key in {
            "banner_position_x",
            "banner_position_y",
        }:

            if not re.fullmatch(r"\d+", value):

                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid banner position for {key}."
                )

            numeric_value = int(value)

            if (
                numeric_value < 0
                or numeric_value > 100
            ):

                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"{key} must be between "
                        "0 and 100."
                    )
                )

            value = str(numeric_value)


        elif key == "login_background_overlay":

            if not re.fullmatch(r"\d+", value):

                raise HTTPException(
                    status_code=400,
                    detail="Invalid login background overlay."
                )

            numeric_value = int(value)

            if (
                numeric_value < 0
                or numeric_value > 100
            ):

                raise HTTPException(
                    status_code=400,
                    detail=(
                        "login_background_overlay must be "
                        "between 0 and 100."
                    )
                )

            value = str(numeric_value)


        elif key == "login_card_position":

            value = value.lower()

            if value not in {"left", "center", "right"}:

                raise HTTPException(
                    status_code=400,
                    detail=(
                        "Login card position must be "
                        "left, center or right."
                    )
                )


        elif key in {
            "login_animation_style",
            "banner_animation_style",
        }:

            value = value.lower()

            if value not in {
                "cyber",
                "digital_rain",
                "network_grid",
                "security_scanner",
            }:

                raise HTTPException(
                    status_code=400,
                    detail="Unsupported animation style."
                )


        elif key in {
            "login_animation_intensity",
            "banner_animation_intensity",
        }:

            value = value.lower()

            if value not in {"low", "medium", "high", "ultra"}:

                raise HTTPException(
                    status_code=400,
                    detail=(
                        "Animation intensity must be "
                        "low, medium, high or ultra."
                    )
                )


        elif key == "login_background_image":

            if (
                value != ""
                and
                not re.fullmatch(
                    r"uploads/appearance/"
                    r"login_[a-f0-9]{32}\.webp",
                    value
                )
            ):

                raise HTTPException(
                    status_code=400,
                    detail="Invalid login background image path."
                )


        elif key == "login_title":

            if len(value) > 120:

                raise HTTPException(
                    status_code=400,
                    detail="Login title must not exceed 120 characters."
                )


        elif key == "login_subtitle":

            if len(value) > 250:

                raise HTTPException(
                    status_code=400,
                    detail="Login subtitle must not exceed 250 characters."
                )


        elif key == "login_footer_text":

            if len(value) > 300:

                raise HTTPException(
                    status_code=400,
                    detail="Login footer text must not exceed 300 characters."
                )


        validated[key] = value


    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:

        for key, value in validated.items():

            cur.execute(
                """
                INSERT INTO portal_settings (
                    setting_key,
                    setting_value,
                    updated_at
                )
                VALUES (%s, %s, CURRENT_TIMESTAMP)

                ON CONFLICT (setting_key)
                DO UPDATE SET
                    setting_value = EXCLUDED.setting_value,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (
                    key,
                    value
                )
            )

        conn.commit()

        return {
            "success": True,
            "settings": validated
        }

    except Exception:

        conn.rollback()
        raise

    finally:

        cur.close()
        conn.close()
        
class HeartbeatRequest(BaseModel):
    hostname: str
    ip_address: str
    cpu_percent: float | None = None
    memory_percent: float | None = None
    disk_percent: float | None = None
    load_1m: float | None = None
    load_5m: float | None = None
    load_15m: float | None = None

    # online/offline from the sender's
    # own probe; host heartbeats stay
    # online by default.

    status: str = "online"
    
@app.get("/api/monitoring/servers")
def list_monitoring_servers():

    """Every server that has checked in,
    with its live status - a heartbeat
    within the last 3 minutes means
    online - and its latest metrics."""

    conn = monitoring_db()
    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT s.id,
                   s.hostname,
                   s.ip_address,
                   s.environment,
                   s.last_seen,
                   s.last_seen
                       >= NOW()
                       - INTERVAL '3 minutes'
                   AND s.status <> 'offline',
                   m.cpu_percent,
                   m.memory_percent,
                   m.disk_percent,
                   m.load_1m,
                   EXTRACT(
                       EPOCH
                       FROM (
                           NOW() - s.last_seen
                       )
                   )
            FROM monitoring.servers s
            LEFT JOIN LATERAL (
                SELECT cpu_percent,
                       memory_percent,
                       disk_percent,
                       load_1m
                FROM monitoring.metrics
                WHERE server_id = s.id
                ORDER BY created_at DESC
                LIMIT 1
            ) m ON TRUE
            ORDER BY s.hostname
        """)

        rows = cur.fetchall()

        # Backend-specific probe rows only appear when that backend
        # is the active provider: a stale Technitium DNS or
        # NetFortress Appliance row from an earlier configuration
        # must not show as offline on a portal that does not use
        # that backend.
        provider = _portal_setting_get("dns_provider")
        rows = [
            row for row in rows
            if not (
                row[1] == "Technitium DNS"
                and provider != "technitium"
            )
            and not (
                row[1] == "NetFortress Appliance"
                and provider != "firewall"
            )
        ]

        def number(value):

            return (
                float(value)
                if value is not None
                else None
            )

        return [
            {
                "id": r[0],
                "hostname": r[1],
                "ip_address": r[2],
                "environment": r[3],
                "last_seen": str(r[4]),
                "online": r[5],
                "cpu_percent": number(r[6]),
                "memory_percent": number(r[7]),
                "disk_percent": number(r[8]),
                "load_1m": number(r[9]),
                "seconds_since_seen":
                    int(r[10])
                    if r[10] is not None
                    else None,
            }
            for r in rows
        ]

    finally:
        cur.close()
        conn.close()


# Both paths serve the same endpoint:
# the API is reached directly (with the
# /api prefix) by the local heartbeat
# sender, and through the portal's nginx
# proxy (which strips /api) by remote
# servers.

@app.post("/api/monitoring/heartbeat")
@app.post("/monitoring/heartbeat")
def heartbeat(data: HeartbeatRequest):

    conn = monitoring_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT id
        FROM monitoring.servers
        WHERE hostname = %s
    """, (data.hostname,))

    server = cur.fetchone()

    if server:

        server_id = server[0]

        cur.execute("""
            UPDATE monitoring.servers
            SET
                ip_address = %s,
                last_seen = NOW(),
                status = %s
            WHERE id = %s
        """, (
            data.ip_address,
            data.status,
            server_id
        ))

    else:

        cur.execute("""
            INSERT INTO monitoring.servers
            (
                hostname,
                ip_address,
                status,
                last_seen
            )
            VALUES
            (
                %s,
                %s,
                %s,
                NOW()
            )
            RETURNING id
        """, (
            data.hostname,
            data.ip_address,
            data.status
        ))

        server_id = cur.fetchone()[0]

    cur.execute("""
        INSERT INTO monitoring.metrics
        (
            server_id,
            cpu_percent,
            memory_percent,
            disk_percent,
            load_1m,
            load_5m,
            load_15m
        )
        VALUES
        (
            %s,%s,%s,%s,%s,%s,%s
        )
    """, (
        server_id,
        data.cpu_percent,
        data.memory_percent,
        data.disk_percent,
        data.load_1m,
        data.load_5m,
        data.load_15m
    ))

    conn.commit()

    cur.close()
    conn.close()

    return {"status": "ok"}


# ============================================================
# LOCAL NETWORK INTERFACE - LAN configuration for the
# Services > Network > Local Interface tab. The server
# uses ifupdown (/etc/network/interfaces).
# ============================================================

class NetworkInterfaceRequest(BaseModel):
    interface: str
    method: str
    address: str = ""
    netmask: str = ""
    gateway: str = ""
    dns: str = ""
    dry_run: bool = False


NETWORK_DHCPCD_CONF = "/etc/dhcpcd.conf"


def network_parse_iface_stanza(iface):

    """Parse the current configuration
    for an interface from dhcpcd.conf.
    An interface with no static block
    configured uses DHCP."""

    result = {
        "method": "dhcp",
        "address": "",
        "netmask": "",
        "gateway": "",
        "dns": []
    }

    try:
        lines = open(
            NETWORK_DHCPCD_CONF
        ).read().splitlines()
    except Exception:
        return result

    in_block = False

    for line in lines:

        stripped = line.strip()

        if (
            not stripped
            or stripped.startswith("#")
        ):
            continue

        parts = stripped.split()

        if parts[0] == "interface":

            in_block = (
                len(parts) >= 2
                and parts[1] == iface
            )

            continue

        if not in_block:
            continue

        if not stripped.startswith("static"):
            continue

        rest = stripped[
            len("static"):
        ].strip()

        option, _, value = rest.partition("=")

        option = option.strip()
        value = value.strip()

        if option == "ip_address":

            import ipaddress as _ipa

            address, _, prefix = (
                value.partition("/")
            )

            result["method"] = "static"
            result["address"] = address

            if prefix:

                try:
                    result["netmask"] = str(
                        _ipa.ip_network(
                            "0.0.0.0/"
                            + prefix,
                            strict=False
                        ).netmask
                    )
                except Exception:
                    pass

        elif option == "routers":

            result["gateway"] = (
                value.split()[0]
                if value.split()
                else ""
            )

        elif option == "domain_name_servers":

            result["dns"] = value.split()

    return result



def network_live_state(iface):

    """The currently applied addresses, default
    gateway and resolvers of the interface."""

    import json as _json

    addresses = []

    try:

        out = subprocess.run(
            [
                "/usr/bin/ip",
                "-j",
                "addr",
                "show",
                "dev",
                iface
            ],
            capture_output=True,
            text=True
        ).stdout

        for info in _json.loads(out)[0].get(
            "addr_info",
            []
        ):
            addresses.append(
                info["local"]
                + "/"
                + str(info["prefixlen"])
            )

    except Exception:
        pass

    gateway = ""

    try:

        out = subprocess.run(
            [
                "/usr/bin/ip",
                "-j",
                "route",
                "show",
                "default"
            ],
            capture_output=True,
            text=True
        ).stdout

        for route in _json.loads(out):

            if route.get("dev") == iface:
                gateway = route.get(
                    "gateway",
                    route.get("via", "")
                )
                break

    except Exception:
        pass

    dns = []

    try:

        for line in open("/etc/resolv.conf"):

            line = line.strip()

            if line.startswith("nameserver"):

                parts = line.split()

                if len(parts) > 1:
                    dns.append(parts[1])

    except Exception:
        pass

    return {
        "addresses": addresses,
        "gateway": gateway,
        "dns": dns
    }


def network_primary_interface():

    """The first physical interface that is
    up, skipping loopback."""

    try:

        out = subprocess.run(
            ["/usr/bin/ip", "-o", "link", "show"],
            capture_output=True,
            text=True
        ).stdout

        for line in out.splitlines():

            match = re.match(
                r"\d+:\s*([^:@]+)[:@]?",
                line.strip()
            )

            if not match:
                continue

            name = match.group(1).strip()

            if name == "lo":
                continue

            return name

    except Exception:
        pass

    return ""


@app.get("/network/interface")
def network_get_interface():

    iface = network_primary_interface()

    if not iface:
        return {
            "status": "error",
            "message":
                "No network interface found."
        }

    result = network_parse_iface_stanza(
        iface
    )

    return {
        "status": "ok",
        "interface": iface,
        **result,
        "live": network_live_state(iface)
    }


@app.post("/network/interface")
def network_apply_interface(
    data: NetworkInterfaceRequest
):

    import ipaddress as _ip

    iface = (data.interface or "").strip()

    if (
        not re.fullmatch(
            r"[a-zA-Z0-9_.\-]+",
            iface
        )
        or not os.path.exists(
            "/sys/class/net/" + iface
        )
    ):
        return {
            "status": "error",
            "message":
                "Unknown network interface."
        }

    method = (data.method or "").strip().lower()

    if method not in ("dhcp", "static"):
        return {
            "status": "error",
            "message":
                "Method must be dhcp or static."
        }

    address = (data.address or "").strip()
    netmask = (data.netmask or "").strip()
    gateway = (data.gateway or "").strip()

    dns_servers = [
        entry.strip()
        for entry in (data.dns or "").splitlines()
        if entry.strip()
    ]

    if method == "static":

        try:
            _ip.ip_address(address)
        except ValueError:
            return {
                "status": "error",
                "message":
                    "Invalid static IP address."
            }

        try:
            _ip.ip_address(netmask)
        except ValueError:
            return {
                "status": "error",
                "message":
                    "Invalid subnet mask."
            }

        try:
            _ip.ip_address(gateway)
        except ValueError:
            return {
                "status": "error",
                "message":
                    "Invalid gateway address."
            }

    for server in dns_servers:

        try:
            _ip.ip_address(server)
        except ValueError:
            return {
                "status": "error",
                "message":
                    "Invalid DNS server: "
                    + server
            }

    import ipaddress as _ipa

    try:
        content = open(
            NETWORK_DHCPCD_CONF
        ).read()
    except Exception:
        return {
            "status": "error",
            "message":
                "Unable to read "
                "/etc/dhcpcd.conf."
        }

    # drop any existing block for this
    # interface and append the new one
    content = re.sub(
        r"(?ms)^interface\s+"
        + re.escape(iface)
        + r"\n.*?(?=^interface\s|\Z)",
        "",
        content
    )

    content = content.rstrip("\n") + "\n"

    if method == "static":

        prefix = _ipa.ip_network(
            "0.0.0.0/" + netmask,
            strict=False
        ).prefixlen

        content += (
            "\ninterface " + iface + "\n"
            "static ip_address="
            + address
            + "/" + str(prefix) + "\n"
            "static routers="
            + gateway + "\n"
        )

        if dns_servers:
            content += (
                "static domain_name_servers="
                + " ".join(dns_servers)
                + "\n"
            )

    if data.dry_run:
        return {
            "status": "ok",
            "dry_run": True,
            "generated": content
        }

    backup = (
        NETWORK_DHCPCD_CONF
        + ".before-portal"
    )

    try:

        if os.path.exists(backup):
            os.remove(backup)

        shutil.copy2(
            NETWORK_DHCPCD_CONF,
            backup
        )

        open(
            NETWORK_DHCPCD_CONF,
            "w"
        ).write(content)

    except Exception as e:
        return {
            "status": "error",
            "message":
                "Failed to write the "
                "configuration: " + str(e)
        }

    try:

        # a clean single master: the boot
        # time master may not respond to
        # rebind signals, so stop every
        # instance and start one fresh
        subprocess.run(
            [
                "/usr/bin/pkill",
                "-x",
                "dhcpcd"
            ],
            capture_output=True,
            text=True,
            timeout=30
        )

        time.sleep(1)

        subprocess.run(
            [
                "/usr/bin/systemctl",
                "restart",
                "portal-dhcpcd"
            ],
            capture_output=True,
            text=True,
            timeout=60
        )

        time.sleep(6)

    except Exception as e:

        return {
            "status": "error",
            "message":
                "Configuration saved but "
                "dhcpcd failed to rebind: "
                + str(e)
        }

    result = network_parse_iface_stanza(
        iface
    )

    live = network_live_state(iface)

    if live["dns"]:
        result["dns"] = live["dns"]

    return {
        "status": "ok",
        **result,
        "live": live
    }

# ============================================================
# Network services backends (portal v2: selected at runtime
# from Settings -> System Status; the clean portal ships with
# no backend and provisions one on demand)
# ============================================================

import json as _backend_json
import threading as _backend_threading

PORTAL_VERSION = "1.0"
BACKENDS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "backends")
PROVISION_LOG = "/var/lib/portal/backend-provision.log"
PROVISION_RESULT = "/var/lib/portal/backend-provision.result"

_BACKEND_OPTIONS = [
    {
        "id": "technitium",
        "label": "Technitium DNS Server",
        "description": (
            "Domain blocking and request approvals backed by the "
            "Technitium DNS Server, downloaded from Technitium's "
            "official site and configured automatically."
        ),
    },
    {
        "id": "netfortress",
        "label": "NetFortress Firewall Appliance",
        "description": (
            "Domain blocking, request approvals, user shadowing and "
            "licence limits backed by the NetFortress Firewall "
            "Appliance, downloaded from netfortress.tech."
        ),
    },
]


class BackendSelectRequest(BaseModel):
    backend: str
    appliance_admin_username: str = ""
    appliance_admin_password: str = ""


def _portal_setting_get(key):
    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )
    cur = conn.cursor()
    try:
        cur.execute(
            "SELECT setting_value FROM portal_settings WHERE setting_key = %s",
            (key,)
        )
        row = cur.fetchone()
        return row[0] if row else None
    finally:
        cur.close()
        conn.close()


def _portal_setting_set(key, value):
    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )
    cur = conn.cursor()
    try:
        cur.execute(
            """
            INSERT INTO portal_settings (
                setting_key, setting_value, updated_at
            )
            VALUES (%s, %s, CURRENT_TIMESTAMP)
            ON CONFLICT (setting_key)
            DO UPDATE SET
                setting_value = EXCLUDED.setting_value,
                updated_at = CURRENT_TIMESTAMP
            """,
            (key, value)
        )
        conn.commit()
    finally:
        cur.close()
        conn.close()


def _portal_first_admin_username():
    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )
    cur = conn.cursor()
    try:
        cur.execute(
            """
            SELECT username FROM portal_auth
            ORDER BY id LIMIT 1
            """
        )
        row = cur.fetchone()
        return row[0] if row else None
    finally:
        cur.close()
        conn.close()


def _provision_state_read():
    raw = _portal_setting_get("backend_provision")
    try:
        state = _backend_json.loads(raw) if raw else {}
    except ValueError:
        state = {}
    if not isinstance(state, dict):
        state = {}

    # Orphan-run detection: a successful provisioning script writes a
    # result marker as its final step (before restarting this service),
    # so a persisted "running" state combined with a marker means the
    # job actually completed while the portal restarted.
    if state.get("state") == "running" and os.path.isfile(PROVISION_RESULT):
        try:
            with open(PROVISION_RESULT, "r", encoding="utf-8") as handle:
                marker = _backend_json.load(handle)
            if isinstance(marker, dict) and marker.get("backend") == state.get("backend"):
                state = marker
                _portal_setting_set("backend_provision", _backend_json.dumps(state))
        except (OSError, ValueError):
            pass
    return state


def _provision_log_tail(limit=40):
    try:
        with open(PROVISION_LOG, "r", encoding="utf-8", errors="replace") as handle:
            lines = handle.readlines()
        return [line.rstrip("\n") for line in lines[-limit:]]
    except OSError:
        return []


@app.get("/api/backends/status")
def backends_status():
    """System Status -> network services backend card: which backend is
    active, whether a provisioning job is running, and the choices."""
    provider = _portal_setting_get("dns_provider")
    state = _provision_state_read()

    provider_health = None
    if provider:
        try:
            provider_health = get_provider().health()
        except Exception as exc:
            provider_health = {"status": "error", "message": str(exc)}

    return {
        "portal_version": PORTAL_VERSION,
        "provider": provider,
        "configured": bool(provider),
        "provider_health": provider_health,
        "provisioning": state,
        "provisioning_log": _provision_log_tail() if state.get("state") in ("running", "failed") else [],
        "options": _BACKEND_OPTIONS,
    }


def _portal_admin_password_matches(password):
    """The Technitium provisioning applies the Portal administrator
    password to the Technitium console admin account; verify the
    caller actually knows it before starting the job."""
    try:
        conn = psycopg2.connect(
            host=POSTGRES_HOST,
            database=POSTGRES_DB,
            user=POSTGRES_USER,
            password=POSTGRES_PASSWORD
        )
        cur = conn.cursor()
        cur.execute(
            """
            SELECT password_hash
            FROM portal_auth
            WHERE is_disabled = FALSE
            ORDER BY id
            LIMIT 1
            """
        )
        row = cur.fetchone()
        cur.close()
        conn.close()
    except Exception:
        return False

    if not row:
        return False

    return hash_portal_password(password) == row[0]


def _run_backend_provision(backend, env_extra=None):
    script = os.path.join(BACKENDS_DIR, "provision-%s.sh" % backend)
    os.makedirs("/var/lib/portal", exist_ok=True)
    try:
        # The service unit runs with a minimal PATH (the venv only),
        # so the child gets a full standard PATH: the script needs
        # curl, psql, systemctl, openssl, python3, ...
        run_env = dict(os.environ)
        run_env["PATH"] = (
            "/opt/portal/api/venv/bin"
            ":/usr/local/sbin:/usr/local/bin"
            ":/usr/sbin:/usr/bin:/sbin:/bin"
        )
        if env_extra:
            run_env.update(env_extra)
        with open(PROVISION_LOG, "w", encoding="utf-8") as log:
            process = subprocess.Popen(
                ["/bin/bash", script],
                stdout=log,
                stderr=subprocess.STDOUT,
                cwd="/opt/portal",
                env=run_env,
            )
            return_code = process.wait()

            # The successful script writes its result marker as its
            # final step and then restarts this service; systemd's
            # cgroup cleanup signals the child (and this thread) at
            # that moment. A killed child WITH a marker present means
            # the script finished successfully: keep the persisted
            # "running" state untouched so the marker reconciles it
            # to complete after the restart.
            if os.path.isfile(PROVISION_RESULT):
                return

        # No marker: the script really failed (this branch also runs
        # for scripts that failed without restarting).
        _portal_setting_set("backend_provision", _backend_json.dumps({
            "state": "failed",
            "backend": backend,
            "completed_at": datetime.now().isoformat(),
            "error": "Provisioning script exited with code %s" % return_code,
        }))

    except Exception as exc:
        # Never leave the job stuck at "running": the System Status
        # card would spin forever with no way to see what happened.
        _portal_setting_set("backend_provision", _backend_json.dumps({
            "state": "failed",
            "backend": backend,
            "completed_at": datetime.now().isoformat(),
            "error": "Provisioning could not start: %s" % exc,
        }))


@app.post("/api/backends/select")
def backends_select(payload: BackendSelectRequest):
    """Start the provisioning job for the selected backend. Returns
    immediately; the UI polls /api/backends/status for progress."""
    backend = (payload.backend or "").strip().lower()
    if backend not in ("technitium", "netfortress"):
        return {"status": "error", "message": "Unknown backend"}

    state = _provision_state_read()
    if state.get("state") == "running":
        return {
            "status": "error",
            "message": "A backend provisioning job is already running",
        }

    script = os.path.join(BACKENDS_DIR, "provision-%s.sh" % backend)
    if not os.path.isfile(script):
        return {
            "status": "error",
            "message": "Provisioning script not found: %s" % script,
        }

    env_extra = None
    if backend == "netfortress":
        admin_username = (payload.appliance_admin_username or "").strip()
        admin_password = payload.appliance_admin_password or ""
        if not admin_username:
            # Default to the portal's own administrator account.
            admin_username = _portal_first_admin_username() or "admin"
        if not admin_password:
            return {
                "status": "error",
                "message": (
                    "The appliance administrator password is required "
                    "(minimum 12 characters, at least three character "
                    "categories)"
                ),
            }
        env_extra = {
            "APPLIANCE_ADMIN_USERNAME": admin_username,
            "APPLIANCE_ADMIN_PASSWORD": admin_password,
        }

    else:

        # Technitium: the Portal administrator password is applied to
        # the Technitium console admin account, so the card collects
        # it and it must match the Portal administrator.
        admin_password = payload.appliance_admin_password or ""

        if not admin_password:
            return {
                "status": "error",
                "message": (
                    "The Portal administrator password is required: "
                    "it is also set as the Technitium console "
                    "administrator password"
                ),
            }

        if not _portal_admin_password_matches(admin_password):
            return {
                "status": "error",
                "message": (
                    "The password does not match the Portal "
                    "administrator account"
                ),
            }

        env_extra = {
            "TECH_ADMIN_PASSWORD": admin_password,
        }

    _portal_setting_set("backend_provision", _backend_json.dumps({
        "state": "running",
        "backend": backend,
        "started_at": datetime.now().isoformat(),
    }))
    try:
        os.remove(PROVISION_RESULT)
    except OSError:
        pass

    worker = _backend_threading.Thread(
        target=_run_backend_provision,
        args=(backend, env_extra),
        daemon=True,
    )
    worker.start()
    return {"status": "ok", "backend": backend}


@app.get("/api/backends/capabilities")
@app.get("/backends/capabilities")
def backends_capabilities():
    """Lightweight provider state for UI conditioning. Deliberately
    performs no health checks so page renders can call it cheaply."""
    provider = _portal_setting_get("dns_provider")
    capabilities = None
    if provider:
        try:
            capabilities = get_provider().capabilities()
        except Exception:
            capabilities = None
    return {"provider": provider or None, "capabilities": capabilities}
# =====================================================================
# NetFortress appliance console: Devices and Modules endpoints
# =====================================================================
# The Settings -> Services -> NetFortress pages render native portal
# UIs for the local Firewall Appliance. These endpoints wrap the
# network services provider; the PHP proxy netfortress-api.php
# enforces the NetFortress permission before forwarding.

from pydantic import BaseModel


class NetFortressDeviceBlockRequest(BaseModel):
    target_type: str
    target_value: str
    reason: str = ""


class NetFortressDeviceUnblockRequest(BaseModel):
    policy_id: int


class NetFortressModuleToggleRequest(BaseModel):
    module_key: str
    enabled: bool


class NetFortressIdsActionRequest(BaseModel):
    action: str


def _netfortress_provider():
    """The appliance console endpoints only exist for the Firewall
    Appliance deployment."""
    provider = get_provider()
    if provider.name != "firewall":
        return None
    return provider


@app.get("/api/netfortress/devices")
def netfortress_devices():
    provider = _netfortress_provider()
    if provider is None:
        return {"success": False, "message": "The active backend is not the Firewall Appliance."}
    data = provider.list_devices()
    if data is None:
        return {"success": False, "message": "The appliance API did not return the device inventory."}
    return {"success": True, **data}


@app.post("/api/netfortress/devices/block")
def netfortress_device_block(payload: NetFortressDeviceBlockRequest):
    provider = _netfortress_provider()
    if provider is None:
        return {"success": False, "message": "The active backend is not the Firewall Appliance."}
    return provider.block_device(
        payload.target_type.strip(),
        payload.target_value.strip(),
        payload.reason.strip() or "Blocked from the Portal",
    )


@app.post("/api/netfortress/devices/unblock")
def netfortress_device_unblock(payload: NetFortressDeviceUnblockRequest):
    provider = _netfortress_provider()
    if provider is None:
        return {"success": False, "message": "The active backend is not the Firewall Appliance."}
    return provider.unblock_device(payload.policy_id)


@app.get("/api/netfortress/modules")
def netfortress_modules():
    provider = _netfortress_provider()
    if provider is None:
        return {"success": False, "message": "The active backend is not the Firewall Appliance."}
    data = provider.list_modules()
    if data is None:
        return {"success": False, "message": "The appliance API did not return the module inventory."}
    return {"success": True, **data}


@app.post("/api/netfortress/modules/toggle")
def netfortress_module_toggle(payload: NetFortressModuleToggleRequest):
    provider = _netfortress_provider()
    if provider is None:
        return {"success": False, "message": "The active backend is not the Firewall Appliance."}
    return provider.set_module(payload.module_key.strip(), payload.enabled)


@app.post("/api/netfortress/modules/ids")
def netfortress_modules_ids(payload: NetFortressIdsActionRequest):
    provider = _netfortress_provider()
    if provider is None:
        return {"success": False, "message": "The active backend is not the Firewall Appliance."}
    return provider.ids_ips_action(payload.action.strip())
@app.get("/api/netfortress/events")
def netfortress_events(limit: int = 200):
    """Most recent appliance security events for the native
    Reports page (the page filters them further by age)."""
    provider = _netfortress_provider()
    if provider is None:
        return {"success": False, "message": "The active backend is not the Firewall Appliance."}
    limit = max(1, min(limit, 2000))
    data = provider.recent_events(limit)
    if data is None:
        return {"success": False, "message": "The appliance API did not return recent events."}
    return {"success": True, **data}
class NetFortressInterfaceLabelRequest(BaseModel):
    interface: str
    label: str = ""


class NetFortressHostnameRequest(BaseModel):
    hostname: str


@app.get("/api/netfortress/network")
def netfortress_network():
    """Appliance interfaces (with labels) and hostname for the
    Services -> Network -> NetFortress page."""
    provider = _netfortress_provider()
    if provider is None:
        return {"success": False, "message": "The active backend is not the Firewall Appliance."}
    data = provider.network_info()
    if data is None:
        return {"success": False, "message": "The appliance API did not return network information."}
    return {"success": True, **data}


@app.post("/api/netfortress/network/label")
def netfortress_network_label(payload: NetFortressInterfaceLabelRequest):
    provider = _netfortress_provider()
    if provider is None:
        return {"success": False, "message": "The active backend is not the Firewall Appliance."}
    return provider.set_interface_label(
        payload.interface.strip(),
        payload.label.strip(),
    )


@app.post("/api/netfortress/network/hostname")
def netfortress_network_hostname(payload: NetFortressHostnameRequest):
    provider = _netfortress_provider()
    if provider is None:
        return {"success": False, "message": "The active backend is not the Firewall Appliance."}
    return provider.set_hostname(payload.hostname.strip().lower())
