"""
Portal notification dispatch backend.

Each channel has the service endpoint the
portal uses to reach it defined here, with a
send function driven by the settings stored
under the Notification Channels hub.
"""

import smtplib
import requests

from email.message import EmailMessage

import psycopg2

from config import (
    POSTGRES_HOST,
    POSTGRES_DB,
    POSTGRES_USER,
    POSTGRES_PASSWORD
)

# ---------------------------------------------------------
# Service endpoints the portal talks to
# ---------------------------------------------------------

PUSHBULLET_API_URL = \
    "https://api.pushbullet.com/v2/pushes"

TELEGRAM_API_URL = \
    "https://api.telegram.org/bot{token}/sendMessage"

WHATSAPP_DEFAULT_BASE = \
    "https://graph.facebook.com/v21.0"

WHATSAPP_API_URL = \
    "{base}/{phone_number_id}/messages"

HTTP_TIMEOUT = 10

SMTP_TIMEOUT = 12

# ---------------------------------------------------------
# Settings
# ---------------------------------------------------------

def get_notification_settings():

    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )

    cur = conn.cursor()

    try:
        cur.execute("""
            SELECT setting_key, setting_value
            FROM portal_settings
            WHERE setting_key LIKE 'notify_%'
        """)

        return {
            row[0]: row[1]
            for row in cur.fetchall()
        }

    finally:
        cur.close()
        conn.close()


def missing_settings(channel, settings):

    required = {
        "email": [
            "notify_email_host",
            "notify_email_port",
            "notify_email_from"
        ],
        "push": [
            "notify_push_public_key",
            "notify_push_private_key"
        ],
        "whatsapp": [
            "notify_whatsapp_token",
            "notify_whatsapp_number_id"
        ],
        "telegram": [
            "notify_telegram_token",
            "notify_telegram_chat_id"
        ],
        "pushbullet": [
            "notify_pushbullet_token"
        ]
    }.get(channel, [])

    return [
        key
        for key in required
        if not (settings.get(key) or "").strip()
    ]

# ---------------------------------------------------------
# Channels
# ---------------------------------------------------------

def send_pushbullet(title, body, settings):

    token = (
        settings.get("notify_pushbullet_token")
        or ""
    ).strip()

    payload = {
        "type": "note",
        "title": title,
        "body": body
    }

    channel_tag = (
        settings.get("notify_pushbullet_channel")
        or ""
    ).strip()

    if channel_tag:
        payload["channel_tag"] = channel_tag

    try:
        response = requests.post(
            PUSHBULLET_API_URL,
            json=payload,
            headers={
                "Access-Token": token,
                "Content-Type": "application/json"
            },
            timeout=HTTP_TIMEOUT
        )

        if response.status_code in (200, 201):

            return {
                "success": True,
                "message": (
                    "Pushbullet accepted the "
                    "notification."
                )
            }

        detail = response.text[:300]

        if response.status_code == 401:
            detail = "the access token was rejected"

        return {
            "success": False,
            "message": (
                "Pushbullet rejected the request "
                "(HTTP %s): %s"
                % (response.status_code, detail)
            )
        }

    except Exception as error:

        return {
            "success": False,
            "message": (
                "Could not reach Pushbullet: %s"
                % error
            )
        }


def send_telegram(text, settings):

    token = (
        settings.get("notify_telegram_token")
        or ""
    ).strip()

    chat_id = (
        settings.get("notify_telegram_chat_id")
        or ""
    ).strip()

    try:
        response = requests.post(
            TELEGRAM_API_URL.format(token=token),
            json={
                "chat_id": chat_id,
                "text": text
            },
            timeout=HTTP_TIMEOUT
        )

        data = response.json()

        if data.get("ok") is True:

            return {
                "success": True,
                "message": (
                    "Telegram accepted the message."
                )
            }

        return {
            "success": False,
            "message": (
                "Telegram rejected the request: %s"
                % data.get("description",
                           response.text[:300])
            )
        }

    except Exception as error:

        return {
            "success": False,
            "message": (
                "Could not reach Telegram: %s"
                % error
            )
        }


def send_whatsapp(message, to, settings):

    token = (
        settings.get("notify_whatsapp_token")
        or ""
    ).strip()

    number_id = (
        settings.get("notify_whatsapp_number_id")
        or ""
    ).strip()

    base = (
        settings.get("notify_whatsapp_url")
        or WHATSAPP_DEFAULT_BASE
    ).strip() or WHATSAPP_DEFAULT_BASE

    try:
        response = requests.post(
            WHATSAPP_API_URL.format(
                base=base.rstrip("/"),
                phone_number_id=number_id
            ),
            json={
                "messaging_product": "whatsapp",
                "to": to,
                "type": "text",
                "text": {"body": message}
            },
            headers={
                "Authorization": (
                    "Bearer " + token
                )
            },
            timeout=HTTP_TIMEOUT
        )

        data = response.json()

        if response.status_code in (200, 201):

            return {
                "success": True,
                "message": (
                    "WhatsApp accepted the message."
                )
            }

        error = data.get("error") or {}

        return {
            "success": False,
            "message": (
                "WhatsApp rejected the request "
                "(HTTP %s): %s"
                % (
                    response.status_code,
                    error.get(
                        "message",
                        response.text[:300]
                    )
                )
            )
        }

    except Exception as error:

        return {
            "success": False,
            "message": (
                "Could not reach WhatsApp: %s"
                % error
            )
        }


def send_email(subject, message, settings, to=None):

    host = (
        settings.get("notify_email_host")
        or ""
    ).strip()

    port = int(
        (settings.get("notify_email_port")
         or "587")
        .strip() or 587
    )

    encryption = (
        settings.get("notify_email_encryption")
        or "tls"
    ).strip().lower()

    username = (
        settings.get("notify_email_username")
        or ""
    ).strip()

    password = (
        settings.get("notify_email_password")
        or ""
    )

    from_addr = (
        settings.get("notify_email_from")
        or ""
    ).strip()

    if not from_addr:
        from_addr = username

    to_addr = (to or "").strip() or from_addr

    try:
        if encryption == "ssl":
            server = smtplib.SMTP_SSL(
                host,
                port,
                timeout=SMTP_TIMEOUT
            )
        else:
            server = smtplib.SMTP(
                host,
                port,
                timeout=SMTP_TIMEOUT
            )

            if encryption == "tls":
                server.starttls()

        if username:
            server.login(username, password)

        mail = EmailMessage()

        mail["From"] = from_addr
        mail["To"] = to_addr
        mail["Subject"] = subject
        mail.set_content(message)

        server.send_message(mail)

        server.quit()

        return {
            "success": True,
            "message": (
                "Email delivered to the SMTP "
                "server."
            )
        }

    except Exception as error:

        return {
            "success": False,
            "message": (
                "SMTP failed: %s"
                % error
            )
        }


def send_push(title, body, settings):

    """
    Web Push needs a browser push subscription
    per recipient. The portal does not collect
    subscriptions yet, so this channel cannot
    send until that exists.
    """

    return {
        "success": False,
        "message": (
            "Web Push requires browser push "
            "subscriptions, which the portal "
            "does not collect yet."
        )
    }

# ---------------------------------------------------------
# Entry points
# ---------------------------------------------------------

def send_test(channel, extra=None):

    channel = (channel or "").strip().lower()
    extra = extra or {}

    settings = get_notification_settings()

    missing = missing_settings(
        channel,
        settings
    )

    if missing:
        return {
            "success": False,
            "message": (
                "Channel is not configured - "
                "missing: %s"
                % ", ".join(missing)
            )
        }

    if channel == "pushbullet":

        return send_pushbullet(
            "Portal Test Notification",
            "This is a test notification from "
            "your DNS Security Dashboard portal.",
            settings
        )

    if channel == "telegram":

        return send_telegram(
            "Portal Test Notification - this is "
            "a test from your DNS Security "
            "Dashboard portal.",
            settings
        )

    if channel == "whatsapp":

        to = (extra.get("to") or "").strip()

        if not to:
            return {
                "success": False,
                "message": (
                    "A recipient mobile number is "
                    "required for the WhatsApp "
                    "test."
                )
            }

        return send_whatsapp(
            "Portal Test Notification - this is "
            "a test from your DNS Security "
            "Dashboard portal.",
            to,
            settings
        )

    if channel == "email":

        return send_email(
            "Portal Test Notification",
            "This is a test notification from "
            "your DNS Security Dashboard portal.",
            settings
        )

    if channel == "push":

        return send_push(
            "Portal Test Notification",
            "",
            settings
        )

    return {
        "success": False,
        "message": (
            "Unknown channel: %s" % channel
        )
    }


def send_notification(
    channel,
    title,
    message,
    recipient=None
):

    """
    Generic dispatch used by the notification
    engine (login notifications, monitor
    alerts). Recipient handling differs per
    channel: WhatsApp expects a mobile number,
    the others use their stored configuration.
    """

    channel = (channel or "").strip().lower()

    settings = get_notification_settings()

    missing = missing_settings(
        channel,
        settings
    )

    if missing:
        return {
            "success": False,
            "message": (
                "Channel is not configured - "
                "missing: %s"
                % ", ".join(missing)
            )
        }

    if channel == "pushbullet":
        return send_pushbullet(
            title, message, settings
        )

    if channel == "telegram":
        return send_telegram(
            "%s - %s" % (title, message),
            settings
        )

    if channel == "whatsapp":
        return send_whatsapp(
            message,
            recipient or "",
            settings
        )

    if channel == "email":
        return send_email(
            title,
            message,
            settings,
            to=recipient
        )

    if channel == "push":
        return send_push(title, message, settings)

    return {
        "success": False,
        "message": "Unknown channel: %s" % channel
    }
