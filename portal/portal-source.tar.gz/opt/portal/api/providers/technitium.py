"""
Technitium DNS provider.

Wraps the Technitium Web API for the capabilities the portal
needs. This is where the portal's existing direct Technitium
calls live; the rest of the portal talks to this class only.
"""

import requests

from config import (
    POSTGRES_HOST,
    POSTGRES_DB,
    POSTGRES_USER,
    POSTGRES_PASSWORD,
    TECHNITIUM_HOST,
    TECHNITIUM_TOKEN,
)

from providers.base import NetworkServiceProvider

TECHNITIUM_HEADERS = {
    "Authorization": f"Bearer {TECHNITIUM_TOKEN}"
}

TECHNITIUM_BASE = f"http://{TECHNITIUM_HOST}:5380"


class TechnitiumProvider(NetworkServiceProvider):

    name = "technitium"

    def capabilities(self):
        return {
            "blocking": True,
            "allow_timed_unblock": True,
            "cache": True,
            "recursion": True,
            "forwarders": True,
            "dhcp": True,
            "blocklists": True,
            "stats": True,
        }

    # -- health -------------------------------------------------

    def health(self):
        try:
            response = requests.get(
                f"{TECHNITIUM_BASE}/api/user/profile/get",
                headers=TECHNITIUM_HEADERS,
                timeout=5
            )
            ok = (
                response.status_code == 200
                and response.json()
                .get("response", {})
                .get("username") == "portal-api"
            )
            return {"status": "ok" if ok else "error"}
        except Exception as exc:
            return {"status": "error", "message": str(exc)}

    # -- domain blocking ----------------------------------------

    def block_domain(self, domain):
        try:
            response = requests.get(
                f"{TECHNITIUM_BASE}/api/blocked/add",
                headers=TECHNITIUM_HEADERS,
                params={"domain": domain},
                timeout=10
            )
            return response.status_code == 200
        except Exception:
            return False

    # -- shadow account management (portal pushes, Technitium mirrors) --

    def _admin_user_call(self, path, params):
        """Best-effort admin user API call. Never raises."""
        try:
            response = requests.get(
                f"{TECHNITIUM_BASE}{path}",
                headers=TECHNITIUM_HEADERS,
                params=params,
                timeout=10
            )
            data = response.json()
            return (
                isinstance(data, dict)
                and str(data.get("status", "")).lower() != "error"
            )
        except Exception:
            return False

    def create_account_shadow(self, username, display_name, password):
        return self._admin_user_call(
            "/api/admin/users/create",
            {
                "displayName": display_name,
                "user": username,
                "pass": password
            }
        )

    def set_user_password(self, username, password):
        return self._admin_user_call(
            "/api/admin/users/set",
            {"user": username, "newPass": password}
        )

    def set_user_enabled(self, username, enabled):
        return self._admin_user_call(
            "/api/admin/users/set",
            {"user": username, "disabled": "false" if enabled else "true"}
        )

    def delete_user(self, username):
        return self._admin_user_call(
            "/api/admin/users/delete",
            {"user": username}
        )

    def set_user_display_name(self, username, display_name):
        return self._admin_user_call(
            "/api/admin/users/set",
            {"user": username, "displayName": display_name}
        )

    def unblock_domain(self, domain):
        try:
            response = requests.get(
                f"{TECHNITIUM_BASE}/api/blocked/delete",
                headers=TECHNITIUM_HEADERS,
                params={"domain": domain},
                timeout=10
            )
            return response.status_code == 200
        except Exception:
            return False
