"""
Unconfigured provider.

The state of a clean portal installation before an administrator
selects the network services backend in Settings -> System Status.
Nothing is provisioned yet: portal-owned features work normally and
backend-driven features stay dormant until a backend is provisioned.
"""

from providers.base import NetworkServiceProvider


class UnconfiguredProvider(NetworkServiceProvider):

    name = "none"

    def capabilities(self):
        return {}

    def health(self):
        return {
            "status": "error",
            "message": "No network services backend is configured",
        }

    def account_limit(self):
        return None

    def block_domain(self, domain):
        return False

    def unblock_domain(self, domain):
        return False

    def create_user(self, username, password):
        # Portal-only users are allowed: there is no backend to
        # mirror into and no licence account limit in play.
        return {"ok": True, "limit_reached": False, "synced": False}
