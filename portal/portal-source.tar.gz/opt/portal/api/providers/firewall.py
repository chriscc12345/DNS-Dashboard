"""
Firewall Appliance provider.

Drives the Firewall Appliance REST API (v3.1+) for the
capabilities the portal needs. Domain writes land in the
appliance database and are compiled into the dnsmasq config;
the appliance reconciles every 60 seconds, and this provider
additionally asks for immediate activation through the
guarded DNS transaction flow so portal approvals take effect
within seconds instead of at the next reconciler tick.
"""

import time

import requests

from config import FIREWALL_API_URL, FIREWALL_API_TOKEN

from providers.base import NetworkServiceProvider

# Category the portal uses for its own blocks, so entries the
# portal creates are identifiable in the appliance dashboard.
PORTAL_CATEGORY = "portal"


class FirewallProvider(NetworkServiceProvider):

    name = "firewall"

    def capabilities(self):
        # First integration: the block/unblock workflow that
        # main.py drives. The appliance also has blocklists,
        # DHCP, records and cache features - those stay on the
        # appliance's own dashboard until the portal DNS
        # services pages move behind the provider layer.
        return {
            "blocking": True,
            "allow_timed_unblock": True,
            "cache": False,
            "recursion": False,
            "forwarders": False,
            "dhcp": False,
            "blocklists": False,
            "stats": False,
        }

    def _headers(self):
        return {"Authorization": f"Bearer {FIREWALL_API_TOKEN}"}

    # -- health -------------------------------------------------

    def health(self):
        try:
            # Public endpoint first: is the appliance up?
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/health",
                timeout=5,
            )
            if response.status_code != 200 or response.json().get("status") != "ok":
                return {"status": "error", "message": "appliance reported unhealthy"}

            # Authenticated check: is the portal token valid and
            # the DNS service active?
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dns/status",
                headers=self._headers(),
                timeout=5,
            )
            if response.status_code != 200:
                return {
                    "status": "error",
                    "message": f"appliance API token rejected (HTTP {response.status_code})",
                }

            data = response.json()
            return {
                "status": "ok",
                "provider": self.name,
                "dns_service": data.get("dns_service"),
                "blocked_domains": data.get("blocked_domains"),
            }
        except Exception as exc:
            return {"status": "error", "message": str(exc)}

    # -- licence ------------------------------------------------

    # Class-level cache: providers are instantiated per request,
    # but the licence rarely changes and user-management pages
    # must not hit the appliance on every call.
    _licence_cache = None  # (fetched_at, account_limit)

    def account_limit(self):
        """The appliance licence's account limit; None means
        unlimited (the appliance reports 0 for unlimited, and
        unlicensed/unknown states also fail open to None)."""
        cached = FirewallProvider._licence_cache
        if cached and time.time() - cached[0] < 300:
            return cached[1]
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/licensing/status",
                headers=self._headers(),
                timeout=5,
            )
            limit = None
            if response.status_code == 200:
                value = response.json().get("account_limit")
                # 0 = unlimited on the appliance
                limit = value if value else None
        except Exception:
            # keep the last known value; None if we never knew
            limit = cached[1] if cached else None
        FirewallProvider._licence_cache = (time.time(), limit)
        return limit

    # -- block page access requests ------------------------------

    def access_requests(self):
        """Pending access requests submitted from the appliance's
        block page (Security reports -> Access requests)."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/access-requests",
                headers=self._headers(),
                timeout=10,
            )
            if response.status_code != 200:
                return None
            rows = response.json()
            return rows if isinstance(rows, list) else None
        except Exception:
            return None

    def review_access_request(self, request_id, decision, allow_minutes=None):
        """Send an approve/deny decision back to the appliance. The
        appliance's allow rules can override category blocklists
        (service-level allows), which a plain domain unblock cannot."""
        minutes = int(allow_minutes or 0)
        duration = {
            60: "1h",
            240: "4h",
            480: "8h",
            1440: "24h",
            4320: "3d",
            10080: "7d",
            43200: "30d",
        }.get(minutes, "permanent")
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/access-requests/{request_id}/review",
                headers=self._headers(),
                json={
                    "decision": decision,
                    "create_allow_rule": decision == "approved",
                    "duration": duration,
                },
                timeout=15,
            )
            return response.status_code == 200
        except Exception:
            return False

    # -- user sync ------------------------------------------------

    def create_user(self, username, password):
        """Create the appliance-side counterpart of a portal user.
        The appliance enforces its own licence account limit and its
        refusal is surfaced to the portal admin as "maximum user
        count reached"."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/users",
                headers=self._headers(),
                json={
                    "username": username.strip().lower(),
                    "password": password,
                    "role": "viewer",
                },
                timeout=10,
            )
            if response.status_code == 201:
                return {"ok": True, "limit_reached": False, "synced": True}

            if response.status_code == 409:
                message = (
                    response.json().get("detail")
                    or "Maximum user count reached on the appliance licence"
                )
                if "already exists" in str(message).lower():
                    # The appliance already holds this shadow account -
                    # idempotent success, not a licence limit.
                    return {"ok": True, "limit_reached": False, "synced": True}
                return {"ok": False, "limit_reached": True, "message": message}

            return {
                "ok": False,
                "limit_reached": False,
                "message": f"appliance user creation failed (HTTP {response.status_code})",
            }
        except Exception as exc:
            return {"ok": False, "limit_reached": False, "message": str(exc)}

    # -- shadow account management (portal pushes, appliance mirrors) --

    def _lookup_user(self, username):
        """Return the appliance user record for a portal username."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/users",
                headers=self._headers(),
                timeout=10,
            )
            if response.status_code != 200:
                return None
        except Exception:
            return None
        wanted = (username or "").strip().lower()
        for user in response.json():
            if str(user.get("username", "")).lower() == wanted:
                return user
        return None

    def create_account_shadow(self, username, display_name, password):
        # The appliance counterpart is created together with the user
        # profile (see create_user) so the licence account limit is
        # enforced at a single point.
        return True

    def set_user_enabled(self, username, enabled):
        user = self._lookup_user(username)
        if user is None:
            return True
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/users/{user['id']}",
                headers=self._headers(),
                json={
                    "role": user.get("role") or "viewer",
                    "enabled": bool(enabled),
                    "group_id": user.get("group_id"),
                },
                timeout=10,
            )
            return response.status_code == 200
        except Exception:
            return False

    def delete_user(self, username):
        user = self._lookup_user(username)
        if user is None:
            return True
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/users/{user['id']}",
                headers=self._headers(),
                timeout=10,
            )
            return response.status_code in (200, 204, 404)
        except Exception:
            return False

    def set_user_password(self, username, password):
        user = self._lookup_user(username)
        if user is None:
            return True
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/users/{user['id']}/password",
                headers=self._headers(),
                json={"new_password": password},
                timeout=10,
            )
            return response.status_code == 200
        except Exception:
            return False

    def set_user_display_name(self, username, display_name):
        # The appliance has no display-name field; the portal profile
        # owns it.
        return True

    # -- immediate activation -----------------------------------

    def _activate_now(self):
        """Ask the appliance to compile and apply the new DNS
        state immediately. Failures are non-fatal: the
        appliance's own reconciler applies the same state
        within the minute."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/dns/candidates",
                headers=self._headers(),
                timeout=10,
            )
            if response.status_code != 201:
                return
            transaction_id = response.json().get("transaction_id")
            if not transaction_id:
                return
            requests.post(
                f"{FIREWALL_API_URL}/api/v1/dns/transactions/{transaction_id}/activate",
                headers=self._headers(),
                timeout=10,
            )
        except Exception:
            pass

    # -- domain blocking ----------------------------------------

    def block_domain(self, domain):
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/domains",
                headers=self._headers(),
                json={
                    "domain": domain.strip().lower(),
                    "action": "block",
                    "category": PORTAL_CATEGORY,
                },
                timeout=10,
            )
            if response.status_code == 201:
                self._activate_now()
                return True
            # 409 means the domain is already in the table -
            # success for our purposes (idempotent re-block).
            if response.status_code == 409:
                return True
            return False
        except Exception:
            return False

    def unblock_domain(self, domain):
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/domains",
                headers=self._headers(),
                timeout=10,
            )
            if response.status_code != 200:
                return False

            wanted = domain.strip().lower()
            removed = False
            failed = False
            for entry in response.json():
                if (
                    entry.get("domain", "").lower() == wanted
                    and entry.get("action") == "block"
                ):
                    delete = requests.delete(
                        f"{FIREWALL_API_URL}/api/v1/domains/{entry['id']}",
                        headers=self._headers(),
                        timeout=10,
                    )
                    if delete.status_code == 204:
                        removed = True
                    else:
                        failed = True

            if failed:
                return False
            if removed:
                self._activate_now()
            # Nothing to remove means the domain is not blocked,
            # which is what the caller wanted (idempotent).
            return True
        except Exception:
            return False