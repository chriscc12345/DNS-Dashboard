"""
Firewall Appliance provider.

Drives the Firewall Appliance REST API (v3.1+) for the
capabilities the portal needs. Domain writes land in the
appliance database and are compiled into the dnsmasq config;
the appliance reconciles every 60 seconds, and this provider
additionally asks for immediate activation through the
guarded DNS transaction flow so portal approvals take effect
within seconds instead of at the next reconciler tick.
"""

import time

from datetime import datetime, timedelta, timezone

import requests

from config import FIREWALL_API_URL, FIREWALL_API_TOKEN

from providers.base import NetworkServiceProvider

# Category the portal uses for its own blocks, so entries the
# portal creates are identifiable in the appliance dashboard.
PORTAL_CATEGORY = "portal"


class FirewallProvider(NetworkServiceProvider):

    name = "firewall"

    def capabilities(self):
        # First integration: the block/unblock workflow that
        # main.py drives. The appliance also has blocklists,
        # DHCP, records and cache features - those stay on the
        # appliance's own dashboard until the portal DNS
        # services pages move behind the provider layer.
        return {
            "blocking": True,
            "allow_timed_unblock": True,
            "cache": False,
            "recursion": False,
            "forwarders": False,
            "dhcp": False,
            "blocklists": False,
            "stats": False,
        }

    def _headers(self):
        return {"Authorization": f"Bearer {FIREWALL_API_TOKEN}"}

    # -- health -------------------------------------------------

    def health(self):
        try:
            # Public endpoint first: is the appliance up?
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/health",
                timeout=5,
            )
            if response.status_code != 200 or response.json().get("status") != "ok":
                return {"status": "error", "message": "appliance reported unhealthy"}

            # Authenticated check: is the portal token valid and
            # the DNS service active?
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dns/status",
                headers=self._headers(),
                timeout=5,
            )
            if response.status_code != 200:
                return {
                    "status": "error",
                    "message": f"appliance API token rejected (HTTP {response.status_code})",
                }

            data = response.json()
            return {
                "status": "ok",
                "provider": self.name,
                "dns_service": data.get("dns_service"),
                "blocked_domains": data.get("blocked_domains"),
            }
        except Exception as exc:
            return {"status": "error", "message": str(exc)}

    # -- licence ------------------------------------------------

    # Class-level cache: providers are instantiated per request,
    # but the licence rarely changes and user-management pages
    # must not hit the appliance on every call.
    _licence_cache = None  # (fetched_at, account_limit)

    def account_limit(self):
        """The appliance licence's account limit; None means
        unlimited (the appliance reports 0 for unlimited, and
        unlicensed/unknown states also fail open to None)."""
        cached = FirewallProvider._licence_cache
        if cached and time.time() - cached[0] < 300:
            return cached[1]
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/licensing/status",
                headers=self._headers(),
                timeout=5,
            )
            limit = None
            if response.status_code == 200:
                value = response.json().get("account_limit")
                # 0 = unlimited on the appliance
                limit = value if value else None
        except Exception:
            # keep the last known value; None if we never knew
            limit = cached[1] if cached else None
        FirewallProvider._licence_cache = (time.time(), limit)
        return limit

    # -- block page access requests ------------------------------

    def access_requests(self):
        """Pending access requests submitted from the appliance's
        block page (Security reports -> Access requests)."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/access-requests",
                headers=self._headers(),
                timeout=10,
            )
            if response.status_code != 200:
                return None
            rows = response.json()
            return rows if isinstance(rows, list) else None
        except Exception:
            return None

    def review_access_request(self, request_id, decision, allow_minutes=None):
        """Send an approve/deny decision back to the appliance. The
        appliance's allow rules can override category blocklists
        (service-level allows), which a plain domain unblock cannot."""
        minutes = int(allow_minutes or 0)
        duration = "permanent"
        if minutes > 0:
            # The backend applies timed allows in fixed steps; a request
            # below the smallest step rounds UP instead of going
            # permanent.
            for step, code in (
                (60, "1h"), (240, "4h"), (480, "8h"), (1440, "24h"),
                (4320, "3d"), (10080, "7d"), (43200, "30d"),
            ):
                if minutes <= step:
                    duration = code
                    break
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/access-requests/{request_id}/review",
                headers=self._headers(),
                json={
                    "decision": decision,
                    "create_allow_rule": decision == "approved",
                    "duration": duration,
                },
                timeout=15,
            )
            return response.status_code == 200
        except Exception:
            return False

    def allow_domain_timed(self, domain, allow_minutes):
        """Apply a timed allow directly (used when re-allowing a request
        the appliance already reviewed - its review endpoint is
        one-shot). Unlike the review flow this honors the EXACT
        requested duration, and covers the same service-level domain
        group the review flow would have allowed."""
        target = domain.strip().lower()
        domains = {target}
        if target.startswith("www."):
            domains.add(target[4:])

        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/applications",
                headers=self._headers(),
                timeout=10,
            )
            if response.status_code == 200:
                for service in response.json():
                    service_domains = {
                        (entry or "").strip().lower()
                        for entry in service.get("domains") or []
                    }
                    if target in service_domains or any(
                        target.endswith("." + entry)
                        for entry in service_domains
                    ):
                        domains |= service_domains
                        break
        except Exception:
            pass

        minutes = int(allow_minutes or 0)
        expires = None
        if minutes > 0:
            expires = (
                datetime.now(timezone.utc) + timedelta(minutes=minutes)
            ).isoformat()

        try:
            existing = requests.get(
                f"{FIREWALL_API_URL}/api/v1/domains",
                headers=self._headers(),
                timeout=10,
            )
            existing_rows = existing.json() if existing.status_code == 200 else []
        except Exception:
            existing_rows = []

        ok = False
        for entry_domain in sorted(domains):
            try:
                for row in existing_rows:
                    if (row.get("domain") or "").lower() == entry_domain:
                        requests.delete(
                            f"{FIREWALL_API_URL}/api/v1/domains/{row.get('id')}",
                            headers=self._headers(),
                            timeout=10,
                        )
                created = requests.post(
                    f"{FIREWALL_API_URL}/api/v1/domains",
                    headers=self._headers(),
                    json={
                        "domain": entry_domain,
                        "action": "allow",
                        "category": "access-request",
                        "expires_at": expires,
                    },
                    timeout=10,
                )
                if created.status_code in (200, 201):
                    ok = True
            except Exception:
                continue

        if ok:
            self._activate_now()
        return ok

    def revoke_domain_allows(self, domain):
        """Remove the access-request allow rules the appliance created
        for a domain. Blocking is service-level, so allowing was too:
        the review created one allow per service domain and they all
        share the review's expiry timestamp - that shared timestamp is
        what identifies the group."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/domains",
                headers=self._headers(),
                timeout=10,
            )
            if response.status_code != 200:
                return False
            entries = response.json()
            wanted = domain.strip().lower()
            anchor = next(
                (
                    entry
                    for entry in entries
                    if (entry.get("domain") or "").lower() == wanted
                    and entry.get("action") == "allow"
                    and entry.get("category") == "access-request"
                ),
                None,
            )
            if not anchor:
                return True

            group_expiry = anchor.get("expires_at")
            for entry in entries:
                if (
                    entry.get("action") != "allow"
                    or entry.get("category") != "access-request"
                ):
                    continue
                if entry.get("id") != anchor.get("id") and entry.get("expires_at") != group_expiry:
                    continue
                requests.delete(
                    f"{FIREWALL_API_URL}/api/v1/domains/{entry.get('id')}",
                    headers=self._headers(),
                    timeout=10,
                )

            self._activate_now()
            return True
        except Exception:
            return False

    # -- user sync ------------------------------------------------

    def create_user(self, username, password):
        """Create the appliance-side counterpart of a portal user.
        The appliance enforces its own licence account limit and its
        refusal is surfaced to the portal admin as "maximum user
        count reached"."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/users",
                headers=self._headers(),
                json={
                    "username": username.strip().lower(),
                    "password": password,
                    "role": "viewer",
                },
                timeout=10,
            )
            if response.status_code == 201:
                return {"ok": True, "limit_reached": False, "synced": True}

            if response.status_code == 409:
                message = (
                    response.json().get("detail")
                    or "Maximum user count reached on the appliance licence"
                )
                if "already exists" in str(message).lower():
                    # The appliance already holds this shadow account -
                    # idempotent success, not a licence limit.
                    return {"ok": True, "limit_reached": False, "synced": True}
                return {"ok": False, "limit_reached": True, "message": message}

            return {
                "ok": False,
                "limit_reached": False,
                "message": f"appliance user creation failed (HTTP {response.status_code})",
            }
        except Exception as exc:
            return {"ok": False, "limit_reached": False, "message": str(exc)}

    # -- shadow account management (portal pushes, appliance mirrors) --

    def _lookup_user(self, username):
        """Return the appliance user record for a portal username."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/users",
                headers=self._headers(),
                timeout=10,
            )
            if response.status_code != 200:
                return None
        except Exception:
            return None
        wanted = (username or "").strip().lower()
        for user in response.json():
            if str(user.get("username", "")).lower() == wanted:
                return user
        return None

    def create_account_shadow(self, username, display_name, password):
        # The appliance counterpart is created together with the user
        # profile (see create_user) so the licence account limit is
        # enforced at a single point.
        return True

    def set_user_enabled(self, username, enabled):
        user = self._lookup_user(username)
        if user is None:
            return True
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/users/{user['id']}",
                headers=self._headers(),
                json={
                    "role": user.get("role") or "viewer",
                    "enabled": bool(enabled),
                    "group_id": user.get("group_id"),
                },
                timeout=10,
            )
            return response.status_code == 200
        except Exception:
            return False

    def delete_user(self, username):
        user = self._lookup_user(username)
        if user is None:
            return True
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/users/{user['id']}",
                headers=self._headers(),
                timeout=10,
            )
            return response.status_code in (200, 204, 404)
        except Exception:
            return False

    def set_user_password(self, username, password):
        user = self._lookup_user(username)
        if user is None:
            return True
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/users/{user['id']}/password",
                headers=self._headers(),
                json={"new_password": password},
                timeout=10,
            )
            return response.status_code == 200
        except Exception:
            return False

    def set_user_display_name(self, username, display_name):
        # The appliance has no display-name field; the portal profile
        # owns it.
        return True

    # -- immediate activation -----------------------------------

    def _activate_now(self):
        """Ask the appliance to compile and apply the new DNS
        state immediately. Failures are non-fatal: the
        appliance's own reconciler applies the same state
        within the minute."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/dns/candidates",
                headers=self._headers(),
                timeout=10,
            )
            if response.status_code != 201:
                return
            transaction_id = response.json().get("transaction_id")
            if not transaction_id:
                return
            requests.post(
                f"{FIREWALL_API_URL}/api/v1/dns/transactions/{transaction_id}/activate",
                headers=self._headers(),
                timeout=10,
            )
        except Exception:
            pass

    # -- domain blocking ----------------------------------------

    def block_domain(self, domain):
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/domains",
                headers=self._headers(),
                json={
                    "domain": domain.strip().lower(),
                    "action": "block",
                    "category": PORTAL_CATEGORY,
                },
                timeout=10,
            )
            if response.status_code == 201:
                self._activate_now()
                return True
            # 409 means the domain is already in the table -
            # success for our purposes (idempotent re-block).
            if response.status_code == 409:
                return True
            return False
        except Exception:
            return False

    def unblock_domain(self, domain):
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/domains",
                headers=self._headers(),
                timeout=10,
            )
            if response.status_code != 200:
                return False

            wanted = domain.strip().lower()
            removed = False
            failed = False
            for entry in response.json():
                if (
                    entry.get("domain", "").lower() == wanted
                    and entry.get("action") == "block"
                ):
                    delete = requests.delete(
                        f"{FIREWALL_API_URL}/api/v1/domains/{entry['id']}",
                        headers=self._headers(),
                        timeout=10,
                    )
                    if delete.status_code == 204:
                        removed = True
                    else:
                        failed = True

            if failed:
                return False
            if removed:
                self._activate_now()
            # Nothing to remove means the domain is not blocked,
            # which is what the caller wanted (idempotent).
            return True
        except Exception:
            return False    # -- appliance console: devices -----------------------------

    def list_devices(self):
        """Live device inventory plus the blocking policies that
        target them. Block state is derived from enabled policies
        (the appliance blocks via policy targets)."""
        try:
            devices = requests.get(
                f"{FIREWALL_API_URL}/api/v1/devices",
                headers=self._headers(),
                timeout=15,
            )
            if devices.status_code != 200:
                return None
            policies = requests.get(
                f"{FIREWALL_API_URL}/api/v1/policies",
                headers=self._headers(),
                timeout=15,
            )
            policy_rows = policies.json() if policies.status_code == 200 else []
            targets = {}
            for row in policy_rows:
                if row.get("enabled"):
                    key = str(row.get("target_value", "")).strip().lower()
                    if key:
                        targets[key] = row
            return {"devices": devices.json(), "blocked_targets": targets}
        except Exception:
            return None

    def block_device(self, target_type, target_value, reason="Blocked from the Portal"):
        """Block a device by mac/ip/hostname through an appliance
        blocking policy."""
        if target_type not in ("mac", "ip", "hostname"):
            return {"success": False, "message": "target_type must be mac, ip or hostname"}
        if not target_value:
            return {"success": False, "message": "target_value is required"}
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/policies",
                headers=self._headers(),
                json={
                    "name": f"Portal block {target_value}",
                    "target_type": target_type,
                    "target_value": target_value,
                    "enabled": True,
                    "reason": reason or "Blocked from the Portal",
                },
                timeout=15,
            )
            if response.status_code == 201:
                return {"success": True, "policy": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def unblock_device(self, policy_id):
        """Remove the blocking policy so the device is unblocked."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/policies/{policy_id}",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code == 204:
                return {"success": True}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    # -- appliance console: firewall modules --------------------

    def list_modules(self):
        """Firewall module inventory plus the IDS/IPS helper status."""
        try:
            modules = requests.get(
                f"{FIREWALL_API_URL}/api/v1/firewall/modules",
                headers=self._headers(),
                timeout=15,
            )
            if modules.status_code != 200:
                return None
            ids = requests.get(
                f"{FIREWALL_API_URL}/api/v1/firewall/modules/ids_ips/status",
                headers=self._headers(),
                timeout=15,
            )
            return {
                "modules": modules.json(),
                "ids_ips": ids.json() if ids.status_code == 200 else None,
            }
        except Exception:
            return None

    def set_module(self, module_key, enabled):
        """Enable or disable a firewall module."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/firewall/modules/{module_key}",
                headers=self._headers(),
                json={"enabled": bool(enabled)},
                timeout=30,
            )
            if response.status_code == 200:
                return {"success": True, "module": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def ids_ips_action(self, action):
        """Install, uninstall or update the IDS/IPS rule feed."""
        endpoints = {
            "install": ("/api/v1/firewall/modules/ids_ips/install", 600),
            "uninstall": ("/api/v1/firewall/modules/ids_ips/uninstall", 600),
            "rules_update": ("/api/v1/firewall/modules/ids_ips/rules/update", 600),
        }
        if action not in endpoints:
            return {"success": False, "message": "unknown action"}
        path, timeout = endpoints[action]
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}{path}",
                headers=self._headers(),
                timeout=timeout,
            )
            body = {}
            try:
                body = response.json()
            except Exception:
                body = {}
            if response.status_code == 200:
                return {"success": True, "result": body}
            message = str(body.get("detail") or body.get("message") or f"appliance returned HTTP {response.status_code}")
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}
    # -- appliance console: recent security events ------------------

    def recent_events(self, limit=200):
        """Most recent appliance security events (newest first)."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/events",
                headers=self._headers(),
                params={"limit": limit},
                timeout=15,
            )
            if response.status_code != 200:
                return None
            return {"events": response.json()}
        except Exception:
            return None
    # -- appliance console: network (interfaces + hostname) ----------

    def network_info(self):
        """Appliance network interfaces (with labels) and hostname."""
        try:
            interfaces = requests.get(
                f"{FIREWALL_API_URL}/api/v1/system/interfaces",
                headers=self._headers(),
                timeout=15,
            )
            if interfaces.status_code != 200:
                return None
            hostname = requests.get(
                f"{FIREWALL_API_URL}/api/v1/system/hostname",
                headers=self._headers(),
                timeout=15,
            )
            return {
                "interfaces": interfaces.json(),
                "hostname": hostname.json().get("hostname") if hostname.status_code == 200 else None,
            }
        except Exception:
            return None

    def set_interface_label(self, interface, label):
        """Set (or clear) the display label of an appliance interface."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/system/interfaces/labels",
                headers=self._headers(),
                json={"interface": interface, "label": label},
                timeout=15,
            )
            if response.status_code == 200:
                return {"success": True, "label": response.json().get("label")}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def set_hostname(self, hostname):
        """Change the appliance hostname (runs the appliance's
        hostname transaction helper)."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/system/hostname",
                headers=self._headers(),
                json={"hostname": hostname},
                timeout=90,
            )
            if response.status_code == 200:
                return {"success": True, "hostname": response.json().get("hostname")}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
                elif isinstance(detail, dict):
                    message = str(detail.get("message") or detail)
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}
    # -- appliance console: audit log --------------------------------

    def audit_events(self, limit=200):
        """Most recent appliance audit entries (newest first)."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/audit",
                headers=self._headers(),
                params={"limit": limit},
                timeout=15,
            )
            if response.status_code != 200:
                return None
            return {"events": response.json()}
        except Exception:
            return None

    # -- appliance console: block list feeds -------------------------

    def blocklists(self):
        """Blocklist feed sources with status and domain counts."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/blocklists",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code != 200:
                return None
            return {"blocklists": response.json()}
        except Exception:
            return None

    def _blocklist_result(self, response):
        if response.status_code in (200, 201):
            return {"success": True, "result": response.json()}
        message = f"appliance returned HTTP {response.status_code}"
        try:
            detail = response.json().get("detail")
            if isinstance(detail, str):
                message = detail
        except Exception:
            pass
        return {"success": False, "message": message}

    def blocklist_add(self, name, url, fmt, update_hours, category):
        """Register a custom blocklist feed (hosts or domains format)."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/blocklists",
                headers=self._headers(),
                json={
                    "name": name.strip(),
                    "url": url.strip(),
                    "format": fmt or "hosts",
                    "enabled": True,
                    "update_hours": update_hours,
                    "category": (category or "").strip().lower(),
                },
                timeout=15,
            )
            return self._blocklist_result(response)
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def blocklist_stevenblack(self):
        """Register the curated StevenBlack unified hosts feed."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/blocklists/stevenblack",
                headers=self._headers(),
                timeout=15,
            )
            return self._blocklist_result(response)
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def blocklist_feeds(self):
        """Register every curated category feed that is missing."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/blocklists/category-feeds",
                headers=self._headers(),
                timeout=15,
            )
            return self._blocklist_result(response)
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def blocklist_delete(self, source_id):
        """Remove a blocklist feed source."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/blocklists/{source_id}",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code == 204:
                return {"success": True}
            return {"success": False, "message": f"appliance returned HTTP {response.status_code}"}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def blocklist_update(self, source_id):
        """Refresh one blocklist feed now."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/blocklists/{source_id}/update",
                headers=self._headers(),
                timeout=180,
            )
            return self._blocklist_result(response)
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def blocklists_update_due(self, force=False):
        """Refresh every due blocklist feed."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/blocklists/update-due",
                headers=self._headers(),
                params={"force": "true" if force else "false"},
                timeout=300,
            )
            return self._blocklist_result(response)
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    # -- appliance console: application blocking ----------------------

    def applications_overview(self):
        """Application policies and category cards in one view."""
        try:
            applications = requests.get(
                f"{FIREWALL_API_URL}/api/v1/applications",
                headers=self._headers(),
                timeout=15,
            )
            if applications.status_code != 200:
                return None
            categories = requests.get(
                f"{FIREWALL_API_URL}/api/v1/categories",
                headers=self._headers(),
                timeout=15,
            )
            return {
                "applications": applications.json(),
                "categories": categories.json() if categories.status_code == 200 else [],
            }
        except Exception:
            return None

    def application_set(self, application, enabled, block_quic):
        """Enable/disable one application policy (with QUIC control)."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/applications/{application}",
                headers=self._headers(),
                json={
                    "application": application,
                    "enabled": bool(enabled),
                    "block_quic": bool(block_quic),
                },
                timeout=30,
            )
            if response.status_code == 200:
                return {"success": True, "application": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def category_set(self, category, enabled, block_quic):
        """Enable/disable a whole category (custom groups apply to
        every member application)."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/categories/{category}",
                headers=self._headers(),
                json={
                    "category": category,
                    "enabled": bool(enabled),
                    "block_quic": bool(block_quic),
                },
                timeout=60,
            )
            if response.status_code == 200:
                return {"success": True, "category": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def service_add(self, name, category, domains):
        """Create a custom service (name + domains)."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/applications",
                headers=self._headers(),
                json={
                    "name": name.strip().lower(),
                    "category": category.strip(),
                    "domains": domains,
                },
                timeout=15,
            )
            return self._blocklist_result(response)
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def service_delete(self, name):
        """Remove a custom service."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/applications/{name}",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code == 204:
                return {"success": True}
            return {"success": False, "message": f"appliance returned HTTP {response.status_code}"}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def group_add(self, name, description):
        """Create a custom application group."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/categories",
                headers=self._headers(),
                json={"name": name.strip(), "description": (description or "").strip()},
                timeout=15,
            )
            return self._blocklist_result(response)
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def group_delete(self, category):
        """Remove a custom application group."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/categories/{category}",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code == 204:
                return {"success": True}
            return {"success": False, "message": f"appliance returned HTTP {response.status_code}"}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def group_member_add(self, category, application):
        """Add an application to a custom group."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/categories/{category}/members",
                headers=self._headers(),
                json={"application": application.strip().lower()},
                timeout=15,
            )
            return self._blocklist_result(response)
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def group_member_remove(self, category, application):
        """Remove an application from a custom group."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/categories/{category}/members/{application}",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code == 204:
                return {"success": True}
            return {"success": False, "message": f"appliance returned HTTP {response.status_code}"}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    # -- appliance console: web proxy and cache -----------------------

    def proxy_overview(self):
        """Squid proxy settings plus cache status."""
        try:
            settings = requests.get(
                f"{FIREWALL_API_URL}/api/v1/proxy/settings",
                headers=self._headers(),
                timeout=15,
            )
            if settings.status_code != 200:
                return None
            cache = requests.get(
                f"{FIREWALL_API_URL}/api/v1/cache/status",
                headers=self._headers(),
                timeout=15,
            )
            return {
                "settings": settings.json(),
                "cache": cache.json() if cache.status_code == 200 else None,
            }
        except Exception:
            return None

    def proxy_set(self, payload):
        """Save the proxy settings (full object; TLS inspection rejected
        by the appliance in this release)."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/proxy/settings",
                headers=self._headers(),
                json=payload,
                timeout=15,
            )
            if response.status_code == 200:
                return {"success": True, "settings": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def cache_purge(self, url):
        """Purge one URL from the proxy cache."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/cache/purge",
                headers=self._headers(),
                json={"url": url},
                timeout=30,
            )
            if response.status_code == 200:
                return {"success": True, "result": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    # -- appliance console: policy acceptance --------------------------

    def policy_overview(self):
        """Policy-acceptance portal settings plus accepted devices."""
        try:
            settings = requests.get(
                f"{FIREWALL_API_URL}/api/v1/portal/settings",
                headers=self._headers(),
                timeout=15,
            )
            if settings.status_code != 200:
                return None
            accepted = requests.get(
                f"{FIREWALL_API_URL}/api/v1/portal/accepted",
                headers=self._headers(),
                timeout=15,
            )
            return {
                "settings": settings.json(),
                "accepted": accepted.json() if accepted.status_code == 200 else [],
            }
        except Exception:
            return None

    def policy_set(self, payload):
        """Save the policy-acceptance portal settings (full object)."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/portal/settings",
                headers=self._headers(),
                json=payload,
                timeout=15,
            )
            if response.status_code == 200:
                return {"success": True, "settings": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def acceptance_revoke(self, item_id):
        """Revoke a device's policy acceptance."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/portal/accepted/{item_id}",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code == 204:
                return {"success": True}
            return {"success": False, "message": f"appliance returned HTTP {response.status_code}"}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    # -- appliance console: block page ---------------------------------

    def blockpage_settings(self):
        """Block page presentation settings."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/block-page/settings",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code != 200:
                return None
            return {"settings": response.json()}
        except Exception:
            return None

    def blockpage_set(self, payload):
        """Save the block page settings (full object)."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/block-page/settings",
                headers=self._headers(),
                json=payload,
                timeout=15,
            )
            if response.status_code == 200:
                return {"success": True, "settings": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    # -- appliance console: operations -------------------------------

    def operations_info(self):
        """System overview plus the appliance service list."""
        try:
            overview = requests.get(
                f"{FIREWALL_API_URL}/api/v1/system/overview",
                headers=self._headers(),
                timeout=15,
            )
            if overview.status_code != 200:
                return None
            services = requests.get(
                f"{FIREWALL_API_URL}/api/v1/system/services",
                headers=self._headers(),
                timeout=15,
            )
            return {
                "overview": overview.json(),
                "services": services.json() if services.status_code == 200 else [],
            }
        except Exception:
            return None

    def backup_export(self):
        """Download the appliance backup archive (tar.gz)."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/backup/export",
                headers=self._headers(),
                timeout=120,
            )
            if response.status_code != 200:
                return None
            return response.content
        except Exception:
            return None

    # -- appliance console: DHCP / IP pools ---------------------------

    def dhcp_overview(self):
        """DHCP settings, live leases, VLAN IP pools and reservations."""
        try:
            settings = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dhcp/settings",
                headers=self._headers(),
                timeout=15,
            )
            if settings.status_code != 200:
                return None
            leases = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dhcp/leases",
                headers=self._headers(),
                timeout=15,
            )
            pools = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dhcp/pools",
                headers=self._headers(),
                timeout=15,
            )
            reservations = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dhcp/reservations",
                headers=self._headers(),
                timeout=15,
            )
            return {
                "settings": settings.json(),
                "leases": leases.json() if leases.status_code == 200 else {"active": 0, "leases": []},
                "pools": pools.json() if pools.status_code == 200 else [],
                "reservations": reservations.json() if reservations.status_code == 200 else [],
            }
        except Exception:
            return None

    def dhcp_set_enabled(self, enabled):
        """Enable or disable the primary DHCP service."""
        try:
            current = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dhcp/settings",
                headers=self._headers(),
                timeout=15,
            )
            if current.status_code != 200:
                return {"success": False, "message": "could not read current DHCP settings"}
            payload = current.json()
            payload["enabled"] = bool(enabled)
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/dhcp/settings",
                headers=self._headers(),
                json=payload,
                timeout=15,
            )
            if response.status_code == 200:
                return {"success": True, "settings": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def dhcp_pool_add(self, payload):
        """Add a VLAN client IP pool."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/dhcp/pools",
                headers=self._headers(),
                json=payload,
                timeout=200,
            )
            if response.status_code == 201:
                return {"success": True, "pool": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def dhcp_pool_delete(self, pool_id):
        """Remove a VLAN client IP pool."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/dhcp/pools/{pool_id}",
                headers=self._headers(),
                timeout=200,
            )
            if response.status_code == 204:
                return {"success": True}
            return {"success": False, "message": f"appliance returned HTTP {response.status_code}"}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def dhcp_reservation_add(self, payload):
        """Add a DHCP reservation (MAC -> fixed IP)."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/dhcp/reservations",
                headers=self._headers(),
                json=payload,
                timeout=15,
            )
            if response.status_code == 201:
                return {"success": True, "reservation": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def dhcp_reservation_delete(self, reservation_id):
        """Remove a DHCP reservation."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/dhcp/reservations/{reservation_id}",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code == 204:
                return {"success": True}
            return {"success": False, "message": f"appliance returned HTTP {response.status_code}"}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    # -- appliance console: WireGuard VPN ------------------------------

    def wireguard_overview(self):
        """WireGuard settings, live status and peers."""
        try:
            settings = requests.get(
                f"{FIREWALL_API_URL}/api/v1/wireguard/settings",
                headers=self._headers(),
                timeout=15,
            )
            if settings.status_code != 200:
                return None
            status = requests.get(
                f"{FIREWALL_API_URL}/api/v1/wireguard/status",
                headers=self._headers(),
                timeout=15,
            )
            peers = requests.get(
                f"{FIREWALL_API_URL}/api/v1/wireguard/peers",
                headers=self._headers(),
                timeout=15,
            )
            return {
                "settings": settings.json(),
                "status": status.json() if status.status_code == 200 else None,
                "peers": peers.json() if peers.status_code == 200 else [],
            }
        except Exception:
            return None

    def wireguard_set_enabled(self, enabled):
        """Enable or disable the WireGuard tunnel."""
        try:
            current = requests.get(
                f"{FIREWALL_API_URL}/api/v1/wireguard/settings",
                headers=self._headers(),
                timeout=15,
            )
            if current.status_code != 200:
                return {"success": False, "message": "could not read current WireGuard settings"}
            payload = current.json()
            payload["enabled"] = bool(enabled)
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/wireguard/settings",
                headers=self._headers(),
                json=payload,
                timeout=60,
            )
            if response.status_code == 200:
                return {"success": True, "settings": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def wireguard_peer_add(self, payload):
        """Add a WireGuard peer (client or site)."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/wireguard/peers",
                headers=self._headers(),
                json=payload,
                timeout=30,
            )
            if response.status_code == 201:
                return {"success": True, "peer": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def wireguard_peer_delete(self, peer_id):
        """Remove a WireGuard peer."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/wireguard/peers/{peer_id}",
                headers=self._headers(),
                timeout=30,
            )
            if response.status_code == 204:
                return {"success": True}
            return {"success": False, "message": f"appliance returned HTTP {response.status_code}"}
        except Exception as exc:
            return {"success": False, "message": str(exc)}
    # -- appliance console: block page logo + custom page ------------

    def blockpage_logo(self):
        """The block page logo image (bundled default until uploaded)."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/block-page/logo",
                timeout=15,
            )
            if response.status_code != 200:
                return None
            media = response.headers.get("Content-Type", "image/png")
            return response.content, media
        except Exception:
            return None

    def blockpage_logo_upload(self, data, content_type):
        """Upload the block page logo (PNG/JPEG/SVG, under 256 KB)."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/block-page/logo",
                headers=self._headers() | {"Content-Type": content_type or "application/octet-stream"},
                data=data,
                timeout=15,
            )
            if response.status_code == 200:
                return {"success": True, "result": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def blockpage_logo_delete(self):
        """Remove the uploaded logo (falls back to the bundled one)."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/block-page/logo",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code == 204:
                return {"success": True}
            return {"success": False, "message": f"appliance returned HTTP {response.status_code}"}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def blockpage_custom_upload(self, html):
        """Upload a fully custom HTML block page (placeholders
        {{REQUESTED_HOST}}, {{CLIENT_IP}}, {{HOSTNAME}}, {{POLICY}}
        are filled live)."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/block-page/custom",
                headers=self._headers() | {"Content-Type": "text/html; charset=utf-8"},
                data=html,
                timeout=15,
            )
            if response.status_code == 201:
                return {"success": True, "result": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def blockpage_custom_delete(self):
        """Remove the custom HTML page (back to the generated page)."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/block-page/custom",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code == 204:
                return {"success": True}
            return {"success": False, "message": f"appliance returned HTTP {response.status_code}"}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def blockpage_preview(self):
        """The rendered block page exactly as blocked clients see it."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/block-page/preview",
                timeout=15,
            )
            if response.status_code != 200:
                return None
            return response.text
        except Exception:
            return None
    # -- appliance console: license, admin port, ACME TLS, docs ------

    def license_status(self):
        """The appliance licence state (edition, features, limits)."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/licensing/status",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code != 200:
                return None
            return response.json()
        except Exception:
            return None

    def admin_port(self):
        """The admin dashboard TCP port plus the reserved list."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/system/admin-port",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code != 200:
                return None
            return response.json()
        except Exception:
            return None

    def admin_port_set(self, port):
        """Move the admin dashboard to another port."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/system/admin-port",
                headers=self._headers(),
                json={"port": int(port)},
                timeout=120,
            )
            if response.status_code == 200:
                return {"success": True, "result": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
                elif isinstance(detail, dict):
                    message = str(detail.get("message") or detail)
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def acme_settings(self):
        """ACME (Cloudflare DNS-01) TLS certificate settings and status."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/system/acme",
                headers=self._headers(),
                timeout=40,
            )
            if response.status_code != 200:
                return None
            return response.json()
        except Exception:
            return None

    def acme_set(self, payload):
        """Save the ACME settings (empty api_token preserves the stored one)."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/system/acme",
                headers=self._headers(),
                json=payload,
                timeout=15,
            )
            if response.status_code == 200:
                return {"success": True, "result": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def acme_request(self):
        """Request the certificate now (runs the appliance ACME helper)."""
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/system/acme/request",
                headers=self._headers(),
                timeout=360,
            )
            if response.status_code == 200:
                return {"success": True, "result": response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def documentation(self, filename):
        """Download a manual PDF from the appliance."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/system/docs/{filename}",
                headers=self._headers(),
                timeout=30,
            )
            if response.status_code != 200:
                return None
            return response.content
        except Exception:
            return None
    # -- appliance console: block page DNS hostname + CA cert ------

    def dns_block_hostname(self):
        """The hostname blocked sites redirect to (from the DNS
        settings) plus a snapshot for the merge-on-save."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dns/settings",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code != 200:
                return None
            settings = response.json()
            return {
                "block_hostname": settings.get("block_hostname"),
                "block_page_ipv4": settings.get("block_page_ipv4"),
                "block_page_ipv6": settings.get("block_page_ipv6"),
            }
        except Exception:
            return None

    def dns_block_hostname_set(self, hostname):
        """Set the block hostname: read the DNS settings, change only
        block_hostname, save (everything else is preserved)."""
        try:
            current = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dns/settings",
                headers=self._headers(),
                timeout=15,
            )
            if current.status_code != 200:
                return {"success": False, "message": "could not read the DNS settings"}
            payload = current.json()
            payload["block_hostname"] = (hostname or "").strip() or None
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/dns/settings",
                headers=self._headers(),
                json=payload,
                timeout=30,
            )
            if response.status_code == 200:
                return {"success": True, "block_hostname": response.json().get("block_hostname")}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def ca_certificate(self):
        """The appliance HTTPS block CA certificate (for installing
        on client devices)."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/block-page/ca",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code != 200:
                return None
            return response.content
        except Exception:
            return None

    # -- appliance console: IP pools + device assignment (3.5) ------------

    def pools_overview(self):
        """IP pools plus current reservations for the Devices page
        assignment flow."""
        try:
            pools = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dhcp/pools",
                headers=self._headers(),
                timeout=15,
            )
            if pools.status_code != 200:
                return None
            reservations = requests.get(
                f"{FIREWALL_API_URL}/api/v1/dhcp/reservations",
                headers=self._headers(),
                timeout=15,
            )
            return {
                "pools": pools.json(),
                "reservations": reservations.json() if reservations.status_code == 200 else [],
            }
        except Exception:
            return None

    def assign_device_to_pool(self, mac_address, pool_id, ip_address=None):
        """Pin a device (MAC) to an IP pool through a DHCP reservation
        inside the pool's VLAN subnet."""
        payload = {"mac_address": mac_address, "pool_id": pool_id}
        if ip_address:
            payload["ip_address"] = ip_address
        try:
            response = requests.post(
                f"{FIREWALL_API_URL}/api/v1/dhcp/devices/assign",
                headers=self._headers(),
                json=payload,
                timeout=60,
            )
            if response.status_code == 201:
                return {"success": True, **response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def unassign_device(self, reservation_id):
        """Remove a device's pool assignment (its DHCP reservation)."""
        try:
            response = requests.delete(
                f"{FIREWALL_API_URL}/api/v1/dhcp/reservations/{reservation_id}",
                headers=self._headers(),
                timeout=30,
            )
            if response.status_code == 204:
                return {"success": True}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}

    def update_mode(self):
        """Whether the appliance auto-applies builds or waits for manual."""
        try:
            response = requests.get(
                f"{FIREWALL_API_URL}/api/v1/system/update-mode",
                headers=self._headers(),
                timeout=15,
            )
            if response.status_code != 200:
                return None
            return response.json()
        except Exception:
            return None

    def update_mode_set(self, mode):
        """Switch the appliance between automatic and manual updates."""
        try:
            response = requests.put(
                f"{FIREWALL_API_URL}/api/v1/system/update-mode",
                headers=self._headers(),
                json={"mode": mode},
                timeout=15,
            )
            if response.status_code == 200:
                return {"success": True, **response.json()}
            message = f"appliance returned HTTP {response.status_code}"
            try:
                detail = response.json().get("detail")
                if isinstance(detail, str):
                    message = detail
            except Exception:
                pass
            return {"success": False, "message": message}
        except Exception as exc:
            return {"success": False, "message": str(exc)}
