"""
Provider registry.

The active network-services provider is chosen by the
portal_settings.dns_provider key ("technitium" or "firewall"),
which the administrator sets when provisioning a backend from
Settings -> System Status. A clean installation has no backend
configured yet and runs on the UnconfiguredProvider.
"""

import psycopg2

from config import (
    POSTGRES_HOST,
    POSTGRES_DB,
    POSTGRES_USER,
    POSTGRES_PASSWORD,
)

from providers.technitium import TechnitiumProvider
from providers.firewall import FirewallProvider
from providers.unconfigured import UnconfiguredProvider

_REGISTRY = {
    "technitium": TechnitiumProvider,
    "firewall": FirewallProvider,
    "none": UnconfiguredProvider,
}

DEFAULT_PROVIDER = "none"


def active_provider_name():
    """Read the configured provider (falls back to the unconfigured
    state when no backend has been provisioned yet)."""

    try:
        conn = psycopg2.connect(
            host=POSTGRES_HOST,
            database=POSTGRES_DB,
            user=POSTGRES_USER,
            password=POSTGRES_PASSWORD
        )
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT setting_value
                FROM portal_settings
                WHERE setting_key = 'dns_provider'
                LIMIT 1
            """)
            row = cur.fetchone()
            value = (row[0] if row else "") or ""
        finally:
            cur.close()
            conn.close()

        value = value.strip().lower()
        if value in _REGISTRY:
            return value
    except Exception:
        pass

    return DEFAULT_PROVIDER


def get_provider():
    """Return the provider instance for this deployment."""

    name = active_provider_name()
    cls = _REGISTRY.get(name, UnconfiguredProvider)
    return cls()
