"""
Network service provider interface.

The portal manages "the DNS/network engine" through this
abstraction so the deployment can pair the Management Portal
with either Technitium DNS (installed alongside the portal)
or the Firewall Appliance (driven over its REST API).

Every concrete provider reports which capabilities it
supports; the portal UI hides the features a provider does
not offer.
"""


class NetworkServiceProvider:
    """Base class - all providers inherit from this."""

    name = "base"

    def capabilities(self):
        """
        Return the feature matrix the UI understands.

        Keys not listed here default to unsupported.
        """
        return {
            "blocking": False,
            "allow_timed_unblock": False,
            "cache": False,
            "recursion": False,
            "forwarders": False,
            "dhcp": False,
            "blocklists": False,
            "stats": False,
        }

    # -- health -------------------------------------------------

    def health(self):
        """Cheap reachability check -> {"status": "ok"/"error", ...}"""
        return {"status": "error", "message": "not implemented"}

    # -- licence ------------------------------------------------

    def account_limit(self):
        """Maximum number of user accounts this deployment's
        licence allows, or None when unlimited. Providers whose
        engine has no licensing (e.g. Technitium) return None."""
        return None

    # -- block page access requests ------------------------------

    def access_requests(self):
        """Pending client access requests submitted on the backend's
        own block page. None when the backend has no such store."""
        return None

    def review_access_request(self, request_id, decision, allow_minutes=None):
        """Apply an approve/deny decision to a backend access request.
        False when the backend has no such store."""
        return False

    def revoke_domain_allows(self, domain):
        """Remove the backend's access-request allow rules for a domain
        (the whole service group). Providers without such rules accept
        the change."""
        return True

    def allow_domain_timed(self, domain, allow_minutes):
        """Apply a timed allow directly on the backend (used when a
        request the backend already reviewed is re-allowed). False when
        the provider cannot apply allows directly."""
        return False

    # -- user sync (deployment option 2) ----------------------------

    def create_user(self, username, password):
        """Mirror a new portal user into the network engine.
        Returns {"ok": bool, "limit_reached": bool, "message": str}.
        Providers without user sync accept every user (ok, no sync)."""
        return {"ok": True, "limit_reached": False, "synced": False}

    # -- shadow account management (portal pushes, backend mirrors) ----

    def create_account_shadow(self, username, display_name, password):
        """Push a newly created portal user account to the backend.
        Providers without shadow accounts accept the change (ok)."""
        return True

    def set_user_enabled(self, username, enabled):
        """Push enable/disable of a portal user to the backend.
        Providers without shadow accounts accept the change (ok)."""
        return True

    def delete_user(self, username):
        """Push deletion of a portal user to the backend.
        Providers without shadow accounts accept the change (ok)."""
        return True

    def set_user_password(self, username, password):
        """Push a password change for a portal user to the backend.
        Providers without shadow accounts accept the change (ok)."""
        return True

    def set_user_display_name(self, username, display_name):
        """Push a display-name change for a portal user to the backend.
        Providers without shadow accounts accept the change (ok)."""
        return True

    # -- domain blocking (the unblock-request workflow) --------

    def block_domain(self, domain):
        """Block a domain. Returns True on success."""
        return False

    def unblock_domain(self, domain):
        """Un-block a domain. Returns True on success."""
        return False
