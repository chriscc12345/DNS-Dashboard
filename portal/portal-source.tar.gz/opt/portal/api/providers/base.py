"""
Network service provider interface.

The portal manages "the DNS/network engine" through this
abstraction so the deployment can pair the Management Portal
with either Technitium DNS (installed alongside the portal)
or the Firewall Appliance (driven over its REST API).

Every concrete provider reports which capabilities it
supports; the portal UI hides the features a provider does
not offer.
"""


class NetworkServiceProvider:
    """Base class - all providers inherit from this."""

    name = "base"

    def capabilities(self):
        """
        Return the feature matrix the UI understands.

        Keys not listed here default to unsupported.
        """
        return {
            "blocking": False,
            "allow_timed_unblock": False,
            "cache": False,
            "recursion": False,
            "forwarders": False,
            "dhcp": False,
            "blocklists": False,
            "stats": False,
        }

    # -- health -------------------------------------------------

    def health(self):
        """Cheap reachability check -> {"status": "ok"/"error", ...}"""
        return {"status": "error", "message": "not implemented"}

    # -- licence ------------------------------------------------

    def account_limit(self):
        """Maximum number of user accounts this deployment's
        licence allows, or None when unlimited. Providers whose
        engine has no licensing (e.g. Technitium) return None."""
        return None

    # -- block page access requests ------------------------------

    def access_requests(self):
        """Pending client access requests submitted on the backend's
        own block page. None when the backend has no such store."""
        return None

    def review_access_request(self, request_id, decision, allow_minutes=None):
        """Apply an approve/deny decision to a backend access request.
        False when the backend has no such store."""
        return False

    def revoke_domain_allows(self, domain):
        """Remove the backend's access-request allow rules for a domain
        (the whole service group). Providers without such rules accept
        the change."""
        return True

    def allow_domain_timed(self, domain, allow_minutes):
        """Apply a timed allow directly on the backend (used when a
        request the backend already reviewed is re-allowed). False when
        the provider cannot apply allows directly."""
        return False

    # -- user sync (deployment option 2) ----------------------------

    def create_user(self, username, password):
        """Mirror a new portal user into the network engine.
        Returns {"ok": bool, "limit_reached": bool, "message": str}.
        Providers without user sync accept every user (ok, no sync)."""
        return {"ok": True, "limit_reached": False, "synced": False}

    # -- shadow account management (portal pushes, backend mirrors) ----

    def create_account_shadow(self, username, display_name, password):
        """Push a newly created portal user account to the backend.
        Providers without shadow accounts accept the change (ok)."""
        return True

    def set_user_enabled(self, username, enabled):
        """Push enable/disable of a portal user to the backend.
        Providers without shadow accounts accept the change (ok)."""
        return True

    def delete_user(self, username):
        """Push deletion of a portal user to the backend.
        Providers without shadow accounts accept the change (ok)."""
        return True

    def set_user_password(self, username, password):
        """Push a password change for a portal user to the backend.
        Providers without shadow accounts accept the change (ok)."""
        return True

    def set_user_display_name(self, username, display_name):
        """Push a display-name change for a portal user to the backend.
        Providers without shadow accounts accept the change (ok)."""
        return True

    # -- domain blocking (the unblock-request workflow) --------

    def block_domain(self, domain):
        """Block a domain. Returns True on success."""
        return False

    def unblock_domain(self, domain):
        """Un-block a domain. Returns True on success."""
        return False
    # -- appliance console: devices -----------------------------

    def list_devices(self):
        """Device inventory for the appliance console pages.
        None when the backend has no device inventory."""
        return None

    def block_device(self, target_type, target_value, reason="Blocked from the Portal"):
        """Block a device. Providers without device blocking reject."""
        return {"success": False, "message": "not supported by this backend"}

    def unblock_device(self, policy_id):
        """Unblock a device. Providers without device blocking reject."""
        return {"success": False, "message": "not supported by this backend"}

    # -- appliance console: firewall modules --------------------

    def list_modules(self):
        """Firewall module inventory for the appliance console pages.
        None when the backend has no firewall modules."""
        return None

    def set_module(self, module_key, enabled):
        """Enable/disable a firewall module. Providers without
        modules reject."""
        return {"success": False, "message": "not supported by this backend"}

    def ids_ips_action(self, action):
        """IDS/IPS install/uninstall/rules-update. Providers without
        an IDS/IPS module reject."""
        return {"success": False, "message": "not supported by this backend"}
    # -- appliance console: recent security events ------------------

    def recent_events(self, limit=200):
        """Recent security events for the Reports page.
        None when the backend has no security event store."""
        return None
    # -- appliance console: network (interfaces + hostname) ----------

    def network_info(self):
        """Appliance network interfaces for the Network page.
        None when the backend has no such view."""
        return None

    def set_interface_label(self, interface, label):
        """Set an interface label. Providers without this reject."""
        return {"success": False, "message": "not supported by this backend"}

    def set_hostname(self, hostname):
        """Set the backend hostname. Providers without this reject."""
        return {"success": False, "message": "not supported by this backend"}
    # -- appliance console: audit log / block list / application
    # blocking / web proxy and cache / policy acceptance / block page /
    # operations / DHCP / WireGuard. Defaults so non-appliance
    # deployments refuse gracefully.

    def audit_events(self, limit=200):
        return None

    def blocklists(self):
        return None

    def blocklist_add(self, name, url, fmt, update_hours, category):
        return {"success": False, "message": "not supported by this backend"}

    def blocklist_stevenblack(self):
        return {"success": False, "message": "not supported by this backend"}

    def blocklist_feeds(self):
        return {"success": False, "message": "not supported by this backend"}

    def blocklist_delete(self, source_id):
        return {"success": False, "message": "not supported by this backend"}

    def blocklist_update(self, source_id):
        return {"success": False, "message": "not supported by this backend"}

    def blocklists_update_due(self, force=False):
        return {"success": False, "message": "not supported by this backend"}

    def applications_overview(self):
        return None

    def application_set(self, application, enabled, block_quic):
        return {"success": False, "message": "not supported by this backend"}

    def category_set(self, category, enabled, block_quic):
        return {"success": False, "message": "not supported by this backend"}

    def service_add(self, name, category, domains):
        return {"success": False, "message": "not supported by this backend"}

    def service_delete(self, name):
        return {"success": False, "message": "not supported by this backend"}

    def group_add(self, name, description):
        return {"success": False, "message": "not supported by this backend"}

    def group_delete(self, category):
        return {"success": False, "message": "not supported by this backend"}

    def group_member_add(self, category, application):
        return {"success": False, "message": "not supported by this backend"}

    def group_member_remove(self, category, application):
        return {"success": False, "message": "not supported by this backend"}

    def proxy_overview(self):
        return None

    def proxy_set(self, payload):
        return {"success": False, "message": "not supported by this backend"}

    def cache_purge(self, url):
        return {"success": False, "message": "not supported by this backend"}

    def policy_overview(self):
        return None

    def policy_set(self, payload):
        return {"success": False, "message": "not supported by this backend"}

    def acceptance_revoke(self, item_id):
        return {"success": False, "message": "not supported by this backend"}

    def blockpage_settings(self):
        return None

    def blockpage_set(self, payload):
        return {"success": False, "message": "not supported by this backend"}

    def operations_info(self):
        return None

    def backup_export(self):
        return None

    def dhcp_overview(self):
        return None

    def dhcp_set_enabled(self, enabled):
        return {"success": False, "message": "not supported by this backend"}

    def dhcp_pool_add(self, payload):
        return {"success": False, "message": "not supported by this backend"}

    def dhcp_pool_delete(self, pool_id):
        return {"success": False, "message": "not supported by this backend"}

    def dhcp_reservation_add(self, payload):
        return {"success": False, "message": "not supported by this backend"}

    def dhcp_reservation_delete(self, reservation_id):
        return {"success": False, "message": "not supported by this backend"}

    def wireguard_overview(self):
        return None

    def wireguard_set_enabled(self, enabled):
        return {"success": False, "message": "not supported by this backend"}

    def wireguard_peer_add(self, payload):
        return {"success": False, "message": "not supported by this backend"}

    def wireguard_peer_delete(self, peer_id):
        return {"success": False, "message": "not supported by this backend"}
    # -- appliance console: block page logo + custom page ------------

    def blockpage_logo(self):
        return None

    def blockpage_logo_upload(self, data, content_type):
        return {"success": False, "message": "not supported by this backend"}

    def blockpage_logo_delete(self):
        return {"success": False, "message": "not supported by this backend"}

    def blockpage_custom_upload(self, html):
        return {"success": False, "message": "not supported by this backend"}

    def blockpage_custom_delete(self):
        return {"success": False, "message": "not supported by this backend"}

    def blockpage_preview(self):
        return None
    # -- appliance console: license, admin port, ACME TLS, docs ------

    def license_status(self):
        return None

    def admin_port(self):
        return None

    def admin_port_set(self, port):
        return {"success": False, "message": "not supported by this backend"}

    def acme_settings(self):
        return None

    def acme_set(self, payload):
        return {"success": False, "message": "not supported by this backend"}

    def acme_request(self):
        return {"success": False, "message": "not supported by this backend"}

    def documentation(self, filename):
        return None
    # -- appliance console: block page DNS hostname + CA cert ------

    def dns_block_hostname(self):
        return None

    def dns_block_hostname_set(self, hostname):
        return {"success": False, "message": "not supported by this backend"}

    def ca_certificate(self):
        return None
