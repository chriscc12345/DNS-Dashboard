"""Portal automatic updates: the portal pulls new builds itself.

The same contract as the appliance fleet: every 15 minutes the portal
polls the update server (/portal-update). When the notice version is
newer than this build and carries a server-signed manifest, the portal:

  1. downloads the package and checks its SHA-256,
  2. verifies the Ed25519 manifest signature against the installed
     update public key (the update server cannot push anything this
     portal did not already trust),
  3. backs up the current /opt/portal tree (minus the venv),
  4. extracts the new tree over /opt/portal and restarts the API
     through systemd-run (the restart escapes the dying process).

Update mode (auto | manual) and the update server URL live in
portal_settings: update_server_url, portal_update_mode. The manual mode
stores the notice and shows the banner; an administrator applies it.
A portal without update_server_url (the DEV masters) never polls.
"""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import ssl
import subprocess
import tarfile
import time
import urllib.request
from pathlib import Path

import psycopg2
import config

PORTAL_DIR = Path("/opt/portal")
PUBKEY = PORTAL_DIR / "backends" / "update-public-key.pem"
BACKUP_DIR = Path("/var/backups/portal")
STATE_PATH = Path("/var/lib/portal/update-state.json")
INTERVAL_SECONDS = 900
MAX_PACKAGE_BYTES = 400 * 1024 * 1024
_LOG = logging.getLogger("portal-update")

# DEV masters never poll - the update server URL is only provisioned on
# consumer installs. Transport certificate checking is relaxed (internal
# masters may use self-signed certificates): trust comes from the signed
# manifest and the package SHA-256, both verified below.
_CONTEXT = ssl._create_unverified_context()


def _setting(key: str):
    conn = psycopg2.connect(
        host=config.POSTGRES_HOST,
        database=config.POSTGRES_DB,
        user=config.POSTGRES_USER,
        password=config.POSTGRES_PASSWORD,
    )
    try:
        cur = conn.cursor()
        cur.execute("SELECT setting_value FROM portal_settings WHERE setting_key = %s", (key,))
        row = cur.fetchone()
        return row[0] if row else None
    finally:
        conn.close()


def _set_setting(key: str, value: str) -> None:
    conn = psycopg2.connect(
        host=config.POSTGRES_HOST,
        database=config.POSTGRES_DB,
        user=config.POSTGRES_USER,
        password=config.POSTGRES_PASSWORD,
    )
    try:
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO portal_settings (setting_key, setting_value, updated_at)
            VALUES (%s, %s, now())
            ON CONFLICT (setting_key)
            DO UPDATE SET setting_value = excluded.setting_value, updated_at = now()
            """,
            (key, value),
        )
        conn.commit()
    finally:
        conn.close()


def _newer(notice_version: str, current_version: str) -> bool:
    """Dotted numeric compare: a republished or stale notice (equal or
    older) must never downgrade or re-apply this build."""
    def key(value: str):
        try:
            return tuple(int(part) for part in value.split("."))
        except ValueError:
            return (0,)
    return key(notice_version) > key(current_version)


def _verify_signature(manifest: dict, signature_b64: str) -> bool:
    """Ed25519 verification through the openssl CLI - the same key pair
    the appliance fleet uses for its update manifests."""
    try:
        canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":"))
        sig = base64.b64decode(signature_b64)
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            tmpdir = Path(tmp)
            manifest_file = tmpdir / "manifest.json"
            sig_file = tmpdir / "manifest.sig"
            manifest_file.write_text(canonical)
            sig_file.write_bytes(sig)
            result = subprocess.run(
                ["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", str(PUBKEY),
                 "-rawin", "-in", str(manifest_file), "-sigfile", str(sig_file)],
                capture_output=True, timeout=15, check=False,
            )
        return result.returncode == 0
    except Exception:
        return False


def _download(url: str) -> bytes:
    if not url.startswith("https://"):
        raise ValueError("Refusing to download a portal update over a non-HTTPS URL")
    request = urllib.request.Request(url, headers={"User-Agent": "curl/8.0"})
    with urllib.request.urlopen(request, timeout=120, context=_CONTEXT) as response:
        package = response.read(MAX_PACKAGE_BYTES + 1)
    if len(package) > MAX_PACKAGE_BYTES:
        raise ValueError("Update package exceeds the size limit")
    return package


def _apply(package_path: Path) -> None:
    """Back up the live tree, extract the new one, restart the API."""
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"portal-before-update-{stamp}.tar.gz"
    subprocess.run(
        ["tar", "czf", str(backup), "-C", "/",
         "--exclude=opt/portal/api/venv",
         "--exclude=opt/portal/api/__pycache__",
         "--exclude=opt/portal/api/.before-*",
         "--exclude=opt/portal/web/uploads",
         "opt/portal"],
        check=True, timeout=300,
    )
    _LOG.info("portal update: backup %s (%d bytes)", backup.name, backup.stat().st_size)
    # The local configuration files are owned by the installer/provisioner
    # (database credentials, appliance tokens), never by the update
    # package - the tarball ships neutral templates. Extraction must leave
    # the live ones untouched.
    subprocess.run(
        ["tar", "xzf", str(package_path), "-C", "/",
         "--exclude=opt/portal/api/config.py",
         "--exclude=opt/portal/web/config.php"],
        check=True, timeout=300,
    )
    # Python dependencies may have changed in the new build: install them
    # best-effort (a failure must not abort an applied update - the API
    # restart shows any breakage immediately).
    requirements = PORTAL_DIR / "api" / "requirements.txt"
    pip = PORTAL_DIR / "api" / "venv" / "bin" / "pip"
    if requirements.is_file() and pip.is_file():
        subprocess.run(
            [str(pip), "install", "--quiet", "--no-input", "-r", str(requirements)],
            timeout=600, check=False,
        )
    # The restart must escape this process: systemd-run schedules it
    # outside the dying API service (same pattern as firewall-update).
    subprocess.Popen(
        ["/usr/bin/systemd-run", "--quiet", "--unit=portal-self-restart",
         "/bin/systemctl", "restart", "portal-api"],
        start_new_session=True,
    )
    _LOG.info("portal update applied; API restarting into the new build")


def check_and_apply() -> dict | None:
    """One poll cycle. Returns a result dict when an update was
    processed, None when there is nothing to do."""
    from main import PORTAL_VERSION  # resolved late: after an update the module reloads

    server = (_setting("update_server_url") or "").strip().rstrip("/")
    if not server:
        return None
    mode = (_setting("portal_update_mode") or "auto").strip().lower() or "auto"

    request = urllib.request.Request(server + "/portal-update",
                                     headers={"User-Agent": "curl/8.0"})
    try:
        with urllib.request.urlopen(request, timeout=20, context=_CONTEXT) as response:
            notice = json.loads(response.read(65_537))
    except Exception as exc:
        _LOG.warning("portal update poll failed (%s)", exc)
        return None
    if not isinstance(notice, dict) or not notice.get("version"):
        return None

    # Always store the notice so the settings page can show the state.
    _set_setting("portal_update_notice", json.dumps(notice))

    version = str(notice.get("version"))
    manifest = notice.get("manifest") or {}
    signature = str(notice.get("signature") or "")
    url = str(notice.get("download_url") or "")
    sha256 = str(notice.get("sha256") or "")

    if not _newer(version, str(PORTAL_VERSION)):
        return None
    if mode != "auto":
        _LOG.info("portal update %s available (manual mode) - banner shows, administrator applies", version)
        return None
    if not url or not sha256 or not manifest or not signature:
        _LOG.info("portal update %s announced but not auto-downloadable - manual update applies", version)
        return None

    try:
        package = _download(url)
    except Exception as exc:
        _LOG.warning("portal update download failed (%s); retried next cycle", exc)
        return {"ok": False, "stage": "download", "message": str(exc)[:200]}
    if hashlib.sha256(package).hexdigest() != sha256:
        return {"ok": False, "stage": "verify", "message": "Package hash does not match the notice"}
    if manifest.get("sha256") != sha256 or not _verify_signature(manifest, signature):
        return {"ok": False, "stage": "verify", "message": "Manifest signature verification failed"}

    if manifest.get("size") and int(manifest["size"]) != len(package):
        return {"ok": False, "stage": "verify", "message": "Package size does not match the manifest"}

    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    staged = STATE_PATH.parent / f"portal-update-{int(time.time())}.tar.gz"
    staged.write_bytes(package)
    STATE_PATH.write_text(json.dumps({"applied_version": version, "applied_sha256": sha256,
                                       "applied_at": time.time()}))
    _apply(staged)
    return {"ok": True, "version": version, "package": str(staged)}


def _update_loop() -> None:
    while True:
        try:
            check_and_apply()
        except Exception:
            pass  # never fatal: retried next cycle
        time.sleep(INTERVAL_SECONDS)


def start_update_poller() -> None:
    """Started from the API startup hook. Daemon thread: dies with the process."""
    import threading
    threading.Thread(target=_update_loop, daemon=True, name="portal-update-poller").start()