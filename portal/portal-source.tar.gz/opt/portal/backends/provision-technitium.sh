#!/bin/bash
set -euo pipefail

###############################################################################
# Provision the Technitium DNS backend for an installed portal.
#
# Invoked by the portal API from Settings -> System Status when the
# administrator selects the Technitium backend. Idempotent: safe to
# re-run; an existing installation and token are reused.
###############################################################################

PORTAL_API="/opt/portal/api"
CONFIG_FILE="$PORTAL_API/config.py"
PORTAL_VENV_PY="$PORTAL_API/venv/bin/python"

TECH_ROOT="/opt/technitium"
TECH_DNS="$TECH_ROOT/dns"
TECH_CONFIG="/etc/dns"
TECH_HOST="127.0.0.1"
TECH_PORT="5380"

export DEBIAN_FRONTEND=noninteractive

log() {
    echo
    echo "======================================================================"
    echo "$1"
    echo "======================================================================"
}

ok() { echo "[ OK ] $1"; }
warn() { echo "[WARN] $1"; }
error() { echo "[ERROR] $1"; }
fail() { error "$1"; exit 1; }

[[ -f "$PORTAL_API/main.py" ]] \
    || fail "The Portal is not installed at /opt/portal - run the portal installer first"

# Reuse the existing Technitium token (reruns) so the portal-api
# account keeps working without depending on the Technitium admin.
EXISTING_TECH_API_TOKEN="$("$PORTAL_VENV_PY" - <<'PYTOKEN'
import re
try:
    text = open("/opt/portal/api/config.py").read()
except OSError:
    raise SystemExit
match = re.search(r"(?m)^TECHNITIUM_TOKEN\s*=\s*[\"']([^\"']*)[\"']$", text)
print(match.group(1) if match else "")
PYTOKEN
)"

export EXISTING_TECH_API_TOKEN
###############################################################################
# Technitium DNS
###############################################################################

log "INSTALLING TECHNITIUM DNS"

if systemctl cat dns.service >/dev/null 2>&1; then

    ok "Technitium dns.service already installed"

elif [[ -d "$TECH_DNS" && -f "$TECH_DNS/DnsServerApp.dll" ]]; then

    ok "Technitium installation already exists"

else

    curl -fsSL \
        https://download.technitium.com/dns/install.sh |
        bash

fi

###############################################################################
# Fix Technitium filesystem traversal permissions
###############################################################################

log "FIXING TECHNITIUM PERMISSIONS"

mkdir -p /opt
chmod 755 /opt

if [[ -d "$TECH_ROOT" ]]; then
    chmod 755 "$TECH_ROOT"
fi

if [[ -d "$TECH_DNS" ]]; then
    chmod 755 "$TECH_DNS"
fi

mkdir -p "$TECH_CONFIG"

ok "Technitium directory permissions configured"

###############################################################################
# Start Technitium
###############################################################################

log "STARTING TECHNITIUM DNS"

systemctl daemon-reload
systemctl enable dns.service
systemctl restart dns.service

TECH_READY=0

for i in {1..60}; do

    if curl -fsS \
        --max-time 2 \
        "http://${TECH_HOST}:${TECH_PORT}/api/status" \
        >/dev/null 2>&1; then

        TECH_READY=1
        break
    fi

    sleep 2
done

if [[ "$TECH_READY" -ne 1 ]]; then
    systemctl status dns.service --no-pager || true
    journalctl -u dns.service -n 50 --no-pager || true
    fail "Technitium API did not become ready."
fi

ok "Technitium API is responding"

###############################################################################
# Technitium API provisioning
###############################################################################

log "CONFIGURING TECHNITIUM PORTAL API USER"

TECH_API_USER="portal-api"

# Generate a random password only for creating the Technitium account.
TECH_API_PASSWORD="$(openssl rand -hex 32)"

# IMPORTANT:
# Do not print the password or token.
#
# Technitium documentation confirms:
#   /api/user/login
#   /api/admin/users/create
#   /api/admin/users/set
#   /api/user/createToken
#
# API authentication uses:
#   Authorization: Bearer <token>

TECH_ADMIN_TOKEN=""
TECH_RERUN_EXISTING=0

# On a rerun, prefer the existing portal-api Bearer token. The portal-api
# account is an Administrators member, so its token can perform provisioning
# without depending on the Technitium admin password.
if [[ -n "${EXISTING_TECH_API_TOKEN:-}" ]]; then

    EXISTING_TOKEN_TEST="$(
        curl -sS \
            --max-time 10 \
            -H "Authorization: Bearer $EXISTING_TECH_API_TOKEN" \
            "http://${TECH_HOST}:${TECH_PORT}/api/admin/users/list" \
            2>/dev/null || true
    )"

    if [[ "$(jq -r '.status // empty' <<<"$EXISTING_TOKEN_TEST")" == "ok" ]]; then
        TECH_ADMIN_TOKEN="$EXISTING_TECH_API_TOKEN"
        TECH_RERUN_EXISTING=1
        ok "Existing portal-api token accepted for Technitium provisioning"
    fi
fi

# Fresh Technitium installation: fall back to the default administrator
# credentials when no usable existing portal-api token is available.
if [[ -z "$TECH_ADMIN_TOKEN" ]]; then

    LOGIN_RESPONSE="$(
        curl -sS \
            --max-time 10 \
            --get \
            --data-urlencode "user=admin" \
            --data-urlencode "pass=admin" \
            --data-urlencode "includeInfo=true" \
            "http://${TECH_HOST}:${TECH_PORT}/api/user/login"
    )"

    if [[ "$(jq -r '.status // empty' <<<"$LOGIN_RESPONSE")" == "ok" ]]; then
        TECH_ADMIN_TOKEN="$(jq -r '.token // empty' <<<"$LOGIN_RESPONSE")"
    fi

    if [[ -z "$TECH_ADMIN_TOKEN" ]]; then
        fail "No valid Technitium administrative credential is available."
    fi

    ok "Technitium administrator login succeeded"
fi

###############################################################################
# Check/create portal-api user
###############################################################################

if [[ "$TECH_RERUN_EXISTING" -eq 1 ]]; then

    ###########################################################################
    # Rerun: keep existing portal-api user and token
    ###########################################################################

    log "REUSING EXISTING TECHNITIUM PORTAL API USER"

    USER_CHECK_RESPONSE="$(
        curl -fsS \
            --max-time 10 \
            -H "Authorization: Bearer $TECH_ADMIN_TOKEN" \
            --get \
            --data-urlencode "user=$TECH_API_USER" \
            --data-urlencode "includeGroups=true" \
            "http://${TECH_HOST}:${TECH_PORT}/api/admin/users/get"
    )"

    USER_STATUS="$(jq -r '.status // empty' <<<"$USER_CHECK_RESPONSE")"

    if [[ "$USER_STATUS" != "ok" ]]; then
        USER_ERROR="$(jq -r '.errorMessage // "Unknown Technitium error"' <<<"$USER_CHECK_RESPONSE")"
        fail "Existing $TECH_API_USER user could not be verified: $USER_ERROR"
    fi

    TECH_API_TOKEN="$EXISTING_TECH_API_TOKEN"

    ok "Existing Technitium user $TECH_API_USER retained"
    ok "Existing Technitium API token retained"

else

    ###########################################################################
    # Fresh provisioning: create portal-api user
    ###########################################################################

    USER_CHECK_RESPONSE="$(
        curl -sS \
            --max-time 10 \
            -H "Authorization: Bearer $TECH_ADMIN_TOKEN" \
            --get \
            --data-urlencode "user=$TECH_API_USER" \
            --data-urlencode "includeGroups=true" \
            "http://${TECH_HOST}:${TECH_PORT}/api/admin/users/get" \
            2>/dev/null || true
    )"

    USER_EXISTS="$(jq -r '.status // empty' <<<"$USER_CHECK_RESPONSE")"

    if [[ "$USER_EXISTS" == "ok" ]]; then

        log "RECREATING EXISTING TECHNITIUM PORTAL API USER"

        DELETE_USER_RESPONSE="$(
            curl -fsS \
                --max-time 10 \
                -H "Authorization: Bearer $TECH_ADMIN_TOKEN" \
                --get \
                --data-urlencode "user=$TECH_API_USER" \
                "http://${TECH_HOST}:${TECH_PORT}/api/admin/users/delete"
        )"

        DELETE_STATUS="$(jq -r '.status // empty' <<<"$DELETE_USER_RESPONSE")"

        if [[ "$DELETE_STATUS" != "ok" ]]; then
            DELETE_ERROR="$(jq -r '.errorMessage // "Unknown Technitium error"' <<<"$DELETE_USER_RESPONSE")"
            fail "Could not delete existing $TECH_API_USER user: $DELETE_ERROR"
        fi

        ok "Existing Technitium user $TECH_API_USER deleted"
    fi

    ###########################################################################
    # Create portal-api user
    ###########################################################################

    CREATE_USER_RESPONSE="$(
        curl -fsS \
            --max-time 10 \
            -H "Authorization: Bearer $TECH_ADMIN_TOKEN" \
            --get \
            --data-urlencode "displayName=Portal API" \
            --data-urlencode "user=$TECH_API_USER" \
            --data-urlencode "pass=$TECH_API_PASSWORD" \
            "http://${TECH_HOST}:${TECH_PORT}/api/admin/users/create"
    )"

    CREATE_STATUS="$(jq -r '.status // empty' <<<"$CREATE_USER_RESPONSE")"

    if [[ "$CREATE_STATUS" != "ok" ]]; then
        CREATE_ERROR="$(jq -r '.errorMessage // "Unknown Technitium error"' <<<"$CREATE_USER_RESPONSE")"
        fail "Technitium portal-api user creation failed: $CREATE_ERROR"
    fi

    ok "Technitium user $TECH_API_USER created"

    ###########################################################################
    # Put portal-api in Administrators
    ###########################################################################

    SET_USER_RESPONSE="$(
        curl -fsS \
            --max-time 10 \
            -H "Authorization: Bearer $TECH_ADMIN_TOKEN" \
            --get \
            --data-urlencode "user=$TECH_API_USER" \
            --data-urlencode "displayName=Portal API" \
            --data-urlencode "pass=$TECH_API_PASSWORD" \
            --data-urlencode "disabled=false" \
            --data-urlencode "memberOfGroups=Administrators" \
            "http://${TECH_HOST}:${TECH_PORT}/api/admin/users/set"
    )"

    SET_STATUS="$(jq -r '.status // empty' <<<"$SET_USER_RESPONSE")"

    if [[ "$SET_STATUS" != "ok" ]]; then
        SET_ERROR="$(jq -r '.errorMessage // "Unknown Technitium error"' <<<"$SET_USER_RESPONSE")"
        fail "Failed to add portal-api to Administrators: $SET_ERROR"
    fi

    ok "portal-api assigned to Administrators"

    ###########################################################################
    # Create non-expiring API token
    ###########################################################################

    log "CREATING TECHNITIUM API TOKEN"

    TOKEN_RESPONSE="$(
        curl -sS \
            --max-time 10 \
            --get \
            --data-urlencode "user=$TECH_API_USER" \
            --data-urlencode "pass=$TECH_API_PASSWORD" \
            --data-urlencode "tokenName=Portal API" \
            "http://${TECH_HOST}:${TECH_PORT}/api/user/createToken"
    )"

    TOKEN_STATUS="$(jq -r '.status // empty' <<<"$TOKEN_RESPONSE")"

    if [[ "$TOKEN_STATUS" != "ok" ]]; then
        TOKEN_ERROR="$(jq -r '.errorMessage // "Unknown Technitium error"' <<<"$TOKEN_RESPONSE")"
        fail "Technitium API token creation failed: $TOKEN_ERROR"
    fi

    TECH_API_TOKEN="$(
        jq -r '.token // .response.token // empty' <<<"$TOKEN_RESPONSE"
    )"

    if [[ -z "$TECH_API_TOKEN" ]]; then
        fail "Technitium returned status ok but no API token."
    fi

    ok "Technitium API token created"

fi

###############################################################################
# Validate portal-api token
###############################################################################

log "VERIFYING TECHNITIUM API TOKEN"

TOKEN_TEST="$(
    curl -fsS \
        --max-time 10 \
        -H "Authorization: Bearer $TECH_API_TOKEN" \
        "http://${TECH_HOST}:${TECH_PORT}/api/user/profile/get"
)"

TOKEN_TEST_USER="$(jq -r '.response.username // empty' <<<"$TOKEN_TEST")"

if [[ "$TOKEN_TEST_USER" != "$TECH_API_USER" ]]; then
    fail "Technitium API token belongs to unexpected user: ${TOKEN_TEST_USER:-unknown}"
fi

ok "Technitium API token validated"

###############################################################################
# Store token securely
###############################################################################

log "CONFIGURING PORTAL TECHNITIUM TOKEN"

CONFIG_FILE="$PORTAL_API/config.py"

if [[ ! -f "$CONFIG_FILE" ]]; then
    fail "Portal config.py not found: $CONFIG_FILE"
fi

chmod 600 "$CONFIG_FILE"

python3 - "$CONFIG_FILE" "$TECH_API_TOKEN" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
token = sys.argv[2]

text = path.read_text()

pattern = r'(^TECHNITIUM_TOKEN\s*=\s*)["\'][^"\']*["\']'

replacement = rf'\1"{token}"'

text, count = re.subn(
    pattern,
    replacement,
    text,
    count=1,
    flags=re.MULTILINE
)

if count == 0:
    # Add the variable if the source does not currently define it.
    text = f'TECHNITIUM_TOKEN = "{token}"\n\n' + text

path.write_text(text)
PY

chmod 600 "$CONFIG_FILE"

ok "Technitium token inserted into Portal configuration"

###############################################################################
# Clear secrets from shell environment
###############################################################################

unset TECH_ADMIN_TOKEN
unset TECH_API_PASSWORD


###############################################################################
# Activate the provider in the portal
###############################################################################

"$PORTAL_VENV_PY" - technitium <<'PYPROVIDER'
import sys
sys.path.insert(0, "/opt/portal/api")
import config
import psycopg2

conn = psycopg2.connect(
    host=config.POSTGRES_HOST,
    database=config.POSTGRES_DB,
    user=config.POSTGRES_USER,
    password=config.POSTGRES_PASSWORD,
)
cur = conn.cursor()
cur.execute(
    """
    INSERT INTO portal_settings (setting_key, setting_value, updated_at)
    VALUES ('dns_provider', %s, CURRENT_TIMESTAMP)
    ON CONFLICT (setting_key)
    DO UPDATE SET setting_value = EXCLUDED.setting_value,
                 updated_at = CURRENT_TIMESTAMP
    """,
    (sys.argv[1],),
)
conn.commit()
cur.close()
conn.close()
print("[ OK ] Active network services backend: " + sys.argv[1])
PYPROVIDER

printf '{"state":"complete","backend":"technitium","completed_at":"%s"}\n' \
    "$(date -Iseconds)" > /var/lib/portal/backend-provision.result

ok "Provisioning complete - restarting the portal"

systemctl restart portal-api.service
