#!/bin/bash
set -euo pipefail

###############################################################################
# Provision the NetFortress Firewall Appliance backend for an installed
# portal.
#
# Invoked by the portal API from Settings -> System Status when the
# administrator selects the NetFortress backend. The appliance package
# is downloaded from netfortress.tech; the administrator account given
# in the provisioning card becomes the appliance administrator.
#
# Environment (set by the portal API):
#   APPLIANCE_ADMIN_USERNAME  - administrator username (portal admin)
#   APPLIANCE_ADMIN_PASSWORD - collected in the provisioning card
###############################################################################

PORTAL_API="/opt/portal/api"
CONFIG_FILE="$PORTAL_API/config.py"
PORTAL_VENV_PY="$PORTAL_API/venv/bin/python"

FIREWALL_API_URL="http://127.0.0.1:8080"
APPLIANCE_ENV="/etc/firewall-appliance/environment"
APPLIANCE_SRC_ROOT="/opt/firewall-appliance-src"
APPLIANCE_SOURCE_DIR="$APPLIANCE_SRC_ROOT/firewall-appliance"
APPLIANCE_INSTALLER="$APPLIANCE_SOURCE_DIR/deploy/install.sh"
APPLIANCE_PACKAGE_URL="https://netfortress.tech/downloads/file/netfortress-appliance-3.2.tar.gz"
APPLIANCE_ARCHIVE="/tmp/netfortress-appliance.tar.gz"

export DEBIAN_FRONTEND=noninteractive

log() {
    echo
    echo "======================================================================"
    echo "$1"
    echo "======================================================================"
}

ok() { echo "[ OK ] $1"; }
warn() { echo "[WARN] $1"; }
error() { echo "[ERROR] $1"; }
fail() { error "$1"; exit 1; }

###############################################################################
# Preflight
###############################################################################

log "VALIDATING PROVISIONING INPUT"

[[ -f "$PORTAL_API/main.py" ]] \
    || fail "The Portal is not installed at /opt/portal - run the portal installer first"

[[ -n "${APPLIANCE_ADMIN_USERNAME:-}" ]] \
    || fail "Appliance administrator username is missing"

APPLIANCE_ADMIN_PASSWORD="${APPLIANCE_ADMIN_PASSWORD:-}"

[[ "${#APPLIANCE_ADMIN_PASSWORD}" -ge 12 ]] \
    || fail "Appliance administrator password must be at least 12 characters"

CATEGORY_COUNT=0
[[ "$APPLIANCE_ADMIN_PASSWORD" =~ [a-z] ]] && CATEGORY_COUNT=$((CATEGORY_COUNT + 1))
[[ "$APPLIANCE_ADMIN_PASSWORD" =~ [A-Z] ]] && CATEGORY_COUNT=$((CATEGORY_COUNT + 1))
[[ "$APPLIANCE_ADMIN_PASSWORD" =~ [0-9] ]] && CATEGORY_COUNT=$((CATEGORY_COUNT + 1))
[[ ! "$APPLIANCE_ADMIN_PASSWORD" =~ ^[A-Za-z0-9]+$ ]] && CATEGORY_COUNT=$((CATEGORY_COUNT + 1))

[[ "$CATEGORY_COUNT" -ge 3 ]] \
    || fail "Appliance administrator password must use at least three character categories (lowercase, uppercase, digit, symbol)"

PORTAL_HOSTNAME="$(
    # Globs name the symlinked vhost directly (grep -r skips symlinks),
    # and || true keeps a failed pipeline under 'set -o pipefail' from
    # killing the script silently - the empty value is reported by the
    # visible check below.
    grep -h 'server_name' \
        /etc/nginx/sites-enabled/* \
        /etc/nginx/sites-available/* \
        2>/dev/null \
        | grep -v '^\s*#' | head -1 \
        | awk '{print $2}' | tr -d ';' \
        || true
)"

[[ -n "$PORTAL_HOSTNAME" && "$PORTAL_HOSTNAME" != "_" ]] \
    || fail "Could not determine the Portal hostname from the nginx configuration"

ok "Portal hostname: $PORTAL_HOSTNAME"
ok "Appliance administrator: $APPLIANCE_ADMIN_USERNAME"

###############################################################################
# Download the appliance package
###############################################################################

log "DOWNLOADING NETFORTRESS FIREWALL APPLIANCE"

if curl -fsSL --max-time 600 "$APPLIANCE_PACKAGE_URL" -o "$APPLIANCE_ARCHIVE"; then
    ok "Appliance package downloaded from netfortress.tech"
else
    fail "Could not download the appliance package from $APPLIANCE_PACKAGE_URL"
fi

###############################################################################
# Install the appliance
###############################################################################

log "INSTALLING NETFORTRESS FIREWALL APPLIANCE"

rm -rf "$APPLIANCE_SRC_ROOT"
mkdir -p "$APPLIANCE_SRC_ROOT"

tar -xzf "$APPLIANCE_ARCHIVE" -C "$APPLIANCE_SRC_ROOT"

[[ -f "$APPLIANCE_INSTALLER" ]] \
    || fail "NetFortress appliance installer was not extracted correctly"

bash "$APPLIANCE_INSTALLER"

ok "NetFortress Firewall Appliance installed"

###############################################################################
# Enable appliance DNS enforcement
###############################################################################

log "CONFIGURING APPLIANCE DNS ENFORCEMENT"

# DNS blocking must enforce immediately for the portal workflows
# (FIREWALL_ENABLE_DNS_APPLY) and the reconciler must render the
# block page and dnsmasq state (FIREWALL_ENABLE_POLICY_REFRESH).
# Firewall rule enforcement stays in the appliance's guarded
# candidate-only mode (FIREWALL_ENABLE_LIVE_APPLY stays disabled)
# until the administrator deploys policy from the appliance console.

python3 - "$APPLIANCE_ENV" "$PORTAL_HOSTNAME" <<'PYAPPLIANCEENV' || fail "appliance environment patch failed"
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text()

for key in ("FIREWALL_ENABLE_DNS_APPLY", "FIREWALL_ENABLE_POLICY_REFRESH"):
    line = key + "=1"
    commented = "#" + line
    if commented in text:
        text = text.replace(commented, line, 1)
    elif key + "=" not in text:
        if not text.endswith(chr(10)):
            text += chr(10)
        text += line + chr(10)

# Combined deployment: the appliance console redirects its visitors to
# the Portal setup page while no administrator exists yet. The appliance
# reads FIREWALL_PORTAL_SETUP_URL at request time.
url_line = "FIREWALL_PORTAL_SETUP_URL=https://" + sys.argv[2] + "/setup.php"
lines = [
    line for line in text.splitlines()
    if not line.lstrip("#").startswith("FIREWALL_PORTAL_SETUP_URL=")
]
lines.append(url_line)
text = "\n".join(lines) + "\n"

path.write_text(text)
print("[ OK ] DNS apply and policy refresh enabled")
print("[ OK ] Appliance console setup redirect configured")
PYAPPLIANCEENV

systemctl restart firewall-api

APPLIANCE_READY=0

for i in {1..45}; do
    if curl -fsS --max-time 2 \
        "$FIREWALL_API_URL/api/v1/health" \
        >/dev/null 2>&1; then
        APPLIANCE_READY=1
        break
    fi
    sleep 2
done

[[ "$APPLIANCE_READY" -eq 1 ]] \
    || fail "The appliance API did not become ready"

ok "Appliance API is responding"

###############################################################################
# Administrator session
###############################################################################

log "CONFIGURING APPLIANCE ADMINISTRATOR"

AUTH_RESPONSE="$(
    curl -fsS --max-time 10 \
        "$FIREWALL_API_URL/api/v1/auth/status" 2>/dev/null || true
)"

BOOTSTRAP_REQUIRED="$(
    jq -r '.bootstrap_required // false' <<<"$AUTH_RESPONSE" 2>/dev/null || true
)"

if [[ "$BOOTSTRAP_REQUIRED" == "true" ]]; then
    ADMIN_RESPONSE="$(
        curl -sS --max-time 15 \
            -H "Content-Type: application/json" \
            -d "{\"username\":\"$APPLIANCE_ADMIN_USERNAME\",\"password\":\"$APPLIANCE_ADMIN_PASSWORD\"}" \
            "$FIREWALL_API_URL/api/v1/auth/bootstrap" 2>/dev/null || true
    )"
    ok "Appliance administrator account created"
else
    ADMIN_RESPONSE="$(
        curl -sS --max-time 15 \
            -H "Content-Type: application/json" \
            -d "{\"username\":\"$APPLIANCE_ADMIN_USERNAME\",\"password\":\"$APPLIANCE_ADMIN_PASSWORD\"}" \
            "$FIREWALL_API_URL/api/v1/auth/login" 2>/dev/null || true
    )"
    ok "Existing appliance administrator authenticated"
fi

FIREWALL_ADMIN_SESSION="$(
    jq -r '.access_token // empty' <<<"$ADMIN_RESPONSE" 2>/dev/null || true
)"

[[ -n "$FIREWALL_ADMIN_SESSION" ]] \
    || fail "Appliance administrator authentication failed (check the username and password from the provisioning card)"

SESSION_HEADER="Authorization: Bearer $FIREWALL_ADMIN_SESSION"

unset APPLIANCE_ADMIN_PASSWORD

###############################################################################
# Configure appliance licensing and start the trial
###############################################################################

log "CONFIGURING APPLIANCE LICENSING"

# The appliance ships with the licence server commented out; point it at
# the NetFortress licence server (netfortress.tech via Cloudflare) and
# install the licence verification key that ships with the portal.
LICENSE_PUBLIC_KEY_FILE="/opt/portal/backends/license-public-key.pem"

if [[ ! -f "$LICENSE_PUBLIC_KEY_FILE" ]]; then
    fail "Licence verification key not found: $LICENSE_PUBLIC_KEY_FILE"
fi

APPLIANCE_ENV_FILE="/etc/firewall-appliance/environment"

python3 - <<'PYENV'
from pathlib import Path

path = Path('/etc/firewall-appliance/environment')
lines = path.read_text().splitlines()

wanted = {
    'FIREWALL_LICENSE_SERVER_URL':
        'https://netfortress.tech/api/activate',
    'FIREWALL_LICENSE_PUBLIC_KEY':
        '/etc/firewall-appliance/license-public-key.pem',
}

out = []
seen = set()

for line in lines:
    stripped = line.lstrip('#').strip()
    key = stripped.split('=', 1)[0] if '=' in stripped else None

    if key == 'FIREWALL_LICENSE_DEVELOPMENT':
        # Never ship the development trial on a real deployment.
        continue

    if key in wanted:
        if key not in seen:
            out.append(key + '=' + wanted[key])
            seen.add(key)
        continue

    out.append(line)

for key, value in wanted.items():
    if key not in seen:
        out.append(key + '=' + value)

path.write_text('\n'.join(out) + '\n')
PYENV

install -m 0640 -o root -g firewall-api \
    "$LICENSE_PUBLIC_KEY_FILE" \
    /etc/firewall-appliance/license-public-key.pem

ok "Licence server and verification key configured"

systemctl restart firewall-api

API_READY=0
for i in {1..30}; do
    if curl -fsS --max-time 3 \
        "$FIREWALL_API_URL/api/v1/health" >/dev/null 2>&1; then
        API_READY=1
        break
    fi
    sleep 2
done

[[ "$API_READY" -eq 1 ]] \
    || fail "Appliance API did not return after the licensing restart"

ok "Appliance API is responding after the licensing configuration"

# Start the 60-day full trial. A 409 means a trial or paid licence is
# already active on this installation - the precheck below confirms the
# features either way.
TRIAL_HTTP_CODE="$(
    curl -s -o /tmp/appliance-trial-response.json -w '%{http_code}' \
        --max-time 30 \
        -X POST \
        -H "$SESSION_HEADER" \
        "$FIREWALL_API_URL/api/v1/licensing/trial" 2>/dev/null || true
)"

if [[ "$TRIAL_HTTP_CODE" == "200" ]]; then
    ok "60-day full trial licence started"
elif [[ "$TRIAL_HTTP_CODE" == "409" ]]; then
    warn "A trial or paid licence is already active on this appliance - continuing"
else
    warn "Trial activation returned HTTP $TRIAL_HTTP_CODE - the licence precheck below reports the result"
fi

###############################################################################
# Licence precheck
###############################################################################

log "VERIFYING APPLIANCE LICENCE"

# The provider needs the DNS features that ship with every edition
# from Home Lite upward. A fresh appliance activates its trial licence
# during installation; retry briefly while activation completes.

MISSING_FEATURES=""
LICENSE_OK=0

for i in {1..30}; do

    LICENSE_RESPONSE="$(
        curl -fsS --max-time 15 \
            -H "$SESSION_HEADER" \
            "$FIREWALL_API_URL/api/v1/licensing/status" 2>/dev/null || true
    )"

    MISSING_FEATURES=""

    for feature in dns dns_filtering; do
        if ! jq -e --arg f "$feature" \
            '(.features // []) | index($f) != null' \
            <<<"$LICENSE_RESPONSE" >/dev/null 2>&1; then
            MISSING_FEATURES="$MISSING_FEATURES $feature"
        fi
    done

    if [[ -z "$MISSING_FEATURES" ]]; then
        LICENSE_OK=1
        break
    fi

    sleep 4
done

if [[ "$LICENSE_OK" -ne 1 ]]; then
    LICENSE_EDITION="$(
        jq -r '.edition_label // "unknown"' <<<"$LICENSE_RESPONSE" 2>/dev/null || true
    )"
    fail "The appliance licence (edition: $LICENSE_EDITION) does not include the required features:$MISSING_FEATURES"
fi

LICENSE_EDITION="$(
    jq -r '.edition_label // "unknown"' <<<"$LICENSE_RESPONSE" 2>/dev/null || true
)"

ok "Appliance licence verified (edition: $LICENSE_EDITION)"

###############################################################################
# Mint the portal provider token
###############################################################################

log "CREATING PORTAL PROVIDER TOKEN"

# Remove any previous portal-provider token so re-runs leave one clean
# token with the current scope set.
TOKEN_LIST="$(
    curl -fsS --max-time 15 -H "$SESSION_HEADER" \
        "$FIREWALL_API_URL/api/v1/auth/tokens" 2>/dev/null || true
)"

for OLD_TOKEN_ID in $(jq -r '.[]? | select(.name == "portal-provider") | .id' <<<"$TOKEN_LIST" 2>/dev/null); do
    curl -s -o /dev/null -X DELETE -H "$SESSION_HEADER" \
        "$FIREWALL_API_URL/api/v1/auth/tokens/$OLD_TOKEN_ID" 2>/dev/null || true
done

TOKEN_RESPONSE="$(
    curl -sS --max-time 15 \
        -H "$SESSION_HEADER" \
        -H "Content-Type: application/json" \
        -d '{"name":"portal-provider","scopes":["dns:read","dns:write","users:read","users:write","policies:read","policies:write","deployment:read","deployment:write","audit:read","proxy:read","proxy:write"]}' \
        "$FIREWALL_API_URL/api/v1/auth/tokens" 2>/dev/null || true
)"

FIREWALL_API_TOKEN="$(
    jq -r '.token // empty' <<<"$TOKEN_RESPONSE" 2>/dev/null || true
)"

[[ -n "$FIREWALL_API_TOKEN" ]] \
    || fail "Could not create the appliance API token"

TOKEN_HEADER="Authorization: Bearer $FIREWALL_API_TOKEN"

TOKEN_TEST_STATUS="$(
    curl -s -o /dev/null -w "%{http_code}" --max-time 15 \
        -H "$TOKEN_HEADER" \
        "$FIREWALL_API_URL/api/v1/dns/status" 2>/dev/null || true
)"

[[ "$TOKEN_TEST_STATUS" == "200" ]] \
    || fail "The appliance API token did not validate (HTTP $TOKEN_TEST_STATUS)"

ok "Appliance API token created (scopes: dns, users, policies, deployment, audit and proxy)"
ok "Appliance API token validated"

###############################################################################
# Point blocked sites at the portal's Access Denied page
###############################################################################

log "CONFIGURING APPLIANCE BLOCK PAGE REDIRECTION"

# The portal's nginx answers unknown Host headers on port 80 and sends
# browsers to /blocked.php?host=<blocked site>, where the user can
# request access; the portal request workflow then approves/unblocks
# through this provider. The appliance DNS just needs to answer blocked
# domains with this host's LAN address.
HOST_LAN_IPV4="$(
    ip -4 route get 1.1.1.1 2>/dev/null \
        | awk '{print $7; exit}' || true
)"

[[ -n "$HOST_LAN_IPV4" ]] \
    || fail "Could not determine this host's LAN address for the DNS block page"

DNS_SETTINGS="$(
    curl -fsS --max-time 15 \
        -H "$SESSION_HEADER" \
        "$FIREWALL_API_URL/api/v1/dns/settings" 2>/dev/null || true
)"

[[ -n "$DNS_SETTINGS" ]] \
    || fail "Could not read the appliance DNS settings"

DNS_PUT="$(
    jq -c \
        --arg ip "$HOST_LAN_IPV4" \
        '.block_response = "block_page" | .block_page_ipv4 = $ip' \
        <<<"$DNS_SETTINGS" 2>/dev/null || true
)"

[[ -n "$DNS_PUT" ]] \
    || fail "Could not build the appliance DNS settings update"

DNS_RESULT="$(
    curl -sS --max-time 30 \
        -X PUT \
        -H "$SESSION_HEADER" \
        -H "Content-Type: application/json" \
        -d "$DNS_PUT" \
        "$FIREWALL_API_URL/api/v1/dns/settings" 2>/dev/null || true
)"

DNS_BLOCK_IP="$(
    jq -r '.block_page_ipv4 // empty' <<<"$DNS_RESULT" 2>/dev/null || true
)"

if [[ "$DNS_BLOCK_IP" == "$HOST_LAN_IPV4" ]]; then
    ok "Blocked domains now resolve to $HOST_LAN_IPV4 (the portal Access Denied page)"
else
    fail "Could not configure the DNS block page address on the appliance"
fi

unset FIREWALL_ADMIN_SESSION

###############################################################################
# Configure the portal
###############################################################################

log "CONFIGURING PORTAL APPLIANCE INTEGRATION"

chmod 600 "$CONFIG_FILE"

python3 - "$CONFIG_FILE" "$FIREWALL_API_URL" "$FIREWALL_API_TOKEN" <<'PYFIREWALLCONFIG'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
api_url = sys.argv[2]
api_token = sys.argv[3]

text = path.read_text()

for key, value in (
    ("FIREWALL_API_URL", api_url),
    ("FIREWALL_API_TOKEN", api_token),
):
    pattern = r'(^%s\s*=\s*)["\'][^"\']*["\']' % key

    text, count = re.subn(
        pattern,
        lambda m, value=value: m.group(1) + repr(value),
        text,
        count=1,
        flags=re.MULTILINE,
    )

    if count != 1:
        raise SystemExit("Could not set %s in Portal config.py" % key)

path.write_text(text)
PYFIREWALLCONFIG

chmod 600 "$CONFIG_FILE"

ok "Appliance URL and token inserted into Portal configuration"

unset FIREWALL_API_TOKEN

###############################################################################
# Activate the provider in the portal
###############################################################################

"$PORTAL_VENV_PY" - firewall <<'PYPROVIDER'
import sys
sys.path.insert(0, "/opt/portal/api")
import config
import psycopg2

conn = psycopg2.connect(
    host=config.POSTGRES_HOST,
    database=config.POSTGRES_DB,
    user=config.POSTGRES_USER,
    password=config.POSTGRES_PASSWORD,
)
cur = conn.cursor()
cur.execute(
    """
    INSERT INTO portal_settings (setting_key, setting_value, updated_at)
    VALUES ('dns_provider', %s, CURRENT_TIMESTAMP)
    ON CONFLICT (setting_key)
    DO UPDATE SET setting_value = EXCLUDED.setting_value,
                 updated_at = CURRENT_TIMESTAMP
    """,
    (sys.argv[1],),
)
conn.commit()
cur.close()
conn.close()
print("[ OK ] Active network services backend: " + sys.argv[1])
PYPROVIDER

printf '{"state":"complete","backend":"netfortress","completed_at":"%s"}\n' \
    "$(date -Iseconds)" > /var/lib/portal/backend-provision.result

ok "Provisioning complete - restarting the portal"

systemctl restart portal-api.service
