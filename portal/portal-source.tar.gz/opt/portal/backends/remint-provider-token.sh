#!/bin/bash
set -euo pipefail
###############################################################################
# Re-mint the appliance provider token (e.g. after the scope set
# changed) without re-running the whole provisioning. Requires the
# appliance administrator credentials in the environment:
#
#   APPLIANCE_ADMIN_USERNAME=admin APPLIANCE_ADMIN_PASSWORD='...' \
#       bash remint-provider-token.sh
###############################################################################
FIREWALL_API_URL="http://127.0.0.1:8080"
PORTAL_API="/opt/portal/api"

[[ -n "${APPLIANCE_ADMIN_USERNAME:-}" && -n "${APPLIANCE_ADMIN_PASSWORD:-}" ]] \
    || { echo "[ERROR] APPLIANCE_ADMIN_USERNAME and APPLIANCE_ADMIN_PASSWORD are required"; exit 1; }

LOGIN="$(
    curl -sS --max-time 15 -H 'Content-Type: application/json' \
        -d "{\"username\":\"$APPLIANCE_ADMIN_USERNAME\",\"password\":\"$APPLIANCE_ADMIN_PASSWORD\"}" \
        "$FIREWALL_API_URL/api/v1/auth/login" 2>/dev/null || true
)"
SESSION="$(jq -r '.access_token // empty' <<<"$LOGIN")"
[[ -n "$SESSION" ]] || { echo "[ERROR] Appliance administrator authentication failed"; exit 1; }
HEADER="Authorization: Bearer $SESSION"

TOKEN_LIST="$(curl -fsS --max-time 15 -H "$HEADER" "$FIREWALL_API_URL/api/v1/auth/tokens" 2>/dev/null || true)"
for OLD_TOKEN_ID in $(jq -r '.[]? | select(.name == "portal-provider") | .id' <<<"$TOKEN_LIST" 2>/dev/null); do
    curl -s -o /dev/null -X DELETE -H "$HEADER" "$FIREWALL_API_URL/api/v1/auth/tokens/$OLD_TOKEN_ID" 2>/dev/null || true
done

MINT="$(
    curl -sS --max-time 15 -H "$HEADER" -H 'Content-Type: application/json' \
        -d '{"name":"portal-provider","scopes":["dns:read","dns:write","users:read","users:write","policies:read","policies:write"]}' \
        "$FIREWALL_API_URL/api/v1/auth/tokens" 2>/dev/null || true
)"
TOKEN="$(jq -r '.token // empty' <<<"$MINT")"
[[ -n "$TOKEN" ]] || { echo "[ERROR] Token creation failed"; exit 1; }

python3 - "$PORTAL_API/config.py" "$TOKEN" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
text = path.read_text()
text, count = re.subn(
    r'(?m)^(FIREWALL_API_TOKEN\s*=\s*)["\'][^"\']*["\']',
    lambda m: m.group(1) + '"' + sys.argv[2] + '"',
    text,
    count=1,
)
if count != 1:
    raise SystemExit("FIREWALL_API_TOKEN not found in config.py")
path.write_text(text)
PY

systemctl restart portal-api
sleep 3
systemctl is-active portal-api
echo "[ OK ] portal-provider token re-minted (dns, users and policies scopes)"
