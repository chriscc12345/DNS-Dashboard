<?php

require_once 'auth.php';
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

$username =
    isset($_SESSION['username'])
        ? trim((string)$_SESSION['username'])
        : '';

if ($username === '') {

    http_response_code(401);

    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated'
    ]);

    exit;
}


function portalApiRequest(
    string $url,
    string $method = 'GET',
    ?array $payload = null
): array {

    $options = [
        'http' => [
            'method'        => $method,
            'ignore_errors' => true,
            'timeout'       => 10
        ]
    ];

    if ($payload !== null) {

        $options['http']['header'] =
            "Content-Type: application/json\r\n";

        $options['http']['content'] =
            json_encode($payload);
    }

    $response = @file_get_contents(
        $url,
        false,
        stream_context_create($options)
    );

    $statusCode = 0;

    if (
        isset($http_response_header)
        &&
        is_array($http_response_header)
        &&
        isset($http_response_header[0])
        &&
        preg_match(
            '/\s(\d{3})\s/',
            $http_response_header[0],
            $matches
        )
    ) {
        $statusCode = (int)$matches[1];
    }

    $decoded =
        $response !== false
            ? json_decode($response, true)
            : null;

    return [
        'ok' =>
            $response !== false
            &&
            (
                $statusCode === 0
                ||
                (
                    $statusCode >= 200
                    &&
                    $statusCode < 300
                )
            ),

        'status' => $statusCode,

        'data' =>
            is_array($decoded)
                ? $decoded
                : null
    ];
}


$action =
    isset($_GET['action'])
        ? (string)$_GET['action']
        : 'get';


/* =========================================================
   GET CURRENT AUTHENTICATED PROFILE
   ========================================================= */

if ($action === 'get') {

    $profileResult =
        portalApiRequest(
            $FASTAPI_URL
            . '/user-profiles/'
            . rawurlencode($username)
        );

    if (
        !$profileResult['ok']
        ||
        !is_array($profileResult['data'])
        ||
        empty($profileResult['data']['username'])
    ) {

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'message' => 'Profile was not found'
        ]);

        exit;
    }

    $profile = $profileResult['data'];

    /*
     * Resolve group name from the authoritative
     * Portal username -> group mapping.
     */

    $groupName = 'Unassigned';

    $groupsResult =
        portalApiRequest(
            $FASTAPI_URL . '/users/groups'
        );

    if (
        $groupsResult['ok']
        &&
        is_array($groupsResult['data'])
    ) {

        foreach (
            $groupsResult['data']
            as $groupUsername => $name
        ) {

            if (
                strcasecmp(
                    (string)$groupUsername,
                    $username
                ) === 0
            ) {
                $groupName =
                    trim((string)$name) !== ''
                        ? (string)$name
                        : 'Unassigned';

                break;
            }
        }
    }

    $profile['group_name'] = $groupName;

    /*
     * Load custom fields for the authenticated user.
     *
     * IMPORTANT:
     * The browser does not supply a user ID.
     * We use the numeric profile ID returned for the
     * authenticated session username.
     */

    $profileId =
        isset($profile['id'])
            ? (int)$profile['id']
            : 0;

    $customFields = [];

    if ($profileId > 0) {

        $customFieldResult =
            portalApiRequest(
                $FASTAPI_URL
                . '/user-custom-fields/user/'
                . $profileId
            );

        if (
            !$customFieldResult['ok']
            ||
            !is_array($customFieldResult['data'])
            ||
            (
                isset($customFieldResult['data']['success'])
                &&
                $customFieldResult['data']['success'] === false
            )
        ) {

            http_response_code(502);

            echo json_encode([
                'success' => false,
                'message' =>
                    'Unable to load custom profile fields'
            ]);

            exit;
        }

        $customFields =
            is_array(
                $customFieldResult['data']['fields']
                ?? null
            )
                ? $customFieldResult['data']['fields']
                : [];
    }

    echo json_encode([
        'success' => true,
        'profile' => $profile,
        'custom_fields' => $customFields
    ]);

    exit;
}


/* =========================================================
   SAVE CURRENT AUTHENTICATED PROFILE
   ========================================================= */

if ($action === 'save') {

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

        http_response_code(405);

        echo json_encode([
            'success' => false,
            'message' => 'Method not allowed'
        ]);

        exit;
    }

    $input =
        json_decode(
            file_get_contents('php://input'),
            true
        );

    if (!is_array($input)) {

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'message' => 'Invalid request'
        ]);

        exit;
    }

    $displayName =
        trim(
            (string)(
                $input['display_name']
                ?? ''
            )
        );

    if ($displayName === '') {

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'message' =>
                'Display Name is required'
        ]);

        exit;
    }

    /*
     * Read the existing profile first.
     *
     * Security-sensitive fields that the user is
     * not allowed to self-edit are preserved here.
     */

    $existingResult =
        portalApiRequest(
            $FASTAPI_URL
            . '/user-profiles/'
            . rawurlencode($username)
        );

    if (
        !$existingResult['ok']
        ||
        !is_array($existingResult['data'])
        ||
        empty($existingResult['data']['username'])
    ) {

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'message' => 'Profile was not found'
        ]);

        exit;
    }

    $existing =
        $existingResult['data'];

    /*
     * Resolve the authenticated user's numeric profile ID.
     * A browser-supplied user ID is deliberately ignored.
     */

    $profileId =
        isset($existing['id'])
            ? (int)$existing['id']
            : 0;

    if ($profileId <= 0) {

        http_response_code(500);

        echo json_encode([
            'success' => false,
            'message' =>
                'Authenticated profile has no valid user ID'
        ]);

        exit;
    }

    $customFieldValues =
        $input['custom_fields']
        ?? [];

    if (!is_array($customFieldValues)) {

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'message' =>
                'Invalid custom profile fields'
        ]);

        exit;
    }

    $cleanCustomFieldValues = [];

    foreach ($customFieldValues as $item) {

        if (!is_array($item)) {

            http_response_code(400);

            echo json_encode([
                'success' => false,
                'message' =>
                    'Invalid custom profile field'
            ]);

            exit;
        }

        $fieldId =
            isset($item['field_id'])
                ? (int)$item['field_id']
                : 0;

        if ($fieldId <= 0) {

            http_response_code(400);

            echo json_encode([
                'success' => false,
                'message' =>
                    'Invalid custom profile field ID'
            ]);

            exit;
        }

        $cleanCustomFieldValues[] = [
            'field_id' => $fieldId,
            'value' =>
                array_key_exists('value', $item)
                    ? (string)$item['value']
                    : ''
        ];
    }

    /*
     * Username, group_id and photo are NOT accepted
     * from the browser.
     *
     * Photo will get its own validated upload path
     * later.
     */

    $profilePayload = [
        'username' =>
            $username,

        'display_name' =>
            $displayName,

        'surname' =>
            trim(
                (string)(
                    $input['surname']
                    ?? ''
                )
            ),

        'department' =>
            trim(
                (string)(
                    $input['department']
                    ?? ''
                )
            ),

        'email_address' =>
            trim(
                (string)(
                    $input['email_address']
                    ?? ''
                )
            ),

        'country_code' =>
            trim(
                (string)(
                    $input['country_code']
                    ?? ''
                )
            ),

        'mobile_number' =>
            trim(
                (string)(
                    $input['mobile_number']
                    ?? ''
                )
            ),

        'photo' =>
            $existing['photo'] ?? '',

        'group_id' =>
            $existing['group_id'] ?? null
    ];

    $profileUpdate =
        portalApiRequest(
            $FASTAPI_URL
            . '/user-profiles/update',
            'POST',
            $profilePayload
        );

    if (
        !$profileUpdate['ok']
        ||
        (
            is_array($profileUpdate['data'])
            &&
            isset(
                $profileUpdate['data']['success']
            )
            &&
            $profileUpdate['data']['success']
            === false
        )
    ) {

        http_response_code(500);

        echo json_encode([
            'success' => false,
            'message' =>
                'Unable to save profile'
        ]);

        exit;
    }

    /*
     * Keep the backend display name synchronized.
     */

    $userUpdate =
        portalApiRequest(
            $FASTAPI_URL . '/users/update',
            'POST',
            [
                'username' =>
                    $username,

                'display_name' =>
                    $displayName
            ]
        );

    if (!$userUpdate['ok']) {

        http_response_code(500);

        echo json_encode([
            'success' => false,
            'message' =>
                'Profile saved, but display name synchronization failed'
        ]);

        exit;
    }

    /*
     * Save custom-field values for this authenticated
     * profile only.
     */

    $customFieldUpdate =
        portalApiRequest(
            $FASTAPI_URL
            . '/user-custom-fields/user/'
            . $profileId
            . '/save',
            'POST',
            [
                'values' =>
                    $cleanCustomFieldValues
            ]
        );

    if (
        !$customFieldUpdate['ok']
        ||
        !is_array($customFieldUpdate['data'])
        ||
        (
            isset($customFieldUpdate['data']['success'])
            &&
            $customFieldUpdate['data']['success'] === false
        )
    ) {

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'message' =>
                is_array($customFieldUpdate['data'])
                &&
                !empty(
                    $customFieldUpdate['data']['message']
                )
                    ? (string)
                        $customFieldUpdate['data']['message']
                    : 'Unable to save custom profile fields'
        ]);

        exit;
    }

    /*
     * Update the current PHP session display name
     * so the sidebar/banner can use it next request.
     */

    $_SESSION['displayName'] =
        $displayName;

    echo json_encode([
        'success' => true,
        'message' =>
            'Profile saved successfully'
    ]);

    exit;
}


http_response_code(400);

echo json_encode([
    'success' => false,
    'message' => 'Unknown action'
]);
