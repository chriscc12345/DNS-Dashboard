<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Technitium cache proxy. Serves the
 * Cache tab on the Technitium hub page:
 * flushing the DNS cache and the save
 * cache option. Each action is gated by
 * its own permission so a viewer can be
 * granted flush only or toggle only.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

function technitiumCacheCall(
    $path,
    $params = null
) {

    global $TECHNITIUM_HOST, $TECHNITIUM_TOKEN;

    $ch = curl_init(
        'http://' . $TECHNITIUM_HOST
        . ':5380' . $path
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer '
            . $TECHNITIUM_TOKEN
        ],
        CURLOPT_TIMEOUT => 10
    ]);

    if ($params !== null) {
        curl_setopt(
            $ch,
            CURLOPT_POSTFIELDS,
            http_build_query($params)
        );
    }

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    return json_decode($body, true);
}

function cacheAccessDenied() {

    http_response_code(403);

    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

$action =
    $_GET['action']
    ?? ($_POST['action'] ?? '');

if ($action === 'get') {

    if (
        !hasAnyPermission([
            'Cache',
            'Flush Cache',
            'Enable/Disable Cache'
        ])
    ) {
        cacheAccessDenied();
    }

    $result = technitiumCacheCall(
        '/api/settings/get'
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Failed to read the Technitium '
                . 'DNS server settings.'
        ]);
        exit;
    }

    $settings =
        $result['response'] ?? [];

    echo json_encode([
        'success' => true,
        'save_cache' =>
            (bool)(
                $settings['saveCache']
                ?? false
            )
    ]);
    exit;
}

if ($action === 'flush') {

    if (
        !hasPermission('Flush Cache')
    ) {
        cacheAccessDenied();
    }

    $result = technitiumCacheCall(
        '/api/cache/flush'
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'The Technitium DNS server '
                . 'failed to flush the cache.'
        ]);
        exit;
    }

    echo json_encode([
        'success' => true,
        'message' => 'Cache flushed.'
    ]);
    exit;
}

if ($action === 'set') {

    if (
        !hasPermission(
            'Enable/Disable Cache'
        )
    ) {
        cacheAccessDenied();
    }

    $saveCache = in_array(
        (string)($_POST['save_cache'] ?? ''),
        ['true', '1', 'on'],
        true
    );

    $result = technitiumCacheCall(
        '/api/settings/set',
        [
            'saveCache' =>
                $saveCache
                    ? 'true'
                    : 'false'
        ]
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'The Technitium DNS server '
                . 'rejected the update.'
        ]);
        exit;
    }

    $settings =
        $result['response'] ?? [];

    echo json_encode([
        'success' => true,
        'save_cache' =>
            (bool)(
                $settings['saveCache']
                ?? $saveCache
            )
    ]);
    exit;
}

echo json_encode([
    'success' => false,
    'message' => 'Unknown action.'
]);
