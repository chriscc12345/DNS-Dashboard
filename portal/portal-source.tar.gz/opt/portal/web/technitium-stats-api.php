<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Technitium stats proxy. Serves the
 * Monitor page DNS widgets: the live
 * queries graph and the top users list.
 * Only read-only dashboard stats are
 * exposed and the caller must hold the
 * Technitium permission.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

function technitiumStatsCall(
    $path,
    $params = []
) {

    global $TECHNITIUM_HOST, $TECHNITIUM_TOKEN;

    $ch = curl_init(
        'http://' . $TECHNITIUM_HOST
        . ':5380' . $path
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS =>
            http_build_query($params),
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer '
            . $TECHNITIUM_TOKEN
        ],
        CURLOPT_TIMEOUT => 10
    ]);

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    return json_decode($body, true);
}

function statsAccessDenied() {

    http_response_code(403);

    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

function statsFindSeries(
    $chart,
    $label
) {

    $datasets =
        $chart['datasets']
        ?? [];

    foreach ($datasets as $dataset) {

        if (
            ($dataset['label'] ?? '')
            === $label
        ) {
            $data =
                $dataset['data'] ?? [];

            if (is_array($data)) {
                return array_map(
                    'intval',
                    $data
                );
            }
        }
    }

    return null;
}

function statsMinuteLabel(
    $isoLabel
) {

    $label =
        (string)$isoLabel;

    /*
     * The API returns labels like
     * 2024-05-01T14:05:00.0000000Z
     * when utc is requested; keep
     * only the HH:MM part.
     */

    if (
        strlen($label) >= 16
        && $label[10] === 'T'
    ) {
        return substr(
            $label,
            11,
            5
        );
    }

    return $label;
}

$action =
    $_GET['action']
    ?? '';

if ($action === 'graph') {

    if (
        !hasPermission(
            'Technitium'
        )
    ) {
        statsAccessDenied();
    }

    $result = technitiumStatsCall(
        '/api/dashboard/stats/get',
        [
            'type' => 'lastHour'
        ]
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Failed to read the '
                . 'Technitium DNS stats.'
        ]);
        exit;
    }

    $response =
        $result['response'] ?? [];

    $chart =
        $response['mainChartData']
        ?? null;

    $labels =
        $chart['labels']
        ?? [];

    $total =
        statsFindSeries(
            $chart,
            'Total'
        );

    $blocked =
        statsFindSeries(
            $chart,
            'Blocked'
        );

    if (
        $total === null
        || $blocked === null
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Unexpected Technitium '
                . 'stats response.'
        ]);
        exit;
    }

    $stats =
        $response['stats']
        ?? [];

    echo json_encode([
        'success' => true,
        'labels' => array_map(
            'statsMinuteLabel',
            $labels
        ),
        'total' => $total,
        'blocked' => $blocked,
        'total_queries' =>
            (int)(
                $stats['totalQueries']
                ?? 0
            ),
        'total_blocked' =>
            (int)(
                $stats['totalBlocked']
                ?? 0
            ),
        'total_clients' =>
            (int)(
                $stats['totalClients']
                ?? 0
            ),
        'cached_entries' =>
            (int)(
                $stats['cachedEntries']
                ?? 0
            ),
        'block_list_zones' =>
            (int)(
                $stats['blockListZones']
                ?? 0
            ),
        'zones' =>
            (int)(
                $stats['zones']
                ?? 0
            )
    ]);
    exit;
}

if ($action === 'top') {

    if (
        !hasPermission(
            'Technitium'
        )
    ) {
        statsAccessDenied();
    }

    $statsType =
        $_GET['statsType']
        ?? 'TopClients';

    if (
        !in_array(
            $statsType,
            [
                'TopClients',
                'TopDomains',
                'TopBlockedDomains'
            ],
            true
        )
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Unsupported stats type.'
        ]);
        exit;
    }

    $limit =
        (int)(
            $_GET['limit'] ?? 10
        );

    if (
        $limit < 1
        || $limit > 25
    ) {
        $limit = 10;
    }

    $result = technitiumStatsCall(
        '/api/dashboard/stats/getTop',
        [
            'type' => 'lastHour',
            'statsType' => $statsType,
            'limit' => $limit
        ]
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Failed to read the '
                . 'Technitium DNS stats.'
        ]);
        exit;
    }

    $response =
        $result['response'] ?? [];

    $source =
        $response['topClients']
        ?? ($response['topDomains']
        ?? ($response['topBlockedDomains']
        ?? []));

    $items = [];

    foreach ($source as $row) {

        $items[] = [
            'name' =>
                (string)(
                    $row['name'] ?? ''
                ),
            'hits' =>
                (int)(
                    $row['hits'] ?? 0
                )
        ];
    }

    echo json_encode([
        'success' => true,
        'items' => $items
    ]);
    exit;
}

if ($action === 'summary') {

    $stats =
        technitiumStatsCall(
            '/api/dashboard/stats/get'
        );

    $stats =
        $stats['response']['stats']
        ?? null;

    if ($stats === null) {

        echo json_encode([
            'success' => false,
            'message' => 'DNS server is '
                . 'not reachable.'
        ]);

        exit;
    }

    echo json_encode([
        'totalQueries' =>
            (int)($stats['totalQueries'] ?? 0),
        'totalBlocked' =>
            (int)($stats['totalBlocked'] ?? 0),
        'totalClients' =>
            (int)($stats['totalClients'] ?? 0),
        'cachedEntries' =>
            (int)($stats['cachedEntries'] ?? 0),
        'blockListZones' =>
            (int)($stats['blockListZones'] ?? 0),
        'zones' =>
            (int)($stats['zones'] ?? 0)
    ]);

    exit;
}

if ($action === 'dhcp') {

    $scopes =
        technitiumStatsCall(
            '/api/dhcp/scopes/list'
        );

    $leases =
        technitiumStatsCall(
            '/api/dhcp/leases/list'
        );

    echo json_encode([
        'scopes' =>
            $scopes['response']['scopes']
            ?? [],
        'leases' =>
            $leases['response']['leases']
            ?? []
    ]);

    exit;
}

echo json_encode([
    'success' => false,
    'message' => 'Unknown action.'
]);
