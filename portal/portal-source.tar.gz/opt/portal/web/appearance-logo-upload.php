<?php

require_once 'auth.php';
require_once 'config.php';

header('Content-Type: application/json');

function logoResponse(
    bool $success,
    string $message,
    array $extra = []
): void {

    echo json_encode(
        array_merge(
            [
                'success' => $success,
                'message' => $message
            ],
            $extra
        )
    );

    exit;
}


if (!hasPermission('Logo')) {
    http_response_code(403);

    logoResponse(
        false,
        'You do not have permission to manage the company logo.'
    );
}


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    logoResponse(
        false,
        'POST required.'
    );
}


$action =
    trim(
        (string)(
            $_POST['action']
            ?? ''
        )
    );


$uploadDirectory =
    '/opt/portal/web/uploads/appearance';

$relativeDirectory =
    'uploads/appearance';


function getCurrentCompanyLogo(
    string $fastApiUrl
): string {

    $settings =
        @file_get_contents(
            $fastApiUrl . '/portal-settings'
        );

    if ($settings === false) {
        return '';
    }

    $decoded =
        json_decode(
            $settings,
            true
        );

    if (!is_array($decoded)) {
        return '';
    }

    return trim(
        (string)(
            $decoded['company_logo']
            ?? ''
        )
    );
}


function saveCompanyLogoSetting(
    string $fastApiUrl,
    string $logoPath
): bool {

    $payload =
        json_encode(
            [
                'settings' => [
                    'company_logo' => $logoPath
                ]
            ]
        );

    $context =
        stream_context_create(
            [
                'http' => [
                    'method' => 'POST',
                    'header' =>
                        "Content-Type: application/json\r\n",
                    'content' => $payload,
                    'ignore_errors' => true,
                    'timeout' => 10
                ]
            ]
        );

    $response =
        @file_get_contents(
            $fastApiUrl . '/portal-settings/appearance',
            false,
            $context
        );

    if ($response === false) {
        return false;
    }

    $decoded =
        json_decode(
            $response,
            true
        );

    return
        is_array($decoded)
        && (
            ($decoded['success'] ?? false) === true
            || ($decoded['settings']['company_logo'] ?? null)
                === $logoPath
        );
}


function deleteManagedLogo(
    string $relativePath,
    string $uploadDirectory
): void {

    if (
        !preg_match(
            '#^uploads/appearance/logo_[a-f0-9]{32}\.webp$#',
            $relativePath
        )
    ) {
        return;
    }

    $filename =
        basename(
            $relativePath
        );

    $absolutePath =
        $uploadDirectory
        . '/'
        . $filename;

    if (is_file($absolutePath)) {
        @unlink($absolutePath);
    }
}


/*
 * Update003 - Favicon management
 *
 * The factory favicon at images/favicon.png is never modified.
 * Custom favicons are stored as managed WebP files.
 */

function getCurrentPortalFavicon(
    string $fastApiUrl
): string {

    $settings =
        @file_get_contents(
            $fastApiUrl . '/portal-settings'
        );

    if ($settings === false) {
        return '';
    }

    $decoded =
        json_decode(
            $settings,
            true
        );

    if (!is_array($decoded)) {
        return '';
    }

    return trim(
        (string)(
            $decoded['portal_favicon']
            ?? ''
        )
    );
}


function savePortalFaviconSetting(
    string $fastApiUrl,
    string $faviconPath
): bool {

    $payload =
        json_encode(
            [
                'settings' => [
                    'portal_favicon' => $faviconPath
                ]
            ]
        );

    $context =
        stream_context_create(
            [
                'http' => [
                    'method' => 'POST',
                    'header' =>
                        "Content-Type: application/json\r\n",
                    'content' => $payload,
                    'ignore_errors' => true,
                    'timeout' => 10
                ]
            ]
        );

    $response =
        @file_get_contents(
            $fastApiUrl . '/portal-settings/appearance',
            false,
            $context
        );

    if ($response === false) {
        return false;
    }

    $decoded =
        json_decode(
            $response,
            true
        );

    return
        is_array($decoded)
        && (
            ($decoded['success'] ?? false) === true
            || ($decoded['settings']['portal_favicon'] ?? null)
                === $faviconPath
        );
}


function deleteManagedFavicon(
    string $relativePath,
    string $uploadDirectory
): void {

    if (
        !preg_match(
            '#^uploads/appearance/favicon_[a-f0-9]{32}\.webp$#',
            $relativePath
        )
    ) {
        return;
    }

    $filename =
        basename(
            $relativePath
        );

    $absolutePath =
        $uploadDirectory
        . '/'
        . $filename;

    if (is_file($absolutePath)) {
        @unlink($absolutePath);
    }
}


if ($action === 'favicon_remove') {

    $oldFavicon =
        getCurrentPortalFavicon(
            $FASTAPI_URL
        );

    if (
        !savePortalFaviconSetting(
            $FASTAPI_URL,
            ''
        )
    ) {
        http_response_code(502);

        logoResponse(
            false,
            'Unable to restore the default favicon.'
        );
    }

    deleteManagedFavicon(
        $oldFavicon,
        $uploadDirectory
    );

    logoResponse(
        true,
        'Default favicon restored.',
        [
            'portal_favicon' => ''
        ]
    );
}


if ($action === 'favicon_upload') {

    if (
        !isset($_FILES['favicon'])
        || !is_array($_FILES['favicon'])
    ) {
        http_response_code(400);

        logoResponse(
            false,
            'No favicon file was supplied.'
        );
    }


    $file =
        $_FILES['favicon'];


    if (
        ($file['error'] ?? UPLOAD_ERR_NO_FILE)
        !== UPLOAD_ERR_OK
    ) {
        http_response_code(400);

        logoResponse(
            false,
            'Favicon upload failed.'
        );
    }


    $fileSize =
        (int)(
            $file['size']
            ?? 0
        );


    if (
        $fileSize <= 0
        || $fileSize > (5 * 1024 * 1024)
    ) {
        http_response_code(400);

        logoResponse(
            false,
            'Favicon must be 5 MB or smaller.'
        );
    }


    $tempFile =
        (string)(
            $file['tmp_name']
            ?? ''
        );


    if (
        $tempFile === ''
        || !is_uploaded_file($tempFile)
    ) {
        http_response_code(400);

        logoResponse(
            false,
            'Invalid uploaded favicon.'
        );
    }


    $finfo =
        new finfo(
            FILEINFO_MIME_TYPE
        );

    $mimeType =
        $finfo->file(
            $tempFile
        );


    $allowedMimeTypes = [
        'image/jpeg',
        'image/png',
        'image/webp'
    ];


    if (
        !in_array(
            $mimeType,
            $allowedMimeTypes,
            true
        )
    ) {
        http_response_code(400);

        logoResponse(
            false,
            'Only JPG, PNG and WebP images are allowed.'
        );
    }


    switch ($mimeType) {

        case 'image/jpeg':
            $source =
                @imagecreatefromjpeg(
                    $tempFile
                );
            break;

        case 'image/png':
            $source =
                @imagecreatefrompng(
                    $tempFile
                );
            break;

        case 'image/webp':
            $source =
                @imagecreatefromwebp(
                    $tempFile
                );
            break;

        default:
            $source = false;
    }


    if ($source === false) {
        http_response_code(400);

        logoResponse(
            false,
            'The uploaded favicon could not be processed.'
        );
    }


    $sourceWidth =
        imagesx(
            $source
        );

    $sourceHeight =
        imagesy(
            $source
        );


    if (
        $sourceWidth < 1
        || $sourceHeight < 1
    ) {
        imagedestroy(
            $source
        );

        http_response_code(400);

        logoResponse(
            false,
            'Invalid favicon dimensions.'
        );
    }


    /*
     * Produce a square 256x256 favicon while preserving
     * the complete source image and transparency.
     */

    $canvasSize = 256;

    $scale =
        min(
            $canvasSize / $sourceWidth,
            $canvasSize / $sourceHeight
        );

    $targetWidth =
        max(
            1,
            (int)round(
                $sourceWidth * $scale
            )
        );

    $targetHeight =
        max(
            1,
            (int)round(
                $sourceHeight * $scale
            )
        );

    $offsetX =
        (int)floor(
            ($canvasSize - $targetWidth) / 2
        );

    $offsetY =
        (int)floor(
            ($canvasSize - $targetHeight) / 2
        );


    $destination =
        imagecreatetruecolor(
            $canvasSize,
            $canvasSize
        );


    if ($destination === false) {
        imagedestroy(
            $source
        );

        http_response_code(500);

        logoResponse(
            false,
            'Unable to create favicon image.'
        );
    }


    imagealphablending(
        $destination,
        false
    );

    imagesavealpha(
        $destination,
        true
    );

    $transparent =
        imagecolorallocatealpha(
            $destination,
            0,
            0,
            0,
            127
        );

    imagefilledrectangle(
        $destination,
        0,
        0,
        $canvasSize - 1,
        $canvasSize - 1,
        $transparent
    );


    imagecopyresampled(
        $destination,
        $source,
        $offsetX,
        $offsetY,
        0,
        0,
        $targetWidth,
        $targetHeight,
        $sourceWidth,
        $sourceHeight
    );


    $filename =
        'favicon_'
        . bin2hex(
            random_bytes(16)
        )
        . '.webp';

    $absolutePath =
        $uploadDirectory
        . '/'
        . $filename;

    $relativePath =
        $relativeDirectory
        . '/'
        . $filename;


    $written =
        imagewebp(
            $destination,
            $absolutePath,
            90
        );


    imagedestroy(
        $source
    );

    imagedestroy(
        $destination
    );


    if (
        !$written
        || !is_file($absolutePath)
    ) {
        http_response_code(500);

        logoResponse(
            false,
            'Unable to save the processed favicon.'
        );
    }


    @chmod(
        $absolutePath,
        0644
    );


    $oldFavicon =
        getCurrentPortalFavicon(
            $FASTAPI_URL
        );


    if (
        !savePortalFaviconSetting(
            $FASTAPI_URL,
            $relativePath
        )
    ) {
        @unlink(
            $absolutePath
        );

        http_response_code(502);

        logoResponse(
            false,
            'Unable to save the favicon setting.'
        );
    }


    if (
        $oldFavicon !== ''
        && $oldFavicon !== $relativePath
    ) {
        deleteManagedFavicon(
            $oldFavicon,
            $uploadDirectory
        );
    }


    logoResponse(
        true,
        'Favicon uploaded.',
        [
            'portal_favicon' => $relativePath
        ]
    );
}


if ($action === 'remove') {

    $oldLogo =
        getCurrentCompanyLogo(
            $FASTAPI_URL
        );

    if (
        !saveCompanyLogoSetting(
            $FASTAPI_URL,
            ''
        )
    ) {
        http_response_code(502);

        logoResponse(
            false,
            'Unable to clear the company logo setting.'
        );
    }

    deleteManagedLogo(
        $oldLogo,
        $uploadDirectory
    );

    logoResponse(
        true,
        'Company logo removed.',
        [
            'company_logo' => ''
        ]
    );
}


if ($action !== 'upload') {
    http_response_code(400);

    logoResponse(
        false,
        'Invalid action.'
    );
}


if (
    !isset($_FILES['logo'])
    || !is_array($_FILES['logo'])
) {
    http_response_code(400);

    logoResponse(
        false,
        'No logo file was supplied.'
    );
}


$file =
    $_FILES['logo'];


if (
    ($file['error'] ?? UPLOAD_ERR_NO_FILE)
    !== UPLOAD_ERR_OK
) {
    http_response_code(400);

    logoResponse(
        false,
        'Logo upload failed.'
    );
}


$fileSize =
    (int)(
        $file['size']
        ?? 0
    );


if (
    $fileSize <= 0
    || $fileSize > (5 * 1024 * 1024)
) {
    http_response_code(400);

    logoResponse(
        false,
        'Logo must be 5 MB or smaller.'
    );
}


$tempFile =
    (string)(
        $file['tmp_name']
        ?? ''
    );


if (
    $tempFile === ''
    || !is_uploaded_file($tempFile)
) {
    http_response_code(400);

    logoResponse(
        false,
        'Invalid uploaded file.'
    );
}


$finfo =
    new finfo(
        FILEINFO_MIME_TYPE
    );

$mimeType =
    $finfo->file(
        $tempFile
    );


$allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/webp'
];


if (
    !in_array(
        $mimeType,
        $allowedMimeTypes,
        true
    )
) {
    http_response_code(400);

    logoResponse(
        false,
        'Only JPG, PNG and WebP images are allowed.'
    );
}


switch ($mimeType) {

    case 'image/jpeg':
        $source =
            @imagecreatefromjpeg(
                $tempFile
            );
        break;

    case 'image/png':
        $source =
            @imagecreatefrompng(
                $tempFile
            );
        break;

    case 'image/webp':
        $source =
            @imagecreatefromwebp(
                $tempFile
            );
        break;

    default:
        $source = false;
}


if ($source === false) {
    http_response_code(400);

    logoResponse(
        false,
        'The uploaded image could not be processed.'
    );
}


$sourceWidth =
    imagesx(
        $source
    );

$sourceHeight =
    imagesy(
        $source
    );


if (
    $sourceWidth < 1
    || $sourceHeight < 1
) {
    imagedestroy($source);

    http_response_code(400);

    logoResponse(
        false,
        'Invalid image dimensions.'
    );
}


/*
 * Logos do not need enormous source dimensions.
 * Preserve aspect ratio and transparency.
 */

$maximumWidth = 1600;
$maximumHeight = 800;

$scale =
    min(
        1,
        $maximumWidth / $sourceWidth,
        $maximumHeight / $sourceHeight
    );

$targetWidth =
    max(
        1,
        (int)round(
            $sourceWidth * $scale
        )
    );

$targetHeight =
    max(
        1,
        (int)round(
            $sourceHeight * $scale
        )
    );


$destination =
    imagecreatetruecolor(
        $targetWidth,
        $targetHeight
    );


imagealphablending(
    $destination,
    false
);

imagesavealpha(
    $destination,
    true
);

$transparent =
    imagecolorallocatealpha(
        $destination,
        0,
        0,
        0,
        127
    );

imagefilledrectangle(
    $destination,
    0,
    0,
    $targetWidth,
    $targetHeight,
    $transparent
);


imagecopyresampled(
    $destination,
    $source,
    0,
    0,
    0,
    0,
    $targetWidth,
    $targetHeight,
    $sourceWidth,
    $sourceHeight
);


$filename =
    'logo_'
    . bin2hex(
        random_bytes(16)
    )
    . '.webp';

$absolutePath =
    $uploadDirectory
    . '/'
    . $filename;

$relativePath =
    $relativeDirectory
    . '/'
    . $filename;


$written =
    imagewebp(
        $destination,
        $absolutePath,
        88
    );


imagedestroy(
    $source
);

imagedestroy(
    $destination
);


if (
    !$written
    || !is_file($absolutePath)
) {
    http_response_code(500);

    logoResponse(
        false,
        'Unable to save the processed logo.'
    );
}


@chmod(
    $absolutePath,
    0644
);


$oldLogo =
    getCurrentCompanyLogo(
        $FASTAPI_URL
    );


if (
    !saveCompanyLogoSetting(
        $FASTAPI_URL,
        $relativePath
    )
) {
    @unlink(
        $absolutePath
    );

    http_response_code(502);

    logoResponse(
        false,
        'Unable to save the company logo setting.'
    );
}


if (
    $oldLogo !== ''
    && $oldLogo !== $relativePath
) {
    deleteManagedLogo(
        $oldLogo,
        $uploadDirectory
    );
}


logoResponse(
    true,
    'Company logo uploaded.',
    [
        'company_logo' => $relativePath
    ]
);
