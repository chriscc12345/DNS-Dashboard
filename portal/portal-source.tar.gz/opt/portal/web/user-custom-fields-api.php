<?php

require_once 'auth.php';
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');


function customFieldResponse(
    bool $success,
    string $message = '',
    array $extra = [],
    int $statusCode = 200
): void {

    http_response_code($statusCode);

    echo json_encode(
        array_merge(
            [
                'success' => $success,
                'message' => $message
            ],
            $extra
        )
    );

    exit;
}


if(!hasPermission('Users')){

    customFieldResponse(
        false,
        'Permission denied.',
        [],
        403
    );
}


function customFieldApiGet(
    string $url
): array {

    $context = stream_context_create([
        'http' => [
            'method'        => 'GET',
            'ignore_errors' => true,
            'timeout'       => 10
        ]
    ]);

    $response =
        @file_get_contents(
            $url,
            false,
            $context
        );

    $statusCode = 0;

    if(
        isset($http_response_header)
        &&
        is_array($http_response_header)
        &&
        isset($http_response_header[0])
        &&
        preg_match(
            '/\s(\d{3})\s/',
            $http_response_header[0],
            $matches
        )
    ){
        $statusCode = (int)$matches[1];
    }

    $decoded =
        $response !== false
            ? json_decode($response, true)
            : null;

    return [
        'ok' =>
            $response !== false
            &&
            (
                $statusCode === 0
                ||
                (
                    $statusCode >= 200
                    &&
                    $statusCode < 300
                )
            ),
        'status' => $statusCode,
        'data'   =>
            is_array($decoded)
                ? $decoded
                : null
    ];
}


function customFieldApiPost(
    string $url,
    array $payload
): array {

    $context = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        =>
                "Content-Type: application/json\r\n",
            'content'       => json_encode($payload),
            'ignore_errors' => true,
            'timeout'       => 10
        ]
    ]);

    $response =
        @file_get_contents(
            $url,
            false,
            $context
        );

    $statusCode = 0;

    if(
        isset($http_response_header)
        &&
        is_array($http_response_header)
        &&
        isset($http_response_header[0])
        &&
        preg_match(
            '/\s(\d{3})\s/',
            $http_response_header[0],
            $matches
        )
    ){
        $statusCode = (int)$matches[1];
    }

    $decoded =
        $response !== false
            ? json_decode($response, true)
            : null;

    return [
        'ok' =>
            $response !== false
            &&
            (
                $statusCode === 0
                ||
                (
                    $statusCode >= 200
                    &&
                    $statusCode < 300
                )
            ),
        'status' => $statusCode,
        'data'   =>
            is_array($decoded)
                ? $decoded
                : null
    ];
}


$action =
    trim(
        (string)(
            $_REQUEST['action']
            ?? ''
        )
    );


/*
 * =========================================================
 * CUSTOM FIELD DEFINITIONS
 *
 * Permission:
 *   Users
 *   + Edit User Fields
 *
 * These actions manage field definitions only.
 * Existing load/save actions below manage user values.
 * =========================================================
 */

if(
    in_array(
        $action,
        [
            'definitions',
            'create-definition',
            'update-definition',
            'delete-definition',
            'sections',
            'create-section',
            'update-section',
            'delete-section'
        ],
        true
    )
    &&
    !hasPermission('Edit User Fields')
){

    customFieldResponse(
        false,
        'Permission denied.',
        [],
        403
    );
}


/*
 * =========================================================
 * LIST DEFINITIONS
 * =========================================================
 */

if($action === 'definitions'){

    $result =
        customFieldApiGet(
            $FASTAPI_URL .
            '/user-custom-fields'
        );

    if(
        !$result['ok']
        ||
        !is_array($result['data'])
    ){

        customFieldResponse(
            false,
            'Unable to load custom field definitions.',
            [],
            502
        );
    }

    customFieldResponse(
        true,
        '',
        [
            'fields' => $result['data']
        ]
    );
}


/*
 * =========================================================
 * CREATE DEFINITION
 * =========================================================
 */

if($action === 'create-definition'){

    if($_SERVER['REQUEST_METHOD'] !== 'POST'){

        customFieldResponse(
            false,
            'POST required.',
            [],
            405
        );
    }


    $raw =
        file_get_contents('php://input');

    $input =
        json_decode(
            $raw ?: '',
            true
        );


    if(!is_array($input)){

        customFieldResponse(
            false,
            'Invalid request body.',
            [],
            400
        );
    }


    $fieldName =
        trim(
            (string)(
                $input['field_name']
                ?? ''
            )
        );

    $fieldType =
        strtolower(
            trim(
                (string)(
                    $input['field_type']
                    ?? 'text'
                )
            )
        );

    $required =
        filter_var(
            $input['required'] ?? false,
            FILTER_VALIDATE_BOOLEAN
        );

    $sortOrder =
        isset($input['sort_order'])
            ? (int)$input['sort_order']
            : 0;

    $sectionId =
        isset($input['section_id'])
            ? (int)$input['section_id']
            : 0;

    $prepend =
        trim(
            (string)(
                $input['prepend']
                ?? ''
            )
        );


    $allowedTypes = [
        'text',
        'textarea',
        'email',
        'number',
        'date',
        'checkbox'
    ];


    if($fieldName === ''){

        customFieldResponse(
            false,
            'Field name is required.',
            [],
            400
        );
    }


    if(strlen($fieldName) > 100){

        customFieldResponse(
            false,
            'Field name is too long.',
            [],
            400
        );
    }


    if(
        !in_array(
            $fieldType,
            $allowedTypes,
            true
        )
    ){

        customFieldResponse(
            false,
            'Invalid field type.',
            [],
            400
        );
    }


    if($sectionId <= 0){

        customFieldResponse(
            false,
            'Invalid custom field section.',
            [],
            400
        );
    }


    if(strlen($prepend) > 50){

        customFieldResponse(
            false,
            'Prepend is too long.',
            [],
            400
        );
    }


    $result =
        customFieldApiPost(
            $FASTAPI_URL .
            '/user-custom-fields/create',
            [
                'field_name' => $fieldName,
                'field_type' => $fieldType,
                'required'   => $required,
                'sort_order' => $sortOrder,
                'section_id' => $sectionId,
                'prepend'    => $prepend
            ]
        );


    if(
        !$result['ok']
        ||
        !is_array($result['data'])
    ){

        customFieldResponse(
            false,
            'Unable to create custom field.',
            [],
            502
        );
    }


    if(
        empty(
            $result['data']['success']
        )
    ){

        customFieldResponse(
            false,
            (string)(
                $result['data']['message']
                ?? 'Unable to create custom field.'
            ),
            [],
            400
        );
    }


    customFieldResponse(
        true,
        'Custom field created successfully.',
        [
            'field' =>
                $result['data']
        ]
    );
}


/*
 * =========================================================
 * UPDATE DEFINITION
 * =========================================================
 */

if($action === 'update-definition'){

    if($_SERVER['REQUEST_METHOD'] !== 'POST'){

        customFieldResponse(
            false,
            'POST required.',
            [],
            405
        );
    }


    $raw =
        file_get_contents('php://input');

    $input =
        json_decode(
            $raw ?: '',
            true
        );


    if(!is_array($input)){

        customFieldResponse(
            false,
            'Invalid request body.',
            [],
            400
        );
    }


    $fieldId =
        isset($input['field_id'])
            ? (int)$input['field_id']
            : 0;

    $fieldName =
        trim(
            (string)(
                $input['field_name']
                ?? ''
            )
        );

    $fieldType =
        strtolower(
            trim(
                (string)(
                    $input['field_type']
                    ?? ''
                )
            )
        );

    $required =
        filter_var(
            $input['required'] ?? false,
            FILTER_VALIDATE_BOOLEAN
        );

    $sortOrder =
        isset($input['sort_order'])
            ? (int)$input['sort_order']
            : 0;

    $sectionId =
        isset($input['section_id'])
            ? (int)$input['section_id']
            : 0;

    $prepend =
        trim(
            (string)(
                $input['prepend']
                ?? ''
            )
        );


    $allowedTypes = [
        'text',
        'textarea',
        'email',
        'number',
        'date',
        'checkbox'
    ];


    if($fieldId <= 0){

        customFieldResponse(
            false,
            'Invalid custom field ID.',
            [],
            400
        );
    }


    if($fieldName === ''){

        customFieldResponse(
            false,
            'Field name is required.',
            [],
            400
        );
    }


    if(strlen($fieldName) > 100){

        customFieldResponse(
            false,
            'Field name is too long.',
            [],
            400
        );
    }


    if(
        !in_array(
            $fieldType,
            $allowedTypes,
            true
        )
    ){

        customFieldResponse(
            false,
            'Invalid field type.',
            [],
            400
        );
    }


    if($sectionId <= 0){

        customFieldResponse(
            false,
            'Invalid custom field section.',
            [],
            400
        );
    }


    if(strlen($prepend) > 50){

        customFieldResponse(
            false,
            'Prepend is too long.',
            [],
            400
        );
    }


    $result =
        customFieldApiPost(
            $FASTAPI_URL .
            '/user-custom-fields/' .
            $fieldId .
            '/update',
            [
                'field_name' => $fieldName,
                'field_type' => $fieldType,
                'required'   => $required,
                'sort_order' => $sortOrder,
                'section_id' => $sectionId,
                'prepend'    => $prepend
            ]
        );


    if(
        !$result['ok']
        ||
        !is_array($result['data'])
    ){

        customFieldResponse(
            false,
            'Unable to update custom field.',
            [],
            502
        );
    }


    if(
        empty(
            $result['data']['success']
        )
    ){

        customFieldResponse(
            false,
            (string)(
                $result['data']['message']
                ?? 'Unable to update custom field.'
            ),
            [],
            400
        );
    }


    customFieldResponse(
        true,
        'Custom field updated successfully.',
        [
            'field' =>
                $result['data']
        ]
    );
}


/*
 * =========================================================
 * DELETE DEFINITION
 * =========================================================
 */

if($action === 'delete-definition'){

    if($_SERVER['REQUEST_METHOD'] !== 'POST'){

        customFieldResponse(
            false,
            'POST required.',
            [],
            405
        );
    }


    $raw =
        file_get_contents('php://input');

    $input =
        json_decode(
            $raw ?: '',
            true
        );


    if(!is_array($input)){

        customFieldResponse(
            false,
            'Invalid request body.',
            [],
            400
        );
    }


    $fieldId =
        isset($input['field_id'])
            ? (int)$input['field_id']
            : 0;


    if($fieldId <= 0){

        customFieldResponse(
            false,
            'Invalid custom field ID.',
            [],
            400
        );
    }


    $result =
        customFieldApiPost(
            $FASTAPI_URL .
            '/user-custom-fields/' .
            $fieldId .
            '/delete',
            []
        );


    if(
        !$result['ok']
        ||
        !is_array($result['data'])
    ){

        customFieldResponse(
            false,
            'Unable to delete custom field.',
            [],
            502
        );
    }


    if(
        empty(
            $result['data']['success']
        )
    ){

        customFieldResponse(
            false,
            (string)(
                $result['data']['message']
                ?? 'Unable to delete custom field.'
            ),
            [],
            400
        );
    }


    customFieldResponse(
        true,
        'Custom field deleted successfully.',
        [
            'field' =>
                $result['data']
        ]
    );
}


/*
 * =========================================================
 * CUSTOM FIELD SECTIONS
 *
 * Permission:
 *   Users
 *   + Edit User Fields
 * =========================================================
 */

if($action === 'sections'){

    $result =
        customFieldApiGet(
            $FASTAPI_URL .
            '/user-custom-field-sections'
        );

    if(
        !$result['ok']
        ||
        !is_array($result['data'])
    ){

        customFieldResponse(
            false,
            'Unable to load custom field sections.',
            [],
            502
        );
    }

    customFieldResponse(
        true,
        '',
        [
            'sections' => $result['data']
        ]
    );
}


if($action === 'create-section'){

    if($_SERVER['REQUEST_METHOD'] !== 'POST'){

        customFieldResponse(
            false,
            'POST required.',
            [],
            405
        );
    }

    $raw =
        file_get_contents('php://input');

    $input =
        json_decode(
            $raw ?: '',
            true
        );

    if(!is_array($input)){

        customFieldResponse(
            false,
            'Invalid request body.',
            [],
            400
        );
    }

    $sectionName =
        trim(
            (string)(
                $input['section_name']
                ?? ''
            )
        );

    $sortOrder =
        isset($input['sort_order'])
            ? (int)$input['sort_order']
            : 0;

    if($sectionName === ''){

        customFieldResponse(
            false,
            'Section name is required.',
            [],
            400
        );
    }

    if(strlen($sectionName) > 100){

        customFieldResponse(
            false,
            'Section name is too long.',
            [],
            400
        );
    }

    $result =
        customFieldApiPost(
            $FASTAPI_URL .
            '/user-custom-field-sections/create',
            [
                'section_name' => $sectionName,
                'sort_order'   => $sortOrder
            ]
        );

    if(
        !$result['ok']
        ||
        !is_array($result['data'])
    ){

        customFieldResponse(
            false,
            'Unable to create custom field section.',
            [],
            502
        );
    }

    if(empty($result['data']['success'])){

        customFieldResponse(
            false,
            (string)(
                $result['data']['message']
                ?? 'Unable to create custom field section.'
            ),
            [],
            400
        );
    }

    customFieldResponse(
        true,
        'Custom field section created successfully.',
        [
            'section' => $result['data']
        ]
    );
}


if($action === 'update-section'){

    if($_SERVER['REQUEST_METHOD'] !== 'POST'){

        customFieldResponse(
            false,
            'POST required.',
            [],
            405
        );
    }

    $raw =
        file_get_contents('php://input');

    $input =
        json_decode(
            $raw ?: '',
            true
        );

    if(!is_array($input)){

        customFieldResponse(
            false,
            'Invalid request body.',
            [],
            400
        );
    }

    $sectionId =
        isset($input['section_id'])
            ? (int)$input['section_id']
            : 0;

    $sectionName =
        trim(
            (string)(
                $input['section_name']
                ?? ''
            )
        );

    $sortOrder =
        isset($input['sort_order'])
            ? (int)$input['sort_order']
            : 0;

    if($sectionId <= 0){

        customFieldResponse(
            false,
            'Invalid custom field section ID.',
            [],
            400
        );
    }

    if($sectionName === ''){

        customFieldResponse(
            false,
            'Section name is required.',
            [],
            400
        );
    }

    if(strlen($sectionName) > 100){

        customFieldResponse(
            false,
            'Section name is too long.',
            [],
            400
        );
    }

    $result =
        customFieldApiPost(
            $FASTAPI_URL .
            '/user-custom-field-sections/' .
            $sectionId .
            '/update',
            [
                'section_name' => $sectionName,
                'sort_order'   => $sortOrder
            ]
        );

    if(
        !$result['ok']
        ||
        !is_array($result['data'])
    ){

        customFieldResponse(
            false,
            'Unable to update custom field section.',
            [],
            502
        );
    }

    if(empty($result['data']['success'])){

        customFieldResponse(
            false,
            (string)(
                $result['data']['message']
                ?? 'Unable to update custom field section.'
            ),
            [],
            400
        );
    }

    customFieldResponse(
        true,
        'Custom field section updated successfully.',
        [
            'section' => $result['data']
        ]
    );
}


if($action === 'delete-section'){

    if($_SERVER['REQUEST_METHOD'] !== 'POST'){

        customFieldResponse(
            false,
            'POST required.',
            [],
            405
        );
    }

    $raw =
        file_get_contents('php://input');

    $input =
        json_decode(
            $raw ?: '',
            true
        );

    if(!is_array($input)){

        customFieldResponse(
            false,
            'Invalid request body.',
            [],
            400
        );
    }

    $sectionId =
        isset($input['section_id'])
            ? (int)$input['section_id']
            : 0;

    if($sectionId <= 0){

        customFieldResponse(
            false,
            'Invalid custom field section ID.',
            [],
            400
        );
    }

    $result =
        customFieldApiPost(
            $FASTAPI_URL .
            '/user-custom-field-sections/' .
            $sectionId .
            '/delete',
            []
        );

    if(
        !$result['ok']
        ||
        !is_array($result['data'])
    ){

        customFieldResponse(
            false,
            'Unable to delete custom field section.',
            [],
            502
        );
    }

    if(empty($result['data']['success'])){

        customFieldResponse(
            false,
            (string)(
                $result['data']['message']
                ?? 'Unable to delete custom field section.'
            ),
            [],
            400
        );
    }

    customFieldResponse(
        true,
        'Custom field section deleted successfully.',
        [
            'section' => $result['data']
        ]
    );
}


/*
 * =========================================================
 * LOAD VALUES
 * Permission: Users
 * =========================================================
 */

if($action === 'load'){

    $userId =
        isset($_GET['user_id'])
            ? (int)$_GET['user_id']
            : 0;

    if($userId <= 0){

        customFieldResponse(
            false,
            'Invalid user ID.',
            [],
            400
        );
    }

    $result =
        customFieldApiGet(
            $FASTAPI_URL .
            '/user-custom-fields/user/' .
            $userId
        );

    if(
        !$result['ok']
        ||
        !is_array($result['data'])
    ){

        customFieldResponse(
            false,
            'Unable to load custom user fields.',
            [],
            502
        );
    }

    if(
        isset($result['data']['success'])
        &&
        $result['data']['success'] === false
    ){

        customFieldResponse(
            false,
            (string)(
                $result['data']['message']
                ?? 'Unable to load custom user fields.'
            ),
            [],
            404
        );
    }

    customFieldResponse(
        true,
        '',
        [
            'user_id' =>
                (int)(
                    $result['data']['user_id']
                    ?? $userId
                ),

            'fields' =>
                is_array(
                    $result['data']['fields']
                    ?? null
                )
                    ? $result['data']['fields']
                    : []
        ]
    );
}


/*
 * =========================================================
 * SAVE VALUES
 * Permission: Users
 * =========================================================
 */

if($action === 'save'){

    if($_SERVER['REQUEST_METHOD'] !== 'POST'){

        customFieldResponse(
            false,
            'POST required.',
            [],
            405
        );
    }

    $raw =
        file_get_contents('php://input');

    $input =
        json_decode(
            $raw ?: '',
            true
        );

    if(!is_array($input)){

        customFieldResponse(
            false,
            'Invalid request body.',
            [],
            400
        );
    }

    $userId =
        isset($input['user_id'])
            ? (int)$input['user_id']
            : 0;

    if($userId <= 0){

        customFieldResponse(
            false,
            'Invalid user ID.',
            [],
            400
        );
    }

    $values =
        $input['values']
        ?? null;

    if(!is_array($values)){

        customFieldResponse(
            false,
            'Custom field values are required.',
            [],
            400
        );
    }

    $cleanValues = [];

    foreach($values as $item){

        if(!is_array($item)){

            customFieldResponse(
                false,
                'Invalid custom field value.',
                [],
                400
            );
        }

        $fieldId =
            isset($item['field_id'])
                ? (int)$item['field_id']
                : 0;

        if($fieldId <= 0){

            customFieldResponse(
                false,
                'Invalid custom field ID.',
                [],
                400
            );
        }

        $value =
            array_key_exists(
                'value',
                $item
            )
                ? $item['value']
                : '';

        if(
            !is_null($value)
            &&
            !is_scalar($value)
        ){

            customFieldResponse(
                false,
                'Invalid custom field value.',
                [],
                400
            );
        }

        $cleanValues[] = [
            'field_id' => $fieldId,
            'value'    =>
                is_null($value)
                    ? ''
                    : (string)$value
        ];
    }

    $result =
        customFieldApiPost(
            $FASTAPI_URL .
            '/user-custom-fields/user/' .
            $userId .
            '/save',
            [
                'values' => $cleanValues
            ]
        );

    if(
        !$result['ok']
        ||
        !is_array($result['data'])
    ){

        customFieldResponse(
            false,
            'Unable to save custom user fields.',
            [],
            502
        );
    }

    if(
        empty($result['data']['success'])
    ){

        customFieldResponse(
            false,
            (string)(
                $result['data']['message']
                ?? 'Unable to save custom user fields.'
            ),
            [],
            400
        );
    }

    customFieldResponse(
        true,
        'Custom user fields saved successfully.',
        [
            'user_id' => $userId
        ]
    );
}


customFieldResponse(
    false,
    'Unknown action.',
    [],
    400
);
