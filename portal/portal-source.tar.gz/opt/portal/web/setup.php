<?php

session_start();

require_once 'config.php';

$installedAt =
    '/var/lib/portal/installed-at';

$setupComplete =
    '/var/lib/portal/initial-setup-complete';

$error = '';

/*
 * Deployment shape: on the NetFortress deployment the administrator
 * account set here covers BOTH the Portal and the local Firewall
 * Appliance, and there is no current-password step (the account is
 * being created, not changed).
 */
$setupProvider = 'none';
$minPasswordLength = 6;

$setupInfoJson =
    @file_get_contents(
        $FASTAPI_URL . '/initial-setup-info',
        false,
        stream_context_create([
            'http' => [
                'timeout' => 5
            ]
        ])
    );

if ($setupInfoJson !== false) {

    $setupInfo =
        json_decode($setupInfoJson, true);

    if (is_array($setupInfo)) {

        $setupProvider =
            $setupInfo['provider'] ?? 'none';

        $minPasswordLength =
            (int) ($setupInfo['min_password_length'] ?? 6);
    }
}

$isFirewallSetup =
    ($setupProvider === 'firewall');

/*
 * A clean portal (no backend provisioned yet) uses the
 * same simple form: the administrator account is being
 * created, so there is no current-password step. The
 * backend is selected later in Settings -> System Status.
 */
$isSimpleSetup =
    $isFirewallSetup
    || ($setupProvider === 'none');

/*
 * Initial Setup is only available for installations created
 * by the new installer generation.
 */
if (!file_exists($installedAt)) {
    header('Location: login.php');
    exit;
}

/*
 * Once setup has completed, this page can no longer be used.
 */
if (file_exists($setupComplete)) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $adminUsername =
        trim($_POST['username'] ?? 'admin');

    $currentPassword =
        $_POST['current_password'] ?? '';

    $newPassword =
        $_POST['new_password'] ?? '';

    $confirmPassword =
        $_POST['confirm_password'] ?? '';

    if (!$isSimpleSetup && $currentPassword === '') {

        $error =
            'Current administrator password is required.';

    } elseif ($newPassword === '') {

        $error =
            'New administrator password is required.';

    } elseif (
        strlen($newPassword) < $minPasswordLength
    ) {

        $error =
            'Password must be at least '
            . $minPasswordLength
            . ' characters.';

    } elseif ($newPassword !== $confirmPassword) {

        $error =
            'New passwords do not match.';

    } elseif ($newPassword === $currentPassword) {

        $error =
            'New password must be different from the current password.';

    } else {

        $url =
            $FASTAPI_URL . '/initial-setup';

        $data = json_encode([
            'username'         => $adminUsername,
            'current_password' => $currentPassword,
            'new_password'     => $newPassword
        ]);

        $context = stream_context_create([
            'http' => [
                'method'        => 'POST',
                'header'        =>
                    "Content-Type: application/json\r\n",
                'content'       => $data,
                'ignore_errors' => true,
                'timeout'       => 15
            ]
        ]);

        $response =
            @file_get_contents(
                $url,
                false,
                $context
            );

        if ($response === false) {

            $error =
                'Unable to contact the Portal API.';

        } else {

            $result =
                json_decode($response, true);

            if (
                is_array($result) &&
                ($result['status'] ?? '') === 'ok'
            ) {

                $_SESSION = [];

                if (
                    ini_get('session.use_cookies')
                ) {
                    $params =
                        session_get_cookie_params();

                    setcookie(
                        session_name(),
                        '',
                        time() - 42000,
                        $params['path'],
                        $params['domain'],
                        $params['secure'],
                        $params['httponly']
                    );
                }

                session_destroy();

                header(
                    'Location: login.php?setup=complete'
                );
                exit;

            } else {

                $message =
                    is_array($result)
                        ? ($result['message'] ?? '')
                        : '';

                if ($message === '') {

                    $httpStatus =
                        $http_response_header[0]
                        ?? 'unknown HTTP status';

                    $message =
                        'Initial setup failed. '
                        . 'The Portal API returned: '
                        . $httpStatus;
                }

                $error = $message;

            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0">

<title>Initial Administrator Setup</title>

<?php include __DIR__ . '/includes/favicon.php'; ?>


<style>

* {
    box-sizing: border-box;
}

html,
body {
    margin: 0;
    width: 100%;
    min-height: 100%;
    font-family:
        Inter,
        -apple-system,
        BlinkMacSystemFont,
        "Segoe UI",
        sans-serif;
}

body {
    min-height: 100vh;
    min-height: 100dvh;

    display: flex;
    align-items: center;
    justify-content: center;

    padding: 32px 20px;

    color: #e5eef8;

    overflow-x: hidden;

    background:
        radial-gradient(
            circle at 20% 20%,
            rgba(37, 99, 235, .20),
            transparent 32%
        ),
        radial-gradient(
            circle at 80% 75%,
            rgba(6, 182, 212, .13),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #07101d 0%,
            #0b1625 48%,
            #07111d 100%
        );
}

/* Security grid */

.security-grid {
    position: fixed;
    inset: 0;
    z-index: 0;

    pointer-events: none;

    background-image:
        linear-gradient(
            rgba(96, 165, 250, .055) 1px,
            transparent 1px
        ),
        linear-gradient(
            90deg,
            rgba(96, 165, 250, .055) 1px,
            transparent 1px
        );

    background-size: 52px 52px;

    mask-image:
        linear-gradient(
            to bottom,
            rgba(0,0,0,.9),
            rgba(0,0,0,.3)
        );
}

/* Decorative network nodes */

.network {
    position: fixed;
    inset: 0;
    z-index: 0;

    overflow: hidden;
    pointer-events: none;
}

.node {
    position: absolute;

    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #60a5fa;

    box-shadow:
        0 0 10px rgba(96,165,250,.9),
        0 0 24px rgba(37,99,235,.55);

    opacity: .55;

    animation:
        nodePulse 4s ease-in-out infinite;
}

.node::after {
    content: "";

    position: absolute;
    top: 3px;
    left: 7px;

    width: 170px;
    height: 1px;

    transform-origin: left center;

    background:
        linear-gradient(
            90deg,
            rgba(96,165,250,.35),
            transparent
        );
}

.node-1 {
    left: 8%;
    top: 16%;
}

.node-1::after {
    transform: rotate(24deg);
}

.node-2 {
    left: 17%;
    top: 72%;
    animation-delay: 1s;
}

.node-2::after {
    transform: rotate(-28deg);
    width: 210px;
}

.node-3 {
    right: 12%;
    top: 20%;
    animation-delay: 2s;
}

.node-3::after {
    left: auto;
    right: 7px;

    transform-origin: right center;
    transform: rotate(-20deg);

    width: 190px;
}

.node-4 {
    right: 8%;
    bottom: 15%;
    animation-delay: 3s;
}

.node-4::after {
    left: auto;
    right: 7px;

    transform-origin: right center;
    transform: rotate(30deg);

    width: 220px;
}

@keyframes nodePulse {

    0%,
    100% {
        opacity: .35;
        transform: scale(.9);
    }

    50% {
        opacity: .9;
        transform: scale(1.2);
    }
}

/* Main layout */

.setup-shell {
    position: relative;
    z-index: 2;

    width: 100%;
    max-width: 520px;
}

.brand {
    margin-bottom: 22px;
    text-align: center;
}

.shield {
    width: 74px;
    height: 82px;

    margin: 0 auto 15px;

    display: flex;
    align-items: center;
    justify-content: center;

    filter:
        drop-shadow(
            0 0 20px rgba(59,130,246,.28)
        );
}

.shield svg {
    width: 100%;
    height: 100%;
}

.brand-title {
    margin: 0;

    color: #f8fafc;

    font-size: 26px;
    font-weight: 700;
    letter-spacing: .4px;
}

.brand-subtitle {
    margin-top: 7px;

    color: #7f94ad;

    font-size: 13px;
    letter-spacing: 2.5px;
    text-transform: uppercase;
}

/* Card */

.setup-card {
    position: relative;

    padding: 36px;

    overflow: hidden;

    border:
        1px solid rgba(148,163,184,.16);

    border-radius: 20px;

    background:
        linear-gradient(
            145deg,
            rgba(19,31,48,.96),
            rgba(10,20,34,.96)
        );

    box-shadow:
        0 30px 70px rgba(0,0,0,.42),
        inset 0 1px 0 rgba(255,255,255,.035);

    backdrop-filter: blur(18px);
}

.setup-card::before {
    content: "";

    position: absolute;
    top: 0;
    left: 10%;
    right: 10%;

    height: 1px;

    background:
        linear-gradient(
            90deg,
            transparent,
            rgba(96,165,250,.85),
            transparent
        );
}

.setup-heading {
    margin: 0 0 8px;

    color: #f8fafc;

    font-size: 23px;
    font-weight: 650;

    text-align: center;
}

.setup-description {
    max-width: 410px;

    margin: 0 auto 27px;

    color: #94a3b8;

    font-size: 14px;
    line-height: 1.55;

    text-align: center;
}

.security-notice {
    display: flex;
    gap: 11px;
    align-items: flex-start;

    margin-bottom: 24px;
    padding: 13px 14px;

    border:
        1px solid rgba(59,130,246,.20);

    border-radius: 10px;

    color: #a9bad0;

    background:
        rgba(37,99,235,.075);

    font-size: 12.5px;
    line-height: 1.45;
}

.notice-icon {
    flex: 0 0 auto;

    width: 18px;
    height: 18px;

    margin-top: 1px;
}

.error-message {
    margin-bottom: 20px;
    padding: 12px 14px;

    border:
        1px solid rgba(248,113,113,.30);

    border-radius: 9px;

    color: #fecaca;

    background:
        rgba(127,29,29,.25);

    font-size: 13px;
    line-height: 1.4;
}

.field {
    margin-bottom: 18px;
}

.field label {
    display: block;

    margin-bottom: 7px;

    color: #cbd5e1;

    font-size: 13px;
    font-weight: 600;
}

.input-wrap {
    position: relative;
}

.field input {
    width: 100%;
    height: 48px;

    padding:
        0 45px
        0 14px;

    border:
        1px solid rgba(148,163,184,.22);

    border-radius: 9px;

    outline: none;

    color: #f8fafc;

    background:
        rgba(4,12,23,.55);

    font-size: 14px;

    transition:
        border-color .2s,
        box-shadow .2s,
        background .2s;
}

.field input:focus {
    border-color:
        rgba(96,165,250,.75);

    background:
        rgba(5,15,28,.82);

    box-shadow:
        0 0 0 3px
        rgba(37,99,235,.12);
}

.field input:disabled {
    padding-right: 14px;

    color: #94a3b8;

    background:
        rgba(15,23,42,.55);

    cursor: not-allowed;
}

.password-toggle {
    position: absolute;
    top: 50%;
    right: 12px;

    width: 28px;
    height: 28px;

    padding: 0;

    display: flex;
    align-items: center;
    justify-content: center;

    transform: translateY(-50%);

    border: 0;
    border-radius: 6px;

    color: #7f94ad;

    background: transparent;

    cursor: pointer;
}

.password-toggle:hover {
    color: #bfdbfe;
    background: rgba(255,255,255,.05);
}

.password-toggle svg {
    width: 19px;
    height: 19px;
}

.submit-button {
    width: 100%;
    height: 50px;

    margin-top: 7px;

    border: 0;
    border-radius: 9px;

    color: #ffffff;

    background:
        linear-gradient(
            135deg,
            #2563eb,
            #0ea5e9
        );

    box-shadow:
        0 8px 22px
        rgba(37,99,235,.22);

    font-size: 14px;
    font-weight: 700;
    letter-spacing: .3px;

    cursor: pointer;

    transition:
        transform .15s,
        box-shadow .15s,
        filter .15s;
}

.submit-button:hover {
    transform: translateY(-1px);

    filter: brightness(1.07);

    box-shadow:
        0 11px 26px
        rgba(37,99,235,.30);
}

.submit-button:active {
    transform: translateY(0);
}

.secure-footer {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 7px;

    margin-top: 19px;

    color: #64748b;

    font-size: 11.5px;
}

.secure-footer svg {
    width: 14px;
    height: 14px;
}

@media (max-width: 600px) {

    body {
        padding: 22px 14px;
        align-items: flex-start;
    }

    .setup-shell {
        margin: auto 0;
    }

    .setup-card {
        padding: 27px 21px;
        border-radius: 16px;
    }

    .shield {
        width: 62px;
        height: 69px;
    }

    .brand-title {
        font-size: 22px;
    }

    .brand-subtitle {
        font-size: 11px;
        letter-spacing: 2px;
    }

    .setup-heading {
        font-size: 20px;
    }

    .node::after {
        width: 90px;
    }
}

@media (prefers-reduced-motion: reduce) {

    .node {
        animation: none;
    }

    .submit-button {
        transition: none;
    }
}

</style>

</head>

<body>

<div class="security-grid"></div>

<div class="network" aria-hidden="true">
    <span class="node node-1"></span>
    <span class="node node-2"></span>
    <span class="node node-3"></span>
    <span class="node node-4"></span>
</div>

<main class="setup-shell">

    <header class="brand">

        <div class="shield" aria-hidden="true">

            <svg
                viewBox="0 0 64 72"
                fill="none"
                xmlns="http://www.w3.org/2000/svg">

                <path
                    d="
                        M32 3
                        L56 12
                        V31
                        C56 48
                        46 61
                        32 68
                        C18 61
                        8 48
                        8 31
                        V12
                        L32 3Z
                    "
                    fill="rgba(37,99,235,.14)"
                    stroke="#60A5FA"
                    stroke-width="2"/>

                <rect
                    x="23"
                    y="31"
                    width="18"
                    height="15"
                    rx="3"
                    stroke="#BAE6FD"
                    stroke-width="2"/>

                <path
                    d="
                        M27 31
                        V26
                        C27 19 37 19 37 26
                        V31
                    "
                    stroke="#BAE6FD"
                    stroke-width="2"
                    stroke-linecap="round"/>

                <circle
                    cx="32"
                    cy="38"
                    r="2"
                    fill="#BAE6FD"/>

            </svg>

        </div>

        <h1 class="brand-title">
            DNS Security Portal
        </h1>

        <div class="brand-subtitle">
            Secure Administration
        </div>

    </header>

    <section class="setup-card">

        <h2 class="setup-heading">
            Initial Administrator Setup
        </h2>

        <p class="setup-description">
            Secure your new Portal installation by changing
            the default administrator password before
            continuing.
        </p>

        <div class="security-notice">

            <svg
                class="notice-icon"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#60A5FA"
                stroke-width="2"
                aria-hidden="true">

                <circle
                    cx="12"
                    cy="12"
                    r="9"/>

                <path
                    d="M12 11v5"/>

                <path
                    d="M12 8h.01"/>

            </svg>

            <span>
                This security step is required once for a
                newly installed Portal.
            </span>

        </div>

        <?php if ($error): ?>

            <div
                class="error-message"
                role="alert">

                <?= htmlspecialchars(
                    $error,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>

            </div>

        <?php endif; ?>

        <form
            method="post"
            autocomplete="off">

            <div class="field">

                <label>
                    Administrator
                </label>

                <div class="input-wrap">

                    <input
                        type="text"
                        name="username"
                        value="admin"
                        aria-label="Administrator username"
                        <?php if (!$isSimpleSetup): ?>
                        disabled
                        <?php else: ?>
                        pattern="[A-Za-z0-9_.@-]+"
                        required
                        <?php endif; ?>>

                </div>

            </div>

            <?php if (!$isSimpleSetup): ?>
            <div class="field">

                <label for="current_password">
                    Current Password
                </label>

                <div class="input-wrap">

                    <input
                        id="current_password"
                        type="password"
                        name="current_password"
                        autocomplete="current-password"
                        required>

                    <button
                        type="button"
                        class="password-toggle"
                        data-target="current_password"
                        aria-label="Show current password">

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2">

                            <path
                                d="
                                    M2 12
                                    s3.5-6 10-6
                                    10 6 10 6
                                    -3.5 6-10 6
                                    S2 12 2 12Z
                                "/>

                            <circle
                                cx="12"
                                cy="12"
                                r="2.5"/>

                        </svg>

                    </button>

                </div>

            </div>

            <?php endif; ?>
            <div class="field">

                <label for="new_password">
                    New Password
                </label>

                <div class="input-wrap">

                    <input
                        id="new_password"
                        type="password"
                        name="new_password"
                        autocomplete="new-password"
                        required>

                    <button
                        type="button"
                        class="password-toggle"
                        data-target="new_password"
                        aria-label="Show new password">

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2">

                            <path
                                d="
                                    M2 12
                                    s3.5-6 10-6
                                    10 6 10 6
                                    -3.5 6-10 6
                                    S2 12 2 12Z
                                "/>

                            <circle
                                cx="12"
                                cy="12"
                                r="2.5"/>

                        </svg>

                    </button>

                </div>

            </div>

            <div class="field">

                <label for="confirm_password">
                    Confirm New Password
                </label>

                <div class="input-wrap">

                    <input
                        id="confirm_password"
                        type="password"
                        name="confirm_password"
                        autocomplete="new-password"
                        required>

                    <button
                        type="button"
                        class="password-toggle"
                        data-target="confirm_password"
                        aria-label="Show confirmed password">

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2">

                            <path
                                d="
                                    M2 12
                                    s3.5-6 10-6
                                    10 6 10 6
                                    -3.5 6-10 6
                                    S2 12 2 12Z
                                "/>

                            <circle
                                cx="12"
                                cy="12"
                                r="2.5"/>

                        </svg>

                    </button>

                </div>

            </div>

            <button
                type="submit"
                class="submit-button">

                Complete Secure Setup

            </button>

        </form>

        <div class="secure-footer">

            <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                aria-hidden="true">

                <rect
                    x="5"
                    y="10"
                    width="14"
                    height="10"
                    rx="2"/>

                <path
                    d="
                        M8 10
                        V7
                        a4 4 0 0 1 8 0
                        v3
                    "/>

            </svg>

            Administrator security initialization

        </div>

    </section>

</main>

<script>

document
    .querySelectorAll('.password-toggle')
    .forEach(function (button) {

        button.addEventListener(
            'click',
            function () {

                const input =
                    document.getElementById(
                        button.dataset.target
                    );

                const showing =
                    input.type === 'text';

                input.type =
                    showing
                        ? 'password'
                        : 'text';

                button.setAttribute(
                    'aria-label',
                    showing
                        ? 'Show password'
                        : 'Hide password'
                );
            }
        );

    });

</script>

</body>
</html>
