<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';

if (
    !hasAnyPermission(
        [
            'Cache',
            'Flush Cache',
            'Enable/Disable Cache'
        ]
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'technitium';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

/*
 * Read the live save cache option
 * from the Technitium DNS server API
 * for the initial render.
 */

function technitiumSaveCache() {

    global $TECHNITIUM_HOST, $TECHNITIUM_TOKEN;

    $ch = curl_init(
        'http://' . $TECHNITIUM_HOST
        . ':5380/api/settings/get'
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer '
            . $TECHNITIUM_TOKEN
        ],
        CURLOPT_TIMEOUT => 10
    ]);

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    $json = json_decode($body, true);

    if (
        !is_array($json)
        || ($json['status'] ?? '') !== 'ok'
    ) {
        return null;
    }

    return (bool)(
        ($json['response'] ?? [])[
            'saveCache'
        ]
        ?? false
    );
}

$saveCacheEnabled = technitiumSaveCache();

$canFlushCache =
    hasPermission('Flush Cache');

$canToggleCache =
    hasPermission(
        'Enable/Disable Cache'
    );

?>
<!DOCTYPE html>
<html>
<head>
    <title>Technitium - Cache</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Technitium</h1>

            <p>
                Manage the Technitium DNS server.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="settings-saved" id="cache_saved" hidden>
        Settings saved.
    </div>

    <?php if ($canFlushCache): ?>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Flush Cache</h2>

                <p>
                    Clear all cached DNS entries so the server re-resolves every domain on the next request.
                </p>
            </div>

        </div>

        <div class="settings-form">

            <div class="settings-field">

                <label>
                    Flush DNS Cache
                </label>

                <button
                    type="button"
                    id="flush_cache"
                    class="approve-btn">
                    Flush Cache
                </button>

                <p class="appearance-help">
                    The cache repopulates automatically
                    as queries arrive.
                </p>

            </div>

        </div>

    </div>

    <?php endif; ?>

    <?php if ($canToggleCache): ?>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Enable/Disable Cache</h2>

                <p>
                    Control whether the DNS cache is saved to disk and reloaded when the DNS server restarts.
                </p>
            </div>

        </div>

        <div class="settings-form">

            <div class="settings-field">

                <label for="toggle_save_cache">
                    Save Cache
                </label>

                <button
                    type="button"
                    id="toggle_save_cache"
                    data-enabled="<?= $saveCacheEnabled
                        ? 'true'
                        : 'false' ?>"
                    class="<?= $saveCacheEnabled
                        ? 'badge-active'
                        : 'badge-disabled' ?>">
                    <?= $saveCacheEnabled
                        ? 'Enabled'
                        : 'Disabled' ?>
                </button>

                <p class="appearance-help">
                    Technitium always caches DNS
                    responses. This option saves the
                    cache to disk when the DNS server
                    stops and loads it back on the
                    next start.
                </p>

            </div>

        </div>

    </div>

    <?php endif; ?>

</div>

<script>
const cacheApi =
    'technitium-cache-api.php';

const saveCacheToggle =
    document.getElementById('toggle_save_cache');
const flushCacheButton =
    document.getElementById('flush_cache');
const cacheSavedBox =
    document.getElementById('cache_saved');

let cacheFlashTimer = null;

function showCacheMessage(message) {

    cacheSavedBox.hidden = false;
    cacheSavedBox.textContent = message;

    if (cacheFlashTimer) {
        clearTimeout(cacheFlashTimer);
    }

    cacheFlashTimer = setTimeout(() => {
        cacheSavedBox.hidden = true;
    }, 4000);
}

function setSaveCacheToggle(enabled) {

    if (!saveCacheToggle) {
        return;
    }

    saveCacheToggle.dataset.enabled =
        enabled ? 'true' : 'false';

    saveCacheToggle.classList.toggle(
        'badge-active',
        enabled
    );

    saveCacheToggle.classList.toggle(
        'badge-disabled',
        !enabled
    );

    saveCacheToggle.textContent =
        enabled ? 'Enabled' : 'Disabled';
}

if (saveCacheToggle) {

    // the toggle applies instantly -
    // no separate save button needed
    saveCacheToggle.addEventListener(
        'click',
        async () => {

            const newState =
                saveCacheToggle.dataset.enabled
                    !== 'true';

            setSaveCacheToggle(newState);

            try {

                const response = await fetch(
                    cacheApi,
                    {
                        method: 'POST',
                        body: new URLSearchParams({
                            action: 'set',
                            save_cache:
                                newState
                                    ? '1'
                                    : '0'
                        })
                    }
                );

                const json =
                    await response.json();

                if (json.success !== true) {
                    setSaveCacheToggle(!newState);
                    showCacheMessage(
                        json.message
                            || 'Update failed.'
                    );
                    return;
                }

                setSaveCacheToggle(
                    !!json.save_cache
                );

                showCacheMessage(
                    'Cache settings saved.'
                );

            } catch (error) {
                setSaveCacheToggle(!newState);
                showCacheMessage(
                    'Update failed.'
                );
            }
        }
    );
}

if (flushCacheButton) {

    flushCacheButton.addEventListener(
        'click',
        async () => {

            flushCacheButton.disabled = true;

            try {

                const response = await fetch(
                    cacheApi,
                    {
                        method: 'POST',
                        body: new URLSearchParams({
                            action: 'flush'
                        })
                    }
                );

                const json =
                    await response.json();

                showCacheMessage(
                    json.success
                        ? (json.message
                            || 'Cache flushed.')
                        : (json.message
                            || 'Flush failed.')
                );

            } catch (error) {
                showCacheMessage(
                    'Flush failed.'
                );
            } finally {
                flushCacheButton.disabled = false;
            }
        }
    );
}
</script>

</body>

</html>
