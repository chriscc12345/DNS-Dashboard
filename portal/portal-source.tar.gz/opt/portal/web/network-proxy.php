<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';

if (
    !hasPermission(
        'Network Proxy'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'network-proxy';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

/*
 * Read the live proxy and forwarder
 * settings from the Technitium DNS
 * server API for the initial render.
 */

function technitiumProxySettings() {

    global $TECHNITIUM_HOST, $TECHNITIUM_TOKEN;

    $ch = curl_init(
        'http://' . $TECHNITIUM_HOST
        . ':5380/api/settings/get'
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer '
            . $TECHNITIUM_TOKEN
        ],
        CURLOPT_TIMEOUT => 10
    ]);

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    $json = json_decode($body, true);

    if (
        !is_array($json)
        || ($json['status'] ?? '') !== 'ok'
    ) {
        return null;
    }

    return $json['response'] ?? [];
}

$proxySettings =
    technitiumProxySettings();

$proxy =
    $proxySettings['proxy'] ?? null;

$proxyType =
    is_array($proxy)
        ? (string)(
            $proxy['type'] ?? 'None'
        )
        : 'None';

$proxyAddress =
    is_array($proxy)
        ? (string)(
            $proxy['address'] ?? ''
        )
        : '';

$proxyPort =
    is_array($proxy)
        ? (string)(
            $proxy['port'] ?? ''
        )
        : '';

$proxyUsername =
    is_array($proxy)
        ? (string)(
            $proxy['username'] ?? ''
        )
        : '';

$proxyPassword =
    is_array($proxy)
        ? (string)(
            $proxy['password'] ?? ''
        )
        : '';

$proxyBypass =
    is_array($proxy)
        && is_array(
            $proxy['bypass'] ?? null
        )
        ? $proxy['bypass']
        : [];

$proxyBypassText =
    implode("\n", $proxyBypass);

$forwarders =
    is_array(
        $proxySettings['forwarders']
        ?? null
    )
        ? $proxySettings['forwarders']
        : [];

$forwardersText =
    implode("\n", $forwarders);

$forwarderProtocol =
    (string)(
        $proxySettings[
            'forwarderProtocol'
        ]
        ?? 'Udp'
    );

$concurrentForwarding =
    (bool)(
        $proxySettings[
            'concurrentForwarding'
        ]
        ?? false
    );

$forwarderRetries =
    (int)(
        $proxySettings[
            'forwarderRetries'
        ]
        ?? 2
    );

$forwarderTimeout =
    (int)(
        $proxySettings[
            'forwarderTimeout'
        ]
        ?? 2000
    );

$forwarderConcurrency =
    (int)(
        $proxySettings[
            'forwarderConcurrency'
        ]
        ?? 2
    );

?>
<!DOCTYPE html>
<html>
<head>
    <title>Technitium - Network Proxy</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Technitium</h1>

            <p>
                Manage the Technitium DNS server.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="settings-saved" id="proxy_saved" hidden>
        Settings saved.
    </div>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Proxy</h2>

                <p>
                    Route outgoing DNS resolution traffic through a proxy server.
                </p>
            </div>

        </div>

        <div class="settings-form">

            <div class="settings-field">

                <label for="proxy_type">
                    Proxy Type
                </label>

                <select
                    id="proxy_type"
                    class="table-control">

                    <option
                        value="None"
                        <?= $proxyType === 'None'
                            ? 'selected'
                            : '' ?>>
                        None
                    </option>

                    <option
                        value="Http"
                        <?= $proxyType === 'Http'
                            ? 'selected'
                            : '' ?>>
                        HTTP
                    </option>

                    <option
                        value="Socks5"
                        <?= $proxyType === 'Socks5'
                            ? 'selected'
                            : '' ?>>
                        SOCKS5
                    </option>

                </select>

            </div>

            <div class="settings-field-row">

                <div class="settings-field">

                    <label for="proxy_address">
                        Proxy Address
                    </label>

                    <input
                        type="text"
                        id="proxy_address"
                        value="<?= htmlspecialchars(
                            $proxyAddress
                        ) ?>"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label for="proxy_port">
                        Proxy Port
                    </label>

                    <input
                        type="number"
                        id="proxy_port"
                        min="1"
                        max="65535"
                        value="<?= htmlspecialchars(
                            (string)$proxyPort
                        ) ?>"
                        class="table-control">

                </div>

            </div>

            <div class="settings-field-row">

                <div class="settings-field">

                    <label for="proxy_username">
                        Proxy Username
                    </label>

                    <input
                        type="text"
                        id="proxy_username"
                        autocomplete="off"
                        value="<?= htmlspecialchars(
                            $proxyUsername
                        ) ?>"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label for="proxy_password">
                        Proxy Password
                    </label>

                    <input
                        type="password"
                        id="proxy_password"
                        autocomplete="new-password"
                        value="<?= htmlspecialchars(
                            $proxyPassword
                        ) ?>"
                        class="table-control">

                </div>

            </div>

            <div class="settings-field">

                <label for="proxy_bypass">
                    Proxy Bypass
                </label>

                <textarea
                    id="proxy_bypass"
                    class="table-control"
                    rows="4"
                    spellcheck="false"><?= htmlspecialchars(
                        $proxyBypassText
                    ) ?></textarea>

                <p class="appearance-help">
                    One IP address, network address
                    or domain per line that must never
                    use the proxy.
                </p>

            </div>

            <button
                type="button"
                id="save_proxy"
                class="approve-btn">
                Save
            </button>

        </div>

    </div>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Forwarders</h2>

                <p>
                    Upstream DNS servers used instead of the DNS server doing recursive resolution itself.
                </p>
            </div>

        </div>

        <div class="settings-form">

            <div class="settings-field">

                <label for="forwarders">
                    Forwarders
                </label>

                <textarea
                    id="forwarders"
                    class="table-control"
                    rows="4"
                    spellcheck="false"><?= htmlspecialchars(
                        $forwardersText
                    ) ?></textarea>

                <p class="appearance-help">
                    One forwarder IP or DoH URL per
                    line. Leave empty to remove all
                    forwarders so the DNS server
                    resolves recursively by itself.
                </p>

            </div>

            <div class="settings-field">

                <label for="forwarder_protocol">
                    Forwarder Protocol
                </label>

                <select
                    id="forwarder_protocol"
                    class="table-control">

                    <?php foreach (
                        ['Udp', 'Tcp', 'Tls', 'Https', 'Quic']
                        as $protocolOption
                    ): ?>

                    <option
                        value="<?= $protocolOption ?>"
                        <?= $forwarderProtocol === $protocolOption
                            ? 'selected'
                            : '' ?>>
                        <?= $protocolOption ?>
                    </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <div class="settings-field">

                <label for="toggle_concurrent_forwarding">
                    Concurrent Forwarding
                </label>

                <button
                    type="button"
                    id="toggle_concurrent_forwarding"
                    data-enabled="<?= $concurrentForwarding
                        ? 'true'
                        : 'false' ?>"
                    class="<?= $concurrentForwarding
                        ? 'badge-active'
                        : 'badge-disabled' ?>">
                    <?= $concurrentForwarding
                        ? 'Enabled'
                        : 'Disabled' ?>
                </button>

                <p class="appearance-help">
                    Query two or more forwarders at
                    the same time and use the
                    fastest response.
                </p>

            </div>

            <div class="settings-field-row">

                <div class="settings-field">

                    <label for="forwarder_retries">
                        Retries
                    </label>

                    <input
                        type="number"
                        id="forwarder_retries"
                        min="0"
                        max="15"
                        value="<?= (int)$forwarderRetries ?>"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label for="forwarder_timeout">
                        Timeout (ms)
                    </label>

                    <input
                        type="number"
                        id="forwarder_timeout"
                        min="100"
                        max="60000"
                        value="<?= (int)$forwarderTimeout ?>"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label for="forwarder_concurrency">
                        Concurrency
                    </label>

                    <input
                        type="number"
                        id="forwarder_concurrency"
                        min="1"
                        max="100"
                        value="<?= (int)$forwarderConcurrency ?>"
                        class="table-control">

                </div>

            </div>

            <button
                type="button"
                id="save_forwarders"
                class="approve-btn">
                Save
            </button>

        </div>

    </div>

</div>

<script>
const proxyApi =
    'technitium-proxy-api.php';

const proxyTypeSelect =
    document.getElementById('proxy_type');
const proxyAddressInput =
    document.getElementById('proxy_address');
const proxyPortInput =
    document.getElementById('proxy_port');
const proxyUsernameInput =
    document.getElementById('proxy_username');
const proxyPasswordInput =
    document.getElementById('proxy_password');
const proxyBypassBox =
    document.getElementById('proxy_bypass');
const forwardersBox =
    document.getElementById('forwarders');
const forwarderProtocolSelect =
    document.getElementById('forwarder_protocol');
const concurrentToggle =
    document.getElementById(
        'toggle_concurrent_forwarding'
    );
const forwarderRetriesInput =
    document.getElementById('forwarder_retries');
const forwarderTimeoutInput =
    document.getElementById('forwarder_timeout');
const forwarderConcurrencyInput =
    document.getElementById(
        'forwarder_concurrency'
    );
const proxySavedBox =
    document.getElementById('proxy_saved');

let proxyFlashTimer = null;

function showProxyMessage(message) {

    proxySavedBox.hidden = false;
    proxySavedBox.textContent = message;

    if (proxyFlashTimer) {
        clearTimeout(proxyFlashTimer);
    }

    proxyFlashTimer = setTimeout(() => {
        proxySavedBox.hidden = true;
    }, 4000);
}

function setConcurrentToggle(enabled) {

    concurrentToggle.dataset.enabled =
        enabled ? 'true' : 'false';

    concurrentToggle.classList.toggle(
        'badge-active',
        enabled
    );

    concurrentToggle.classList.toggle(
        'badge-disabled',
        !enabled
    );

    concurrentToggle.textContent =
        enabled ? 'Enabled' : 'Disabled';
}

function applyProxyView(view) {

    if (!view || view.success !== true) {
        return;
    }

    proxyTypeSelect.value =
        view.proxy_type || 'None';

    proxyAddressInput.value =
        view.proxy_address || '';

    proxyPortInput.value =
        view.proxy_port || '';

    proxyUsernameInput.value =
        view.proxy_username || '';

    proxyPasswordInput.value =
        view.proxy_password || '';

    proxyBypassBox.value =
        (view.proxy_bypass || []).join('\n');

    forwardersBox.value =
        (view.forwarders || []).join('\n');

    forwarderProtocolSelect.value =
        view.forwarder_protocol || 'Udp';

    setConcurrentToggle(
        !!view.concurrent_forwarding
    );

    forwarderRetriesInput.value =
        view.forwarder_retries ?? 2;

    forwarderTimeoutInput.value =
        view.forwarder_timeout ?? 2000;

    forwarderConcurrencyInput.value =
        view.forwarder_concurrency ?? 2;
}

async function refreshProxy() {

    try {

        const response = await fetch(
            proxyApi + '?action=get'
        );

        applyProxyView(
            await response.json()
        );

    } catch (error) {
        /* keep the server rendered values */
    }
}

async function postProxySet(params) {

    const response = await fetch(
        proxyApi,
        {
            method: 'POST',
            body: new URLSearchParams(
                Object.assign(
                    { action: 'set' },
                    params
                )
            )
        }
    );

    const json = await response.json();

    if (json.success !== true) {
        showProxyMessage(
            json.message || 'Update failed.'
        );
        return false;
    }

    applyProxyView(json);
    return true;
}

concurrentToggle.addEventListener(
    'click',
    () => {
        setConcurrentToggle(
            concurrentToggle.dataset.enabled
                !== 'true'
        );
    }
);

document
    .getElementById('save_proxy')
    .addEventListener('click', async () => {

        const ok = await postProxySet({
            proxy_type: proxyTypeSelect.value,
            proxy_address:
                proxyAddressInput.value,
            proxy_port: proxyPortInput.value,
            proxy_username:
                proxyUsernameInput.value,
            proxy_password:
                proxyPasswordInput.value,
            proxy_bypass: proxyBypassBox.value
        });

        if (ok) {
            showProxyMessage(
                'Proxy settings saved.'
            );
        }
    }
);

document
    .getElementById('save_forwarders')
    .addEventListener('click', async () => {

        const ok = await postProxySet({
            forwarders_submitted: '1',
            forwarders: forwardersBox.value,
            forwarder_protocol:
                forwarderProtocolSelect.value,
            concurrent_forwarding:
                concurrentToggle.dataset.enabled
                    === 'true'
                    ? '1'
                    : '0',
            forwarder_retries:
                forwarderRetriesInput.value,
            forwarder_timeout:
                forwarderTimeoutInput.value,
            forwarder_concurrency:
                forwarderConcurrencyInput.value
        });

        if (ok) {
            showProxyMessage(
                'Forwarder settings saved.'
            );
        }
    }
);

refreshProxy();
</script>

</body>

</html>
