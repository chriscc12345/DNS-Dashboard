<?php
/*
 * UPDATE - Portal two-factor authentication proxy.
 *
 * Browser-facing endpoint for the My Profile 2FA section.
 * The authenticated PHP session owns identity: a user can
 * only manage their OWN two-factor enrolment through this
 * endpoint. Admin recovery goes through users.php -> /2fa/reset.
 */

require_once 'config.php';
require_once 'auth.php';

header('Content-Type: application/json');

function twofaRespond($success, $payload = [], $status = 200)
{
    http_response_code($status);
    echo json_encode(
        array_merge(
            ['success' => $success],
            $payload
        )
    );
    exit;
}

if (
    empty($_SESSION['username'])
    || strtolower(trim((string)$_SESSION['username'])) === 'guest'
) {
    twofaRespond(false, ['message' => 'Not signed in.'], 403);
}

$username = (string)$_SESSION['username'];

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

if ($method !== 'POST') {
    twofaRespond(false, ['message' => 'Method not allowed.'], 405);
}

$action = trim((string)($_GET['action'] ?? ''));

$input = [];
$raw = file_get_contents('php://input');

if (is_string($raw) && $raw !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $input = $decoded;
    }
}

$code = trim((string)($input['code'] ?? ''));

function twofaCall($path, $payload)
{
    global $FASTAPI_URL;

    $context = stream_context_create([
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/json\r\n",
            'content' => json_encode($payload),
            'ignore_errors' => true
        ]
    ]);

    $raw = @file_get_contents(
        $FASTAPI_URL . $path,
        false,
        $context
    );

    if ($raw === false) {
        return null;
    }

    $decoded = json_decode($raw, true);

    return is_array($decoded) ? $decoded : null;
}

switch ($action) {

    case 'status':
        {
            $context = stream_context_create([
                'http' => ['ignore_errors' => true]
            ]);

            $raw = @file_get_contents(
                $FASTAPI_URL . '/2fa/status/' .
                    rawurlencode($username),
                false,
                $context
            );

            $result = is_string($raw)
                ? json_decode($raw, true)
                : null;

            if (
                is_array($result)
                && ($result['status'] ?? '') === 'ok'
            ) {
                twofaRespond(true, [
                    'enabled' => ($result['enabled'] ?? false) === true,
                    'pending' => ($result['pending'] ?? false) === true
                ]);
            }

            twofaRespond(false, [
                'message' => 'Unable to load 2FA status.'
            ]);
        }
        break;

    case 'setup':
        {
            $result = twofaCall('/2fa/setup', [
                'username' => $username
            ]);

            if (
                is_array($result)
                && ($result['status'] ?? '') === 'ok'
            ) {
                twofaRespond(true, [
                    'secret' => $result['secret'] ?? '',
                    'otpauth_url' => $result['otpauth_url'] ?? '',
                    'qr_png' => $result['qr_png'] ?? ''
                ]);
            }

            twofaRespond(false, [
                'message' => $result['message']
                    ?? 'Unable to start 2FA setup.'
            ]);
        }
        break;

    case 'enable':
        {
            if ($code === '') {
                twofaRespond(false, [
                    'message' => 'Verification code is required.'
                ]);
            }

            $result = twofaCall('/2fa/enable', [
                'username' => $username,
                'code' => $code
            ]);

            if (
                is_array($result)
                && ($result['status'] ?? '') === 'ok'
            ) {
                twofaRespond(true);
            }

            twofaRespond(false, [
                'message' => $result['message']
                    ?? 'Invalid verification code.'
            ]);
        }
        break;

    case 'disable':
        {
            if ($code === '') {
                twofaRespond(false, [
                    'message' => 'Verification code is required.'
                ]);
            }

            $result = twofaCall('/2fa/disable', [
                'username' => $username,
                'code' => $code
            ]);

            if (
                is_array($result)
                && ($result['status'] ?? '') === 'ok'
            ) {
                twofaRespond(true);
            }

            twofaRespond(false, [
                'message' => $result['message']
                    ?? 'Invalid verification code.'
            ]);
        }
        break;

    default:
        twofaRespond(false, ['message' => 'Unsupported action.'], 400);
}
