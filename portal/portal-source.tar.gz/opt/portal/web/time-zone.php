<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (
    !hasPermission(
        'Time Zone'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'time-zone';
$pageHeading = 'General';
$showSidebarPageHeading = true;

$portalSettings =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];

$portalTimezone =
    trim(
        (string)(
            $portalSettings['portal_timezone']
            ?? ''
        )
    );

$weatherLatitude =
    (float)(
        $portalSettings['weather_latitude']
        ?? -26.20
    );

$weatherLongitude =
    (float)(
        $portalSettings['weather_longitude']
        ?? 28.05
    );

function savePortalSettings($settings) {

    global $FASTAPI_URL;

    $payload =
        json_encode(
            ['settings' => $settings]
        );

    return file_get_contents(
        $FASTAPI_URL . '/portal-settings/appearance',
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $payload
            ]
        ])
    );
}

if (isset($_POST['save_timezone'])) {

    savePortalSettings([
        'portal_timezone' =>
            trim((string)$_POST['portal_timezone'])
    ]);

    header('Location: time-zone.php?saved=timezone');
    exit;
}

if (isset($_POST['save_weather'])) {

    savePortalSettings([
        'weather_latitude' =>
            (string)(float)$_POST['weather_latitude'],
        'weather_longitude' =>
            (string)(float)$_POST['weather_longitude']
    ]);

    header('Location: time-zone.php?saved=weather');
    exit;
}

$timezoneChoices = [
    ''                    => 'Browser Default',
    'Africa/Johannesburg' => 'Africa/Johannesburg (SAST)',
    'Africa/Cairo'        => 'Africa/Cairo',
    'Africa/Lagos'        => 'Africa/Lagos',
    'Africa/Nairobi'      => 'Africa/Nairobi',
    'Europe/London'       => 'Europe/London',
    'Europe/Berlin'       => 'Europe/Berlin',
    'Europe/Paris'        => 'Europe/Paris',
    'America/New_York'    => 'America/New_York',
    'America/Chicago'     => 'America/Chicago',
    'America/Los_Angeles' => 'America/Los_Angeles',
    'Asia/Dubai'          => 'Asia/Dubai',
    'Asia/Singapore'      => 'Asia/Singapore',
    'Asia/Tokyo'          => 'Asia/Tokyo',
    'Australia/Sydney'    => 'Australia/Sydney',
    'UTC'                 => 'UTC'
];

if (
    $portalTimezone !== ''
    &&
    !isset($timezoneChoices[$portalTimezone])
) {
    $timezoneChoices[$portalTimezone] = $portalTimezone;
}

$savedMessage = '';

if (($_GET['saved'] ?? '') === 'timezone') {
    $savedMessage = 'Time zone saved.';
}

if (($_GET['saved'] ?? '') === 'weather') {
    $savedMessage = 'Weather location saved.';
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Time Zone</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Time Zone</h1>

            <p>
                Configure the portal clock time zone and the live weather location.
            </p>
        </div>

    </div>

    <?php if($savedMessage !== ''): ?>

    <div class="settings-saved">
        <?= htmlspecialchars($savedMessage) ?>
    </div>

    <?php endif; ?>

        <?php include __DIR__ . '/includes/page-tabs.php'; ?>

<div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Portal Time Zone</h2>

                <p>
                    Drives the date and time shown in the banner clock.
                </p>
            </div>

        </div>

        <form method="post" class="settings-form">

            <div class="settings-field">

                <label for="portal_timezone">
                    Time Zone
                </label>

                <select
                    id="portal_timezone"
                    name="portal_timezone"
                    class="table-control">

                    <?php foreach($timezoneChoices as $value => $label): ?>

                    <option
                        value="<?= htmlspecialchars($value) ?>"
                        <?= $portalTimezone === $value ? 'selected' : '' ?>>
                        <?= htmlspecialchars($label) ?>
                    </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <p class="appearance-help">
                Browser Default follows each user's own device
                time zone. Selecting a specific zone shows the
                same time for everyone.
            </p>

            <button
                type="submit"
                name="save_timezone"
                value="1"
                class="approve-btn">
                Save
            </button>

        </form>

    </div>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Weather Location</h2>

                <p>
                    Coordinates used by the live weather badge inside the banner clock.
                </p>
            </div>

        </div>

        <form method="post" class="settings-form">

            <div class="settings-field-row">

                <div class="settings-field">

                    <label for="weather_latitude">
                        Latitude
                    </label>

                    <input
                        type="number"
                        step="any"
                        id="weather_latitude"
                        name="weather_latitude"
                        value="<?= htmlspecialchars((string)$weatherLatitude) ?>"
                        class="table-control"
                        required>

                </div>

                <div class="settings-field">

                    <label for="weather_longitude">
                        Longitude
                    </label>

                    <input
                        type="number"
                        step="any"
                        id="weather_longitude"
                        name="weather_longitude"
                        value="<?= htmlspecialchars((string)$weatherLongitude) ?>"
                        class="table-control"
                        required>

                </div>

            </div>

            <p class="appearance-help">
                The weather badge shows current conditions from
                Open-Meteo for these coordinates. Defaults to
                Johannesburg (-26.20, 28.05). Use decimals, for
                example -26.10 and 28.05.
            </p>

            <button
                type="submit"
                name="save_weather"
                value="1"
                class="approve-btn">
                Save
            </button>

        </form>

    </div>

</div>
</body>
</html>
