<?php

session_start();

if (!isset($_SESSION['username'])) {

    header("Location: login.php");
    exit;

}

function getUserPermissions(){

    return $_SESSION['permissions'] ?? [];

}

function hasPermission(
    $permission
){

    $permissions =
        getUserPermissions();

    return in_array(
        $permission,
        $permissions
    );

}

function hasAnyPermission(
    array $permissions
){

    foreach($permissions as $permission){

        if(hasPermission($permission)){
            return true;
        }

    }

    return false;

}

