<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (!hasPermission('Logo')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'appearance-logo';
$pageHeading = 'Customization';
$showSidebarPageHeading = true;

$portalSettings =
    json_decode(
        file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];

$companyLogo =
    trim(
        (string)(
            $portalSettings['company_logo']
            ?? ''
        )
    );


$portalFavicon =
    trim(
        (string)(
            $portalSettings['portal_favicon']
            ?? ''
        )
    );

$faviconPreview =
    $portalFavicon !== ''
        ? $portalFavicon
        : 'images/favicon.png';

$showLogoBanner =
    strtolower(
        (string)(
            $portalSettings['show_logo_banner']
            ?? 'true'
        )
    ) === 'true';

$showLogoSidebar =
    strtolower(
        (string)(
            $portalSettings['show_logo_sidebar']
            ?? 'true'
        )
    ) === 'true';

$bannerLogoSize =
    (int)(
        $portalSettings['banner_logo_size']
        ?? 140
    );

if (
    $bannerLogoSize < 100
    ||
    $bannerLogoSize > 350
) {
    $bannerLogoSize = 140;
}

$sidebarLogoSize =
    (int)(
        $portalSettings['sidebar_logo_size']
        ?? 100
    );

if (
    $sidebarLogoSize < 40
    ||
    $sidebarLogoSize > 180
) {
    $sidebarLogoSize = 100;
}

?>
<!DOCTYPE html>
<html>
<head>

    <title>Appearance - Logo</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined"
        rel="stylesheet">

</head>

<body>

<?php include 'includes/banner.php'; ?>
<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Appearance</h1>

            <p>
                Configure the company logo used by the Basic theme.
            </p>
        </div>


    </div>


        <?php include __DIR__ . '/includes/page-tabs.php'; ?>


    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Company Logo</h2>

                <p>
                    Upload the logo displayed in the portal.
                </p>
            </div>

        </div>


        <div class="appearance-logo-layout">

            <div class="appearance-logo-preview">

                <div class="appearance-logo-preview-box">

                    <?php if($companyLogo !== ''): ?>

                        <img
                            src="<?= htmlspecialchars($companyLogo) ?>"
                            alt="Company logo">

                    <?php else: ?>

                        <span class="material-symbols-outlined">
                            business
                        </span>

                        <strong>
                            Company Logo
                        </strong>

                    <?php endif; ?>

                </div>

                <div class="appearance-logo-actions">

                    <button
                        type="button"
                        class="table-btn"
                        id="appearanceChooseLogo">
                        Upload Logo
                    </button>

                    <?php if($companyLogo !== ''): ?>

                    <button
                        type="button"
                        class="table-btn appearance-secondary-btn"
                        id="appearanceRemoveLogo">
                        Remove
                    </button>

                    <?php endif; ?>

                </div>

                <input
                    type="file"
                    id="appearanceLogoFile"
                    accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                    hidden>

                <p class="appearance-help">
                    JPG, PNG or WebP. Maximum file size 5 MB.
                </p>

            </div>


            <div class="appearance-logo-options">

                <div class="appearance-logo-setting-group">

                    <label class="appearance-option">

                        <span>
                            <strong>Show Logo in Banner</strong>

                            <small>
                                Display the company logo in the centre
                                of the Basic banner.
                            </small>
                        </span>

                        <input
                            type="checkbox"
                            id="showLogoBanner"
                            <?= $showLogoBanner ? 'checked' : '' ?>>

                    </label>

                    <div class="appearance-logo-size-control">

                        <div class="appearance-logo-size-heading">

                            <span>Banner Logo Size</span>

                            <strong id="bannerLogoSizeValue">
                                <?= $bannerLogoSize ?> px
                            </strong>

                        </div>

                        <input
                            type="range"
                            id="bannerLogoSize"
                            min="100"
                            max="350"
                            step="1"
                            value="<?= $bannerLogoSize ?>">

                    </div>

                </div>


                <div class="appearance-logo-setting-group">

                    <label class="appearance-option">

                        <span>
                            <strong>Show Logo in Sidebar</strong>

                            <small>
                                Display the company logo at the top of
                                the expanded sidebar. The logo is always
                                hidden when the sidebar is collapsed.
                            </small>
                        </span>

                        <input
                            type="checkbox"
                            id="showLogoSidebar"
                            <?= $showLogoSidebar ? 'checked' : '' ?>>

                    </label>

                    <div class="appearance-logo-size-control">

                        <div class="appearance-logo-size-heading">

                            <span>Sidebar Logo Size</span>

                            <strong id="sidebarLogoSizeValue">
                                <?= $sidebarLogoSize ?> px
                            </strong>

                        </div>

                        <input
                            type="range"
                            id="sidebarLogoSize"
                            min="40"
                            max="180"
                            step="1"
                            value="<?= $sidebarLogoSize ?>">

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="appearance-panel appearance-favicon-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Favicon</h2>

                <p>
                    Configure the browser icon used by the portal.
                </p>
            </div>

        </div>


        <div class="appearance-logo-layout">

            <div class="appearance-logo-preview">

                <div class="appearance-favicon-preview-box">

                    <img
                        src="<?= htmlspecialchars($faviconPreview) ?>?v=<?= time() ?>"
                        alt="Portal favicon"
                        id="appearanceFaviconPreview">

                </div>


                <div class="appearance-logo-actions">

                    <button
                        type="button"
                        class="table-btn"
                        id="appearanceChooseFavicon">
                        Upload Favicon
                    </button>


                    <?php if($portalFavicon !== ''): ?>

                    <button
                        type="button"
                        class="table-btn appearance-secondary-btn"
                        id="appearanceRestoreFavicon">
                        Restore Default
                    </button>

                    <?php endif; ?>

                </div>


                <input
                    type="file"
                    id="appearanceFaviconFile"
                    accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                    hidden>


                <p class="appearance-help">
                    JPG, PNG or WebP. Maximum file size 5 MB.
                    The uploaded image is fitted into a square
                    256 × 256 favicon.
                </p>

            </div>


            <div class="appearance-logo-options">

                <div class="appearance-option appearance-favicon-info">

                    <span>
                        <strong>
                            <?= $portalFavicon !== ''
                                ? 'Custom Favicon'
                                : 'Default Favicon' ?>
                        </strong>

                        <small>
                            <?= $portalFavicon !== ''
                                ? 'A custom portal favicon is currently active.'
                                : 'The factory portal favicon is currently active.' ?>
                        </small>
                    </span>

                    <span class="material-symbols-outlined">
                        <?= $portalFavicon !== ''
                            ? 'verified'
                            : 'restart_alt' ?>
                    </span>

                </div>

            </div>

        </div>

    </div>

</div>


<div
    id="appearanceLogoMessage"
    class="appearance-logo-message"
    hidden>
</div>


<script>
(function () {

    const chooseButton =
        document.getElementById(
            'appearanceChooseLogo'
        );

    const removeButton =
        document.getElementById(
            'appearanceRemoveLogo'
        );

    const fileInput =
        document.getElementById(
            'appearanceLogoFile'
        );

    const chooseFaviconButton =
        document.getElementById(
            'appearanceChooseFavicon'
        );

    const restoreFaviconButton =
        document.getElementById(
            'appearanceRestoreFavicon'
        );

    const faviconFileInput =
        document.getElementById(
            'appearanceFaviconFile'
        );

    const message =
        document.getElementById(
            'appearanceLogoMessage'
        );

    const showLogoBanner =
        document.getElementById(
            'showLogoBanner'
        );

    const showLogoSidebar =
        document.getElementById(
            'showLogoSidebar'
        );

    const bannerLogoSize =
        document.getElementById(
            'bannerLogoSize'
        );

    const sidebarLogoSize =
        document.getElementById(
            'sidebarLogoSize'
        );

    const bannerLogoSizeValue =
        document.getElementById(
            'bannerLogoSizeValue'
        );

    const sidebarLogoSizeValue =
        document.getElementById(
            'sidebarLogoSizeValue'
        );


    function showMessage(
        text,
        success
    ) {

        if (!message) {
            return;
        }

        message.textContent = text;

        message.classList.toggle(
            'success',
            success
        );

        message.classList.toggle(
            'error',
            !success
        );

        message.hidden = false;

    }


    function setBusy(
        busy
    ) {

        if (chooseButton) {
            chooseButton.disabled = busy;
        }

        if (removeButton) {
            removeButton.disabled = busy;
        }

        if (chooseFaviconButton) {
            chooseFaviconButton.disabled = busy;
        }

        if (restoreFaviconButton) {
            restoreFaviconButton.disabled = busy;
        }

    }


    async function saveLogoSettings(
        settings
    ) {

        const response =
            await fetch(
                'appearance-api.php',
                {
                    method: 'POST',
                    headers: {
                        'Content-Type':
                            'application/json'
                    },
                    body: JSON.stringify({
                        action: 'save',
                        settings: settings
                    })
                }
            );

        const data =
            await response.json();

        if (
            !response.ok
            || !data.success
        ) {

            throw new Error(
                data.message
                || 'Unable to save Logo settings.'
            );

        }

        return data;

    }


    async function saveSingleLogoSetting(
        key,
        value
    ) {

        try {

            await saveLogoSettings({
                [key]: value
            });

            showMessage(
                'Logo settings saved.',
                true
            );

        } catch (error) {

            showMessage(
                error.message
                || 'Unable to save Logo settings.',
                false
            );

        }

    }


    if (bannerLogoSize) {

        bannerLogoSize.addEventListener(
            'input',
            function () {

                if (bannerLogoSizeValue) {
                    bannerLogoSizeValue.textContent =
                        bannerLogoSize.value + ' px';
                }

            }
        );

        bannerLogoSize.addEventListener(
            'change',
            function () {

                saveSingleLogoSetting(
                    'banner_logo_size',
                    bannerLogoSize.value
                );

            }
        );

    }


    if (sidebarLogoSize) {

        sidebarLogoSize.addEventListener(
            'input',
            function () {

                if (sidebarLogoSizeValue) {
                    sidebarLogoSizeValue.textContent =
                        sidebarLogoSize.value + ' px';
                }

            }
        );

        sidebarLogoSize.addEventListener(
            'change',
            function () {

                saveSingleLogoSetting(
                    'sidebar_logo_size',
                    sidebarLogoSize.value
                );

            }
        );

    }


    if (showLogoBanner) {

        showLogoBanner.addEventListener(
            'change',
            function () {

                saveSingleLogoSetting(
                    'show_logo_banner',
                    showLogoBanner.checked
                        ? 'true'
                        : 'false'
                );

            }
        );

    }


    if (showLogoSidebar) {

        showLogoSidebar.addEventListener(
            'change',
            function () {

                saveSingleLogoSetting(
                    'show_logo_sidebar',
                    showLogoSidebar.checked
                        ? 'true'
                        : 'false'
                );

            }
        );

    }


    if (
        chooseButton
        && fileInput
    ) {

        chooseButton.addEventListener(
            'click',
            function () {

                fileInput.value = '';
                fileInput.click();

            }
        );


        fileInput.addEventListener(
            'change',
            async function () {

                const file =
                    fileInput.files[0];

                if (!file) {
                    return;
                }


                const allowedTypes = [
                    'image/jpeg',
                    'image/png',
                    'image/webp'
                ];


                if (
                    !allowedTypes.includes(
                        file.type
                    )
                ) {

                    showMessage(
                        'Please select a JPG, PNG or WebP image.',
                        false
                    );

                    return;
                }


                if (
                    file.size >
                    (5 * 1024 * 1024)
                ) {

                    showMessage(
                        'Logo must be 5 MB or smaller.',
                        false
                    );

                    return;
                }


                const formData =
                    new FormData();

                formData.append(
                    'action',
                    'upload'
                );

                formData.append(
                    'logo',
                    file
                );


                setBusy(true);


                try {

                    const response =
                        await fetch(
                            'appearance-logo-upload.php',
                            {
                                method: 'POST',
                                body: formData
                            }
                        );

                    const data =
                        await response.json();


                    if (
                        !response.ok
                        || !data.success
                    ) {

                        throw new Error(
                            data.message
                            || 'Logo upload failed.'
                        );

                    }


                    showMessage(
                        data.message
                        || 'Company logo uploaded.',
                        true
                    );


                    window.setTimeout(
                        function () {
                            window.location.reload();
                        },
                        450
                    );

                } catch (error) {

                    showMessage(
                        error.message
                        || 'Logo upload failed.',
                        false
                    );

                    setBusy(false);

                }

            }
        );

    }


    if (removeButton) {

        removeButton.addEventListener(
            'click',
            async function () {

                if (
                    !window.confirm(
                        'Remove the company logo?'
                    )
                ) {
                    return;
                }


                const formData =
                    new FormData();

                formData.append(
                    'action',
                    'remove'
                );


                setBusy(true);


                try {

                    const response =
                        await fetch(
                            'appearance-logo-upload.php',
                            {
                                method: 'POST',
                                body: formData
                            }
                        );

                    const data =
                        await response.json();


                    if (
                        !response.ok
                        || !data.success
                    ) {

                        throw new Error(
                            data.message
                            || 'Unable to remove the logo.'
                        );

                    }


                    showMessage(
                        data.message
                        || 'Company logo removed.',
                        true
                    );


                    window.setTimeout(
                        function () {
                            window.location.reload();
                        },
                        350
                    );

                } catch (error) {

                    showMessage(
                        error.message
                        || 'Unable to remove the logo.',
                        false
                    );

                    setBusy(false);

                }

            }
        );

    }



    if (
        chooseFaviconButton
        && faviconFileInput
    ) {

        chooseFaviconButton.addEventListener(
            'click',
            function () {

                faviconFileInput.value = '';
                faviconFileInput.click();

            }
        );


        faviconFileInput.addEventListener(
            'change',
            async function () {

                const file =
                    faviconFileInput.files[0];

                if (!file) {
                    return;
                }


                const allowedTypes = [
                    'image/jpeg',
                    'image/png',
                    'image/webp'
                ];


                if (
                    !allowedTypes.includes(
                        file.type
                    )
                ) {

                    showMessage(
                        'Please select a JPG, PNG or WebP image.',
                        false
                    );

                    return;
                }


                if (
                    file.size >
                    (5 * 1024 * 1024)
                ) {

                    showMessage(
                        'Favicon must be 5 MB or smaller.',
                        false
                    );

                    return;
                }


                const formData =
                    new FormData();

                formData.append(
                    'action',
                    'favicon_upload'
                );

                formData.append(
                    'favicon',
                    file
                );


                setBusy(true);


                try {

                    const response =
                        await fetch(
                            'appearance-logo-upload.php',
                            {
                                method: 'POST',
                                body: formData
                            }
                        );

                    const data =
                        await response.json();


                    if (
                        !response.ok
                        || !data.success
                    ) {

                        throw new Error(
                            data.message
                            || 'Favicon upload failed.'
                        );

                    }


                    showMessage(
                        data.message
                        || 'Favicon uploaded.',
                        true
                    );


                    window.setTimeout(
                        function () {
                            window.location.reload();
                        },
                        450
                    );

                } catch (error) {

                    showMessage(
                        error.message
                        || 'Favicon upload failed.',
                        false
                    );

                    setBusy(false);

                }

            }
        );

    }


    if (restoreFaviconButton) {

        restoreFaviconButton.addEventListener(
            'click',
            async function () {

                if (
                    !window.confirm(
                        'Restore the default portal favicon?'
                    )
                ) {
                    return;
                }


                const formData =
                    new FormData();

                formData.append(
                    'action',
                    'favicon_remove'
                );


                setBusy(true);


                try {

                    const response =
                        await fetch(
                            'appearance-logo-upload.php',
                            {
                                method: 'POST',
                                body: formData
                            }
                        );

                    const data =
                        await response.json();


                    if (
                        !response.ok
                        || !data.success
                    ) {

                        throw new Error(
                            data.message
                            || 'Unable to restore the default favicon.'
                        );

                    }


                    showMessage(
                        data.message
                        || 'Default favicon restored.',
                        true
                    );


                    window.setTimeout(
                        function () {
                            window.location.reload();
                        },
                        350
                    );

                } catch (error) {

                    showMessage(
                        error.message
                        || 'Unable to restore the default favicon.',
                        false
                    );

                    setBusy(false);

                }

            }
        );

    }

})();
</script>

</body>
</html>
