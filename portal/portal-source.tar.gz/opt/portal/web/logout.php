<?php

session_start();

/*
 * UPDATE005 - Login notification engine.
 * The username is captured before the
 * session is destroyed so the logout
 * rules can fire for this user.
 */

$logoutUser =
    $_SESSION['username']
        ?? '';

$_SESSION = [];

session_destroy();

if (trim((string)$logoutUser) !== '') {

    require_once 'config.php';

    @file_get_contents(
        $FASTAPI_URL
        . '/monitor/login-notifications'
        . '/dispatch',
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  =>
                    "Content-Type: application/json\r\n",
                'content' => json_encode([
                    'event' => 'logout',
                    'username' => $logoutUser
                ]),
                'timeout' => 2
            ]
        ])
    );

}

header("Location: login.php");
exit;
