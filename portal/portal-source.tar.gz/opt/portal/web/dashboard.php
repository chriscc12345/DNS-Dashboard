<?php
require_once 'auth.php';
$currentPage = 'dashboard';

require_once 'config.php';

$json = file_get_contents(
    $FASTAPI_URL . "/stats"
);

$stats = json_decode($json, true);

?>

<!DOCTYPE html>
<html>
<head>
  
  <title>DNS Security Dashboard</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
    <link
        rel="icon"
        type="image/png"
        href="images/favicon.png">
        
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/sidebar.php'; ?>

<div class="banner">
  <img src="images/banner.jpg">
</div>

<div class="content">

        <div class="dash-header">
        
            <h1>DNS Security Dashboard</h1>
        
            <p>
                Technitium Request Management System
            </p>
        
        </div>
        
        <div class="dash-row">
        
            <div class="dash-item">
        
            <div class="dash-card pending">
            
                <h2>Pending</h2>
            
                <div class="dash-card-number">
                    <?= $stats['pending'] ?>
                </div>
            
            </div>
      
                <?php if(hasPermission('Pending Requests')): ?>
                
                <a href="admin.php" class="dash-nav-btn pending-btn">
                    View Pending Requests
                </a>
                
                <?php else: ?>
                
                <button
                    class="dash-nav-btn pending-btn disabled-btn"
                    disabled>
                    View Pending Requests
                </button>
                
                <?php endif; ?>
        
            </div>
        
            <div class="dash-item">
        
            <div class="dash-card approved">
            
                <h2>Approved</h2>
            
                <div class="dash-card-number">
                    <?= $stats['approved'] ?>
                </div>
            
            </div>
        
                <?php if(hasPermission('Approve Requests')): ?>
                
                <a href="approved.php" class="dash-nav-btn approved-btn">
                    View Approved Requests
                </a>
                
                <?php else: ?>
                
                <button
                    class="dash-nav-btn approved-btn disabled-btn"
                    disabled>
                    View Approved Requests
                </button>
                
                <?php endif; ?>
        
            </div>
        
            <div class="dash-item">
        
            <div class="dash-card denied">
            
                <h2>Denied</h2>
            
                <div class="dash-card-number">
                    <?= $stats['denied'] ?>
                </div>
            
            </div>
        
                <?php if(hasPermission('Deny Requests')): ?>
                
                <a href="denied.php" class="dash-nav-btn denied-btn">
                    View Denied Requests
                </a>
                
                <?php else: ?>
                
                <button
                    class="dash-nav-btn denied-btn disabled-btn"
                    disabled>
                    View Denied Requests
                </button>
                
                <?php endif; ?>
        
            </div>
        
        </div>
        
        <div class="dash-footer">
        
            DNS Approval Portal
        
        </div>
        
        <script>
        
        const ws = new WebSocket(
            `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`
        );
        
        ws.onmessage = function(event){
        
            if(event.data === "refresh"){
        
                location.reload();
        
            }
        
        };
        
        </script>
</div>
</body>
</html>