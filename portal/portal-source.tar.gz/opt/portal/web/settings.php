<?php

require_once 'auth.php';
require_once 'config.php';

if(
    !hasAnyPermission([
        'General',
        'Dashboard',
        'Reports',
        'Time Zone',

        'Appearance',
        'Banner',
        'Logo',
        'Portal Name',
        'Favicon',
        'Background',
        'Button Colours',
        'Login',

        'Security',
        'HTTPS/SSL',
        'Users',
        'User Groups',
        'Session Timeout',
        '3rd Party Integrations',
        'Data Deletion',

        'Notifications',
        'Email Notifications',
        'Push Notifications',
        'WhatsApp/Telegram Integration',

        'DNS Server',
        'Flush Cache',
        'Enable/Disable Cache',
        'Enable/Disable Blocking',
        'Allow Lists',
        'Block Lists',
        'Network Proxy',
        'DHCP',

        'System Status',
        'Database Server',
        'API Server',
        'DNS Server Status'
    ])
){
    include 'includes/access-denied.php';
    exit;
}

$currentPage = 'settings';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Settings</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
    <link
        rel="icon"
        type="image/png"
        href="images/favicon.png">
    
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />    
    
</head>

<body>

<?php include 'includes/sidebar.php'; ?>

<div class="banner">
  <img src="images/banner.jpg">
</div>


<div class="content settings-scroll">

        <h1>Settings</h1>
               
        <?php if(
            hasAnyPermission([
                'General',
                'Dashboard',
                'Pending Requests',
                'Approve Requests',
                'Deny Requests',
                'Reports',
                'Time Zone'
            ])
        ): ?>
        
        <div class="settings-section">
        
            <h2>General</h2>
        
            ...
        
        </div>
        
        <?php endif; ?>
        
        <?php if(
            hasAnyPermission([
                'Appearance',
                'Banner',
                'Logo',
                'Portal Name',
                'Favicon',
                'Background',
                'Button Colours',
                'Login'
            ])
        ): ?>
        
        <div class="settings-section">
        
            <h2>Appearance</h2>
        
            ...
        
        </div>
        
        <?php endif; ?>
        
        <?php if(
            hasAnyPermission([
                'DNS Server',
                'Flush Cache',
                'Enable/Disable Cache',
                'Enable/Disable Blocking',
                'Allow Lists',
                'Block Lists',
                'Network Proxy',
                'DHCP'
            ])
        ): ?>
        
        <div class="settings-section">
        
            <h2>DNS Server</h2>
        
            ...
        
        </div>
        
        <?php endif; ?>
        
        <?php if(
            hasAnyPermission([
                'Security',
                'HTTPS/SSL',
                'Users',
                'User Groups',
                'Session Timeout',
                '3rd Party Integrations',
                'Data Deletion'
            ])
        ): ?>
        
        <div class="settings-section">
        
            <h2>Security</h2>
        
            <ul>
        
                <?php if(hasPermission('HTTPS/SSL')): ?>
                <li>
                    <a href="https-ssl.php"
                       class="table-btn">
                        HTTPS
                    </a>
                </li>
                <br>
                <?php endif; ?>
        
        
                <?php if(hasPermission('Users')): ?>
                <li>
                    <a href="users.php"
                       class="table-btn">
                        Users
                    </a>
                </li>
                <br>
                <?php endif; ?>
        
        
                <?php if(hasPermission('User Groups')): ?>
                <li>
                    <a href="groups.php"
                       class="table-btn">
                        User Groups
                    </a>
                </li>
                <br>
                <?php endif; ?>
     
                <?php if(hasPermission('Session Timeout')): ?>
                <li>
                    <a href="timeout.php"
                       class="table-btn">
                       Session Timeout
                    </a>
                </li>
                <?php endif; ?>
        
            </ul>
        
        </div>
        
        <?php endif; ?>
        
        <?php if(
            hasAnyPermission([
                'Notifications',
                'Email Notifications',
                'Push Notifications',
                'WhatsApp/Telegram Integration'
            ])
        ): ?>
        
        <div class="settings-section">
        
            <h2>Notifications</h2>
        
            ...
        
        </div>
        
        <?php endif; ?>
        
        <?php if(
            hasAnyPermission([
                'System Status',
                'Database Server',
                'API Server',
                'DNS Server Status'
            ])
        ): ?>
        
        <div class="settings-section">
        
            <h2>System Status</h2>
        
            ...
        
        </div>
        
        <?php endif; ?>
        
        
        <div class="settings-section">
        
            <h2>About</h2>
        
            <p>
                DNS Security Dashboard
            </p>
        
            <p>
                Version 1.0
            </p>
        
            <p>
                Designed and Developed by Chris Coetzer
            </p>
        
        </div>
</div>
</body>
</html>