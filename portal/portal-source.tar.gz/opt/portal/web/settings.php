<?php

require_once 'auth.php';
require_once 'config.php';

if(
    !hasAnyPermission([
        'General',
        'Reports',
        'Time Zone',
        'Edit Settings Fields',

        'Appearance',
        'Banner',
        'Logo',
        'Favicon',
        'Login',
        'Theme',
        'Sidebar',
        'User Disclaimer',

        'Security',
        'HTTPS/SSL',
        'User Management',
        'Users',
        'User Groups',
        'Session Timeout',
        '3rd Party Integrations',
        'Data Deletion',

        'Communications',
        'Notification Channels',
        'Monitor Alerts',
        'Notification Channel',
        'Email Notifications',
        'Push Notifications',
        'WhatsApp',
        'Telegram',
        'Pushbullet',

        'Services', 'Network', 'Technitium',
        'Cache', 'Flush Cache',
        'Enable/Disable Cache',
        'Blocking', 'Recursion',
        'Network Proxy',
        'DHCP',

        'System Status',
        'Database Server',
        'API Server',
        'DNS Server Status',
        'Connectivity Status'
    ])
){
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'settings';
$pageHeading = 'Settings';

/*
 * UPDATE004 - Editable settings sections and fields.
 * Sections and their fields come from the database so
 * they can be added and removed by anyone holding the
 * Edit Settings Fields permission.
 */

$settingsSections =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/settings-field-sections'
        ),
        true
    ) ?? [];

$settingsFields =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/settings-fields'
        ),
        true
    ) ?? [];

/*
 * Network services backend state (clean portal v2):
 * backend-owned settings pages only appear when the
 * matching backend is active.
 */

$backendCapabilities =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL
            . '/api/backends/capabilities'
        ),
        true
    ) ?? [];

$backendProvider =
    is_array($backendCapabilities)
        ? (string)(
            $backendCapabilities['provider']
            ?? ''
        )
        : '';

$backendOnlyHrefs = [
    'technitium.php',
    'blocking.php',
    'recursion.php',
    'network-proxy.php',
    'dhcp.php'
];

$permissionsList =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/permissions'
        ),
        true
    ) ?? [];

$canEditSettingsFields =
    hasPermission('Edit Settings Fields');

/*
 * Connectivity status: the servers
 * that have checked in through the
 * monitoring heartbeat.
 */

$connectivityServers =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL
            . '/api/monitoring/servers'
        ),
        true
    ) ?? [];

$connectivityServers =
    is_array($connectivityServers)
        ? $connectivityServers
        : [];

function connectivitySeenLabel($seconds) {

    $seconds = (int)$seconds;

    if ($seconds < 60) {
        return 'Just now';
    }

    if ($seconds < 3600) {
        return (int)($seconds / 60)
            . ' min ago';
    }

    if ($seconds < 86400) {
        return (int)($seconds / 3600)
            . ' h ago';
    }

    return (int)($seconds / 86400)
        . ' d ago';
}

function connectivityMetric($value) {

    return $value === null
        ? '&mdash;'
        : htmlspecialchars(
            (string)$value
        ) . '%';
}

function portalApiPost($path, $payload) {

    global $FASTAPI_URL;

    return file_get_contents(
        $FASTAPI_URL . $path,
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => json_encode($payload)
            ]
        ])
    );
}

/*
 * Per-field Edit/Delete controls. Rendered
 * inline after a link field, or inside the
 * heading row of an embedded field.
 */

function renderSettingsFieldControls(
    $settingsField,
    $sectionId,
    $canEditSettingsFields
) {

    if (!$canEditSettingsFields) {
        return;
    }

    ?>

    <button
        type="button"
        class="settings-edit-btn"
        onclick="openSettingsFieldModal(
            <?= (int)$settingsField['id'] ?>,
            <?= (int)$sectionId ?>,
            '<?= htmlspecialchars(
                $settingsField['field_name'],
                ENT_QUOTES
            ) ?>',
            '<?= htmlspecialchars(
                $settingsField['field_href'],
                ENT_QUOTES
            ) ?>',
            '<?= htmlspecialchars(
                $settingsField['field_permission'],
                ENT_QUOTES
            ) ?>'
        )">
        Edit
    </button>

    <form
        method="post"
        style="display:inline;">

        <input
            type="hidden"
            name="field_id"
            value="<?= (int)$settingsField['id'] ?>">

        <button
            type="submit"
            name="delete_settings_field"
            value="1"
            class="settings-delete-btn"
            onclick="return confirm(
                'Delete this field?'
            );">
            Delete
        </button>

    </form>

    <?php
}

/*
 * Only holders of Edit Settings Fields may
 * change sections and fields - the UI is gated
 * the same way, direct POSTs must not bypass
 * it.
 */

if (
    isset($_POST['create_settings_section'])
    && $canEditSettingsFields
) {

    portalApiPost(
        '/settings-field-sections/create',
        [
            'section_name' =>
                trim((string)$_POST['section_name']),
            'sort_order' =>
                count($settingsSections)
        ]
    );

    header('Location: settings.php');
    exit;
}

if (
    isset($_POST['update_settings_section'])
    && $canEditSettingsFields
) {

    portalApiPost(
        '/settings-field-sections/'
            . (int)$_POST['section_id']
            . '/update',
        [
            'section_name' =>
                trim((string)$_POST['section_name']),
            'sort_order' =>
                (int)$_POST['sort_order']
        ]
    );

    header('Location: settings.php');
    exit;
}

if (
    isset($_POST['delete_settings_section'])
    && $canEditSettingsFields
) {

    portalApiPost(
        '/settings-field-sections/'
            . (int)$_POST['section_id']
            . '/delete',
        []
    );

    header('Location: settings.php');
    exit;
}

if (
    isset($_POST['create_settings_field'])
    && $canEditSettingsFields
) {

    $sectionFieldCount = 0;

    foreach ($settingsFields as $existingField) {
        if (
            (int)$existingField['section_id']
            === (int)$_POST['section_id']
        ) {
            $sectionFieldCount++;
        }
    }

    portalApiPost(
        '/settings-fields/create',
        [
            'section_id' =>
                (int)$_POST['section_id'],
            'field_name' =>
                trim((string)$_POST['field_name']),
            'field_href' =>
                trim((string)$_POST['field_href']),
            'field_permission' =>
                trim((string)$_POST['field_permission']),
            'sort_order' => $sectionFieldCount
        ]
    );

    header('Location: settings.php');
    exit;
}

if (
    isset($_POST['update_settings_field'])
    && $canEditSettingsFields
) {

    portalApiPost(
        '/settings-fields/'
            . (int)$_POST['field_id']
            . '/update',
        [
            'field_name' =>
                trim((string)$_POST['field_name']),
            'field_href' =>
                trim((string)$_POST['field_href']),
            'field_permission' =>
                trim((string)$_POST['field_permission']),
            'sort_order' =>
                (int)$_POST['sort_order']
        ]
    );

    header('Location: settings.php');
    exit;
}

if (
    isset($_POST['delete_settings_field'])
    && $canEditSettingsFields
) {

    portalApiPost(
        '/settings-fields/'
            . (int)$_POST['field_id']
            . '/delete',
        []
    );

    header('Location: settings.php');
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Settings</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
<?php include __DIR__ . '/includes/favicon.php'; ?>

    
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />    
    
</head>

<body>

<?php include 'includes/sidebar.php'; ?>

<?php include 'includes/banner.php'; ?>


<div class="content settings-scroll">

        
               
        <?php if($canEditSettingsFields): ?>

        <button
            type="button"
            class="settings-add-btn"
            style="margin-bottom:10px;"
            onclick="openSettingsSectionModal(null, '')">
            + Add Section
        </button>

        <?php endif; ?>
        
        <?php

        $fieldsBySection = [];

        foreach ($settingsFields as $settingsField) {

            $fieldsBySection[
                (int)$settingsField['section_id']
            ][] = $settingsField;

        }

        ?>

        <?php foreach ($settingsSections as $settingsSection):

            $sectionId =
                (int)$settingsSection['id'];

            $sectionFields = [];

            foreach (
                ($fieldsBySection[$sectionId] ?? [])
                as $settingsField
            ) {

                $fieldPermission =
                    trim(
                        (string)(
                            $settingsField['field_permission']
                            ?? ''
                        )
                    );

                $fieldHrefRaw =
                    trim(
                        (string)(
                            $settingsField['field_href']
                            ?? ''
                        )
                    );

                /*
                 * Backend-owned fields stay hidden unless
                 * the Technitium backend is active.
                 */

                if (
                    in_array(
                        $fieldHrefRaw,
                        $backendOnlyHrefs,
                        true
                    )
                    &&
                    $backendProvider !== 'technitium'
                ) {
                    continue;
                }

                /*
                 * Notifications is shown when the viewer
                 * holds any notification permission; its
                 * link targets the first channel page
                 * the viewer may open.
                 */

                $fieldIsNotifications =
                    $fieldHrefRaw
                    === 'notifications-email.php';

                $fieldNotificationAccess =
                    $fieldIsNotifications
                    &&
                    hasAnyPermission([
                        'Notification Channels',
                        'Monitor Alerts',
                        'Email Notifications',
                        'Push Notifications',
                        'WhatsApp',
                        'Telegram',
                        'Pushbullet'
                    ]);

                if (
                    $canEditSettingsFields
                    ||
                    $fieldNotificationAccess
                    ||
                    (
                        !$fieldIsNotifications
                        &&
                        $fieldPermission === ''
                        &&
                        $fieldHrefRaw !== ''
                    )
                    ||
                    (
                        !$fieldIsNotifications
                        &&
                        $fieldPermission !== ''
                        &&
                        hasPermission($fieldPermission)
                    )
                ) {
                    $sectionFields[] = $settingsField;
                }

            }

            if (
                !$canEditSettingsFields
                &&
                count($sectionFields) === 0
            ) {
                continue;
            }

        ?>
        
        <div class="settings-section">
        
            <div class="settings-section-heading">
        
                <div class="settings-section-title-group">
        
                    <h2>
                        <?= htmlspecialchars(
                            $settingsSection['section_name']
                        ) ?>
                    </h2>
        
                    <?php if($canEditSettingsFields): ?>
        
                    <button
                        type="button"
                        class="settings-edit-btn"
                        onclick="openSettingsSectionModal(
                            <?= $sectionId ?>,
                            '<?= htmlspecialchars(
                                $settingsSection['section_name'],
                                ENT_QUOTES
                            ) ?>'
                        )">
                        Edit
                    </button>
        
                    <form
                        method="post"
                        style="display:inline;">
        
                        <input
                            type="hidden"
                            name="section_id"
                            value="<?= $sectionId ?>">
        
                        <button
                            type="submit"
                            name="delete_settings_section"
                            value="1"
                            class="settings-delete-btn"
                            onclick="return confirm(
                                'Delete this section and all its fields?'
                            );">
                            Delete
                        </button>
        
                    </form>
        
                    <?php endif; ?>
        
                </div>
        
                <?php if($canEditSettingsFields): ?>
        
                <div class="settings-section-actions">
        
                    <button
                        type="button"
                        class="settings-add-btn"
                        onclick="openSettingsFieldModal(
                            null,
                            <?= $sectionId ?>,
                            '',
                            '',
                            ''
                        )">
                        + Add Field
                    </button>
        
                </div>
        
                <?php endif; ?>
        
            </div>
        
            <ul>
        
                <?php foreach ($sectionFields as $settingsField): ?>
                <li>
        
                    <?php
                        $fieldHref =
                            trim(
                                (string)(
                                    $settingsField['field_href']
                                    ?? ''
                                )
                            );

                        /*
                         * User Management targets the first page
                         * the viewer may open: Users, otherwise
                         * User Groups.
                         */

                        if (
                            $fieldHref === 'users.php'
                            &&
                            !hasPermission('Users')
                            &&
                            hasPermission('User Groups')
                        ) {
                            $fieldHref = 'groups.php';
                        }

                        /*
                         * Notifications targets the first
                         * channel page the viewer may open.
                         * A viewer with no channel
                         * permission gets no link.
                         */

                        if (
                            $fieldHref
                            === 'notifications-email.php'
                        ) {

                            if (
                                hasPermission(
                                    'Email Notifications'
                                )
                            ) {
                                // already correct
                            }
                            elseif (
                                hasPermission(
                                    'Push Notifications'
                                )
                            ) {
                                $fieldHref =
                                    'notifications-push.php';
                            }
                            elseif (
                                hasPermission('WhatsApp')
                            ) {
                                $fieldHref =
                                    'notifications-whatsapp.php';
                            }
                            elseif (
                                hasPermission('Telegram')
                            ) {
                                $fieldHref =
                                    'notifications-telegram.php';
                            }
                            elseif (
                                hasPermission('Pushbullet')
                            ) {
                                $fieldHref =
                                    'notifications-pushbullet.php';
                            }
                            else {
                                $fieldHref = '';
                            }

                        }
                    ?>
        
                    <?php if(
                        $fieldHref
                        === 'network-backend-status'
                    ): ?>

                    <!--
                        Embedded content field. The stored
                        link "network-backend-status" renders
                        the network services backend card:
                        which backend is active, provisioning
                        progress, and the backend chooser.
                    -->

                    <div
                        class="settings-embedded-field-heading">

                        <h3>
                            <?= htmlspecialchars(
                                $settingsField['field_name']
                            ) ?>
                        </h3>

                        <?php
                            renderSettingsFieldControls(
                                $settingsField,
                                $sectionId,
                                $canEditSettingsFields
                            );
                        ?>

                    </div>

                    <div
                        id="networkBackendBody"
                        style="margin:10px 0 4px 0;">

                        <span class="settings-coming-soon">
                            Loading backend status&hellip;
                        </span>

                    </div>

                    <script>

                    function backendEscape(value) {

                        var div =
                            document
                            .createElement('div');

                        div.textContent =
                            String(
                                value === null
                                || value === undefined
                                    ? ''
                                    : value
                            );

                        return div.innerHTML;
                    }

                    function backendLabel(id) {

                        if (id === 'technitium') {
                            return 'Technitium DNS Server';
                        }

                        if (id === 'netfortress') {
                            return 'NetFortress Firewall Appliance';
                        }

                        return id;
                    }

                    function backendOptionsHtml(
                        data,
                        editable
                    ) {

                        var html = '';

                        (data.options || []).forEach(
                            function(option) {

                                var active =
                                    data.provider === option.id;

                                var disabled =
                                    !editable
                                    || (
                                        data.provider
                                        && data.provider
                                            !== option.id
                                    );

                                html +=
                                    '<label'
                                    + ' style="display:block;'
                                    + ' margin:6px 0;'
                                    + (disabled
                                        ? ' opacity:.5;'
                                        : '')
                                    + '">'
                                    + '<input'
                                    + ' type="radio"'
                                    + ' name="backendChoice"'
                                    + ' value="'
                                    + backendEscape(option.id)
                                    + '"'
                                    + (active
                                        ? ' checked'
                                        : '')
                                    + (disabled
                                        ? ' disabled'
                                        : '')
                                    + ' /> '
                                    + '<strong>'
                                    + backendEscape(
                                        option.label
                                    )
                                    + '</strong><br />'
                                    + '<span class='
                                    + '"settings-coming-soon">'
                                    + backendEscape(
                                        option.description
                                    )
                                    + '</span>'
                                    + '</label>';
                            }
                        );

                        if (data.provider) {
                            html +=
                                '<p class='
                                + '"settings-coming-soon">'
                                + 'Backend switching is not'
                                + ' available yet.'
                                + '</p>';
                        } else if (editable) {
                            html +=
                                '<div'
                                + ' id="backendPasswordField"'
                                + ' style="display:none;'
                                + ' margin-top:6px;">'
                                + '<span'
                                + ' id='
                                + '"backendPasswordLabel">'
                                + '</span>'
                                + '<input'
                                + ' type="password"'
                                + ' id="backendAppliancePassword"'
                                + ' autocomplete="new-password"'
                                + ' style="padding:6px;'
                                + ' border-radius:6px;'
                                + ' border:1px solid #ccc;'
                                + ' min-width:260px;" />'
                                + '<br />'
                                + '<span'
                                + ' class='
                                + '"settings-coming-soon"'
                                + ' id='
                                + '"backendPasswordHint">'
                                + '</span>'
                                + '</div>'
                                + '<button'
                                + ' type="button"'
                                + ' class="table-btn"'
                                + ' style="margin-top:10px;"'
                                + ' onclick='
                                + '"backendProvision()">'
                                + 'Provision Backend'
                                + '</button>';
                        }

                        return html;
                    }

                    function backendLogHtml(data) {

                        var lines =
                            data.provisioning_log || [];

                        if (!lines.length) {
                            return '';
                        }

                        var html =
                            '<pre style='
                            + '"max-height:180px; overflow:auto;'
                            + ' background:#f4f4f4;'
                            + ' color:#333; padding:8px;'
                            + ' border-radius:6px; font-size:12px;'
                            + ' margin-top:8px;">';

                        lines.forEach(
                            function(line) {
                                html +=
                                    backendEscape(line)
                                    + '\n';
                            }
                        );

                        return html + '</pre>';
                    }

                    function backendRender(data) {

                        var body = document
                            .getElementById(
                                'networkBackendBody'
                            );

                        if (!body) return;

                        var prov =
                            data.provisioning || {};

                        var html = '';

                        if (prov.state === 'running') {

                            html +=
                                '<span class='
                                + '"badge-active">'
                                + 'Provisioning '
                                + backendEscape(
                                    backendLabel(
                                        prov.backend
                                    )
                                )
                                + ' &hellip;'
                                + '</span>'
                                + '<p class='
                                + '"settings-coming-soon">'
                                + 'This runs in the background'
                                + ' and can take several'
                                + ' minutes. The portal'
                                + ' restarts automatically'
                                + ' when it finishes.'
                                + '</p>'
                                + backendOptionsHtml(
                                    data,
                                    false
                                )
                                + backendLogHtml(data);

                        } else if (prov.state === 'failed') {

                            html +=
                                '<span class='
                                + '"badge-disabled">'
                                + 'Provisioning failed'
                                + '</span>'
                                + '<p style='
                                + '"margin:8px 0;">'
                                + backendEscape(
                                    prov.error
                                    || 'The provisioning'
                                    + ' script failed.'
                                )
                                + '</p>'
                                + backendOptionsHtml(
                                    data,
                                    true
                                )
                                + backendLogHtml(data);

                        } else if (data.provider) {

                            var healthy =
                                (data.provider_health || {})
                                .status === 'ok';

                            html +=
                                '<p style='
                                + '"margin:4px 0;">'
                                + 'Active backend: '
                                + '<strong>'
                                + backendEscape(
                                    backendLabel(
                                        data.provider
                                    )
                                )
                                + '</strong> '
                                + '<span class="'
                                + (healthy
                                    ? 'badge-active'
                                    : 'badge-disabled')
                                + '">'
                                + (healthy
                                    ? 'Healthy'
                                    : 'Unreachable')
                                + '</span>'
                                + '</p>'
                                + backendOptionsHtml(
                                    data,
                                    false
                                );

                        } else {

                            html +=
                                '<p style='
                                + '"margin:4px 0;">'
                                + 'Network services backend: '
                                + '<strong>NOT CONFIGURED'
                                + '</strong>'
                                + '</p>'
                                + backendOptionsHtml(
                                    data,
                                    true
                                );

                        }

                        body.innerHTML = html;
                    }

                    function backendProvision() {

                        var choice = document
                            .querySelector(
                                'input[name='
                                + '"backendChoice"]:checked'
                            );

                        if (!choice) {
                            alert(
                                'Select a backend first.'
                            );
                            return;
                        }

                        var payload = {
                            backend: choice.value
                        };

                        var field = document
                            .getElementById(
                                'backendAppliancePassword'
                            );

                        payload
                            .appliance_admin_password =
                                field
                                    ? field.value
                                    : '';

                        fetch(
                            'backends-api.php',
                            {
                                method: 'POST',
                                headers: {
                                    'Content-Type':
                                        'application/json'
                                },
                                body: JSON.stringify(
                                    payload
                                )
                            }
                        )
                        .then(
                            function(response) {
                                return response
                                    .json();
                            }
                        )
                        .then(
                            function(result) {

                                if (
                                    result.status
                                    === 'ok'
                                ) {
                                    backendRefresh();
                                    return;
                                }

                                alert(
                                    result.message
                                    || 'Provisioning could'
                                    + ' not be started.'
                                );
                            }
                        )
                        .catch(
                            function() {
                                alert(
                                    'The provisioning'
                                    + ' request failed.'
                                );
                            }
                        );
                    }

                    function backendRefresh() {

                        fetch('backends-api.php')
                        .then(
                            function(response) {
                                return response
                                    .json();
                            }
                        )
                        .then(
                            function(data) {

                                backendRender(data);

                                if (
                                    (data.provisioning
                                        || {}).state
                                    === 'running'
                                ) {
                                    setTimeout(
                                        backendRefresh,
                                        3000
                                    );
                                }
                            }
                        )
                        .catch(function() {});
                    }

                    document.addEventListener(
                        'change',
                        function(event) {

                            if (
                                event.target
                                && event.target.name
                                    === 'backendChoice'
                            ) {

                                var field = document
                                    .getElementById(
                                        'backendPasswordField'
                                    );

                                var label = document
                                    .getElementById(
                                        'backendPasswordLabel'
                                    );

                                var hint = document
                                    .getElementById(
                                        'backendPasswordHint'
                                    );

                                if (field) {

                                    var netfortress =
                                        event.target.value
                                            === 'netfortress';

                                    field
                                        .style
                                        .display =
                                            'block';

                                    if (label) {
                                        label.innerHTML =
                                            netfortress
                                                ? 'Appliance'
                                                + ' administrator'
                                                + ' password:'
                                                : 'Portal'
                                                + ' administrator'
                                                + ' password:';
                                    }

                                    if (hint) {
                                        hint.innerHTML =
                                            netfortress
                                                ? 'Minimum 12'
                                                + ' characters with'
                                                + ' at least three'
                                                + ' character'
                                                + ' categories'
                                                + ' (lowercase,'
                                                + ' uppercase,'
                                                + ' digit, symbol).'
                                                + ' This becomes'
                                                + ' the appliance'
                                                + ' console'
                                                + ' password.'
                                                : 'Must match your'
                                                + ' Portal'
                                                + ' administrator'
                                                + ' login - it also'
                                                + ' becomes the'
                                                + ' Technitium'
                                                + ' console admin'
                                                + ' password.';
                                    }
                                }
                            }
                        }
                    );

                    backendRefresh();

                    </script>

                    <?php elseif(
                        $fieldHref
                        === 'connectivity-status'
                    ): ?>

                    <!--
                        Embedded content field. The
                        stored link "connectivity-status"
                        renders the connectivity table
                        instead of a page link, with the
                        field controls in the heading row.
                    -->

                    <div
                        class="settings-embedded-field-heading">

                        <h3>
                            <?= htmlspecialchars(
                                $settingsField['field_name']
                            ) ?>
                        </h3>

                        <?php
                            renderSettingsFieldControls(
                                $settingsField,
                                $sectionId,
                                $canEditSettingsFields
                            );
                        ?>

                    </div>

                    <!--
                        Every server that checks in
                        through the monitoring
                        heartbeat shows here; a fresh
                        heartbeat (last 3 minutes)
                        reads Online. The table
                        refreshes itself every 30
                        seconds.
                    -->

                    <table class="ssl-table">
                        <tr>
                            <th>Server</th>
                            <th>IP Address</th>
                            <th>CPU</th>
                            <th>Memory</th>
                            <th>Disk</th>
                            <th>Last Seen</th>
                            <th>Status</th>
                        </tr>
                        <tbody id="connectivityBody">

                            <?php foreach (
                                $connectivityServers
                                as $connServer
                            ): ?>

                            <tr>
                                <td>
                                    <?= htmlspecialchars(
                                        (string)(
                                            $connServer[
                                                'hostname'
                                            ] ?? ''
                                        )
                                    ) ?>
                                </td>
                                <td>
                                    <?= htmlspecialchars(
                                        (string)(
                                            $connServer[
                                                'ip_address'
                                            ] ?? ''
                                        )
                                    ) ?>
                                </td>
                                <td>
                                    <?= connectivityMetric(
                                        $connServer[
                                            'cpu_percent'
                                        ] ?? null
                                    ) ?>
                                </td>
                                <td>
                                    <?= connectivityMetric(
                                        $connServer[
                                            'memory_percent'
                                        ] ?? null
                                    ) ?>
                                </td>
                                <td>
                                    <?= connectivityMetric(
                                        $connServer[
                                            'disk_percent'
                                        ] ?? null
                                    ) ?>
                                </td>
                                <td>
                                    <?= htmlspecialchars(
                                        connectivitySeenLabel(
                                            $connServer[
                                                'seconds_since_seen'
                                            ] ?? 0
                                        )
                                    ) ?>
                                </td>
                                <td>
                                    <span class="<?= !empty(
                                        $connServer['online']
                                    )
                                        ? 'badge-active'
                                        : 'badge-disabled' ?>">
                                        <?= !empty(
                                            $connServer['online']
                                        )
                                            ? 'Online'
                                            : 'Offline' ?>
                                    </span>
                                </td>
                            </tr>

                            <?php endforeach; ?>

                            <?php if(
                                count(
                                    $connectivityServers
                                ) === 0
                            ): ?>

                            <tr>
                                <td colspan="7">
                                    <span class="settings-coming-soon">
                                        No servers have checked in yet.
                                    </span>
                                </td>
                            </tr>

                            <?php endif; ?>

                        </tbody>
                    </table>

                    <script>

                    function connEscape(value) {

                        var div =
                            document
                            .createElement('div');

                        div.textContent =
                            String(value);

                        return div.innerHTML;
                    }

                    function connSeen(seconds) {

                        seconds = parseInt(seconds, 10) || 0;

                        if (seconds < 60) return 'Just now';
                        if (seconds < 3600) {
                            return Math.floor(seconds / 60)
                                + ' min ago';
                        }
                        if (seconds < 86400) {
                            return Math.floor(seconds / 3600)
                                + ' h ago';
                        }
                        return Math.floor(seconds / 86400)
                            + ' d ago';
                    }

                    function connRender(servers) {

                        var body = document
                            .getElementById(
                                'connectivityBody'
                            );

                        if (!body) return;

                        var html = '';

                        (servers || []).forEach(
                            function(server) {

                                html += '<tr>'
                                    + '<td>' + connEscape(server.hostname) + '</td>'
                                    + '<td>' + connEscape(server.ip_address || '') + '</td>'
                                    + '<td>'
                                    + (server.cpu_percent === null
                                        ? '&mdash;'
                                        : connEscape(server.cpu_percent) + '%')
                                    + '</td>'
                                    + '<td>'
                                    + (server.memory_percent === null
                                        ? '&mdash;'
                                        : connEscape(server.memory_percent) + '%')
                                    + '</td>'
                                    + '<td>'
                                    + (server.disk_percent === null
                                        ? '&mdash;'
                                        : connEscape(server.disk_percent) + '%')
                                    + '</td>'
                                    + '<td>' + connEscape(
                                        connSeen(
                                            server.seconds_since_seen
                                        )
                                    ) + '</td>'
                                    + '<td><span class="'
                                    + (server.online
                                        ? 'badge-active">Online'
                                        : 'badge-disabled">Offline')
                                    + '</span></td>'
                                    + '</tr>';
                            }
                        );

                        if (!html) {
                            html = '<tr><td colspan="7">'
                                + '<span class="settings-coming-soon">'
                                + 'No servers have checked in yet.'
                                + '</span></td></tr>';
                        }

                        body.innerHTML = html;
                    }

                    function connRefresh() {

                        fetch('connectivity-api.php')
                        .then(function(response) {
                            return response.json();
                        })
                        .then(connRender)
                        .catch(function() {});
                    }

                    setInterval(connRefresh, 30000);

                    </script>

                    <?php elseif($fieldHref !== ''): ?>
        
                    <a
                        href="<?= htmlspecialchars($fieldHref) ?>?from=settings"
                        class="table-btn">
                        <?= htmlspecialchars(
                            $settingsField['field_name']
                        ) ?>
                    </a>
        
                    <?php else: ?>
        
                    <span
                        class="table-btn"
                        style="opacity:.55; cursor:default;">
                        <?= htmlspecialchars(
                            $settingsField['field_name']
                        ) ?>
                    </span>
        
                    <?php endif; ?>
        
                    <?php
                    if (
                        $fieldHref
                        !== 'connectivity-status'
                        && $fieldHref
                        !== 'network-backend-status'
                    ) {
                        renderSettingsFieldControls(
                            $settingsField,
                            $sectionId,
                            $canEditSettingsFields
                        );
                    }
                    ?>
        
                </li>
                <br>
                <?php endforeach; ?>
        
            </ul>
        
        </div>
        
        <?php endforeach; ?>
        
        <div class="settings-section">
        
            <h2>About</h2>
        
            <p>
                DNS Security Dashboard
            </p>
        
            <p>
                Version 1.0
            </p>
        
            <p>
                Designed and Developed by Chris Coetzer
            </p>
        
        </div>
</div>

<?php if($canEditSettingsFields): ?>

<!--
    Reuses the Add User modal classes so the
    section popup matches the portal modal
    style; .ln-modal trims it to the small
    field set.
-->

<div id="settingsSectionModal"
     class="modal ln-modal">

    <div class="user-modal-content
              add-user-modal">

        <div class="add-user-titlebar">

            <h3 id="settingsSectionModalTitle">
                Add Section
            </h3>

            <button
                type="button"
                class="add-user-close"
                onclick="closeSettingsSectionModal()"
                aria-label="Close">
                &times;
            </button>

        </div>

        <form method="post">

            <input
                type="hidden"
                name="section_id"
                id="settingsSectionId"
                value="">

            <input
                type="hidden"
                name="sort_order"
                id="settingsSectionSort"
                value="0">

            <div class="add-user-layout">

                <div class="add-user-fields">

                    <div class="add-user-grid">

                        <div class="portal-field"
                             style="grid-column:1 / -1;">

                            <label for="settingsSectionName">
                                Section Name
                            </label>

                            <input
                                type="text"
                                name="section_name"
                                id="settingsSectionName"
                                required>

                        </div>

                    </div>

                </div>

            </div>

            <div class="ln-actions">

                <button
                    type="submit"
                    name="create_settings_section"
                    value="1"
                    class="approve-btn"
                    id="settingsSectionCreateBtn">
                    Create
                </button>

                <button
                    type="submit"
                    name="update_settings_section"
                    value="1"
                    class="approve-btn"
                    id="settingsSectionUpdateBtn"
                    style="display:none;">
                    Save
                </button>

                <button
                    type="button"
                    class="deny-btn"
                    onclick="closeSettingsSectionModal()">
                    Cancel
                </button>

            </div>

        </form>

    </div>

</div>

<!--
    Same Add User modal shell as the
    section popup.
-->

<div id="settingsFieldModal"
     class="modal ln-modal">

    <div class="user-modal-content
              add-user-modal">

        <div class="add-user-titlebar">

            <h3 id="settingsFieldModalTitle">
                Add Field
            </h3>

            <button
                type="button"
                class="add-user-close"
                onclick="closeSettingsFieldModal()"
                aria-label="Close">
                &times;
            </button>

        </div>

        <form method="post">

            <input
                type="hidden"
                name="field_id"
                id="settingsFieldId"
                value="">

            <input
                type="hidden"
                name="section_id"
                id="settingsFieldSectionId"
                value="">

            <input
                type="hidden"
                name="sort_order"
                id="settingsFieldSort"
                value="0">

            <div class="add-user-layout">

                <div class="add-user-fields">

                    <div class="add-user-grid">

                        <div class="portal-field">

                            <label for="settingsFieldName">
                                Field Name
                            </label>

                            <input
                                type="text"
                                name="field_name"
                                id="settingsFieldName"
                                required>

                        </div>

                        <div class="portal-field">

                            <label for="settingsFieldHref">
                                Link (page)
                            </label>

                            <input
                                type="text"
                                name="field_href"
                                id="settingsFieldHref"
                                placeholder="time-zone.php">

                        </div>

                        <div class="portal-field"
                             style="grid-column:1 / -1;">

                            <label for="settingsFieldPermission">
                                Required Permission
                            </label>

                            <select
                                name="field_permission"
                                id="settingsFieldPermission">

                                <option value="">
                                    No permission required
                                </option>

                                <?php foreach ($permissionsList as $permissionItem): ?>

                                <option
                                    value="<?= htmlspecialchars(
                                        $permissionItem[1]
                                    ) ?>">
                                    <?= $permissionItem[2] === null
                                        ? ''
                                        : '- ' ?><?= htmlspecialchars(
                                        $permissionItem[1]
                                    ) ?>
                                </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                    </div>

                </div>

            </div>

            <div class="ln-actions">

                <button
                    type="submit"
                    name="create_settings_field"
                    value="1"
                    class="approve-btn"
                    id="settingsFieldCreateBtn">
                    Create
                </button>

                <button
                    type="submit"
                    name="update_settings_field"
                    value="1"
                    class="approve-btn"
                    id="settingsFieldUpdateBtn"
                    style="display:none;">
                    Save
                </button>

                <button
                    type="button"
                    class="deny-btn"
                    onclick="closeSettingsFieldModal()">
                    Cancel
                </button>

            </div>

        </form>

    </div>

</div>

<script>

function openSettingsSectionModal(
    sectionId,
    sectionName
){

    document
        .getElementById('settingsSectionModalTitle')
        .textContent =
            sectionId
                ? 'Edit Section'
                : 'Add Section';

    document
        .getElementById('settingsSectionId')
        .value = sectionId || '';

    document
        .getElementById('settingsSectionName')
        .value = sectionName || '';

    document
        .getElementById('settingsSectionCreateBtn')
        .style.display =
            sectionId ? 'none' : '';

    document
        .getElementById('settingsSectionUpdateBtn')
        .style.display =
            sectionId ? '' : 'none';

    document
        .getElementById('settingsSectionModal')
        .style.display = 'flex';

}

function closeSettingsSectionModal(){

    document
        .getElementById('settingsSectionModal')
        .style.display = 'none';

}

function openSettingsFieldModal(
    fieldId,
    sectionId,
    fieldName,
    fieldHref,
    fieldPermission
){

    document
        .getElementById('settingsFieldModalTitle')
        .textContent =
            fieldId
                ? 'Edit Field'
                : 'Add Field';

    document
        .getElementById('settingsFieldId')
        .value = fieldId || '';

    document
        .getElementById('settingsFieldSectionId')
        .value = sectionId || '';

    document
        .getElementById('settingsFieldName')
        .value = fieldName || '';

    document
        .getElementById('settingsFieldHref')
        .value = fieldHref || '';

    document
        .getElementById('settingsFieldPermission')
        .value = fieldPermission || '';

    document
        .getElementById('settingsFieldCreateBtn')
        .style.display =
            fieldId ? 'none' : '';

    document
        .getElementById('settingsFieldUpdateBtn')
        .style.display =
            fieldId ? '' : 'none';

    document
        .getElementById('settingsFieldModal')
        .style.display = 'flex';

}

function closeSettingsFieldModal(){

    document
        .getElementById('settingsFieldModal')
        .style.display = 'none';

}

</script>

<?php endif; ?>

</body>
</html>