<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Devices')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Devices</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
        }
        .nf-status-blocked {
            background: #b50b0b;
            color: #fff;
        }
        .nf-status-online {
            background: #097a27;
            color: #fff;
        }
        .nf-note {
            margin-top: 10px;
            font-size: 13px;
            color: #666;
        }
        #nfDevicesMessage {
            margin-top: 10px;
            font-size: 13px;
            display: none;
        }
        #nfDevicesMessage.nf-message-error {
            color: #b50b0b;
            display: block;
        }
        #nfDevicesMessage.nf-message-ok {
            color: #097a27;
            display: block;
        }
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Devices - managed on the local Firewall Appliance.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel um-table-panel">

        <table id="nfDevicesTable">
            <thead>
            <tr>
                <th>Device</th>
                <th>IP Address</th>
                <th>MAC Address</th>
                <th>Interface</th>
                <th>First Seen</th>
                <th>Last Seen</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody id="nfDevicesBody">
            <tr>
                <td colspan="8">Loading devices from the appliance...</td>
            </tr>
            </tbody>
        </table>

        <div id="nfDevicesMessage"></div>

        <p class="nf-note">
            The device list is discovered live by the Firewall Appliance.
            Blocking a device adds an appliance blocking policy; the list
            refreshes automatically every 10 seconds.
        </p>

    </div>

</div>

<script>
(function () {

    const body = document.getElementById('nfDevicesBody');
    const message = document.getElementById('nfDevicesMessage');

    let loading = false;

    function showMessage(text, ok) {

        if (!text) {
            message.className = '';
            message.textContent = '';
            return;
        }

        message.className = ok
            ? 'nf-message-ok'
            : 'nf-message-error';
        message.textContent = text;

    }

    function escapeHtml(value) {

        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');

    }

    function formatSeen(value) {

        if (!value) {
            return '-';
        }

        const date = new Date(value);

        if (isNaN(date.getTime())) {
            return escapeHtml(value);
        }

        return escapeHtml(
            date.toLocaleString()
        );

    }

    function renderRow(device, blockedPolicy) {

        const mac =
            String(device.mac_address || '')
                .trim()
                .toLowerCase();
        const ip =
            String(device.ip_address || '')
                .trim()
                .toLowerCase();
        const hostname =
            String(device.hostname || '')
                .trim()
                .toLowerCase();

        // Display label: real hostname when known, otherwise the IP
        // (neighbour-discovered devices often have no reverse DNS).
        const label =
            device.hostname || device.ip_address || 'Unknown device';

        // A device counts as blocked when an enabled appliance policy
        // targets its MAC, IP or hostname. MAC wins (device-specific).
        let policy = null;
        let targetType = 'ip';

        if (mac && blockedPolicy(mac)) {
            policy = blockedPolicy(mac);
            targetType = 'mac';
        } else if (ip && blockedPolicy(ip)) {
            policy = blockedPolicy(ip);
            targetType = 'ip';
        } else if (hostname && blockedPolicy(hostname)) {
            policy = blockedPolicy(hostname);
            targetType = 'hostname';
        }

        const row = document.createElement('tr');

        const blocked = policy !== null;

        let actionCell;

        if (blocked) {

            actionCell =
                '<button type="button" class="approve-btn nf-nf-action" ' +
                'data-action="unblock" ' +
                'data-policy-id="' + escapeHtml(policy.id) + '" ' +
                'data-label="' +
                escapeHtml(label) +
                '">Unblock</button>';

        } else {

            const targetValue =
                mac || ip;

            actionCell =
                '<button type="button" class="deny-btn nf-nf-action" ' +
                'data-action="block" ' +
                'data-target-type="' +
                (mac ? 'mac' : 'ip') + '" ' +
                'data-target-value="' +
                escapeHtml(targetValue) + '" ' +
                'data-label="' +
                escapeHtml(label) +
                '">Block</button>';

        }

        row.innerHTML =
            '<td><strong>' +
            escapeHtml(label) +
            '</strong></td>' +
            '<td>' + escapeHtml(device.ip_address || '-') + '</td>' +
            '<td>' + escapeHtml(device.mac_address || '-') + '</td>' +
            '<td>' + escapeHtml(device.interface || '-') + '</td>' +
            '<td>' + formatSeen(device.first_seen_at) + '</td>' +
            '<td>' + formatSeen(device.last_seen_at) + '</td>' +
            '<td>' +
            (
                blocked
                    ? '<span class="nf-status-badge nf-status-blocked">Blocked</span>'
                    : '<span class="nf-status-badge nf-status-online">Online</span>'
            ) +
            '</td>' +
            '<td>' + actionCell + '</td>';

        return row;

    }

    function loadDevices() {

        if (loading) {
            return;
        }

        loading = true;

        fetch('netfortress-api.php?action=devices')
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {

                loading = false;

                if (!data.success) {
                    body.innerHTML =
                        '<tr><td colspan="8">' +
                        escapeHtml(data.message || 'The appliance is not reachable.') +
                        '</td></tr>';
                    return;
                }

                const blocked =
                    data.blocked_targets || {};

                body.innerHTML = '';

                const devices = data.devices || [];

                if (devices.length === 0) {
                    body.innerHTML =
                        '<tr><td colspan="8">No devices discovered yet.</td></tr>';
                    return;
                }

                devices.forEach(function (device) {
                    body.appendChild(
                        renderRow(
                            device,
                            function (key) {
                                return blocked[key] || null;
                            }
                        )
                    );
                });

            })
            .catch(function () {

                loading = false;

                body.innerHTML =
                    '<tr><td colspan="8">' +
                    'The appliance API is not reachable.</td></tr>';

            });

    }

    function deviceAction(button) {

        const action = button.dataset.action;
        const label = button.dataset.label || 'device';

        button.disabled = true;

        showMessage(
            (action === 'block' ? 'Blocking ' : 'Unblocking ') + label + '...',
            true
        );

        const payload =
            action === 'block'
                ? {
                    target_type: button.dataset.targetType,
                    target_value: button.dataset.targetValue,
                    reason: 'Blocked from the Portal'
                }
                : {
                    policy_id: parseInt(button.dataset.policyId, 10)
                };

        fetch('netfortress-api.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {

                if (data.success) {
                    showMessage(
                        (action === 'block' ? 'Blocked ' : 'Unblocked ') + label + '.',
                        true
                    );
                } else {
                    showMessage(
                        data.message || 'The appliance rejected the request.',
                        false
                    );
                }

                loadDevices();

            })
            .catch(function () {
                showMessage(
                    'The appliance API is not reachable.',
                    false
                );
                loadDevices();
            });

    }

    document.addEventListener(
        'click',
        function (event) {

            const button = event.target.closest('.nf-nf-action');

            if (button) {
                deviceAction(button);
            }

        }
    );

    loadDevices();
    setInterval(loadDevices, 10000);

})();
</script>

</body>

</html>
