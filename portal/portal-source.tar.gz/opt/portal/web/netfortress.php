<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Devices')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Devices</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
        }
        .nf-status-blocked {
            background: var(--theme-basic-error, #b83b3b);
            color: #fff;
        }
        .nf-status-online {
            background: var(--theme-basic-success, #237a4b);
            color: #fff;
        }
        .nf-note {
            margin-top: 10px;
            font-size: 13px;
            color: var(--theme-basic-text-secondary, #aebbc3);
        }
        #nfDevicesMessage {
            margin-top: 10px;
            font-size: 13px;
            display: none;
        }
        #nfDevicesMessage.nf-message-error {
            color: var(--theme-basic-error, #b83b3b);
            display: block;
        }
        #nfDevicesMessage.nf-message-ok {
            color: var(--theme-basic-success, #237a4b);
            display: block;
        }
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Devices - managed on the local Firewall Appliance.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel um-table-panel">

        <table id="nfDevicesTable">
            <thead>
            <tr>
                <th>Device</th>
                <th>IP Address</th>
                <th>MAC Address</th>
                <th>Interface</th>
                <th>First Seen</th>
                <th>Last Seen</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody id="nfDevicesBody">
            <tr>
                <td colspan="8">Loading devices from the appliance...</td>
            </tr>
            </tbody>
        </table>

        <div id="nfDevicesMessage"></div>

        <p class="nf-note">
            The device list is discovered live by the Firewall Appliance.
            Blocking a device adds an appliance blocking policy; assigning a
            device pins it to a VLAN / DHCP IP pool so its next DHCP request
            lands it on that pool. The list refreshes automatically every 10
            seconds.
        </p>

    </div>

</div>

<script>
(function () {

    const body = document.getElementById('nfDevicesBody');
    const message = document.getElementById('nfDevicesMessage');

    let loading = false;
    let lastSignature = null;

    function showMessage(text, ok) {

        if (!text) {
            message.className = '';
            message.textContent = '';
            return;
        }

        message.className = ok
            ? 'nf-message-ok'
            : 'nf-message-error';
        message.textContent = text;

    }

    function escapeHtml(value) {

        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');

    }

    function formatSeen(value) {

        if (!value) {
            return '-';
        }

        const date = new Date(value);

        if (isNaN(date.getTime())) {
            return escapeHtml(value);
        }

        return escapeHtml(
            date.toLocaleString()
        );

    }

    /* IP pools + reservations for the device-assignment flow. */

    let poolData = null;

    function poolForIp(pools, ip) {

        const parts = String(ip || '').split('.').map(Number);

        if (parts.length !== 4 || parts.some(isNaN)) {
            return null;
        }

        for (const pool of pools) {
            const start = String(pool.pool_start).split('.').map(Number);
            const end = String(pool.pool_end).split('.').map(Number);
            if (
                start.length === 4 &&
                end.length === 4 &&
                parts.every(function (value, index) {
                    return value >= start[index] && value <= end[index];
                })
            ) {
                return pool;
            }
        }

        return null;

    }

    function assignmentFor(device) {

        if (!poolData) {
            return null;
        }

        const mac =
            String(device.mac_address || '')
                .trim()
                .toLowerCase();

        if (!mac) {
            return null;
        }

        const reservation =
            (poolData.reservations || []).find(function (row) {
                return String(row.mac_address || '')
                    .trim()
                    .toLowerCase() === mac;
            });

        if (!reservation) {
            return null;
        }

        const pool = poolForIp(poolData.pools || [], reservation.ip_address);

        return pool ? { reservation: reservation, pool: pool } : null;

    }

    function renderRow(device, blockedPolicy, assigned) {

        const mac =
            String(device.mac_address || '')
                .trim()
                .toLowerCase();
        const ip =
            String(device.ip_address || '')
                .trim()
                .toLowerCase();
        const hostname =
            String(device.hostname || '')
                .trim()
                .toLowerCase();

        // Display label: real hostname when known, otherwise the IP
        // (neighbour-discovered devices often have no reverse DNS).
        const label =
            device.hostname || device.ip_address || 'Unknown device';

        // A device counts as blocked when an enabled appliance policy
        // targets its MAC, IP or hostname. MAC wins (device-specific).
        let policy = null;
        let targetType = 'ip';

        if (mac && blockedPolicy(mac)) {
            policy = blockedPolicy(mac);
            targetType = 'mac';
        } else if (ip && blockedPolicy(ip)) {
            policy = blockedPolicy(ip);
            targetType = 'ip';
        } else if (hostname && blockedPolicy(hostname)) {
            policy = blockedPolicy(hostname);
            targetType = 'hostname';
        }

        const row = document.createElement('tr');

        const blocked = policy !== null;

        let actionCell;

        if (blocked) {

            actionCell =
                '<button type="button" class="approve-btn nf-nf-action" ' +
                'data-action="unblock" ' +
                'data-policy-id="' + escapeHtml(policy.id) + '" ' +
                'data-label="' +
                escapeHtml(label) +
                '">Unblock</button>';

        } else {

            const targetValue =
                mac || ip;

            actionCell =
                '<button type="button" class="deny-btn nf-nf-action" ' +
                'data-action="block" ' +
                'data-target-type="' +
                (mac ? 'mac' : 'ip') + '" ' +
                'data-target-value="' +
                escapeHtml(targetValue) + '" ' +
                'data-label="' +
                escapeHtml(label) +
                '">Block</button>';

        }

        row.innerHTML =
            '<td><strong>' +
            escapeHtml(label) +
            '</strong>' +
            (assigned && assigned.pool
                ? '<br><span class="nf-note">VLAN ' +
                  escapeHtml(assigned.pool.vlan_id) +
                  ' &middot; ' +
                  escapeHtml(assigned.pool.name) +
                  '</span>'
                : '') +
            '</td>' +
            '<td>' + escapeHtml(device.ip_address || '-') + '</td>' +
            '<td>' + escapeHtml(device.mac_address || '-') + '</td>' +
            '<td>' + escapeHtml(device.interface || '-') + '</td>' +
            '<td>' + formatSeen(device.first_seen_at) + '</td>' +
            '<td>' + formatSeen(device.last_seen_at) + '</td>' +
            '<td>' +
            (
                blocked
                    ? '<span class="nf-status-badge nf-status-blocked">Blocked</span>'
                    : '<span class="nf-status-badge nf-status-online">Online</span>'
            ) +
            '</td>' +
            '<td>' + actionCell +
            (mac
                ? (assigned
                    ? ' <button type="button" class="deny-btn nf-nf-assign" ' +
                      'data-action="unassign" ' +
                      'data-reservation-id="' + escapeHtml(assigned.reservation.id) + '" ' +
                      'data-label="' + escapeHtml(label) + '">Unassign</button>'
                    : ' <button type="button" class="approve-btn nf-nf-assign" ' +
                      'data-action="assign" ' +
                      'data-mac="' + escapeHtml(device.mac_address) + '" ' +
                      'data-label="' + escapeHtml(label) + '">Assign</button>')
                : '') +
            '</td>';

        return row;

    }

    function loadDevices() {

        if (loading) {
            return;
        }

        loading = true;

        Promise.all([
            fetch('netfortress-api.php?action=devices')
                .then(function (response) {
                    return response.json();
                }),
            fetch('netfortress-api.php?action=pools')
                .then(function (response) {
                    return response.json();
                })
                .catch(function () {
                    return { success: false };
                })
        ])
            .then(function (results) {

                loading = false;

                const data = results[0];
                const pools = results[1];

                if (!data.success) {
                    lastSignature = null;
                    body.innerHTML =
                        '<tr><td colspan="8">' +
                        escapeHtml(data.message || 'The appliance is not reachable.') +
                        '</td></tr>';
                    return;
                }

                /* IP pools for the assignment flow - failures degrade
                   gracefully (buttons simply stay hidden). */

                poolData =
                    pools && pools.success
                        ? {
                            pools: pools.pools || [],
                            reservations: pools.reservations || []
                        }
                        : null;

                /* Only re-render when the data actually changed - a
                   rebuild on every poll causes a visible flash. */

                const signature = JSON.stringify([data, poolData]);

                if (signature === lastSignature) {
                    return;
                }

                lastSignature = signature;

                const blocked =
                    data.blocked_targets || {};

                body.innerHTML = '';

                const devices = data.devices || [];

                if (devices.length === 0) {
                    body.innerHTML =
                        '<tr><td colspan="8">No devices discovered yet.</td></tr>';
                    return;
                }

                devices.forEach(function (device) {
                    body.appendChild(
                        renderRow(
                            device,
                            function (key) {
                                return blocked[key] || null;
                            },
                            assignmentFor(device)
                        )
                    );
                });

            })
            .catch(function () {

                loading = false;

                body.innerHTML =
                    '<tr><td colspan="8">' +
                    'The appliance API is not reachable.</td></tr>';

            });

    }

    function deviceAction(button) {

        const action = button.dataset.action;
        const label = button.dataset.label || 'device';

        button.disabled = true;

        showMessage(
            (action === 'block' ? 'Blocking ' : 'Unblocking ') + label + '...',
            true
        );

        const payload =
            action === 'block'
                ? {
                    target_type: button.dataset.targetType,
                    target_value: button.dataset.targetValue,
                    reason: 'Blocked from the Portal'
                }
                : {
                    policy_id: parseInt(button.dataset.policyId, 10)
                };

        fetch('netfortress-api.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {

                if (data.success) {
                    showMessage(
                        (action === 'block' ? 'Blocked ' : 'Unblocked ') + label + '.',
                        true
                    );
                } else {
                    showMessage(
                        data.message || 'The appliance rejected the request.',
                        false
                    );
                }

                loadDevices();

            })
            .catch(function () {
                showMessage(
                    'The appliance API is not reachable.',
                    false
                );
                loadDevices();
            });

    }

    function unassignDevice(button) {

        const label = button.dataset.label || 'device';

        if (
            !confirm(
                'Remove the pool assignment for ' + label +
                '? The device returns to the normal DHCP pool.'
            )
        ) {
            return;
        }

        button.disabled = true;

        fetch('netfortress-api.php?action=unassign', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                reservation_id: parseInt(button.dataset.reservationId, 10)
            })
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (data.success) {
                    showMessage('Pool assignment removed for ' + label + '.', true);
                } else {
                    showMessage(data.message || 'The appliance rejected the request.', false);
                }
                loadDevices();
            })
            .catch(function () {
                showMessage('The appliance API is not reachable.', false);
                loadDevices();
            });

    }

    function confirmAssign(button, mac, cell) {

        const poolId =
            parseInt(cell.querySelector('.nf-assign-select').value, 10);
        const ip =
            String(cell.querySelector('.nf-assign-ip').value || '')
                .trim();

        button.disabled = true;

        showMessage('Assigning ' + (button.dataset.label || 'device') + ' to the pool...', true);

        fetch('netfortress-api.php?action=assign', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                mac_address: mac,
                pool_id: poolId,
                ip_address: ip
            })
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (data.success) {
                    showMessage(
                        'Assigned ' + (button.dataset.label || 'device') +
                        ' to the pool (' +
                        (data.reservation ? data.reservation.ip_address : '') + ').',
                        true
                    );
                } else {
                    showMessage(data.message || 'The appliance rejected the request.', false);
                }
                loadDevices();
            })
            .catch(function () {
                showMessage('The appliance API is not reachable.', false);
                loadDevices();
            });

    }

    function assignDevice(button) {

        const action = button.dataset.action;

        if (action === 'unassign') {
            unassignDevice(button);
            return;
        }

        const mac = button.dataset.mac;
        const label = button.dataset.label || 'device';
        const pools =
            (poolData && poolData.pools ? poolData.pools : [])
                .filter(function (pool) {
                    return pool.enabled;
                });

        if (pools.length === 0) {
            alert(
                'No IP pools are configured yet. Create one under ' +
                'Services > Network > NetFortress first.'
            );
            return;
        }

        /* Inline expansion: swap the button for a pool picker. */

        const cell = button.parentElement;

        cell.innerHTML =
            '<select class="nf-assign-select">' +
            pools.map(function (pool) {
                return '<option value="' + escapeHtml(pool.id) + '">' +
                    'VLAN ' + escapeHtml(pool.vlan_id) + ' - ' +
                    escapeHtml(pool.name) +
                    ' (' + escapeHtml(pool.pool_start) + ' - ' +
                    escapeHtml(pool.pool_end) + ')' +
                    '</option>';
            }).join('') +
            '</select> ' +
            '<input class="nf-assign-ip" placeholder="IP (optional)" ' +
            'style="width:130px"> ' +
            '<button type="button" class="approve-btn nf-assign-confirm" ' +
            'data-mac="' + escapeHtml(mac) + '" ' +
            'data-label="' + escapeHtml(label) + '">Assign</button> ' +
            '<button type="button" class="deny-btn nf-assign-cancel">Cancel</button>';

        cell.querySelector('.nf-assign-confirm').addEventListener(
            'click',
            function (event) {
                const confirmButton = event.target;
                confirmAssign(
                    confirmButton,
                    confirmButton.dataset.mac,
                    cell
                );
            }
        );

        cell.querySelector('.nf-assign-cancel').addEventListener(
            'click',
            function () {
                loadDevices();
            }
        );

    }

    document.addEventListener(
        'click',
        function (event) {

            const button = event.target.closest('.nf-nf-action');

            if (button) {
                deviceAction(button);
            }

            const assignButton = event.target.closest('.nf-nf-assign');

            if (assignButton) {
                assignDevice(assignButton);
            }

        }
    );

    loadDevices();
    setInterval(loadDevices, 10000);

})();
</script>

</body>

</html>
