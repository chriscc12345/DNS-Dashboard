<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Monitor board background save
 * proxy. Stores the background
 * colour and image path in the
 * portal settings; clearing the
 * image also removes its file.
 */

header('Content-Type: application/json');

if (!hasPermission('Edit Monitor')) {

    http_response_code(403);

    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    echo json_encode([
        'success' => false,
        'message' => 'POST required.'
    ]);
    exit;
}

$body =
    json_decode(
        (string)file_get_contents(
            'php://input'
        ),
        true
    );

$settings =
    $body['settings']
    ?? null;

if (!is_array($settings)) {

    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'No settings received.'
    ]);
    exit;
}

/* only the two known background
   keys may pass through */

$clean = [];

$allowed = [
    'monitor_background_color',
    'monitor_background_image',
    'monitor_card_background',
    'monitor_card_opacity',
    'monitor_table_color',
    'monitor_table_alt_color',
    'monitor_table_grid_color',
    'monitor_text_color',
    'monitor_table_opacity',
    'monitor_table_grid_enabled',
    'monitor_card_styles'
];

foreach ($allowed as $key) {

    if (array_key_exists($key, $settings)) {

        $clean[$key] =
            trim(
                (string)$settings[$key]
            );
    }
}

if (count($clean) === 0) {

    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'No background keys received.'
    ]);
    exit;
}

/* a cleared image also deletes the
   stored file */

if (
    array_key_exists(
        'monitor_background_image',
        $clean
    )
    && $clean['monitor_background_image'] === ''
) {

    $current =
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        );

    $decoded =
        json_decode(
            (string)$current,
            true
        );

    $oldImage =
        is_array($decoded)
            ? trim(
                (string)(
                    $decoded[
                        'monitor_background_image'
                    ] ?? ''
                )
            )
            : '';

    if (
        preg_match(
            '#^uploads/appearance/'
            . 'monitor_bg_[a-f0-9]{32}'
            . '\.webp$#',
            $oldImage
        )
    ) {

        $absolute =
            '/opt/portal/web/'
            . $oldImage;

        if (is_file($absolute)) {
            @unlink($absolute);
        }
    }
}

$payload =
    json_encode([
        'settings' => $clean
    ]);

$result =
    @file_get_contents(
        $FASTAPI_URL
        . '/portal-settings/appearance',
        false,
        stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' =>
                    "Content-Type: "
                    . "application/json\r\n",
                'content' => $payload
            ]
        ])
    );

if ($result === false) {

    http_response_code(502);

    echo json_encode([
        'success' => false,
        'message' =>
            'Unable to save the background.'
    ]);
    exit;
}

echo json_encode([
    'success' => true,
    'settings' => $clean
]);
