<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';

if (
    !hasPermission(
        'Blocking'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'blocking';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

/*
 * Read the live blocking settings from
 * the Technitium DNS server API for the
 * initial render. The page keeps them
 * fresh through technitium-blocking-api.php.
 */

function technitiumBlockingSettings() {

    global $TECHNITIUM_HOST, $TECHNITIUM_TOKEN;

    $ch = curl_init(
        'http://' . $TECHNITIUM_HOST
        . ':5380/api/settings/get'
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer '
            . $TECHNITIUM_TOKEN
        ],
        CURLOPT_TIMEOUT => 10
    ]);

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    $json = json_decode($body, true);

    if (
        !is_array($json)
        || ($json['status'] ?? '') !== 'ok'
    ) {
        return null;
    }

    return $json['response'] ?? [];
}

$technitiumSettings =
    technitiumBlockingSettings();

$blockingEnabled =
    (bool)(
        $technitiumSettings['enableBlocking']
        ?? false
    );

$blockingType =
    (string)(
        $technitiumSettings['blockingType']
        ?? 'NxDomain'
    );

$blockListUrls =
    is_array(
        $technitiumSettings['blockListUrls']
        ?? null
    )
        ? $technitiumSettings['blockListUrls']
        : [];

$blockListUrlsText =
    implode("\n", $blockListUrls);

$updateIntervalHours =
    (int)(
        $technitiumSettings[
            'blockListUpdateIntervalHours'
        ]
        ?? 24
    );

$nextUpdatedOn =
    trim(
        (string)(
            $technitiumSettings[
                'blockListNextUpdatedOn'
            ]
            ?? ''
        )
    );

$nextUpdatedOnText = 'Not Set';

if ($nextUpdatedOn !== '') {

    try {
        $nextDate =
            new DateTime($nextUpdatedOn);

        $nextUpdatedOnText =
            $nextDate->format('Y-m-d H:i:s')
            . ' UTC';
    } catch (Exception $e) {
        $nextUpdatedOnText = 'Not Set';
    }
}

$customBlockingAddresses =
    is_array(
        $technitiumSettings[
            'customBlockingAddresses'
        ]
        ?? null
    )
        ? $technitiumSettings[
            'customBlockingAddresses'
        ]
        : [];

$customBlockingText =
    implode("\n", $customBlockingAddresses);

/*
 * Quick Add catalog mirrors the
 * Technitium console quick add list.
 */

$quickBlockLists =
    is_readable(
        __DIR__
        . '/json/quick-block-lists.json'
    )
        ? json_decode(
            file_get_contents(
                __DIR__
                . '/json/quick-block-lists.json'
            ),
            true
        )
        : [];

if (!is_array($quickBlockLists)) {
    $quickBlockLists = [];
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Technitium - Blocking</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Technitium</h1>

            <p>
                Manage the Technitium DNS server.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="settings-saved" id="blocking_saved" hidden>
        Settings saved.
    </div>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Blocking</h2>

                <p>
                    Enable or disable DNS level blocking and pick how blocked domains are answered.
                </p>
            </div>

        </div>

        <div class="settings-form">

            <div class="settings-field">

                <label for="toggle_blocking">
                    Enable Blocking
                </label>

                <button
                    type="button"
                    id="toggle_blocking"
                    data-enabled="<?= $blockingEnabled
                        ? 'true'
                        : 'false' ?>"
                    class="<?= $blockingEnabled
                        ? 'badge-active'
                        : 'badge-disabled' ?>">
                    <?= $blockingEnabled
                        ? 'Enabled'
                        : 'Disabled' ?>
                </button>

            </div>

            <div class="settings-field">

                <label for="blocking_type">
                    Blocking Type
                </label>

                <select
                    id="blocking_type"
                    class="table-control">

                    <option
                        value="AnyAddress"
                        <?= $blockingType === 'AnyAddress'
                            ? 'selected'
                            : '' ?>>
                        ANY Address
                    </option>

                    <option
                        value="NxDomain"
                        <?= $blockingType === 'NxDomain'
                            ? 'selected'
                            : '' ?>>
                        NX Domain (recommended)
                    </option>

                    <option
                        value="CustomAddress"
                        <?= $blockingType === 'CustomAddress'
                            ? 'selected'
                            : '' ?>>
                        Custom Address
                    </option>

                </select>

            </div>

            <div class="settings-field">

                <label for="custom_blocking_addresses">
                    Custom Blocking Address
                </label>

                <textarea
                    id="custom_blocking_addresses"
                    class="table-control"
                    rows="3"
                    spellcheck="false"
                    <?= $blockingType !== 'CustomAddress'
                        ? 'disabled'
                        : '' ?>><?= htmlspecialchars(
                            $customBlockingText
                        ) ?></textarea>

                <p class="appearance-help">
                    One IP address per line. Used only
                    when Blocking Type is Custom Address.
                </p>

            </div>

            <p class="appearance-help">
                Blocking uses the Blocked Zone and the
                Block List Zone to sinkhole domain names.
            </p>

            <button
                type="button"
                id="save_blocking"
                class="approve-btn">
                Save
            </button>

        </div>

    </div>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Block Lists</h2>

                <p>
                    Block list URLs the DNS server downloads and applies automatically.
                </p>
            </div>

        </div>

        <div class="settings-form">

            <div class="settings-field">

                <label for="quick_add">
                    Quick Add
                </label>

                <select
                    id="quick_add"
                    class="table-control">

                    <option value="">
                        - Select a list -
                    </option>

                    <option value="none">
                        None
                    </option>

                    <?php foreach (
                        $quickBlockLists
                        as $quickList
                    ): ?>

                    <option
                        value="<?= htmlspecialchars(
                            (string)(
                                $quickList['name']
                                ?? ''
                            )
                        ) ?>">
                        <?= htmlspecialchars(
                            (string)(
                                $quickList['name']
                                ?? ''
                            )
                        ) ?>
                    </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <div class="settings-field">

                <label for="block_list_urls">
                    Block List URLs
                </label>

                <textarea
                    id="block_list_urls"
                    class="table-control"
                    rows="6"
                    spellcheck="false"><?= htmlspecialchars(
                        $blockListUrlsText
                    ) ?></textarea>

                <p class="appearance-help">
                    One URL per line. Prefix a URL with !
                    to use it as an allow list instead.
                </p>

            </div>

            <div class="settings-field-row">

                <div class="settings-field">

                    <label for="update_interval">
                        Update Interval (hours)
                    </label>

                    <input
                        type="number"
                        id="update_interval"
                        min="0"
                        max="168"
                        value="<?= (int)$updateIntervalHours ?>"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label>
                        Next Update
                    </label>

                    <span
                        class="blocking-next-value"
                        id="next_update">
                        <?= htmlspecialchars(
                            $nextUpdatedOnText
                        ) ?>
                    </span>

                </div>

            </div>

            <div class="settings-field">

                <label>
                    Manual Update
                </label>

                <button
                    type="button"
                    id="update_now"
                    class="approve-btn"
                    <?= $blockListUrlsText === ''
                        ? 'disabled'
                        : '' ?>>
                    Update Now
                </button>

                <p class="appearance-help">
                    Reset the next update schedule and
                    force download and update of the block
                    lists now.
                </p>

            </div>

            <p class="appearance-help">
                Set the interval to 0 to disable automatic
                updates. The next update is refreshed after
                every save.
            </p>

            <button
                type="button"
                id="save_block_lists"
                class="approve-btn">
                Save
            </button>

        </div>

    </div>

</div>

<script>
const quickBlockLists =
    <?= json_encode($quickBlockLists) ?>;

const blockingApi =
    'technitium-blocking-api.php';

const blockingToggle =
    document.getElementById('toggle_blocking');
const blockingTypeSelect =
    document.getElementById('blocking_type');
const customBlockingBox =
    document.getElementById(
        'custom_blocking_addresses'
    );
const blockListUrlsBox =
    document.getElementById('block_list_urls');
const updateIntervalInput =
    document.getElementById('update_interval');
const nextUpdateValue =
    document.getElementById('next_update');
const blockingSavedBox =
    document.getElementById('blocking_saved');
const updateNowButton =
    document.getElementById('update_now');

let savedFlashTimer = null;

function setBlockingToggle(enabled) {

    blockingToggle.dataset.enabled =
        enabled ? 'true' : 'false';

    blockingToggle.classList.toggle(
        'badge-active',
        enabled
    );

    blockingToggle.classList.toggle(
        'badge-disabled',
        !enabled
    );

    blockingToggle.textContent =
        enabled ? 'Enabled' : 'Disabled';
}

function syncCustomBlockingField() {

    customBlockingBox.disabled =
        blockingTypeSelect.value
            !== 'CustomAddress';
}

function formatNextUpdate(iso) {

    if (!iso) {
        return 'Not Set';
    }

    const nextDate = new Date(iso);

    if (isNaN(nextDate)) {
        return 'Not Set';
    }

    return nextDate
        .toISOString()
        .slice(0, 19)
        .replace('T', ' ')
        + ' UTC';
}

function applyBlockingView(view) {

    if (!view || view.success !== true) {
        return;
    }

    setBlockingToggle(
        !!view.enable_blocking
    );

    blockingTypeSelect.value =
        view.blocking_type || 'NxDomain';

    customBlockingBox.value =
        (view.custom_blocking_addresses || [])
            .join('\n');

    syncCustomBlockingField();

    blockListUrlsBox.value =
        (view.block_list_urls || []).join('\n');

    updateIntervalInput.value =
        view.block_list_update_interval_hours ?? 24;

    nextUpdateValue.textContent =
        formatNextUpdate(
            view.block_list_next_updated_on
        );

    updateNowButton.disabled =
        !(view.block_list_urls || []).length;
}

function showBlockingMessage(message) {

    blockingSavedBox.hidden = false;
    blockingSavedBox.textContent = message;

    if (savedFlashTimer) {
        clearTimeout(savedFlashTimer);
    }

    savedFlashTimer = setTimeout(() => {
        blockingSavedBox.hidden = true;
    }, 4000);
}

async function refreshBlocking() {

    try {

        const response = await fetch(
            blockingApi + '?action=get'
        );

        applyBlockingView(
            await response.json()
        );

    } catch (error) {
        /* keep the server rendered values */
    }
}

blockingToggle.addEventListener(
    'click',
    () => {
        setBlockingToggle(
            blockingToggle.dataset.enabled
                !== 'true'
        );
    }
);

blockingTypeSelect.addEventListener(
    'change',
    syncCustomBlockingField
);

document
    .getElementById('quick_add')
    .addEventListener('change', (event) => {

        const choice = event.target.value;

        if (choice === '') {
            return;
        }

        if (choice === 'none') {
            blockListUrlsBox.value = '';
            event.target.value = '';
            return;
        }

        const entry = quickBlockLists.find(
            (item) => item.name === choice
        );

        if (!entry) {
            event.target.value = '';
            return;
        }

        let list =
            choice.toLowerCase() === 'default'
                ? ''
                : blockListUrlsBox.value;

        for (const url of entry.urls || []) {

            if (list.indexOf(url) < 0) {

                if (
                    list !== ''
                    && !list.endsWith('\n')
                ) {
                    list += '\n';
                }

                list += url + '\n';
            }
        }

        blockListUrlsBox.value = list;
        event.target.value = '';
    }
);

async function postBlockingSet(params) {

    const response = await fetch(
        blockingApi,
        {
            method: 'POST',
            body: new URLSearchParams(
                Object.assign(
                    { action: 'set' },
                    params
                )
            )
        }
    );

    const json = await response.json();

    if (json.success !== true) {
        showBlockingMessage(
            json.message || 'Update failed.'
        );
        return false;
    }

    applyBlockingView(json);
    return true;
}

document
    .getElementById('save_blocking')
    .addEventListener('click', async () => {

        const ok = await postBlockingSet({
            enable_blocking:
                blockingToggle.dataset.enabled
                    === 'true'
                    ? '1'
                    : '0',
            blocking_type:
                blockingTypeSelect.value,
            custom_blocking_addresses:
                customBlockingBox.value
        });

        if (ok) {
            showBlockingMessage(
                'Blocking settings saved.'
            );
        }
    }
);

document
    .getElementById('save_block_lists')
    .addEventListener('click', async () => {

        const ok = await postBlockingSet({
            block_list_urls: blockListUrlsBox.value,
            block_list_update_interval_hours:
                updateIntervalInput.value
        });

        if (ok) {
            showBlockingMessage(
                'Block list settings saved.'
            );
        }
    }
);

if (updateNowButton) {

    updateNowButton.addEventListener(
        'click',
        async () => {

            updateNowButton.disabled = true;

            try {

                const response = await fetch(
                    blockingApi,
                    {
                        method: 'POST',
                        body: new URLSearchParams({
                            action: 'force_update'
                        })
                    }
                );

                const json =
                    await response.json();

                if (json.success !== true) {
                    showBlockingMessage(
                        json.message
                            || 'Update failed.'
                    );
                    updateNowButton.disabled =
                        blockListUrlsBox.value
                            .trim() !== '';
                    return;
                }

                applyBlockingView(json);
                showBlockingMessage(
                    'Block lists update started. '
                    + 'Next update rescheduled.'
                );

            } catch (error) {

                showBlockingMessage(
                    'Update failed.'
                );

                updateNowButton.disabled =
                    blockListUrlsBox.value
                        .trim() !== '';
            }
        }
    );
}

refreshBlocking();
</script>

</body>

</html>
