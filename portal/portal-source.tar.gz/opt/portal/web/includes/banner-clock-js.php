<script>
(function () {

    /*
     * Portal time zone: falls back to the browser
     * default when unset or invalid.
     */

    const basicBannerTimezone = (function () {

        const wrap =
            document.getElementById(
                'basicBannerClock'
            );

        const tz =
            wrap && wrap.dataset.tz
                ? wrap.dataset.tz.trim()
                : '';

        if (!tz) {
            return undefined;
        }

        try {

            new Intl.DateTimeFormat(
                undefined,
                { timeZone: tz }
            );

            return tz;

        } catch (error) {
            return undefined;
        }
    })();

    function updateBasicBannerClock() {

        const now = new Date();

        const dayElement =
            document.getElementById('basicBannerDay');

        const dateElement =
            document.getElementById('basicBannerDate');

        const timeElement =
            document.getElementById('basicBannerTime');

        if (!dayElement || !dateElement || !timeElement) {
            return;
        }

        dayElement.textContent =
            new Intl.DateTimeFormat(
                undefined,
                {
                    weekday: 'long',
                    timeZone: basicBannerTimezone
                }
            ).format(now);

        dateElement.textContent =
            new Intl.DateTimeFormat(
                undefined,
                {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                    timeZone: basicBannerTimezone
                }
            ).format(now);

        timeElement.textContent =
            new Intl.DateTimeFormat(
                undefined,
                {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    timeZone: basicBannerTimezone
                }
            ).format(now);
    }

    updateBasicBannerClock();

    window.setInterval(
        updateBasicBannerClock,
        1000
    );

    /* =====================================================
       UPDATE004 - ANIMATED WEATHER BADGE
       Open-Meteo current weather, cached 10 minutes.
       The badge renders an animated icon matching the
       live WMO weather code.
       ===================================================== */

    function weatherIconSun() {
        return '<svg viewBox="0 0 48 48">'
            + '<g class="wx-rays">'
            + '<path d="M24 1.5 L27 10 L21 10 Z"/><path d="M24 46.5 L27 38 L21 38 Z"/>'
            + '<path d="M1.5 24 L10 21 L10 27 Z"/><path d="M46.5 24 L38 21 L38 27 Z"/>'
            + '<path d="M7.5 7.5 L16.2 10.8 L11.2 15.8 Z"/><path d="M40.5 40.5 L31.8 37.2 L36.8 32.2 Z"/>'
            + '<path d="M7.5 40.5 L10.8 31.8 L15.8 36.8 Z"/><path d="M40.5 7.5 L37.2 16.2 L32.2 11.2 Z"/>'
            + '</g>'
            + '<circle class="wx-glow" cx="24" cy="24" r="15.5"/>'
            + '<circle class="wx-core" cx="24" cy="24" r="9.5"/>'
            + '</svg>';
    }

    function weatherIconMoon() {
        return '<svg viewBox="0 0 48 48">'
            + '<circle class="wx-moon-glow" cx="24" cy="24" r="17"/>'
            + '<path class="wx-moon" d="M30.5 4 A17.5 17.5 0 1 0 44 30.5 A13.5 13.5 0 0 1 30.5 4 Z"/>'
            + '<circle class="wx-star" cx="40" cy="9" r="1.5"/>'
            + '<circle class="wx-star" cx="43.5" cy="16" r="1.1"/>'
            + '<circle class="wx-star" cx="35" cy="5" r="1"/>'
            + '</svg>';
    }

    function weatherIconMoonCloud() {
        return '<svg viewBox="0 0 48 48">'
            + '<g class="wx-mini-moon">'
            + '<path class="wx-moon" d="M24 7 A11 11 0 1 0 33.5 20.5 A8.5 8.5 0 0 1 24 7 Z"/>'
            + '</g>'
            + '<g class="wx-drift">'
            + weatherIconCloud(false)
            + '</g>'
            + '</svg>';
    }

    function weatherIconCloud(shade) {
        return '<path class="wx-cloud' + (shade ? ' wx-cloud-shade' : '') + '" d="'
            + 'M14 34 h20 a7 7 0 0 0 1.4 -13.8 '
            + 'a10 10 0 0 0 -19.3 -2.6 '
            + 'a8 8 0 0 0 -2.1 16.4 Z"/>';
    }

    function weatherIconRain(kind) {
        return '<svg viewBox="0 0 48 48">'
            + '<g class="wx-drift">'
            + weatherIconCloud(false)
            + '</g>'
            + '<g class="wx-drops">'
            + '<line x1="18" y1="36" x2="16" y2="43"/>'
            + '<line x1="25" y1="36" x2="23" y2="43"/>'
            + '<line x1="32" y1="36" x2="30" y2="43"/>'
            + '</g>'
            + '</svg>';
    }

    function weatherIconSnow() {
        return '<svg viewBox="0 0 48 48">'
            + '<g class="wx-drift">'
            + weatherIconCloud(false)
            + '</g>'
            + '<g class="wx-flakes">'
            + '<circle cx="18" cy="39" r="1.6"/>'
            + '<circle cx="26" cy="40" r="1.6"/>'
            + '<circle cx="34" cy="39" r="1.6"/>'
            + '</g>'
            + '</svg>';
    }

    function weatherIconStorm() {
        return '<svg viewBox="0 0 48 48">'
            + '<g class="wx-drift">'
            + weatherIconCloud(false)
            + '</g>'
            + '<path class="wx-bolt" d="M25 33 L19 43 L24 43 L22 48 L30 37 L25 37 L28 33 Z"/>'
            + '</svg>';
    }

    function weatherIconFog() {
        return '<svg viewBox="0 0 48 48">'
            + '<g class="wx-drift">'
            + weatherIconCloud(true)
            + '</g>'
            + '<g class="wx-fog">'
            + '<line x1="12" y1="39" x2="36" y2="39"/>'
            + '<line x1="16" y1="44" x2="32" y2="44"/>'
            + '</g>'
            + '</svg>';
    }

    function weatherIconSunCloud() {
        return '<svg viewBox="0 0 48 48">'
            + '<g class="wx-mini-sun">'
            + '<circle cx="18" cy="16" r="7"/>'
            + '<path d="M18 3 L20 8 L16 8 Z"/><path d="M5 16 L10 14 L10 18 Z"/>'
            + '<path d="M9 7 L13.5 9.5 L10.5 12.5 Z"/>'
            + '</g>'
            + '<g class="wx-drift">'
            + weatherIconCloud(false)
            + '</g>'
            + '</svg>';
    }

    function describeWeather(code, isDay) {

        code = Number(code) || 0;

        isDay =
            isDay !== 0
            && isDay !== '0'
            && isDay !== false
            && isDay !== undefined;

        if (code === 0) {
            return {
                label: isDay ? 'Clear' : 'Clear Night',
                icon: isDay ? weatherIconSun() : weatherIconMoon()
            };
        }

        if (code === 1) {
            return {
                label: isDay ? 'Mostly Clear' : 'Mostly Clear',
                icon: isDay ? weatherIconSun() : weatherIconMoon()
            };
        }

        if (code === 2) {
            return {
                label: 'Partly Cloudy',
                icon: isDay
                    ? weatherIconSunCloud()
                    : weatherIconMoonCloud()
            };
        }

        if (code === 3) {
            return { label: 'Overcast', icon: weatherIconFog() };
        }

        if (code === 45 || code === 48) {
            return { label: 'Fog', icon: weatherIconFog() };
        }

        if (code >= 51 && code <= 57) {
            return { label: 'Drizzle', icon: weatherIconRain() };
        }

        if (code >= 61 && code <= 67) {
            return { label: 'Rain', icon: weatherIconRain() };
        }

        if (code >= 71 && code <= 77) {
            return { label: 'Snow', icon: weatherIconSnow() };
        }

        if (code >= 80 && code <= 82) {
            return { label: 'Showers', icon: weatherIconRain() };
        }

        if (code === 85 || code === 86) {
            return { label: 'Snow Showers', icon: weatherIconSnow() };
        }

        if (code >= 95) {
            return { label: 'Thunderstorm', icon: weatherIconStorm() };
        }

        return {
            label: 'Cloudy',
            icon: isDay
                ? weatherIconSunCloud()
                : weatherIconMoonCloud()
        };
    }

    async function updateBasicBannerWeather() {

        const wrap =
            document.getElementById(
                'basicBannerWeather'
            );

        if (!wrap) {
            return;
        }

        const lat = wrap.dataset.lat;
        const lon = wrap.dataset.lon;

        const cacheKey =
            'portalWeather_' + lat + '_' + lon;

        let data = null;

        try {

            const cached =
                sessionStorage.getItem(cacheKey);

            if (cached) {

                const parsed = JSON.parse(cached);

                if (Date.now() - parsed.fetchedAt < 600000) {
                    data = parsed;
                }
            }

        } catch (error) {
            /* cache unavailable - fetch fresh */
        }

        if (!data || !data.current) {

            try {

                const url =
                    'https://api.open-meteo.com/v1/forecast'
                    + '?latitude=' + encodeURIComponent(lat)
                    + '&longitude=' + encodeURIComponent(lon)
                    + '&current=weather_code,temperature_2m,is_day';

                const response = await fetch(url);

                const fresh = await response.json();

                fresh.fetchedAt = Date.now();

                try {
                    sessionStorage.setItem(
                        cacheKey,
                        JSON.stringify(fresh)
                    );
                } catch (error) {
                    /* storage full - ignore */
                }

                data = fresh;

            } catch (error) {

                /* offline or blocked - keep hidden */
                return;
            }
        }

        const current = data && data.current;

        if (!current) {
            return;
        }

        const badge =
            document.getElementById('weatherBadge');

        const tempElement =
            document.getElementById('weatherTemp');

        const condElement =
            document.getElementById('weatherCond');

        if (!badge || !tempElement || !condElement) {
            return;
        }

        const info =
            describeWeather(
                current.weather_code,
                current.is_day
            );

        badge.innerHTML = info.icon;

        tempElement.textContent =
            Math.round(current.temperature_2m)
            + '\u00B0C';

        condElement.textContent = info.label;

        wrap.hidden = false;
    }

    updateBasicBannerWeather();

    window.setInterval(
        updateBasicBannerWeather,
        600000
    );



    /* the monitor board weather card reuses this
       icon + label engine */
    window.describeWeather = describeWeather;

})();
</script>
