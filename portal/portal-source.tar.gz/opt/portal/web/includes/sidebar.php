

<div class="sidebar" id="sidebar">

    <div class="sidebar-toggle" onclick="toggleSidebar()">
    
        <span class="material-symbols-outlined">
            menu
        </span>
    
    </div>
    
    <h2>Menu</h2><br>
    
    <div class="sidebar-user">
            Logged in as:<br>
        <strong>
            <?= htmlspecialchars($_SESSION['displayName']) ?>
        </strong>
    </div>
    
    <?php if(hasPermission('Dashboard')): ?>
    
    <a href="dashboard.php"
       class="<?= ($currentPage == 'dashboard') ? 'active' : '' ?>">
    
        <?php if($currentPage == 'dashboard'): ?>
            &raquo;
        <?php endif; ?>
    
        <span class="material-symbols-outlined">home</span>
    
        <span class="nav-text">
            Dashboard
        </span>
    
    </a>
    
    <?php endif; ?>

    
    <?php if(hasPermission('Pending Requests')): ?>
    
    <a href="admin.php"
        class="<?= $currentPage == 'admin' ? 'active' : '' ?>">
        
        <?php if($currentPage == 'admin'): ?>
            &raquo;
        <?php endif; ?>
        
        <span class="material-symbols-outlined">pending_actions</span>
        <span class="nav-text">
        Pending
        </span>
    </a>
    
    <?php endif; ?>
    
    <?php if(hasPermission('Approve Requests')): ?>
    
    <a href="approved.php"
        class="<?= $currentPage == 'approved' ? 'active' : '' ?>">
        
        <?php if($currentPage == 'approved'): ?>
            &raquo;
        <?php endif; ?>
        
        <span class="material-symbols-outlined">check_circle</span>
        <span class="nav-text">
        Approved
        </span>
    </a>
    
    <?php endif; ?>
    
    <?php if(hasPermission('Deny Requests')): ?>
    
    <a href="denied.php"
        class="<?= $currentPage == 'denied' ? 'active' : '' ?>">
        
        <?php if($currentPage == 'denied'): ?>
            &raquo;
        <?php endif; ?>
        
        <span class="material-symbols-outlined">cancel</span>
        <span class="nav-text">
        Denied
        </span>
    </a>
    
    <?php endif; ?>
    
    <?php if(
        hasAnyPermission([
            'Appearance',
            'Banner',
            'Logo',
            'Portal Name',
            'Favicon',
            'Background',
            'Button Colours',
            'Login',
        
            'Security',
            'HTTPS/SSL',
            'Users',
            'User Groups',
            'Session Timeout',
            '3rd Party Integrations',
            'Data Deletion',
        
            'Notifications',
            'Email Notifications',
            'Push Notifications',
            'WhatsApp/Telegram Integration',
        
            'DNS Server',
            'Flush Cache',
            'Enable/Disable Cache',
            'Enable/Disable Blocking',
            'Allow Lists',
            'Block Lists',
            'Network Proxy',
            'DHCP',
        
            'System Status',
            'Database Server',
            'API Server',
            'DNS Server Status'
        ])
    ): ?>
    
    <a href="settings.php"
        class="<?= $currentPage == 'settings' ? 'active' : '' ?>">
    
        <?php if($currentPage == 'settings'): ?>
            &raquo;
        <?php endif; ?>
    
        <span class="material-symbols-outlined">
            settings
        </span>
    
        <span class="nav-text">
            Settings
        </span>
    
    </a>
    
    <?php endif; ?>
    
   
        <a href="logout.php">
    
        <span class="material-symbols-outlined">
            logout
        </span>
    
        <span class="nav-text">
            Logout
        </span>
    
    </a>

</div>

<script>

function toggleSidebar() {

    const sidebar = document.getElementById('sidebar');

    sidebar.classList.toggle('collapsed');

    localStorage.setItem(
        'sidebarCollapsed',
        sidebar.classList.contains('collapsed')
    );
}

window.onload = function() {

    const sidebar = document.getElementById('sidebar');

    if(localStorage.getItem('sidebarCollapsed') === 'true') {

        sidebar.classList.add('collapsed');

    }

}

</script>


