

<?php
$currentSection =
    $currentSection
    ?? $currentPage
    ?? '';


/*
 * UPDATE003 - Basic Appearance Logo
 */

$sidebarAppearanceSettings = [];

if (isset($FASTAPI_URL)) {

    $sidebarAppearanceResponse =
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        );

    if ($sidebarAppearanceResponse !== false) {

        $sidebarAppearanceDecoded =
            json_decode(
                $sidebarAppearanceResponse,
                true
            );

        if (is_array($sidebarAppearanceDecoded)) {
            $sidebarAppearanceSettings =
                $sidebarAppearanceDecoded;
        }
    }
}


$sidebarCompanyLogo =
    trim(
        (string)(
            $sidebarAppearanceSettings['company_logo']
            ?? ''
        )
    );

$sidebarShowCompanyLogo =
    strtolower(
        (string)(
            $sidebarAppearanceSettings['show_logo_sidebar']
            ?? 'true'
        )
    ) === 'true';

$sidebarCompanyLogoSize =
    (int)(
        $sidebarAppearanceSettings['sidebar_logo_size']
        ?? 100
    );

if (
    $sidebarCompanyLogoSize < 40
    ||
    $sidebarCompanyLogoSize > 180
) {
    $sidebarCompanyLogoSize = 100;
}


/*
 * UPDATE003 - configurable expanded Basic sidebar layout.
 * Collapsed dimensions remain fixed in CSS.
 */
$sidebarConfiguredWidth =
    (int)(
        $sidebarAppearanceSettings['sidebar_width']
        ?? 260
    );

if (
    $sidebarConfiguredWidth < 220
    ||
    $sidebarConfiguredWidth > 340
) {
    $sidebarConfiguredWidth = 260;
}


$sidebarConfiguredAvatarSize =
    (int)(
        $sidebarAppearanceSettings['sidebar_avatar_size']
        ?? 64
    );

if (
    $sidebarConfiguredAvatarSize < 36
    ||
    $sidebarConfiguredAvatarSize > 64
) {
    $sidebarConfiguredAvatarSize = 64;
}


$sidebarConfiguredNavTextSize =
    (int)(
        $sidebarAppearanceSettings['sidebar_nav_text_size']
        ?? 15
    );

if (
    $sidebarConfiguredNavTextSize < 13
    ||
    $sidebarConfiguredNavTextSize > 20
) {
    $sidebarConfiguredNavTextSize = 15;
}


$sidebarConfiguredCollapseButtonSize =
    (int)(
        $sidebarAppearanceSettings['sidebar_collapse_button_size']
        ?? 46
    );

if (
    $sidebarConfiguredCollapseButtonSize < 36
    ||
    $sidebarConfiguredCollapseButtonSize > 64
) {
    $sidebarConfiguredCollapseButtonSize = 46;
}


/*
 * UPDATE003 - authenticated user's sidebar profile photo.
 *
 * Resolve the profile from the same FastAPI endpoint used
 * by My Profile. Fall back to the person icon if unavailable.
 */

$sidebarProfilePhoto = '';

$sidebarUsername =
    isset($_SESSION['username'])
        ? trim((string)$_SESSION['username'])
        : '';

if (
    isset($FASTAPI_URL)
    &&
    $sidebarUsername !== ''
) {

    $sidebarProfileResponse =
        @file_get_contents(
            $FASTAPI_URL
            . '/user-profiles/'
            . rawurlencode($sidebarUsername)
        );

    if ($sidebarProfileResponse !== false) {

        $sidebarProfileDecoded =
            json_decode(
                $sidebarProfileResponse,
                true
            );

        if (is_array($sidebarProfileDecoded)) {

            $candidatePhoto =
                trim(
                    (string)(
                        $sidebarProfileDecoded['photo']
                        ?? ''
                    )
                );

            if (
                preg_match(
                    '#^uploads/profiles/profile_[a-f0-9]{32}\\.webp$#',
                    $candidatePhoto
                )
            ) {
                $sidebarProfilePhoto =
                    $candidatePhoto;
            }
        }
    }
}
/*
 * UPDATE003 - Basic Theme runtime colours.
 * Reuse the portal settings already loaded by this component.
 */
$basicThemeSettings = $sidebarAppearanceSettings;

ob_start();
include __DIR__ . '/basic-theme.php';
$basicThemeRuntimeCss = ob_get_clean();
?>
<?= $basicThemeRuntimeCss ?>

<style>
:root {
    --basic-sidebar-width:
        <?= $sidebarConfiguredWidth ?>px;

    --basic-sidebar-avatar-size:
        <?= $sidebarConfiguredAvatarSize ?>px;

    --basic-sidebar-nav-text-size:
        <?= $sidebarConfiguredNavTextSize ?>px;


    --basic-sidebar-collapse-button-size:
        <?= $sidebarConfiguredCollapseButtonSize ?>px;
}
</style>

<div class="sidebar" id="sidebar">

    <?php if($sidebarShowCompanyLogo): ?>

    <div
        class="sidebar-company-logo"
        id="sidebarCompanyLogo"
        aria-label="Company logo">

        <?php if($sidebarCompanyLogo !== ''): ?>

        <img
            src="<?= htmlspecialchars($sidebarCompanyLogo) ?>"
            alt="Company logo"
            style="max-width: <?= $sidebarCompanyLogoSize ?>px; max-height: <?= $sidebarCompanyLogoSize ?>px;">

        <?php else: ?>

        <span class="material-symbols-outlined">
            business
        </span>

        <span class="sidebar-company-logo-text">
            Company Logo
        </span>

        <?php endif; ?>

    </div>

    <?php endif; ?>

<?php if(hasPermission('Dashboard')): ?>
    
    <a href="dashboard.php"
       class="<?= ($currentPage == 'dashboard') ? 'active' : '' ?>">
    
<span class="material-symbols-outlined">home</span>
    
        <span class="nav-text">
            Dashboard
        </span>
    
    </a>
    
    <?php endif; ?>

    
    <?php if(hasPermission('Monitor') || hasPermission('View Monitor')): ?>
    
    <a href="monitor.php"
       class="<?= ($currentPage == 'monitor') ? 'active' : '' ?>">
    
<span class="material-symbols-outlined">monitor</span>
    
        <span class="nav-text">
            Monitor
        </span>
    
    </a>
    
    <?php endif; ?>

    
    
    <?php if(hasPermission('Pending Requests')): ?>
    
    <a href="admin.php"
        class="<?= $currentPage == 'admin' ? 'active' : '' ?>">
        
<span class="material-symbols-outlined">pending_actions</span>
        <span class="nav-text">
        Pending
        </span>
    </a>
    
    <?php endif; ?>
    
    <?php if(hasPermission('Approve Requests')): ?>
    
    <a href="approved.php"
        class="<?= $currentPage == 'approved' ? 'active' : '' ?>">
        
<span class="material-symbols-outlined">check_circle</span>
        <span class="nav-text">
        Approved
        </span>
    </a>
    
    <?php endif; ?>
    
    <?php if(hasPermission('Deny Requests')): ?>
    
    <a href="denied.php"
        class="<?= $currentPage == 'denied' ? 'active' : '' ?>">
        
<span class="material-symbols-outlined">cancel</span>
        <span class="nav-text">
        Denied
        </span>
    </a>
    
    <?php endif; ?>
    
    <?php if(
        hasAnyPermission([
            'Appearance',
            'Banner',
            'Logo',
            'Favicon',
            'Login',
            'Theme',
            'Sidebar',
            'User Disclaimer',
        
            'Security',
            'HTTPS/SSL',
            'User Management',
            'Users',
            'User Groups',
            'Session Timeout',
            '3rd Party Integrations',
            'Data Deletion',
        
            'Communications',
            'Notification Channels',
            'Monitor Alerts',
            'Notification Channel',
            'Email Notifications',
            'Push Notifications',
            'WhatsApp',
            'Telegram',
            'Pushbullet',
        
            'Services', 'Network', 'Technitium',
            'Cache', 'Flush Cache',
            'Enable/Disable Cache',
            'Blocking', 'Recursion',
            'Network Proxy',
            'DHCP',
        
            'System Status',
            'Database Server',
            'API Server',
            'DNS Server Status',
            'Connectivity Status'
        ])
    ): ?>
    
    <a href="settings.php"
        class="<?= $currentSection == 'settings' ? 'active' : '' ?>">
    
<span class="material-symbols-outlined">
            settings
        </span>
    
        <span class="nav-text">
            Settings
        </span>
    
    </a>
    
    <?php endif; ?>
    
   
        <?php if (
        !empty($showSidebarPageHeading)
        && !empty($pageHeading)
    ): ?>

    <div
        class="sidebar-page-context"
        aria-label="Current page">

        <span class="sidebar-page-context-line"></span>

        <span class="sidebar-page-context-title">
            <?= htmlspecialchars($pageHeading) ?>
        </span>

        <span class="sidebar-page-context-line"></span>

    </div>

    <?php endif; ?>


    <div class="sidebar-bottom">

        <button
            type="button"
            class="sidebar-toggle-bottom"
            id="sidebarToggleBottom"
            onclick="toggleSidebar()"
            title="Collapse sidebar"
            aria-label="Collapse or expand sidebar">

            <span class="material-symbols-outlined">
                keyboard_double_arrow_left
            </span>

        </button>

        <a
            href="logout.php"
            class="sidebar-logout"
            title="Logout">

            <span class="material-symbols-outlined">
                logout
            </span>

            <span class="nav-text">
                Logout
            </span>

        </a>

        <button
        type="button"
        class="sidebar-user sidebar-user-profile"
        id="sidebarMyProfile"
        onclick="openMyProfile()"
        title="Open my profile">

        <span class="sidebar-avatar">

            <?php if($sidebarProfilePhoto !== ''): ?>

            <img
                src="<?= htmlspecialchars($sidebarProfilePhoto) ?>"
                alt=""
                class="sidebar-profile-photo">

            <?php else: ?>

            <span class="material-symbols-outlined">
                person
            </span>

            <?php endif; ?>

        </span>

        <span class="sidebar-user-details">
            <span class="sidebar-user-label">
                Logged in as:
            </span>

            <strong class="sidebar-user-name">
                <?= htmlspecialchars($_SESSION['displayName']) ?>
            </strong>
        </span>

    </button>

    </div>

</div>

<?php include __DIR__ . '/profile-modal.php'; ?>

<script>
function openMyProfile() {

    window.dispatchEvent(
        new CustomEvent(
            'portal:open-my-profile',
            {
                detail: {
                    username: <?= json_encode($_SESSION['username']) ?>
                }
            }
        )
    );
}

function updateSidebarLayoutState() {

    const sidebar =
        document.getElementById('sidebar');

    if (!sidebar) {
        return;
    }

    const collapsed =
        sidebar.classList.contains('collapsed');

    document.body.classList.toggle(
        'sidebar-is-collapsed',
        collapsed
    );

    const icon =
        document.querySelector(
            '#sidebarToggleBottom .material-symbols-outlined'
        );

    if (icon) {
        icon.textContent =
            collapsed
                ? 'keyboard_double_arrow_right'
                : 'keyboard_double_arrow_left';
    }
}

function toggleSidebar() {

    const sidebar =
        document.getElementById('sidebar');

    if (!sidebar) {
        return;
    }

    sidebar.classList.toggle('collapsed');

    localStorage.setItem(
        'sidebarCollapsed',
        sidebar.classList.contains('collapsed')
    );

    updateSidebarLayoutState();
}

document.addEventListener(
    'DOMContentLoaded',
    function () {

        const sidebar =
            document.getElementById('sidebar');

        if (!sidebar) {
            return;
        }

        if (
            localStorage.getItem('sidebarCollapsed')
            === 'true'
        ) {
            sidebar.classList.add('collapsed');
        }

        updateSidebarLayoutState();
    }
);
</script>


