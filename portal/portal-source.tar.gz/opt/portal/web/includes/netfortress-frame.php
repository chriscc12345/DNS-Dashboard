<?php
/*
 * Shared NetFortress console frame. $netfortressSection must be set by
 * the including page (devices, reports, audit, policies, content,
 * firewall, modules, operations). The appliance console is served
 * through the portal's own nginx proxy (same origin: no mixed
 * content), and the appliance SPA reads the #section hash to open the
 * requested page. Sign in once inside the frame with the appliance
 * administrator account.
 */
$netfortressSection = $netfortressSection ?? 'devices';
?>
<div
    class="netfortress-console-frame">

    <iframe
        id="netfortressConsole"
        src="/netfortress-console/#<?= htmlspecialchars($netfortressSection) ?>"
        title="NetFortress Firewall Appliance"
        style="width:100%;
               height:calc(100vh - 235px);
               min-height:600px;
               border:1px solid #233545;
               border-radius:8px;
               background:#071019;">

    </iframe>

</div>
