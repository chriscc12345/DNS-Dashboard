<?php
/*
 * Portal Basic Theme
 * Shared Banner Component
 */

$bannerDisplayName =
    $_SESSION['displayName']
    ?? $_SESSION['username']
    ?? 'User';


/*
 * UPDATE003 - Basic Appearance Logo
 */

$basicAppearanceSettings = [];

if (isset($FASTAPI_URL)) {

    $basicAppearanceResponse =
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        );

    if ($basicAppearanceResponse !== false) {

        $basicAppearanceDecoded =
            json_decode(
                $basicAppearanceResponse,
                true
            );

        if (is_array($basicAppearanceDecoded)) {
            $basicAppearanceSettings =
                $basicAppearanceDecoded;
        }
    }
}


$basicBannerImage =
    trim(
        (string)(
            $basicAppearanceSettings['banner_image']
            ?? 'images/banner.jpg'
        )
    );

if ($basicBannerImage === '') {
    $basicBannerImage = 'images/banner.jpg';
}


$basicBannerZoom =
    (int)(
        $basicAppearanceSettings['banner_zoom']
        ?? 100
    );

/*
 * UPDATE004 - Animated Weather Badge
 * Coordinates come from portal settings with
 * Johannesburg defaults. Weather data is fetched
 * client-side from Open-Meteo (no API key).
 */

$weatherLatitude =
    (float)(
        $basicAppearanceSettings['weather_latitude']
        ?? -26.20
    );

$weatherLongitude =
    (float)(
        $basicAppearanceSettings['weather_longitude']
        ?? 28.05
    );

/*
 * UPDATE004 - Portal time zone. Empty means the
 * browser default is used.
 */

$portalTimezone =
    trim(
        (string)(
            $basicAppearanceSettings['portal_timezone']
            ?? ''
        )
    );

if (
    $basicBannerZoom < 60
    ||
    $basicBannerZoom > 500
) {
    $basicBannerZoom = 100;
}


$basicBannerPositionX =
    (int)(
        $basicAppearanceSettings['banner_position_x']
        ?? 50
    );

$basicBannerPositionY =
    (int)(
        $basicAppearanceSettings['banner_position_y']
        ?? 50
    );

if (
    $basicBannerPositionX < 0
    ||
    $basicBannerPositionX > 100
) {
    $basicBannerPositionX = 50;
}

if (
    $basicBannerPositionY < 0
    ||
    $basicBannerPositionY > 100
) {
    $basicBannerPositionY = 50;
}


$basicBannerFitMode =
    strtolower(
        trim(
            (string)(
                $basicAppearanceSettings['banner_fit_mode']
                ?? 'fit'
            )
        )
    );

if (
    $basicBannerFitMode !== 'fit'
    &&
    $basicBannerFitMode !== 'cover'
) {
    $basicBannerFitMode = 'fit';
}


$basicBannerIsWebm =
    (bool)preg_match(
        '/\.webm$/i',
        $basicBannerImage
    );


$basicBannerAnimationEnabled =
    strtolower(
        trim(
            (string)(
                $basicAppearanceSettings[
                    'banner_animation_enabled'
                ]
                ?? 'false'
            )
        )
    ) === 'true';


$basicBannerAnimationStyle =
    strtolower(
        trim(
            (string)(
                $basicAppearanceSettings[
                    'banner_animation_style'
                ]
                ?? 'cyber'
            )
        )
    );

$basicBannerAnimationStyles = [
    'cyber',
    'digital_rain',
    'network_grid',
    'security_scanner'
];

if (
    !in_array(
        $basicBannerAnimationStyle,
        $basicBannerAnimationStyles,
        true
    )
) {
    $basicBannerAnimationStyle = 'cyber';
}


$basicBannerAnimationIntensity =
    strtolower(
        trim(
            (string)(
                $basicAppearanceSettings[
                    'banner_animation_intensity'
                ]
                ?? 'low'
            )
        )
    );

if (
    !in_array(
        $basicBannerAnimationIntensity,
        ['low', 'medium', 'high', 'ultra'],
        true
    )
) {
    $basicBannerAnimationIntensity = 'low';
}


$basicCompanyLogo =
    trim(
        (string)(
            $basicAppearanceSettings['company_logo']
            ?? ''
        )
    );

$basicShowLogoBanner =
    strtolower(
        (string)(
            $basicAppearanceSettings['show_logo_banner']
            ?? 'true'
        )
    ) === 'true';

$basicBannerLogoSize =
    (int)(
        $basicAppearanceSettings['banner_logo_size']
        ?? 140
    );

if (
    $basicBannerLogoSize < 100
    ||
    $basicBannerLogoSize > 350
) {
    $basicBannerLogoSize = 140;
}
?>

<div class="banner basic-banner">

    <div
        class="basic-banner-media-frame"
        id="basicBannerMediaFrame"
        data-zoom="<?= $basicBannerZoom ?>"
        data-position-x="<?= $basicBannerPositionX ?>"
        data-position-y="<?= $basicBannerPositionY ?>"
        data-fit-mode="<?= htmlspecialchars($basicBannerFitMode) ?>">

        <?php if($basicBannerIsWebm): ?>

        <video
            class="basic-banner-media"
            id="basicBannerMedia"
            autoplay
            muted
            loop
            playsinline
            preload="metadata"
            aria-hidden="true">

            <source
                src="<?= htmlspecialchars($basicBannerImage) ?>"
                type="video/webm">

        </video>

        <?php else: ?>

        <img
            class="basic-banner-media"
            id="basicBannerMedia"
            src="<?= htmlspecialchars($basicBannerImage) ?>"
            alt="">

        <?php endif; ?>

    </div>

    <canvas
        class="basic-banner-animation"
        id="basicBannerAnimation"
        aria-hidden="true"
        <?= $basicBannerAnimationEnabled ? '' : 'hidden' ?>>
    </canvas>

    <div class="basic-banner-shade"></div>

    <div class="basic-banner-content">

        <div class="basic-banner-welcome">

            <span class="basic-banner-welcome-label">
                Welcome back,
            </span>

            <strong>
                <?= htmlspecialchars($bannerDisplayName) ?>
            </strong>

        </div>

        <div
            class="basic-banner-logo"
            id="basicBannerLogo">

            <?php if($basicShowLogoBanner): ?>

                <?php if($basicCompanyLogo !== ''): ?>

                <img
                    src="<?= htmlspecialchars($basicCompanyLogo) ?>"
                    alt="Company logo"
                    style="height: <?= $basicBannerLogoSize ?>px; width: auto; max-height: 350px;">

                <?php else: ?>

                <span class="material-symbols-outlined">
                    business
                </span>

                <span>
                    Company Logo
                </span>

                <?php endif; ?>

            <?php endif; ?>

        </div>

        <div
            class="basic-banner-clock"
            id="basicBannerClock"
            data-tz="<?= htmlspecialchars($portalTimezone) ?>">

            <div
                class="basic-banner-weather"
                id="basicBannerWeather"
                data-lat="<?= htmlspecialchars($weatherLatitude) ?>"
                data-lon="<?= htmlspecialchars($weatherLongitude) ?>"
                hidden>

                <span
                    class="weather-badge"
                    id="weatherBadge"
                    aria-hidden="true">
                </span>

                <span class="weather-stack">

                    <span
                        class="weather-temp"
                        id="weatherTemp"></span>

                    <span
                        class="weather-cond"
                        id="weatherCond"></span>

                </span>

            </div>

            <div class="basic-banner-clock-divider"></div>

            <div class="basic-banner-clock-stack">

                <div
                    class="basic-banner-day"
                    id="basicBannerDay">
                </div>

                <div
                    class="basic-banner-date"
                    id="basicBannerDate">
                </div>

                <div
                    class="basic-banner-time"
                    id="basicBannerTime">
                </div>

            </div>

        </div>

    </div>

</div>

<script src="js/portal-animation.js"></script>

<script>
(function () {

    const bannerAnimationCanvas =
        document.getElementById(
            'basicBannerAnimation'
        );

    const bannerAnimationEnabled =
        <?= $basicBannerAnimationEnabled
            ? 'true'
            : 'false' ?>;

    const bannerAnimationStyle =
        <?= json_encode(
            $basicBannerAnimationStyle
        ) ?>;

    const bannerAnimationIntensity =
        <?= json_encode(
            $basicBannerAnimationIntensity
        ) ?>;


    if (
        bannerAnimationCanvas
        && window.PortalAnimation
    ) {

        new window.PortalAnimation({
            canvas:
                bannerAnimationCanvas,

            container:
                bannerAnimationCanvas.parentElement,

            enabled:
                bannerAnimationEnabled,

            style:
                bannerAnimationStyle,

            intensity:
                bannerAnimationIntensity
        });
    }


    const bannerFrame =
        document.getElementById(
            'basicBannerMediaFrame'
        );

    const bannerMedia =
        document.getElementById(
            'basicBannerMedia'
        );


    function clampBasicBannerValue(
        value,
        minimum,
        maximum
    ) {
        return Math.min(
            maximum,
            Math.max(
                minimum,
                value
            )
        );
    }


    function basicBannerZoomMultiplier(
        zoom
    ) {

        const safeZoom =
            clampBasicBannerValue(
                Number(zoom) || 60,
                60,
                500
            );

        return 1
            + (
                (safeZoom - 60)
                / 70
            );
    }


    function basicBannerAxisPosition(
        frameSize,
        renderedSize,
        savedPosition
    ) {

        let minimum;
        let maximum;

        if (renderedSize >= frameSize) {

            minimum =
                frameSize
                - renderedSize;

            maximum = 0;

        } else {

            minimum = 0;

            maximum =
                frameSize
                - renderedSize;
        }

        const normalized =
            clampBasicBannerValue(
                Number(savedPosition) || 0,
                0,
                100
            ) / 100;

        /*
         * Same normalized direction as the editor.
         */
        return maximum
            - (
                (
                    maximum
                    - minimum
                )
                * normalized
            );
    }


    function renderBasicBannerMedia() {

        if (
            !bannerFrame
            ||
            !bannerMedia
        ) {
            return;
        }

        let sourceWidth = 0;
        let sourceHeight = 0;

        if (
            bannerMedia.tagName
            &&
            bannerMedia.tagName.toLowerCase()
                === 'video'
        ) {

            sourceWidth =
                bannerMedia.videoWidth;

            sourceHeight =
                bannerMedia.videoHeight;

        } else {

            sourceWidth =
                bannerMedia.naturalWidth;

            sourceHeight =
                bannerMedia.naturalHeight;
        }

        if (
            sourceWidth <= 0
            ||
            sourceHeight <= 0
        ) {
            return;
        }

        const frameWidth =
            bannerFrame.clientWidth;

        const frameHeight =
            bannerFrame.clientHeight;

        if (
            frameWidth <= 0
            ||
            frameHeight <= 0
        ) {
            return;
        }

        const fitMode =
            bannerFrame.dataset.fitMode
                === 'cover'
                    ? 'cover'
                    : 'fit';

        const widthScale =
            frameWidth
            / sourceWidth;

        const heightScale =
            frameHeight
            / sourceHeight;

        const baseScale =
            fitMode === 'cover'
                ? Math.max(
                    widthScale,
                    heightScale
                )
                : Math.min(
                    widthScale,
                    heightScale
                );

        const renderScale =
            baseScale
            * basicBannerZoomMultiplier(
                bannerFrame.dataset.zoom
            );

        const renderedWidth =
            sourceWidth
            * renderScale;

        const renderedHeight =
            sourceHeight
            * renderScale;

        const x =
            basicBannerAxisPosition(
                frameWidth,
                renderedWidth,
                bannerFrame.dataset.positionX
            );

        const y =
            basicBannerAxisPosition(
                frameHeight,
                renderedHeight,
                bannerFrame.dataset.positionY
            );

        bannerMedia.style.width =
            renderedWidth + 'px';

        bannerMedia.style.height =
            renderedHeight + 'px';

        bannerMedia.style.left =
            x + 'px';

        bannerMedia.style.top =
            y + 'px';

        bannerMedia.style.transform =
            'none';
    }


    function initialiseBasicBannerMedia() {

        if (
            !bannerFrame
            ||
            !bannerMedia
        ) {
            return;
        }

        if (
            bannerMedia.tagName
            &&
            bannerMedia.tagName.toLowerCase()
                === 'video'
        ) {

            if (
                bannerMedia.videoWidth > 0
                &&
                bannerMedia.videoHeight > 0
            ) {
                renderBasicBannerMedia();
            }

            bannerMedia.addEventListener(
                'loadedmetadata',
                renderBasicBannerMedia
            );

        } else {

            if (
                bannerMedia.complete
                &&
                bannerMedia.naturalWidth > 0
            ) {
                renderBasicBannerMedia();
            }

            bannerMedia.addEventListener(
                'load',
                renderBasicBannerMedia
            );
        }

        window.addEventListener(
            'resize',
            renderBasicBannerMedia
        );
    }


    initialiseBasicBannerMedia();

})();
</script>

<?php include __DIR__ . '/banner-clock-js.php'; ?>
