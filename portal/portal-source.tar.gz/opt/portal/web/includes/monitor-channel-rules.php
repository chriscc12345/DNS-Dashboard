<?php

/*
 * Monitor Alerts - per-channel notification
 * rules (render). Each generated channel page
 * (monitor-<channel>.php) sets
 * $monitorChannelName and includes this file
 * to render the channel's rules table, the
 * Add New button and the Add User styled
 * popup.
 *
 * The popup cascades:
 *
 *     Function -> Sub Function -> User
 *     -> Type of Notification -> the
 *     custom message box(es).
 *
 * Every function in the catalog is a real
 * reportable portal action backed by the
 * monitor event engine; Login Notification
 * keeps its per-event message boxes.
 *
 * Rule management is gated by the Notification
 * Channel permission; the page itself is also
 * gated by the channel permission its tab
 * carries.
 */

if (!isset($monitorChannelName)) {
    $monitorChannelName = '';
}

$monitorChannelName =
    trim((string)$monitorChannelName);

$mcrCanManage =
    hasPermission(
        'Notification Channel'
    );

/*
 * The channel's rules come from the
 * monitoring API.
 */

$mcrRules =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL
            . '/monitor/login-notifications'
        ),
        true
    ) ?? [];

$mcrRules =
    is_array($mcrRules)
        ? $mcrRules
        : [];

$mcrRules = array_values(
    array_filter(
        $mcrRules,
        function ($mcrRule)
        use ($monitorChannelName) {

            return strcasecmp(
                (string)(
                    $mcrRule[
                        'notification_channel'
                    ]
                    ?? ''
                ),
                $monitorChannelName
            ) === 0;
        }
    )
);

/*
 * Portal users for the User dropdown.
 */

$mcrUsersResponse =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/users'
        ),
        true
    ) ?? [];

$mcrUsers =
    $mcrUsersResponse['response']['users']
    ?? [];

if (!is_array($mcrUsers)) {
    $mcrUsers = [];
}

/*
 * The catalog of functions the portal can
 * report on. Sub functions drive the User
 * dropdown (Users = a specific user);
 * events are the Type of Notification.
 * Only Login Notification targets users;
 * every other function reports for All
 * Users. A new function is added here and
 * wired to its portal action in the API.
 */

$mcrFunctions = [
    'Login Notification' => [
        'subs' => [
            'Users',
            'All Users'
        ],
        'events' => [
            'Successful Login',
            'Failed Login',
            'Logout',
            'All'
        ]
    ],
    'Account Activity' => [
        'subs' => [
            'All Users'
        ],
        'events' => [
            'User Created',
            'User Deleted',
            'All'
        ]
    ],
    'Group Activity' => [
        'subs' => [
            'All Users'
        ],
        'events' => [
            'Group Created',
            'Group Updated',
            'All'
        ]
    ],
    'Request Approvals' => [
        'subs' => [
            'All Users'
        ],
        'events' => [
            'Request Submitted',
            'Request Approved',
            'Request Denied',
            'All'
        ]
    ],
    'Domain Controls' => [
        'subs' => [
            'All Users'
        ],
        'events' => [
            'Domain Re-blocked',
            'Domain Allowed',
            'All'
        ]
    ],
    'Settings Changes' => [
        'subs' => [
            'All Users'
        ],
        'events' => [
            'Section Added',
            'Section Updated',
            'Field Added',
            'Field Updated',
            'Tab Added',
            'Tab Updated',
            'All'
        ]
    ]
];

/**
 * Display label for a rule's target user.
 */

function mcrTargetLabel($mcrTarget) {

    return strcasecmp(
        (string)$mcrTarget,
        'All'
    ) === 0
        ? 'All Users'
        : (string)$mcrTarget;
}
?>

<?php if ($mcrCanManage): ?>

<!--
    The page title and the active tab already
    say which channel this is - the panel
    keeps only the Add New button.
-->

<div class="appearance-panel-heading">

    <div></div>

    <div style="flex-shrink:0;">

        <button
            type="button"
            class="settings-add-btn"
            onclick="mcrOpenModal()">
            + Add New
        </button>

    </div>

</div>

<?php endif; ?>

<div
    id="mcrResult"
    style="display:none;
           margin-bottom:14px;">
</div>

<table class="ssl-table">

    <tr>
        <th>Function</th>
        <th>Type of Notification</th>
        <th>User</th>
        <th>Custom Message</th>
        <th>Status</th>
        <?php if($mcrCanManage): ?>
        <th>Actions</th>
        <?php endif; ?>
    </tr>

    <?php foreach (
        $mcrRules
        as $mcrRule
    ): ?>

    <tr>
        <td>
            <?= htmlspecialchars(
                (string)(
                    $mcrRule[
                        'rule_function'
                    ]
                    ?? 'Login Notification'
                )
            ) ?>
        </td>
        <td>
            <?= htmlspecialchars(
                (string)(
                    $mcrRule[
                        'notification_type'
                    ]
                    ?? ''
                )
            ) ?>
        </td>
        <td>
            <?= htmlspecialchars(
                mcrTargetLabel(
                    $mcrRule[
                        'target_username'
                    ]
                    ?? ''
                )
            ) ?>
        </td>
        <td>
            <?php
                $mcrMessage =
                    (string)(
                        $mcrRule[
                            'login_custom_message'
                        ]
                        ?? ''
                    );

                if ($mcrMessage === '') {
                    $mcrMessage =
                        (string)(
                            $mcrRule[
                                'failed_custom_message'
                            ]
                            ?? ''
                        );
                }

                if ($mcrMessage === '') {
                    $mcrMessage =
                        (string)(
                            $mcrRule[
                                'logout_custom_message'
                            ]
                            ?? ''
                        );
                }
            ?>
            <?= htmlspecialchars(
                $mcrMessage
            ) ?>
        </td>
        <td>
            <span class="<?= !empty(
                $mcrRule['enabled']
            )
                ? 'badge-active'
                : 'badge-disabled' ?>">
                <?= !empty(
                    $mcrRule['enabled']
                )
                    ? 'Enabled'
                    : 'Disabled' ?>
            </span>
        </td>
        <?php if($mcrCanManage): ?>
        <td style="white-space:nowrap;">

            <button
                type="button"
                class="settings-add-btn"
                style="margin-right:6px;"
                title="Send a test alert through this rule"
                onclick="mcrTestAlert(
                    <?= (int)(
                        $mcrRule['id']
                    ) ?>
                )">
                Test Alert
            </button>

            <button
                type="button"
                class="settings-edit-btn"
                style="margin-right:6px;"
                onclick="mcrOpenModal(
                    <?= (int)(
                        $mcrRule['id']
                    ) ?>,
                    '<?= htmlspecialchars(
                        (string)(
                            $mcrRule[
                                'rule_function'
                            ]
                            ?? 'Login Notification'
                        ),
                        ENT_QUOTES
                    ) ?>',
                    '<?= htmlspecialchars(
                        (string)(
                            $mcrRule[
                                'notification_type'
                            ]
                        ),
                        ENT_QUOTES
                    ) ?>',
                    '<?= htmlspecialchars(
                        (string)(
                            $mcrRule[
                                'target_username'
                            ]
                        ),
                        ENT_QUOTES
                    ) ?>',
                    '<?= htmlspecialchars(
                        (string)(
                            $mcrRule[
                                'login_custom_message'
                            ]
                            ?? ''
                        ),
                        ENT_QUOTES
                    ) ?>',
                    '<?= htmlspecialchars(
                        (string)(
                            $mcrRule[
                                'failed_custom_message'
                            ]
                            ?? ''
                        ),
                        ENT_QUOTES
                    ) ?>',
                    '<?= htmlspecialchars(
                        (string)(
                            $mcrRule[
                                'logout_custom_message'
                            ]
                            ?? ''
                        ),
                        ENT_QUOTES
                    ) ?>',
                    <?= !empty(
                        $mcrRule['enabled']
                    )
                        ? 1
                        : 0 ?>
                )">
                Edit
            </button>

            <button
                type="button"
                class="settings-delete-btn"
                onclick="mcrDeleteRule(
                    <?= (int)(
                        $mcrRule['id']
                    ) ?>
                )">
                Delete
            </button>

        </td>
        <?php endif; ?>
    </tr>

    <?php endforeach; ?>

    <?php if(count($mcrRules) === 0): ?>

    <tr>
        <td colspan="<?= $mcrCanManage
            ? 6
            : 5 ?>">
            <span class="settings-coming-soon">
                No <?= htmlspecialchars(
                    $monitorChannelName
                ) ?> notification rules yet.
            </span>
        </td>
    </tr>

    <?php endif; ?>

</table>

<?php if($mcrCanManage): ?>

<!--
    Reuses the Add User modal id so it
    inherits the full Add User modal
    styling; the .ln-modal class trims
    it to fit this field set.
-->

<div
    id="userModal"
    class="modal ln-modal">

    <div
        class="user-modal-content
               add-user-modal">

        <div class="add-user-titlebar">

            <h3 id="mcrModalTitle">
                Add New
            </h3>

            <button
                type="button"
                class="add-user-close"
                onclick="mcrCloseModal()"
                aria-label="Close">
                &times;
            </button>

        </div>

        <form id="mcrForm" onsubmit="return false;">

            <input
                type="hidden"
                id="mcrRuleId"
                value="">

            <div class="add-user-layout">

                <div class="add-user-fields">

                    <div class="add-user-grid">

                        <div class="portal-field">

                            <label for="mcr_function">
                                Function
                            </label>

                            <select id="mcr_function">

                                <?php foreach (
                                    array_keys(
                                        $mcrFunctions
                                    )
                                    as $mcrFunction
                                ): ?>

                                <option value="<?= htmlspecialchars(
                                    $mcrFunction
                                ) ?>">
                                    <?= htmlspecialchars(
                                        $mcrFunction
                                    ) ?>
                                </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div class="portal-field">

                            <label for="mcr_sub_function">
                                Sub Function
                            </label>

                            <select
                                id="mcr_sub_function">

                            </select>

                        </div>

                        <div
                            class="portal-field"
                            id="mcrUserField">

                            <label for="mcr_user">
                                User
                            </label>

                            <select id="mcr_user">

                                <option
                                    value=""
                                    disabled
                                    selected>
                                    Select a user
                                </option>

                                <?php foreach (
                                    $mcrUsers
                                    as $mcrUser
                                ): ?>

                                <option value="<?= htmlspecialchars(
                                    (string)(
                                        $mcrUser[
                                            'username'
                                        ]
                                        ?? ''
                                    )
                                ) ?>">
                                    <?= htmlspecialchars(
                                        (string)(
                                            $mcrUser[
                                                'displayName'
                                            ]
                                            ?? ''
                                        )
                                    ) ?>
                                    (<?= htmlspecialchars(
                                        (string)(
                                            $mcrUser[
                                                'username'
                                            ]
                                            ?? ''
                                        )
                                    ) ?>)
                                </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div class="portal-field">

                            <label for="mcr_type">
                                Type of Notification
                            </label>

                            <select id="mcr_type">

                            </select>

                        </div>

                        <div class="portal-field">

                            <label for="mcr_enabled">
                                Enabled
                            </label>

                            <select id="mcr_enabled">

                                <option value="1">
                                    Enabled
                                </option>

                                <option value="0">
                                    Disabled
                                </option>

                            </select>

                        </div>

                        <div class="portal-field"
                             id="mcrCustomField"
                             style="grid-column:1 / -1;">

                            <label for="mcr_custom_message">
                                Custom Message
                            </label>

                            <input
                                type="text"
                                id="mcr_custom_message"
                                placeholder="Optional - sent as the notification text">

                        </div>

                        <div class="portal-field"
                             id="mcrLoginField"
                             style="grid-column:1 / -1;">

                            <label for="mcr_login_custom_message">
                                Login Custom Message
                            </label>

                            <input
                                type="text"
                                id="mcr_login_custom_message"
                                placeholder="Optional - sent as the notification text">

                        </div>

                        <div class="portal-field"
                             id="mcrFailedField"
                             style="grid-column:1 / -1;">

                            <label for="mcr_failed_custom_message">
                                Failed Login Custom Message
                            </label>

                            <input
                                type="text"
                                id="mcr_failed_custom_message"
                                placeholder="Optional - sent as the notification text">

                        </div>

                        <div class="portal-field"
                             id="mcrLogoutField"
                             style="grid-column:1 / -1;">

                            <label for="mcr_logout_custom_message">
                                Logout Custom Message
                            </label>

                            <input
                                type="text"
                                id="mcr_logout_custom_message"
                                placeholder="Optional - sent as the notification text">

                        </div>

                    </div>

                </div>

            </div>

            <div
                id="mcrFormError"
                class="error-message"
                style="display:none;
                       margin-top:14px;">
                Please select a user.
            </div>

            <div class="ln-actions">

                <button
                    type="button"
                    class="approve-btn"
                    id="mcrCreateBtn"
                    onclick="mcrSubmit('create')">
                    Create
                </button>

                <button
                    type="button"
                    class="approve-btn"
                    id="mcrUpdateBtn"
                    style="display:none;"
                    onclick="mcrSubmit('update')">
                    Save
                </button>

                <button
                    type="button"
                    class="deny-btn"
                    onclick="mcrCloseModal()">
                    Cancel
                </button>

            </div>

        </form>

    </div>

</div>

<script>

/*
 * Cascade config rendered from the same
 * PHP catalog that builds the Function
 * dropdown.
 */

var mcrFunctionConfig =
    <?= json_encode(
        $mcrFunctions
    ) ?>;

var mcrChannel =
    <?= json_encode(
        $monitorChannelName
    ) ?>;

function mcrFillOptions(
    selectId,
    values
) {

    var sel = document
        .getElementById(selectId);

    sel.innerHTML = '';

    values.forEach(
        function(value) {

            var option =
                document
                .createElement(
                    'option'
                );

            option.value = value;
            option.textContent = value;

            sel.appendChild(option);
        }
    );
}

/*
 * Function -> Sub Function + Type
 * cascade, and the message fields the
 * function uses.
 */

function mcrFunctionChanged() {

    var fn = document
        .getElementById('mcr_function')
        .value;

    var config =
        mcrFunctionConfig[fn]
        || {
            subs: ['All Users'],
            events: []
        };

    mcrFillOptions(
        'mcr_sub_function',
        config.subs
    );

    mcrFillOptions(
        'mcr_type',
        config.events
    );

    mcrSubChanged();
    mcrFieldsForFunction();
}

/*
 * Sub Function -> User cascade: the
 * User dropdown only applies to a
 * specific user.
 */

function mcrSubChanged() {

    var sub = document
        .getElementById(
            'mcr_sub_function'
        ).value;

    var specific =
        sub === 'Users'
        || sub === '';

    document
        .getElementById(
            'mcrUserField'
        ).style.display =
            specific ? '' : 'none';
}

/*
 * Login Notification keeps its three
 * per-event message boxes; every other
 * function has a single custom message.
 */

function mcrFieldsForFunction() {

    var isLogin =
        document
        .getElementById('mcr_function')
        .value
        === 'Login Notification';

    document
        .getElementById(
            'mcrCustomField'
        ).style.display =
            isLogin ? 'none' : '';

    if (isLogin) {

        mcrTypeChanged();

    } else {

        [
            'mcrLoginField',
            'mcrFailedField',
            'mcrLogoutField'
        ].forEach(function(fieldId) {

            document
                .getElementById(fieldId)
                .style.display = 'none';
        });
    }
}

function mcrTypeChanged() {

    var type = document
        .getElementById('mcr_type')
        .value;

    var visible = {
        'Successful Login': [
            'mcrLoginField'
        ],
        'Failed Login': [
            'mcrFailedField'
        ],
        'Logout': [
            'mcrLogoutField'
        ],
        'All': [
            'mcrLoginField',
            'mcrFailedField',
            'mcrLogoutField'
        ]
    }[type] || [];

    [
        'mcrLoginField',
        'mcrFailedField',
        'mcrLogoutField'
    ].forEach(function(fieldId) {

        document
            .getElementById(fieldId)
            .style.display =
                visible.indexOf(fieldId) >= 0
                    ? ''
                    : 'none';
    });
}

function mcrOpenModal(
    ruleId,
    ruleFunction,
    type,
    username,
    loginMessage,
    failedMessage,
    logoutMessage,
    enabled
) {

    ruleId = ruleId || null;
    ruleFunction =
        ruleFunction || 'Login Notification';
    type = type || '';
    username = username || '';
    loginMessage = loginMessage || '';
    failedMessage = failedMessage || '';
    logoutMessage = logoutMessage || '';
    enabled = enabled === 0 ? 0 : 1;

    document
        .getElementById(
            'mcrModalTitle'
        ).textContent =
            ruleId
                ? 'Edit Rule'
                : 'Add New';

    document
        .getElementById('mcrRuleId')
        .value = ruleId || '';

    var fnSel = document
        .getElementById('mcr_function');

    fnSel.value = ruleFunction;

    /*
     * Unknown function (deleted from the
     * catalog): fall back to the first.
     */

    if (!fnSel.value) {
        fnSel.selectedIndex = 0;
    }

    mcrFunctionChanged();

    /*
     * Sub Function follows the saved
     * target: All Users targets every
     * user, otherwise a specific user.
     */

    var subSel = document
        .getElementById(
            'mcr_sub_function'
        );

    if (ruleId && subSel.value === 'Users') {

        if (
            username.toLowerCase()
                === 'all'
        ) {

            subSel.value = 'All Users';

        } else {

            document
                .getElementById('mcr_user')
                .value = username;
        }
    }

    mcrSubChanged();

    var typeSel = document
        .getElementById('mcr_type');

    typeSel.value = type;

    if (!typeSel.value && typeSel.options.length) {
        typeSel.selectedIndex = 0;
    }

    document
        .getElementById('mcr_enabled')
        .value = ruleId
            ? String(enabled)
            : '1';

    document
        .getElementById(
            'mcr_login_custom_message'
        ).value = loginMessage;

    document
        .getElementById(
            'mcr_failed_custom_message'
        ).value = failedMessage;

    document
        .getElementById(
            'mcr_logout_custom_message'
        ).value = logoutMessage;

    document
        .getElementById(
            'mcr_custom_message'
        ).value = loginMessage;

    mcrFieldsForFunction();

    document
        .getElementById('mcrCreateBtn')
        .style.display =
            ruleId ? 'none' : '';

    document
        .getElementById('mcrUpdateBtn')
        .style.display =
            ruleId ? '' : 'none';

    var errorBox = document
        .getElementById(
            'mcrFormError'
        );

    errorBox.textContent =
        'Please select a user.';

    errorBox.style.display = 'none';

    document
        .getElementById('userModal')
        .style.display = 'flex';
}

function mcrCloseModal() {

    document
        .getElementById('mcrFormError')
        .style.display = 'none';

    document
        .getElementById('userModal')
        .style.display = 'none';
}

function mcrPayload(action) {

    var fn = document
        .getElementById('mcr_function')
        .value;

    var sub = document
        .getElementById(
            'mcr_sub_function'
        ).value;

    var isLogin =
        fn === 'Login Notification';

    var loginMessage =
        isLogin
            ? document
                .getElementById(
                    'mcr_login_custom_message'
                ).value
            : document
                .getElementById(
                    'mcr_custom_message'
                ).value;

    return {
        action: action,
        rule_function: fn,
        notification_channel:
            mcrChannel,
        notification_type:
            document
            .getElementById('mcr_type')
            .value,
        target_username:
            sub === 'All Users'
                ? 'All'
                : document
                    .getElementById(
                        'mcr_user'
                    ).value,
        login_custom_message:
            loginMessage,
        failed_custom_message:
            isLogin
                ? document
                    .getElementById(
                        'mcr_failed_custom_message'
                    ).value
                : '',
        logout_custom_message:
            isLogin
                ? document
                    .getElementById(
                        'mcr_logout_custom_message'
                    ).value
                : '',
        enabled:
            document
            .getElementById(
                'mcr_enabled'
            ).value === '1',
        rule_id:
            parseInt(
                document
                .getElementById(
                    'mcrRuleId'
                ).value,
                10
            ) || 0
    };
}

function mcrSubmit(action) {

    var payload = mcrPayload(action);

    /*
     * A Users rule needs a target user;
     * the inline message beats a native
     * validation bubble.
     */

    if (
        payload
            .target_username === ''
    ) {

        document
            .getElementById('mcr_user')
            .focus();

        var errorBox = document
            .getElementById(
                'mcrFormError'
            );

        errorBox.textContent =
            'Please select a user.';

        errorBox.style.display =
            'block';

        return;
    }

    fetch(
        'monitor-rules-api.php',
        {
            method: 'POST',
            headers: {
                'Content-Type':
                    'application/json'
            },
            body: JSON.stringify(payload)
        }
    )
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {

        if (data.success) {
            location.reload();
        } else {

            var errorBox = document
                .getElementById(
                    'mcrFormError'
                );

            errorBox.textContent =
                data.message
                || 'The request failed.';

            errorBox.style.display =
                'block';
        }
    })
    .catch(function() {

        var errorBox = document
            .getElementById(
                'mcrFormError'
            );

        errorBox.textContent =
            'The request failed.';

        errorBox.style.display =
            'block';
    });
}

function mcrDeleteRule(ruleId) {

    if (!confirm(
        'Delete this notification rule?'
    )) {
        return;
    }

    fetch(
        'monitor-rules-api.php',
        {
            method: 'POST',
            headers: {
                'Content-Type':
                    'application/json'
            },
            body: JSON.stringify({
                action: 'delete',
                rule_id: ruleId
            })
        }
    )
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        location.reload();
    });
}

function mcrTestAlert(ruleId) {

    var box = document
        .getElementById('mcrResult');

    box.style.display = 'block';

    box.className = '';

    box.textContent =
        'Sending test alert...';

    fetch(
        'notifications-test-api.php',
        {
            method: 'POST',
            headers: {
                'Content-Type':
                    'application/json'
            },
            body: JSON.stringify({
                rule_id: ruleId
            })
        }
    )
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {

        box.className =
            data.success
                ? 'settings-saved'
                : 'error-message';

        box.textContent =
            data.message
            || 'No response.';
    })
    .catch(function() {

        box.className =
            'error-message';

        box.textContent =
            'The test alert request '
            + 'failed.';
    });
}

document
    .getElementById('mcr_function')
    .addEventListener(
        'change',
        mcrFunctionChanged
    );

document
    .getElementById('mcr_sub_function')
    .addEventListener(
        'change',
        mcrSubChanged
    );

document
    .getElementById('mcr_type')
    .addEventListener(
        'change',
        function() {

            if (
                document
                .getElementById('mcr_function')
                .value
                === 'Login Notification'
            ) {
                mcrTypeChanged();
            }
        }
    );

</script>

<?php endif; ?>
