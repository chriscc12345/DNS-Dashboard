<?php

/*
 * Page tab navigation (render).
 * Shows the pages of the hub that owns the
 * current page as an editable tab bar, the
 * same way the User Management pages manage
 * their tabs. The head include resolves the
 * tab group and handles the POSTs before
 * output.
 */

require_once __DIR__
    . '/page-tabs-head.php';

if ($pageTabsGroup === null) {
    return;
}

/*
 * Channel mode: the Monitor Alerts hub adds
 * one tab per notification channel - picking a
 * channel in the Add Tab popup auto-completes
 * the page link and its permission.
 */

$pageTabsChannelMode =
    $pageTabsGroup
    === 'monitor-login.php';

/*
 * The dropdown lists the channels created
 * under the Notification Channels hub; each
 * becomes a monitor tab whose page and
 * permission are derived from the channel.
 */

function pageTabChannelSlug($channelName) {

    return 'monitor-'
        . strtolower(
            preg_replace(
                '/\s+/',
                '-',
                trim((string)$channelName)
            )
        )
        . '.php';
}

$pageTabChannelDefaults = [];

if ($pageTabsChannelMode) {

    foreach ($pageTabs as $ptChannelRow) {

        if (
            (string)(
                $ptChannelRow['tab_group']
                ?? ''
            ) !== 'notifications-email.php'
        ) {
            continue;
        }

        $ptChannelHref =
            pageTabChannelSlug(
                $ptChannelRow['tab_name']
            );

        $ptChannelExists = false;

        foreach ($pageTabsList as $ptExisting) {

            if (
                trim(
                    (string)(
                        $ptExisting['tab_href']
                        ?? ''
                    )
                ) === $ptChannelHref
            ) {
                $ptChannelExists = true;
                break;
            }
        }

        if ($ptChannelExists) {
            continue;
        }

        $pageTabChannelDefaults[
            (string)$ptChannelRow['tab_name']
        ] = [
            (string)$ptChannelRow['tab_name'],
            $ptChannelHref,
            (string)(
                $ptChannelRow['tab_permission']
                ?? ''
            )
        ];
    }
}

/*
 * Work out which tabs the viewer may see.
 * The current page's tab always shows.
 */

$pageTabsVisible = [];

foreach ($pageTabsList as $ptTab) {

    $ptTabHref =
        trim(
            (string)(
                $ptTab['tab_href']
                ?? ''
            )
        );

    $ptTabPermission =
        trim(
            (string)(
                $ptTab['tab_permission']
                ?? ''
            )
        );

    $ptTabAlternates = array_filter(
        explode(
            ',',
            (string)(
                $ptTab['tab_alternates']
                ?? ''
            )
        )
    );

    $ptTabIsCurrent =
        $ptTabHref === $pageTabsCurrentPage
        || in_array(
            $pageTabsCurrentPage,
            $ptTabAlternates,
            true
        );

    if (
        !$ptTabIsCurrent
        && $ptTabPermission !== ''
        && !hasPermission($ptTabPermission)
    ) {
        continue;
    }

    $pageTabsVisible[] = $ptTab;
}

/*
 * Viewers without any visible tab (and
 * without editing rights) see no bar.
 */

if (
    !$pageTabsCanEdit
    && count($pageTabsVisible) === 0
) {
    return;
}
?>
<nav class="appearance-tabs um-tabs page-tabs">

    <?php foreach ($pageTabsVisible as $ptTab):

        $ptTabHref =
            trim(
                (string)(
                    $ptTab['tab_href']
                    ?? ''
                )
            );

        $ptTabPermission =
            trim(
                (string)(
                    $ptTab['tab_permission']
                    ?? ''
                )
            );

        $ptTabAlternates = array_filter(
            explode(
                ',',
                (string)(
                    $ptTab['tab_alternates']
                    ?? ''
                )
            )
        );

        $ptTabIsCurrent =
            $ptTabHref === $pageTabsCurrentPage
            || in_array(
                $pageTabsCurrentPage,
                $ptTabAlternates,
                true
            );

    ?>

    <a
        href="<?= htmlspecialchars($ptTabHref) ?>"
        class="<?= $ptTabIsCurrent ? 'active' : '' ?>">
        <?= htmlspecialchars(
            $ptTab['tab_name']
        ) ?>
    </a>

    <?php if ($pageTabsCanEdit): ?>

    <button
        type="button"
        class="settings-edit-btn um-tab-btn"
        onclick="openPageTabModal(
            <?= (int)$ptTab['id'] ?>,
            '<?= htmlspecialchars(
                $ptTab['tab_name'],
                ENT_QUOTES
            ) ?>',
            '<?= htmlspecialchars(
                $ptTabHref,
                ENT_QUOTES
            ) ?>',
            '<?= htmlspecialchars(
                $ptTabPermission,
                ENT_QUOTES
            ) ?>',
            <?= (int)$ptTab['sort_order'] ?>
        )">
        Edit
    </button>

    <form
        method="post">

        <input
            type="hidden"
            name="page_tab_id"
            value="<?= (int)$ptTab['id'] ?>">

        <button
            type="submit"
            name="delete_page_tab"
            value="1"
            class="settings-delete-btn um-tab-btn"
            onclick="return confirm(
                'Delete this tab?'
            );">
            Delete
        </button>

    </form>

    <?php endif; ?>

    <?php endforeach; ?>

    <?php if ($pageTabsCanEdit): ?>

    <button
        type="button"
        class="settings-add-btn um-add-tab-btn"
        onclick="openPageTabModal(
            null,
            '',
            '',
            '',
            <?= count($pageTabsList) ?>
        )">
        + Add Tab
    </button>

    <?php endif; ?>

</nav>

<?php if ($pageTabsCanEdit): ?>

<?php if ($pageTabsChannelMode): ?>

<div id="pageTabModal"
     class="modal ln-modal">

    <div class="user-modal-content
              add-user-modal">

        <div class="add-user-titlebar">

            <h3 id="pageTabModalTitle">
                Add Tab
            </h3>

            <button
                type="button"
                class="add-user-close"
                onclick="closePageTabModal()"
                aria-label="Close">
                &times;
            </button>

        </div>

        <form method="post">

            <input
                type="hidden"
                name="page_tab_id"
                id="pageTabId"
                value="">

            <input
                type="hidden"
                name="page_tab_sort"
                id="pageTabSort"
                value="0">

            <div class="add-user-layout">

                <div class="add-user-fields">

                    <div class="add-user-grid">

                        <div class="portal-field"
                             id="pageTabChannelField"
                             style="grid-column:1 / -1;">

                            <label for="pageTabChannel">
                                Notification Channel
                            </label>

                            <select
                                id="pageTabChannel"
                                onchange="pageTabChannelSelected()">

                                <option value="">
                                    Select a channel
                                </option>

                                <?php foreach (
                                    $pageTabChannelDefaults
                                    as $ptChannelName =>
                                        $ptChannelDefault
                                ): ?>

                                <option
                                    value="<?= htmlspecialchars(
                                        $ptChannelName
                                    ) ?>">
                                    <?= htmlspecialchars(
                                        $ptChannelName
                                    ) ?>
                                </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div class="portal-field">

                            <label for="pageTabName">
                                Tab Name
                            </label>

                            <input
                                type="text"
                                name="page_tab_name"
                                id="pageTabName"
                                required>

                        </div>

                        <div class="portal-field">

                            <label for="pageTabHref">
                                Link (page)
                            </label>

                            <input
                                type="text"
                                name="page_tab_href"
                                id="pageTabHref"
                                placeholder="new-page.php">

                        </div>

                        <div class="portal-field">

                            <label for="pageTabPermission">
                                Required Permission
                            </label>

                            <select
                                name="page_tab_permission"
                                id="pageTabPermission">

                                <option value="">
                                    No permission required
                                </option>

                                <?php foreach (
                                    $pageTabsPermissions
                                    as $ptPermItem
                                ): ?>

                                <option
                                    value="<?= htmlspecialchars(
                                        $ptPermItem[1]
                                    ) ?>">
                                    <?= $ptPermItem[2] === null
                                        ? ''
                                        : '- ' ?><?= htmlspecialchars(
                                        $ptPermItem[1]
                                    ) ?>
                                </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                    </div>

                </div>

            </div>

            <div class="ln-actions">

                <button
                    type="submit"
                    name="create_page_tab"
                    value="1"
                    class="approve-btn"
                    id="pageTabCreateBtn">
                    Create
                </button>

                <button
                    type="submit"
                    name="update_page_tab"
                    value="1"
                    class="approve-btn"
                    id="pageTabUpdateBtn"
                    style="display:none;">
                    Save
                </button>

                <button
                    type="button"
                    class="deny-btn"
                    onclick="closePageTabModal()">
                    Cancel
                </button>

            </div>

        </form>

    </div>

</div>

<script>

/*
 * Picking a channel auto-completes the tab
 * name, the page the tab links to and the
 * permission that guards it.
 */

var pageTabChannelDefaults =
    <?= json_encode(
        $pageTabChannelDefaults
    ) ?>;

function pageTabChannelSelected(){

    var defaults =
        pageTabChannelDefaults[
            document
                .getElementById(
                    'pageTabChannel'
                )
                .value
        ];

    if (defaults) {

        document
            .getElementById(
                'pageTabName'
            )
            .value = defaults[0];

        document
            .getElementById(
                'pageTabHref'
            )
            .value = defaults[1];

        document
            .getElementById(
                'pageTabPermission'
            )
            .value = defaults[2];

    }

}

function openPageTabModal(
    tabId,
    tabName,
    tabHref,
    tabPermission,
    tabSort
){

    document
        .getElementById(
            'pageTabChannelField'
        )
        .style.display =
            tabId ? 'none' : '';

    if (!tabId) {

        document
            .getElementById(
                'pageTabChannel'
            )
            .value = '';

        document
            .getElementById(
                'pageTabName'
            )
            .value = '';

        document
            .getElementById(
                'pageTabHref'
            )
            .value = '';

        document
            .getElementById(
                'pageTabPermission'
            )
            .value = '';

    }

    document
        .getElementById('pageTabModalTitle')
        .textContent =
            tabId
                ? 'Edit Tab'
                : 'Add Tab';

    document
        .getElementById('pageTabId')
        .value = tabId || '';

    document
        .getElementById('pageTabName')
        .value = tabName || '';

    document
        .getElementById('pageTabHref')
        .value = tabHref || '';

    document
        .getElementById(
            'pageTabPermission'
        )
        .value = tabPermission || '';

    document
        .getElementById('pageTabSort')
        .value =
            tabSort === null || tabSort === undefined
                ? 0
                : tabSort;

    document
        .getElementById('pageTabCreateBtn')
        .style.display =
            tabId ? 'none' : '';

    document
        .getElementById('pageTabUpdateBtn')
        .style.display =
            tabId ? '' : 'none';

    document
        .getElementById('pageTabModal')
        .style.display = 'flex';

}

function closePageTabModal(){

    document
        .getElementById('pageTabModal')
        .style.display = 'none';

}

</script>

<?php else: ?>

<!--
    Same Add User modal shell as the
    channel mode popup; .ln-modal gives
       it the shared portal popup styling.
-->

<div id="pageTabModal"
     class="modal ln-modal">

    <div class="user-modal-content
              add-user-modal">

        <div class="add-user-titlebar">

            <h3 id="pageTabModalTitle">
                Add Tab
            </h3>

            <button
                type="button"
                class="add-user-close"
                onclick="closePageTabModal()"
                aria-label="Close">
                &times;
            </button>

        </div>

        <form method="post">

            <input
                type="hidden"
                name="page_tab_id"
                id="pageTabId"
                value="">

            <input
                type="hidden"
                name="page_tab_sort"
                id="pageTabSort"
                value="0">

            <div class="add-user-layout">

                <div class="add-user-fields">

                    <div class="add-user-grid">

                        <div class="portal-field">

                            <label for="pageTabName">
                                Tab Name
                            </label>

                            <input
                                type="text"
                                name="page_tab_name"
                                id="pageTabName"
                                required>

                        </div>

                        <div class="portal-field">

                            <label for="pageTabHref">
                                Link (page)
                            </label>

                            <input
                                type="text"
                                name="page_tab_href"
                                id="pageTabHref"
                                placeholder="new-page.php">

                        </div>

                        <div class="portal-field"
                             style="grid-column:1 / -1;">

                            <label for="pageTabPermission">
                                Required Permission
                            </label>

                            <select
                                name="page_tab_permission"
                                id="pageTabPermission">

                                <option value="">
                                    No permission required
                                </option>

                                <?php foreach (
                                    $pageTabsPermissions
                                    as $ptPermItem
                                ): ?>

                                <option
                                    value="<?= htmlspecialchars(
                                        $ptPermItem[1]
                                    ) ?>">
                                    <?= $ptPermItem[2] === null
                                        ? ''
                                        : '- ' ?><?= htmlspecialchars(
                                        $ptPermItem[1]
                                    ) ?>
                                </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                    </div>

                </div>

            </div>

            <div class="ln-actions">

                <button
                    type="submit"
                    name="create_page_tab"
                    value="1"
                    class="approve-btn"
                    id="pageTabCreateBtn">
                    Create
                </button>

                <button
                    type="submit"
                    name="update_page_tab"
                    value="1"
                    class="approve-btn"
                    id="pageTabUpdateBtn"
                    style="display:none;">
                    Save
                </button>

                <button
                    type="button"
                    class="deny-btn"
                    onclick="closePageTabModal()">
                    Cancel
                </button>

            </div>

        </form>

    </div>

</div>

<script>

function openPageTabModal(
    tabId,
    tabName,
    tabHref,
    tabPermission,
    tabSort
){

    document
        .getElementById('pageTabModalTitle')
        .textContent =
            tabId
                ? 'Edit Tab'
                : 'Add Tab';

    document
        .getElementById('pageTabId')
        .value = tabId || '';

    document
        .getElementById('pageTabName')
        .value = tabName || '';

    document
        .getElementById('pageTabHref')
        .value = tabHref || '';

    document
        .getElementById('pageTabPermission')
        .value = tabPermission || '';

    document
        .getElementById('pageTabSort')
        .value =
            tabSort === null || tabSort === undefined
                ? 0
                : tabSort;

    document
        .getElementById('pageTabCreateBtn')
        .style.display =
            tabId ? 'none' : '';

    document
        .getElementById('pageTabUpdateBtn')
        .style.display =
            tabId ? '' : 'none';

    document
        .getElementById('pageTabModal')
        .style.display = 'flex';

}

function closePageTabModal(){

    document
        .getElementById('pageTabModal')
        .style.display = 'none';

}

</script>

<?php endif; ?>

<?php endif; ?>
