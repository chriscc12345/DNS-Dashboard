<?php

/*
 * Update003 - Shared Portal Favicon
 *
 * Uses the configured managed favicon when valid and present.
 * Falls back safely to the factory favicon.
 */

$portalFaviconHref =
    'images/favicon.png';

if (
    isset($FASTAPI_URL)
    && is_string($FASTAPI_URL)
    && $FASTAPI_URL !== ''
) {

    $faviconSettingsJson =
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        );

    if ($faviconSettingsJson !== false) {

        $faviconSettings =
            json_decode(
                $faviconSettingsJson,
                true
            );

        if (is_array($faviconSettings)) {

            $configuredFavicon =
                trim(
                    (string)(
                        $faviconSettings['portal_favicon']
                        ?? ''
                    )
                );

            if (
                preg_match(
                    '#^uploads/appearance/favicon_[a-f0-9]{32}\.webp$#',
                    $configuredFavicon
                )
            ) {

                $faviconAbsolutePath =
                    dirname(__DIR__)
                    . '/'
                    . $configuredFavicon;

                if (is_file($faviconAbsolutePath)) {
                    $portalFaviconHref =
                        $configuredFavicon;
                }
            }
        }
    }
}

$portalFaviconType =
    str_ends_with(
        strtolower($portalFaviconHref),
        '.webp'
    )
        ? 'image/webp'
        : 'image/png';

?>
<link
    rel="icon"
    type="<?= htmlspecialchars(
        $portalFaviconType,
        ENT_QUOTES,
        'UTF-8'
    ) ?>"
    href="<?= htmlspecialchars(
        $portalFaviconHref,
        ENT_QUOTES,
        'UTF-8'
    ) ?>">
