<!DOCTYPE html>
<html>
<head>
    <title>Access Denied</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
    <link
        rel="icon"
        type="image/png"
        href="images/favicon.png">
    
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" /> 

    <style>

    .access-denied{
        display:flex;
        justify-content:center;
        align-items:center;
        height:100vh;
    }

    .access-denied-box{
        background:#212e36;
        padding:40px;
        border-radius:12px;
        text-align:center;
        width:500px;
        box-shadow:
            0 10px 30px rgba(0,0,0,.35);
    }

    .access-denied-box h1{
        color:#dc2626;
    }

    </style>

   
    
</head>
<body>

<div class="access-denied">

    <div class="access-denied-box">

        <h1>Access Denied</h1>

        <p>
            You do not have permission to access this page.
        </p>

        <br>

        <a
            href="dashboard.php"
            class="edit-btn">

            Return To Dashboard

        </a>

    </div>

</div>

</body>
</html>