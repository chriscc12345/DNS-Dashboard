<?php

/*
 * User Management tab navigation (render).
 * Tabs come from the database so holders of the
 * Edit Settings Fields permission can add, edit
 * and remove tabs across the User Management pages.
 *
 * The head include loads the tab data and runs
 * the add/edit/delete POST handlers BEFORE any
 * page output so redirects work cleanly. Pages
 * must require it at the top; the require_once
 * below is a no-op safety net when they do.
 */

require_once __DIR__
    . '/user-management-tabs-head.php';
?>
<nav class="appearance-tabs um-tabs">

    <?php foreach ($umTabs as $umTab):

        $umTabHref =
            trim(
                (string)(
                    $umTab['tab_href']
                    ?? ''
                )
            );

        $umTabPermission =
            trim(
                (string)(
                    $umTab['tab_permission']
                    ?? ''
                )
            );

        $umTabIsCurrent =
            $umTabHref === $umTabsCurrentPage;

        if (
            !$umTabIsCurrent
            &&
            $umTabPermission !== ''
            &&
            !hasPermission($umTabPermission)
        ) {
            continue;
        }

    ?>

    <a
        href="<?= htmlspecialchars($umTabHref) ?>"
        class="<?= $umTabIsCurrent ? 'active' : '' ?>">
        <?= htmlspecialchars($umTab['tab_name']) ?>
    </a>

    <?php if ($umTabsCanEdit): ?>

    <button
        type="button"
        class="settings-edit-btn um-tab-btn"
        onclick="openUmTabModal(
            <?= (int)$umTab['id'] ?>,
            '<?= htmlspecialchars(
                $umTab['tab_name'],
                ENT_QUOTES
            ) ?>',
            '<?= htmlspecialchars(
                $umTabHref,
                ENT_QUOTES
            ) ?>',
            '<?= htmlspecialchars(
                $umTabPermission,
                ENT_QUOTES
            ) ?>'
        )">
        Edit
    </button>

    <form
        method="post">

        <input
            type="hidden"
            name="tab_id"
            value="<?= (int)$umTab['id'] ?>">

        <button
            type="submit"
            name="delete_um_tab"
            value="1"
            class="settings-delete-btn um-tab-btn"
            onclick="return confirm(
                'Delete this tab?'
            );">
            Delete
        </button>

    </form>

    <?php endif; ?>

    <?php endforeach; ?>

    <?php if ($umTabsCanEdit): ?>

    <button
        type="button"
        class="settings-add-btn um-add-tab-btn"
        onclick="openUmTabModal(null, '', '', '')">
        + Add Tab
    </button>

    <?php endif; ?>

</nav>

<?php if ($umTabsCanEdit): ?>

<!--
    Reuses the Add User modal classes so
    the tab popup matches the portal
    modal style; .ln-modal gives it the
    shared popup styling.
-->

<div id="umTabModal"
     class="modal ln-modal">

    <div class="user-modal-content
              add-user-modal">

        <div class="add-user-titlebar">

            <h3 id="umTabModalTitle">
                Add Tab
            </h3>

            <button
                type="button"
                class="add-user-close"
                onclick="closeUmTabModal()"
                aria-label="Close">
                &times;
            </button>

        </div>

        <form method="post">

            <input
                type="hidden"
                name="tab_id"
                id="umTabId"
                value="">

            <input
                type="hidden"
                name="tab_sort"
                id="umTabSort"
                value="0">

            <div class="add-user-layout">

                <div class="add-user-fields">

                    <div class="add-user-grid">

                        <div class="portal-field">

                            <label for="umTabName">
                                Tab Name
                            </label>

                            <input
                                type="text"
                                name="tab_name"
                                id="umTabName"
                                required>

                        </div>

                        <div class="portal-field">

                            <label for="umTabHref">
                                Link (page)
                            </label>

                            <input
                                type="text"
                                name="tab_href"
                                id="umTabHref"
                                placeholder="users.php">

                        </div>

                        <div class="portal-field"
                             style="grid-column:1 / -1;">

                            <label for="umTabPermission">
                                Required Permission
                            </label>

                            <select
                                name="tab_permission"
                                id="umTabPermission">

                                <option value="">
                                    No permission required
                                </option>

                                <?php foreach ($umTabsPermissions as $umPermItem): ?>

                                <option
                                    value="<?= htmlspecialchars(
                                        $umPermItem[1]
                                    ) ?>">
                                    <?= $umPermItem[2] === null
                                        ? ''
                                        : '- ' ?><?= htmlspecialchars(
                                        $umPermItem[1]
                                    ) ?>
                                </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                    </div>

                </div>

            </div>

            <div class="ln-actions">

                <button
                    type="submit"
                    name="create_um_tab"
                    value="1"
                    class="approve-btn"
                    id="umTabCreateBtn">
                    Create
                </button>

                <button
                    type="submit"
                    name="update_um_tab"
                    value="1"
                    class="approve-btn"
                    id="umTabUpdateBtn"
                    style="display:none;">
                    Save
                </button>

                <button
                    type="button"
                    class="deny-btn"
                    onclick="closeUmTabModal()">
                    Cancel
                </button>

            </div>

        </form>

    </div>

</div>

<script>

function openUmTabModal(
    tabId,
    tabName,
    tabHref,
    tabPermission
){

    document
        .getElementById('umTabModalTitle')
        .textContent =
            tabId
                ? 'Edit Tab'
                : 'Add Tab';

    document
        .getElementById('umTabId')
        .value = tabId || '';

    document
        .getElementById('umTabName')
        .value = tabName || '';

    document
        .getElementById('umTabHref')
        .value = tabHref || '';

    document
        .getElementById('umTabPermission')
        .value = tabPermission || '';

    document
        .getElementById('umTabCreateBtn')
        .style.display =
            tabId ? 'none' : '';

    document
        .getElementById('umTabUpdateBtn')
        .style.display =
            tabId ? '' : 'none';

    document
        .getElementById('umTabModal')
        .style.display = 'flex';

}

function closeUmTabModal(){

    document
        .getElementById('umTabModal')
        .style.display = 'none';

}

</script>

<?php endif; ?>
