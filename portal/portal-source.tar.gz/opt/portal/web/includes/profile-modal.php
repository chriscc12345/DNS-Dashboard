<?php

/*
 * Portal Basic Theme
 * Shared My Profile Modal
 *
 * IMPORTANT:
 * Username comes from the authenticated PHP session.
 * It is never accepted from a browser-supplied profile selector.
 */

$myProfileUsername =
    isset($_SESSION['username'])
        ? (string)$_SESSION['username']
        : '';

$myProfileCountries =
    require __DIR__ . '/countries.php';

?>

<div
    id="myProfileModal"
    class="portal-profile-overlay"
    aria-hidden="true">

    <div
        class="portal-profile-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="myProfileTitle">

        <div class="portal-profile-titlebar">

            <h3 id="myProfileTitle">
                My Profile
            </h3>

            <button
                type="button"
                class="portal-profile-close"
                id="myProfileClose"
                aria-label="Close profile">
                &times;
            </button>

        </div>

        <form id="myProfileForm">

            <input
                type="hidden"
                id="myProfileUsername"
                value="<?= htmlspecialchars(
                    $myProfileUsername,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>">

            <input
                type="hidden"
                id="myProfilePhoto"
                value="">

            <input
                type="hidden"
                id="myProfileGroupId"
                value="">

            <section class="portal-profile-header profile-editor-header">

                <div
                    class="portal-profile-avatar profile-avatar-upload"
                    id="myProfileAvatar"
                    aria-label="Profile picture">

                    <img
                        id="myProfileAvatarPreview"
                        class="profile-avatar-preview"
                        src=""
                        alt=""
                        style="display:none;">

                    <span
                        class="profile-avatar-icon"
                        id="myProfileAvatarIcon">
                        &#128100;
                    </span>

                </div>

                <div class="portal-profile-identity profile-editor-identity">

                    <div
                        class="portal-profile-name profile-editor-name"
                        id="myProfileName">
                        User
                    </div>

                    <div
                        class="portal-profile-email profile-editor-email"
                        id="myProfileEmail">
                    </div>

                    <div class="portal-profile-meta profile-editor-meta">

                        <span id="myProfileGroup">
                            Policy Group - Unassigned
                        </span>

                        <span id="myProfileUserId">
                            User ID: —
                        </span>

                    </div>

                </div>

            </section>

            <section class="portal-profile-section">

                <div class="portal-profile-section-heading">
                    <h4>Profile Details</h4>
                </div>

                <div class="portal-profile-grid portal-form-grid">

                    <div class="portal-profile-field portal-field">

                        <label for="myProfileDisplayName">
                            Display Name
                        </label>

                        <input
                            type="text"
                            id="myProfileDisplayName"
                            required>

                    </div>

                    <div class="portal-profile-field portal-field">

                        <label for="myProfileSurname">
                            Surname
                        </label>

                        <input
                            type="text"
                            id="myProfileSurname">

                    </div>

                    <div class="portal-profile-field portal-field">

                        <label for="myProfileDepartment">
                            Department
                        </label>

                        <input
                            type="text"
                            id="myProfileDepartment">

                    </div>

                    <div class="portal-profile-field portal-field">

                        <label for="myProfileUsernameDisplay">
                            Username
                        </label>

                        <input
                            type="text"
                            id="myProfileUsernameDisplay"
                            readonly>

                    </div>

                    <div class="portal-profile-field portal-field">

                        <label for="myProfileEmailAddress">
                            Email Address
                        </label>

                        <input
                            type="email"
                            id="myProfileEmailAddress">

                    </div>

                    <div class="portal-profile-field portal-field">

                        <label for="myProfileCountryCode">
                            Country
                        </label>

                        <select
                            id="myProfileCountryCode"
                            required>

                            <?php foreach(
                                $myProfileCountries
                                as $country
                            ): ?>

                                <option
                                    value="<?= htmlspecialchars(
                                        $country['dial_code'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                    data-country="<?= htmlspecialchars(
                                        $country['code'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>">

                                    <?= htmlspecialchars(
                                        $country['name']
                                        . ' ('
                                        . $country['dial_code']
                                        . ')',
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <div class="portal-profile-field portal-field">

                        <label for="myProfileMobileNumber">
                            Mobile Number
                        </label>

                        <input
                            type="text"
                            id="myProfileMobileNumber">

                    </div>

                </div>

            </section>

            <div
                id="myProfileCustomFields"
                class="portal-profile-custom-fields">
            </div>

            <!--
                UPDATE - Portal two-factor authentication.
                Self-service enrolment: scan the QR with any
                authenticator app, confirm with a live code.
            -->

            <section
                class="portal-profile-section portal-profile-custom-section">

                <div class="portal-profile-section-heading">
                    <h4>Two-Factor Authentication</h4>
                </div>

                <div id="myProfileTwofaBody">
                </div>

            </section>

            <div
                class="portal-profile-message"
                id="myProfileMessage"
                role="status">
            </div>

            <div class="portal-profile-actions">

                <button
                    type="submit"
                    class="portal-profile-save"
                    id="myProfileSave">
                    Save Changes
                </button>

                <button
                    type="button"
                    class="portal-profile-cancel"
                    id="myProfileCancel">
                    Cancel
                </button>

            </div>

        </form>

    </div>

</div>

<script>
(function () {

    const authenticatedUsername =
        <?= json_encode($myProfileUsername) ?>;

    const modal =
        document.getElementById('myProfileModal');

    const form =
        document.getElementById('myProfileForm');

    if (!modal || !form) {
        return;
    }

    function element(id) {
        return document.getElementById(id);
    }

    function setMessage(message, isError) {

        const box = element('myProfileMessage');

        box.textContent = message || '';

        box.classList.toggle(
            'is-error',
            Boolean(isError)
        );

        box.classList.toggle(
            'is-success',
            Boolean(message) && !isError
        );
    }

    function closeMyProfileModal() {

        modal.classList.remove('is-open');

        modal.setAttribute(
            'aria-hidden',
            'true'
        );

        setMessage('', false);
    }

    function escapeProfileHtml(value) {

        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }


    function renderMyProfileCustomFields(fields) {

        const container =
            element('myProfileCustomFields');

        if (!container) {
            return;
        }

        container.innerHTML = '';

        if (!Array.isArray(fields) || fields.length === 0) {
            return;
        }

        const sections = new Map();

        fields.forEach(function (field) {

            const sectionId =
                Number(field.section_id || 0);

            if (!sections.has(sectionId)) {

                sections.set(
                    sectionId,
                    {
                        id: sectionId,
                        name:
                            field.section_name
                            || 'Custom User Fields',
                        sort:
                            Number(
                                field.section_sort_order
                                || 0
                            ),
                        fields: []
                    }
                );
            }

            sections.get(sectionId)
                .fields
                .push(field);
        });

        const orderedSections =
            Array.from(sections.values())
                .sort(function (a, b) {

                    if (a.sort !== b.sort) {
                        return a.sort - b.sort;
                    }

                    return a.id - b.id;
                });

        orderedSections.forEach(
            function (section) {

                const sectionElement =
                    document.createElement('section');

                sectionElement.className =
                    'portal-profile-section ' +
                    'portal-profile-custom-section';

                const heading =
                    document.createElement('div');

                heading.className =
                    'portal-profile-section-heading';

                const title =
                    document.createElement('h4');

                title.textContent =
                    section.name;

                heading.appendChild(title);
                sectionElement.appendChild(heading);

                const grid =
                    document.createElement('div');

                grid.className =
                    'portal-profile-grid portal-form-grid';

                section.fields.forEach(
                    function (field) {

                        const wrapper =
                            document.createElement('div');

                        wrapper.className =
                            'portal-profile-field portal-field';

                        const label =
                            document.createElement('label');

                        const inputId =
                            'myProfileCustomField_' +
                            String(field.id);

                        label.setAttribute(
                            'for',
                            inputId
                        );

                        label.textContent =
                            field.field_name
                            +
                            (
                                field.required
                                    ? ' *'
                                    : ''
                            );

                        wrapper.appendChild(label);

                        const type =
                            String(
                                field.field_type
                                || 'text'
                            ).toLowerCase();

                        let input;

                        if (type === 'checkbox') {

                            input =
                                document.createElement(
                                    'input'
                                );

                            input.type = 'checkbox';

                            input.checked =
                                ['1', 'true', 'yes', 'on']
                                    .includes(
                                        String(
                                            field.value
                                            || ''
                                        ).toLowerCase()
                                    );

                        } else {

                            input =
                                document.createElement(
                                    'input'
                                );

                            if (
                                type === 'email'
                                ||
                                type === 'number'
                                ||
                                type === 'date'
                            ) {
                                input.type = type;
                            } else {
                                input.type = 'text';
                            }

                            input.value =
                                field.value ?? '';

                            if (field.required) {
                                input.required = true;
                            }
                        }

                        input.id = inputId;

                        input.dataset.customFieldId =
                            String(field.id);

                        input.dataset.customFieldType =
                            type;

                        const prepend =
                            String(
                                field.prepend
                                || ''
                            );

                        if (
                            prepend !== ''
                            &&
                            type !== 'checkbox'
                        ) {

                            const inputGroup =
                                document.createElement(
                                    'div'
                                );

                            inputGroup.className =
                                'custom-field-input-with-prepend';

                            const prefix =
                                document.createElement(
                                    'span'
                                );

                            prefix.className =
                                'custom-field-prepend';

                            prefix.textContent =
                                prepend;

                            const control =
                                document.createElement(
                                    'div'
                                );

                            control.className =
                                'custom-field-prepend-control';

                            control.appendChild(input);

                            inputGroup.appendChild(prefix);
                            inputGroup.appendChild(control);

                            wrapper.appendChild(
                                inputGroup
                            );

                        } else {

                            wrapper.appendChild(input);
                        }

                        grid.appendChild(wrapper);
                    }
                );

                sectionElement.appendChild(grid);
                container.appendChild(sectionElement);
            }
        );
    }


    function collectMyProfileCustomFields() {

        const container =
            element('myProfileCustomFields');

        if (!container) {
            return [];
        }

        return Array.from(
            container.querySelectorAll(
                '[data-custom-field-id]'
            )
        ).map(function (input) {

            const type =
                input.dataset.customFieldType
                || 'text';

            return {
                field_id:
                    Number(
                        input.dataset.customFieldId
                    ),

                value:
                    type === 'checkbox'
                        ? (
                            input.checked
                                ? '1'
                                : '0'
                        )
                        : input.value
            };
        });
    }


    async function loadMyProfile() {

        setMessage('', false);

        const response = await fetch(
            '/my-profile-api.php?action=get',
            {
                credentials: 'same-origin'
            }
        );

        if (!response.ok) {
            throw new Error(
                'Unable to load profile.'
            );
        }

        const result =
            await response.json();

        if (
            !result
            ||
            result.success !== true
            ||
            !result.profile
        ) {
            throw new Error(
                result && result.message
                    ? result.message
                    : 'Profile was not found.'
            );
        }

        const profile =
            result.profile;

        renderMyProfileCustomFields(
            Array.isArray(result.custom_fields)
                ? result.custom_fields
                : []
        );

        if (
            !profile
            ||
            !profile.username
        ) {
            throw new Error(
                'Profile was not found.'
            );
        }

        /*
         * Defense in depth:
         * The returned profile must match the
         * authenticated session username.
         */
        if (
            String(profile.username).toLowerCase()
            !==
            String(authenticatedUsername).toLowerCase()
        ) {
            throw new Error(
                'Profile identity mismatch.'
            );
        }

        element(
            'myProfileUsername'
        ).value = authenticatedUsername;

        element(
            'myProfileUsernameDisplay'
        ).value = profile.username || authenticatedUsername;

        element(
            'myProfileDisplayName'
        ).value = profile.display_name || '';

        element(
            'myProfileSurname'
        ).value = profile.surname || '';

        element(
            'myProfileDepartment'
        ).value = profile.department || '';

        element(
            'myProfileEmailAddress'
        ).value = profile.email_address || '';

        element(
            'myProfileMobileNumber'
        ).value = profile.mobile_number || '';

        element(
            'myProfilePhoto'
        ).value = profile.photo || '';

        /*
         * Display the authenticated user's existing profile
         * picture using the same avatar presentation as Edit User.
         * My Profile remains display-only for the picture.
         */

        const avatarPreview =
            element('myProfileAvatarPreview');

        const avatarIcon =
            element('myProfileAvatarIcon');

        const profilePhoto =
            String(profile.photo || '').trim();

        if (avatarPreview && avatarIcon) {

            if (profilePhoto !== '') {

                avatarPreview.src =
                    '/'
                    + profilePhoto.replace(/^\/+/, '');

                avatarPreview.style.display = 'block';
                avatarIcon.style.display = 'none';

                avatarPreview.onerror = function () {
                    avatarPreview.removeAttribute('src');
                    avatarPreview.style.display = 'none';
                    avatarIcon.style.display = '';
                };

            } else {

                avatarPreview.removeAttribute('src');
                avatarPreview.style.display = 'none';
                avatarIcon.style.display = '';
            }
        }

        element(
            'myProfileGroupId'
        ).value =
            profile.group_id !== null
            &&
            profile.group_id !== undefined
                ? profile.group_id
                : '';

        const country =
            element('myProfileCountryCode');

        if (profile.country_code) {
            country.value =
                profile.country_code;
        }

        element(
            'myProfileName'
        ).textContent =
            profile.display_name
            ||
            profile.username
            ||
            authenticatedUsername;

        element(
            'myProfileEmail'
        ).textContent =
            profile.email_address || '';

        element(
            'myProfileUserId'
        ).textContent =
            'User ID: '
            +
            (
                profile.id !== null
                &&
                profile.id !== undefined
                    ? profile.id
                    : '—'
            );

        /*
         * Group is display-only.
         * PHP resolves the authoritative group name.
         */

        element(
            'myProfileGroup'
        ).textContent =
            'Policy Group - '
            +
            (
                profile.group_name
                ||
                'Unassigned'
            );
    }

    /*
     * UPDATE - Portal two-factor authentication UI.
     */

    const twofaBody =
        document.getElementById('myProfileTwofaBody');

    async function twofaApi(action, payload) {

        const response = await fetch(
            '/twofa-api.php?action=' + encodeURIComponent(action),
            {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload || {})
            }
        );

        if (!response.ok) {
            throw new Error('Request failed.');
        }

        return response.json();
    }

    function twofaMessage(text, ok) {

        const note = document.createElement('p');

        note.style.margin = '8px 0 0';
        note.style.fontSize = '13px';
        note.style.color = ok ? '#7fd6a4' : '#f2b8b8';

        note.textContent = text;

        return note;
    }

    function renderTwofaStatus(enabled) {

        while (twofaBody.firstChild) {
            twofaBody.removeChild(
                twofaBody.firstChild
            );
        }

        const wrap = document.createElement('div');
        wrap.className =
            'portal-profile-grid portal-form-grid';

        const text = document.createElement('div');
        text.style.fontSize = '13px';
        text.textContent = enabled
            ? 'Two-factor authentication is enabled for your account. A verification code is requested at every sign-in.'
            : 'Two-factor authentication is currently disabled for your account.';

        wrap.appendChild(text);

        const actions = document.createElement('div');
        actions.style.display = 'flex';
        actions.style.gap = '8px';
        actions.style.flexWrap = 'wrap';

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'table-btn';

        if (enabled) {

            button.textContent = 'Disable 2FA';

            button.addEventListener(
                'click',
                async function () {

                    const code =
                        prompt('Enter your current verification code to disable 2FA:');

                    if (!code) {
                        return;
                    }

                    try {
                        const result =
                            await twofaApi('disable', { code: code });

                        if (result.success) {
                            loadTwofaStatus();
                        } else {
                            alert(result.message || 'Unable to disable 2FA.');
                        }
                    } catch (error) {
                        alert('Unable to disable 2FA.');
                    }
                }
            );

        } else {

            button.textContent = 'Enable 2FA';

            button.addEventListener(
                'click',
                renderTwofaSetup
            );
        }

        actions.appendChild(button);
        wrap.appendChild(actions);
        twofaBody.appendChild(wrap);
    }

    async function renderTwofaSetup() {

        let result;

        try {

            result = await twofaApi('setup');

            if (!result.success) {
                alert(result.message || 'Unable to start 2FA setup.');
                return;
            }

        } catch (error) {
            alert('Unable to start 2FA setup.');
            return;
        }

        while (twofaBody.firstChild) {
            twofaBody.removeChild(
                twofaBody.firstChild
            );
        }

        const wrap = document.createElement('div');
        wrap.style.display = 'flex';
        wrap.style.flexDirection = 'column';
        wrap.style.gap = '12px';
        wrap.style.alignItems = 'center';

        const steps = document.createElement('div');
        steps.style.fontSize = '13px';
        steps.textContent =
            'Scan this QR code with your authenticator app ' +
            '(Google Authenticator, Authy, Microsoft Authenticator...).';

        wrap.appendChild(steps);

        const qr = document.createElement('img');
        qr.src = result.qr_png;
        qr.alt = 'Two-factor QR code';
        qr.style.width = '180px';
        qr.style.height = '180px';
        qr.style.borderRadius = '10px';
        qr.style.background = '#ffffff';
        qr.style.padding = '8px';

        wrap.appendChild(qr);

        const secretLabel = document.createElement('div');
        secretLabel.style.fontSize = '12px';
        secretLabel.textContent =
            'Or enter this key manually: ' + result.secret;

        wrap.appendChild(secretLabel);

        const codeInput = document.createElement('input');
        codeInput.type = 'text';
        codeInput.inputMode = 'numeric';
        codeInput.pattern = '[0-9]*';
        codeInput.maxLength = 6;
        codeInput.placeholder = 'Verification code';
        codeInput.style.textAlign = 'center';
        codeInput.style.letterSpacing = '4px';
        codeInput.style.fontSize = '16px';
        codeInput.style.width = '180px';
        codeInput.style.padding = '10px';
        codeInput.style.borderRadius = '8px';
        codeInput.style.border = '1px solid var(--theme-basic-input-border, #637681)';
        codeInput.style.background = 'var(--theme-basic-input-background, #202c34)';
        codeInput.style.color = 'var(--theme-basic-input-text, #ffffff)';

        wrap.appendChild(codeInput);

        const verify = document.createElement('button');
        verify.type = 'button';
        verify.className = 'table-btn';
        verify.textContent = 'Verify & Enable';

        verify.addEventListener(
            'click',
            async function () {

                const code = codeInput.value.trim();

                if (!code) {
                    codeInput.focus();
                    return;
                }

                try {

                    const enableResult =
                        await twofaApi('enable', { code: code });

                    if (enableResult.success) {
                        renderTwofaStatus(true);
                    } else {
                        wrap.appendChild(
                            twofaMessage(
                                enableResult.message
                                    || 'Invalid verification code.',
                                false
                            )
                        );
                    }

                } catch (error) {
                    wrap.appendChild(
                        twofaMessage(
                            'Unable to verify the code.',
                            false
                        )
                    );
                }
            }
        );

        wrap.appendChild(verify);

        twofaBody.appendChild(wrap);
    }

    async function loadTwofaStatus() {

        try {

            const result =
                await twofaApi('status');

            if (result.success) {
                renderTwofaStatus(
                    result.enabled === true
                );
            }

        } catch (error) {
            /* the profile still loads without 2fa state */
        }
    }

    async function openMyProfileModal() {

        modal.classList.add('is-open');

        modal.setAttribute(
            'aria-hidden',
            'false'
        );

        element(
            'myProfileName'
        ).textContent = 'Loading...';

        element(
            'myProfileEmail'
        ).textContent = '';

        element(
            'myProfileGroup'
        ).textContent =
            'Policy Group - …';

        element(
            'myProfileUserId'
        ).textContent =
            'User ID: —';

        try {

            await loadMyProfile();

        } catch (error) {

            setMessage(
                error.message
                ||
                'Unable to load profile.',
                true
            );
        }

        /* Portal 2FA status alongside the profile. */

        loadTwofaStatus();
    }

    window.addEventListener(
        'portal:open-my-profile',
        function () {

            /*
             * Intentionally ignore event.detail.username.
             * The authenticated PHP session owns identity.
             */

            openMyProfileModal();
        }
    );

    element(
        'myProfileClose'
    ).addEventListener(
        'click',
        closeMyProfileModal
    );

    element(
        'myProfileCancel'
    ).addEventListener(
        'click',
        closeMyProfileModal
    );

    modal.addEventListener(
        'click',
        function (event) {

            if (event.target === modal) {
                closeMyProfileModal();
            }
        }
    );

    document.addEventListener(
        'keydown',
        function (event) {

            if (
                event.key === 'Escape'
                &&
                modal.classList.contains(
                    'is-open'
                )
            ) {
                closeMyProfileModal();
            }
        }
    );

    form.addEventListener(
        'submit',
        async function (event) {

            event.preventDefault();

            const saveButton =
                element('myProfileSave');

            saveButton.disabled = true;

            setMessage(
                'Saving...',
                false
            );

            const payload = {
                username:
                    authenticatedUsername,

                display_name:
                    element(
                        'myProfileDisplayName'
                    ).value.trim(),

                surname:
                    element(
                        'myProfileSurname'
                    ).value.trim(),

                department:
                    element(
                        'myProfileDepartment'
                    ).value.trim(),

                email_address:
                    element(
                        'myProfileEmailAddress'
                    ).value.trim(),

                country_code:
                    element(
                        'myProfileCountryCode'
                    ).value,

                mobile_number:
                    element(
                        'myProfileMobileNumber'
                    ).value.trim(),

                custom_fields:
                    collectMyProfileCustomFields()
            };

            try {

                if (!payload.display_name) {
                    throw new Error(
                        'Display Name is required.'
                    );
                }

                const response =
                    await fetch(
                        '/my-profile-api.php?action=save',
                        {
                            method: 'POST',

                            credentials:
                                'same-origin',

                            headers: {
                                'Content-Type':
                                    'application/json'
                            },

                            body:
                                JSON.stringify(
                                    payload
                                )
                        }
                    );

                if (!response.ok) {
                    throw new Error(
                        'Unable to save profile.'
                    );
                }

                const result =
                    await response.json();

                if (
                    result
                    &&
                    result.success === false
                ) {
                    throw new Error(
                        result.message
                        ||
                        'Unable to save profile.'
                    );
                }

                element(
                    'myProfileName'
                ).textContent =
                    payload.display_name;

                element(
                    'myProfileEmail'
                ).textContent =
                    payload.email_address;

                setMessage(
                    'Profile saved successfully.',
                    false
                );

            } catch (error) {

                setMessage(
                    error.message
                    ||
                    'Unable to save profile.',
                    true
                );

            } finally {

                saveButton.disabled = false;
            }
        }
    );

})();
</script>
