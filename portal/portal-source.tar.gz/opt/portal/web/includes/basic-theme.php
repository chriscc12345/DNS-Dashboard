<?php
/*
 * UPDATE003 - Basic Theme runtime variables
 *
 * Converts the validated theme_basic_* portal settings into
 * CSS custom properties. This file does not fetch settings.
 *
 * The including page/component supplies $basicThemeSettings.
 */

if (
    !isset($basicThemeSettings)
    ||
    !is_array($basicThemeSettings)
) {
    $basicThemeSettings = [];
}

/*
 * The Firewall theme: a fixed palette taken
 * from the network firewall appliance's own
 * interface - deep navy panels on near-black
 * with sky-blue and mint accents. Selecting
 * the theme replaces any customised basic
 * tokens; the palette itself is by design.
 */

if (
    (
        $basicThemeSettings['theme']
        ?? 'basic'
    )
    === 'firewall'
) {

    $basicThemeSettings = [

        'theme_basic_page_background' => '#071019',
        'theme_basic_content_background' => '#071019',

        'theme_basic_text_primary' => '#edf7ff',
        'theme_basic_text_secondary' => '#91a6b8',
        'theme_basic_border' => '#233545',

        'theme_basic_accent' => '#36a3ff',
        'theme_basic_accent_bright' => '#66c2ff',
        'theme_basic_success' => '#2a6452',
        'theme_basic_warning' => '#ffbd59',
        'theme_basic_error' => '#ff6678',

        'theme_basic_sidebar_background_top' => '#09141e',
        'theme_basic_sidebar_background_bottom' => '#071019',
        'theme_basic_sidebar_text' => '#edf7ff',
        'theme_basic_sidebar_icon' => '#edf7ff',
        'theme_basic_sidebar_hover' => '#152534',
        'theme_basic_sidebar_active' => '#36a3ff',
        'theme_basic_sidebar_active_text' => '#08121b',
        'theme_basic_sidebar_active_accent' => '#66c2ff',
        'theme_basic_sidebar_profile_background' => '#09141e',

        'theme_basic_banner_fallback' => '#09141e',
        'theme_basic_banner_text' => '#edf7ff',
        'theme_basic_banner_secondary_text' => '#91a6b8',
        'theme_basic_banner_accent' => '#36a3ff',

        'theme_basic_card_background' => '#0d1823',
        'theme_basic_card_background_alt' => '#152534',
        'theme_basic_card_border' => '#233545',
        'theme_basic_card_text' => '#edf7ff',

        'theme_basic_input_background' => '#152534',
        'theme_basic_input_background_readonly' => '#0d1823',
        'theme_basic_input_text' => '#edf7ff',
        'theme_basic_input_border' => '#233545',
        'theme_basic_input_focus' => '#36a3ff',
        'theme_basic_input_placeholder' => '#91a6b8',

        'theme_basic_button_primary' => '#36a3ff',
        'theme_basic_button_primary_hover' => '#2b8fd9',
        'theme_basic_button_primary_text' => '#08121b',
        'theme_basic_button_secondary' => '#152534',
        'theme_basic_button_secondary_hover' => '#1b3040',
        'theme_basic_button_secondary_text' => '#edf7ff',

        'theme_basic_table_header' => '#0d1823',
        'theme_basic_table_row' => '#071019',
        'theme_basic_table_row_alt' => '#0d1823',
        'theme_basic_table_hover' => '#152534',
        'theme_basic_table_border' => '#233545',
        'theme_basic_table_text' => '#edf7ff',

        'theme_basic_modal_background' => '#0d1823',
        'theme_basic_modal_header' => '#09141e',
        'theme_basic_modal_border' => '#233545',
        'theme_basic_modal_text' => '#edf7ff',

        'theme_basic_login_card_background' => '#0d1823',
        'theme_basic_login_text' => '#edf7ff',
        'theme_basic_login_secondary_text' => '#91a6b8',
        'theme_basic_login_input_background' => '#152534',
        'theme_basic_login_input_border' => '#233545',
        'theme_basic_login_button' => '#36a3ff',
        'theme_basic_login_button_text' => '#08121b',

        'theme_basic_button_action' => '#36a3ff',
        'theme_basic_button_action_hover' => '#2b8fd9',

        'theme_basic_control_accent' => '#36a3ff',
        'theme_basic_control_hover' => '#4db8ff',
        'theme_basic_control_focus' => '#36a3ff'
    ];
}

$basicThemeDefaults = [
    'page_background'            => '#111c23',
    'content_background'         => '#111c23',
    'text_primary'               => '#ffffff',
    'text_secondary'             => '#aebbc3',
    'border'                     => '#637681',
    'accent'                     => '#c79a00',
    'accent_bright'              => '#ebc100',
    'success'                    => '#237a4b',
    'warning'                    => '#c79a00',
    'error'                      => '#b83b3b',

    'sidebar_background_top'     => '#142330',
    'sidebar_background_bottom'  => '#101d28',
    'sidebar_text'               => '#ffffff',
    'sidebar_icon'               => '#ffffff',
    'sidebar_hover'              => '#25333d',
    'sidebar_active'             => '#a88400',
    'sidebar_active_text'        => '#ffffff',
    'sidebar_active_accent'      => '#ebc100',
    'sidebar_profile_background' => '#142330',

    'banner_fallback'            => '#18232a',
    'banner_text'                => '#ffffff',
    'banner_secondary_text'      => '#aebbc3',
    'banner_accent'              => '#c79a00',

    'card_background'            => '#18232a',
    'card_background_alt'        => '#202c34',
    'card_border'                => '#637681',
    'card_text'                  => '#ffffff',

    'input_background'           => '#202c34',
    'input_background_readonly'  => '#1c272e',
    'input_text'                 => '#ffffff',
    'input_border'               => '#637681',
    'input_focus'                => '#db9812',
    'input_placeholder'          => '#aebbc3',

    'button_primary'             => '#c79a00',
    'button_primary_hover'       => '#a88400',
    'button_primary_text'        => '#111827',
    'button_secondary'           => '#24313a',
    'button_secondary_hover'     => '#2b3942',
    'button_action'                => '#966e00',
    'button_action_hover'           => '#b88900',
    'button_secondary_text'      => '#ffffff',

    'table_header'               => '#18232a',
    'table_row'                  => '#111c23',
    'table_row_alt'              => '#18232a',
    'table_hover'                => '#202c34',
    'table_border'               => '#637681',
    'table_text'                 => '#ffffff',

    'modal_background'           => '#18232a',
    'modal_header'               => '#142330',
    'modal_border'               => '#637681',
    'modal_text'                 => '#ffffff',

    'login_card_background'      => '#ffffff',
    'login_text'                 => '#111827',
    'login_secondary_text'       => '#64748b',
    'login_input_background'     => '#ffffff',
    'login_input_border'         => '#d1d5db',
    'login_button'               => '#c79a00',
    'login_button_text'          => '#111827',

    'control_accent'             => '#c79a00',
    'control_hover'              => '#d4af37',
    'control_focus'              => '#db9812',
];

$basicThemeValues = [];

foreach ($basicThemeDefaults as $name => $defaultValue) {
    $settingKey = 'theme_basic_' . $name;

    $candidate = strtolower(
        trim(
            (string)(
                $basicThemeSettings[$settingKey]
                ?? $defaultValue
            )
        )
    );

    if (!preg_match('/^#[0-9a-f]{6}$/', $candidate)) {
        $candidate = $defaultValue;
    }

    $basicThemeValues[$name] = $candidate;
}
?>

<style id="basic-theme-runtime-variables">
:root {
<?php foreach ($basicThemeValues as $name => $value): ?>
    --theme-basic-<?= htmlspecialchars(str_replace('_', '-', $name), ENT_QUOTES, 'UTF-8') ?>: <?= htmlspecialchars($value, ENT_QUOTES, 'UTF-8') ?>;
<?php endforeach; ?>
}
</style>
