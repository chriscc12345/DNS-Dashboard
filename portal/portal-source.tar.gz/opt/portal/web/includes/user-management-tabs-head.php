<?php

/*
 * User Management tabs - request head.
 * Loads tab data and handles add/edit/delete POSTs
 * BEFORE any page output so redirects work cleanly.
 *
 * Expects: auth.php + config.php already included.
 */

$umTabs =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/user-management-tabs'
        ),
        true
    ) ?? [];

$umTabsCurrentPage =
    basename($_SERVER['PHP_SELF']);

$umTabsCanEdit =
    hasPermission(
        'Edit Settings Fields'
    );

$umTabsPermissions =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/permissions'
        ),
        true
    ) ?? [];

function umTabsApiPost($path, $payload) {

    global $FASTAPI_URL;

    return file_get_contents(
        $FASTAPI_URL . $path,
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => json_encode($payload)
            ]
        ])
    );
}

// Only holders of Edit Settings Fields
// may change the tabs (the UI is gated
// the same way - direct POSTs must not
// bypass it).

if (
    isset($_POST['create_um_tab'])
    && $umTabsCanEdit
) {

    umTabsApiPost(
        '/user-management-tabs/create',
        [
            'tab_name' =>
                trim((string)$_POST['tab_name']),
            'tab_href' =>
                trim((string)$_POST['tab_href']),
            'tab_permission' =>
                trim((string)$_POST['tab_permission']),
            'sort_order' =>
                count($umTabs)
        ]
    );

    header(
        'Location: '
        . $umTabsCurrentPage
    );
    exit;
}

if (
    isset($_POST['update_um_tab'])
    && $umTabsCanEdit
) {

    umTabsApiPost(
        '/user-management-tabs/'
            . (int)$_POST['tab_id']
            . '/update',
        [
            'tab_name' =>
                trim((string)$_POST['tab_name']),
            'tab_href' =>
                trim((string)$_POST['tab_href']),
            'tab_permission' =>
                trim((string)$_POST['tab_permission']),
            'sort_order' =>
                (int)$_POST['tab_sort']
        ]
    );

    header(
        'Location: '
        . $umTabsCurrentPage
    );
    exit;
}

if (
    isset($_POST['delete_um_tab'])
    && $umTabsCanEdit
) {

    umTabsApiPost(
        '/user-management-tabs/'
            . (int)$_POST['tab_id']
            . '/delete',
        []
    );

    header(
        'Location: '
        . $umTabsCurrentPage
    );
    exit;
}
?>
