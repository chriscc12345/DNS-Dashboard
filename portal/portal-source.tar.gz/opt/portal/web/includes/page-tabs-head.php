<?php

/*
 * Page tabs - request head.
 * Works out which tab group owns the current
 * page (by matching the page against the group
 * key, the tab links and their alternates) so
 * the hub's pages render as an editable tab
 * bar - the same way the User Management pages
 * manage their tabs.
 *
 * Handles add/edit/delete POSTs BEFORE any
 * page output so redirects work cleanly. A tab
 * created from inside a page also creates its
 * target page when it does not exist (handled
 * by the API).
 *
 * Expects: auth.php + config.php already
 * included.
 */

$pageTabsCurrentPage =
    basename($_SERVER['PHP_SELF']);

$pageTabs =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/page-tabs'
        ),
        true
    ) ?? [];

$pageTabsCanEdit =
    hasPermission(
        'Edit Settings Fields'
    );

$pageTabsPermissions =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/permissions'
        ),
        true
    ) ?? [];

/*
 * Which tab group owns this page?
 */

$pageTabsGroup = null;
$pageTabsList = [];

foreach ($pageTabs as $ptRow) {

    $ptAlternates = array_filter(
        explode(
            ',',
            (string)(
                $ptRow['tab_alternates']
                ?? ''
            )
        )
    );

    if (
        $ptRow['tab_group']
            === $pageTabsCurrentPage
        ||
        $ptRow['tab_href']
            === $pageTabsCurrentPage
        ||
        in_array(
            $pageTabsCurrentPage,
            $ptAlternates,
            true
        )
    ) {
        $pageTabsGroup =
            (string)$ptRow['tab_group'];

        break;
    }
}

if ($pageTabsGroup !== null) {

    foreach ($pageTabs as $ptRow) {

        if (
            (string)$ptRow['tab_group']
            === $pageTabsGroup
        ) {
            $pageTabsList[] = $ptRow;
        }
    }

    usort(
        $pageTabsList,
        function ($a, $b) {
            return
                ((int)$a['sort_order'])
                <=>
                ((int)$b['sort_order']);
        }
    );
}

function pageTabsApiPost($path, $payload) {

    global $FASTAPI_URL;

    return file_get_contents(
        $FASTAPI_URL . $path,
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  =>
                    "Content-Type: application/json\r\n",
                'content' => json_encode($payload)
            ]
        ])
    );
}

/*
 * Only holders of Edit Settings Fields may
 * change the tabs (the UI is gated the same
 * way - direct POSTs must not bypass it).
 */

if (
    isset($_POST['create_page_tab'])
    && $pageTabsCanEdit
    && $pageTabsGroup !== null
) {

    pageTabsApiPost(
        '/page-tabs/create',
        [
            'tab_group' => $pageTabsGroup,
            'tab_name' =>
                trim(
                    (string)(
                        $_POST['page_tab_name']
                    )
                ),
            'tab_href' =>
                trim(
                    (string)(
                        $_POST['page_tab_href']
                    )
                ),
            'tab_permission' =>
                trim(
                    (string)(
                        $_POST['page_tab_permission']
                    )
                ),
            'sort_order' =>
                count($pageTabsList)
        ]
    );

    header(
        'Location: '
        . $pageTabsCurrentPage
    );
    exit;
}

if (
    isset($_POST['update_page_tab'])
    && $pageTabsCanEdit
) {

    pageTabsApiPost(
        '/page-tabs/'
            . (int)$_POST['page_tab_id']
            . '/update',
        [
            'tab_name' =>
                trim(
                    (string)(
                        $_POST['page_tab_name']
                    )
                ),
            'tab_href' =>
                trim(
                    (string)(
                        $_POST['page_tab_href']
                    )
                ),
            'tab_permission' =>
                trim(
                    (string)(
                        $_POST['page_tab_permission']
                    )
                ),
            'sort_order' =>
                (int)(
                    $_POST['page_tab_sort']
                )
        ]
    );

    header(
        'Location: '
        . $pageTabsCurrentPage
    );
    exit;
}

if (
    isset($_POST['delete_page_tab'])
    && $pageTabsCanEdit
) {

    pageTabsApiPost(
        '/page-tabs/'
            . (int)$_POST['page_tab_id']
            . '/delete',
        []
    );

    header(
        'Location: '
        . $pageTabsCurrentPage
    );
    exit;
}
?>
