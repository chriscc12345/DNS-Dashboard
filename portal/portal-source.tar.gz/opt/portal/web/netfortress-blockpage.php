<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Block Page')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-blockpage';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Block Page</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-panel{margin-top:18px;padding:16px;border:1px solid var(--theme-basic-card-border,#637681);border-radius:8px;background:var(--theme-basic-card-background,#18232a);color:var(--theme-basic-card-text,#fff)}
        .nf-panel h2{margin:0 0 6px 0}
        .nf-panel .panel-sub{margin:0 0 16px 0;font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3)}
        .nf-stack-form{display:grid;grid-template-columns:260px 1fr;gap:12px 14px;align-items:center;font-size:14px}
        .nf-stack-form label{font-weight:600}
        .nf-stack-form label small{display:block;font-weight:400;font-size:12px;color:var(--theme-basic-text-secondary,#aebbc3);margin-top:3px}
        .nf-stack-form input[type="text"],
        .nf-stack-form input[type="password"],
        .nf-stack-form textarea,
        .nf-stack-form select{width:100%;max-width:460px;padding:7px 10px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:4px;background:var(--theme-basic-input-background,#202c34);color:var(--theme-basic-input-text,#fff);font-size:13px;font-family:inherit;box-sizing:border-box}
        .nf-stack-form textarea{min-height:70px}
        .nf-stack-form input[type="color"]{width:60px;height:32px;padding:2px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:4px;background:var(--theme-basic-input-background,#202c34)}
        .nf-check{grid-column:1 / -1;display:flex;align-items:center;gap:8px;font-weight:600}
        .nf-check small{font-weight:400;font-size:12px;color:var(--theme-basic-text-secondary,#aebbc3)}
        .nf-check a{color:var(--theme-basic-accent,#c79a00)}
        .nf-full{grid-column:1 / -1}
        .nf-logo-preview{max-height:64px;max-width:220px;border:1px solid var(--theme-basic-card-border,#637681);border-radius:8px;padding:5px;background:var(--theme-basic-card-background-alt,#202c34)}
        .nf-placeholder-note{grid-column:1 / -1;font-size:12px;color:var(--theme-basic-text-secondary,#aebbc3);margin:0}
        .nf-placeholder-note code{background:var(--theme-basic-card-background-alt,#202c34);padding:1px 5px;border-radius:4px;font-size:11px}
        .nf-save-row{grid-column:1 / -1;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
        .nf-button-link{padding:6px 14px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:6px;background:var(--theme-basic-input-background,#202c34);color:var(--theme-basic-input-text,#fff);font-size:13px;text-decoration:none;cursor:pointer}
        #nfMsg{margin-top:12px;font-size:13px;display:none}
        #nfMsg.ok{color:var(--theme-basic-success,#237a4b);display:block}
        #nfMsg.err{color:var(--theme-basic-error,#b83b3b);display:block}
        #nfLogoStatus,#nfCustomStatus{grid-column:1 / -1;font-size:13px;display:none}
        #nfLogoStatus.ok,#nfCustomStatus.ok{color:var(--theme-basic-success,#237a4b);display:block}
        #nfLogoStatus.err,#nfCustomStatus.err{color:var(--theme-basic-error,#b83b3b);display:block}
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Block Page - branded page and URL shown when a blocked
                site is requested.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="nf-panel">

        <h2>Block page</h2>
        <p class="panel-sub">
            Branded page and URL shown when a blocked site is requested.
        </p>

        <form id="nfBlockPageForm" class="nf-stack-form" onsubmit="return false;">

            <label for="nfHostname">
                Block URL hostname
                <small>
                    Blocked sites redirect here instead of a bare IP
                    address. DNS resolves for it automatically.
                </small>
            </label>
            <input type="text" id="nfHostname" placeholder="blocked.firewall.lan"
                   pattern="[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*">

            <label for="nfTitle">Title</label>
            <input type="text" id="nfTitle" required>

            <label for="nfOrg">Organisation</label>
            <input type="text" id="nfOrg" required>

            <label for="nfMessage">Message</label>
            <textarea id="nfMessage" required></textarea>

            <label for="nfContact">Support contact</label>
            <input type="text" id="nfContact" required>

            <label for="nfAccent">Accent colour</label>
            <input type="color" id="nfAccent" value="#a68e17">

            <label for="nfBackground">Page background colour</label>
            <input type="color" id="nfBackground" value="#071019">

            <label for="nfFooter">
                Footer text (optional)
            </label>
            <input type="text" id="nfFooter" placeholder="Your company · IT support ext. 1234">

            <label for="nfPolicyUrl">
                Link to your full policy (optional)
            </label>
            <input type="text" id="nfPolicyUrl" placeholder="https://intranet.example.com/policy">

            <label class="nf-check">
                <input type="checkbox" id="nfShowLogo"> Show my logo on the block page
                <img src="netfortress-api.php?action=blockpage-logo" alt="logo"
                     class="nf-logo-preview" id="nfLogoImg">
            </label>

            <label for="nfLogoFile">
                Logo (PNG, JPEG or SVG, under 256 KB)
            </label>
            <input type="file" id="nfLogoFile" accept="image/png,image/jpeg,image/svg+xml">

            <div id="nfLogoStatus"></div>

            <label class="nf-check">
                <input type="checkbox" id="nfCustomActive"> Serve my own uploaded page design (below)
            </label>

            <label for="nfCustomFile">
                Upload my own page (HTML file, under 200 KB)
            </label>
            <input type="file" id="nfCustomFile" accept="text/html,.html,.htm">

            <div id="nfCustomStatus"></div>

            <label for="nfRedirect">
                Or send blocked sites to my own URL (hosted anywhere)
                <small>
                    Blocked requests are forwarded to this URL with
                    ?host=&lt;blocked site&gt; added, so your page can show
                    which site was blocked. Takes priority over the uploaded
                    page. Leave empty to serve the block page from this
                    firewall.
                </small>
            </label>
            <input type="text" id="nfRedirect" placeholder="https://notice.mycompany.co.za/blocked">

            <p class="nf-placeholder-note">
                Placeholders your own page may use:
                <code>{{REQUESTED_HOST}}</code> <code>{{CLIENT_IP}}</code>
                <code>{{HOSTNAME}}</code> <code>{{POLICY}}</code>
                — filled live for each blocked visit.
            </p>

            <label class="nf-check">
                <input type="checkbox" id="nfShowIp"> Show the client IP
            </label>

            <label class="nf-check">
                <input type="checkbox" id="nfShowHostname"> Show the recognised device name
            </label>

            <label class="nf-check">
                <input type="checkbox" id="nfShowPolicy"> Show the matched policy
            </label>

            <label class="nf-check">
                <input type="checkbox" id="nfHttps"> Show the branded block page on HTTPS sites too
                <small>
                    Needs the appliance certificate installed on each client
                    device — otherwise browsers show a certificate warning.
                </small>
            </label>

            <label for="nfCaButton">
                Appliance certificate
                <small>
                    Install this on each client device when the HTTPS block
                    page is enabled.
                </small>
            </label>
            <div>
                <button type="button" class="table-btn" id="nfCaButton">Download appliance certificate</button>
                <span id="nfCaNote" style="font-size:13px;margin-left:8px"></span>
            </div>

            <label class="nf-check">
                <input type="checkbox" id="nfAllowRequests"> Allow access requests from the block page
            </label>

            <div class="nf-save-row">
                <button type="button" class="approve-btn" id="nfSave">Save block page</button>
                <a class="nf-button-link" href="netfortress-api.php?action=blockpage-preview"
                   target="_blank">Preview page</a>
            </div>

        </form>

        <div id="nfMsg"></div>

    </div>

</div>

<script>
(function () {

    const message = document.getElementById('nfMsg');

    let current = null;

    function esc(v) {
        return String(v ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');
    }

    function msg(text, ok) {
        if (!text) { message.className = ''; message.textContent = ''; return; }
        message.className = ok ? 'ok' : 'err';
        message.textContent = text;
    }

    function status(box, text, ok) {
        box.className = ok ? 'ok' : 'err';
        box.textContent = text;
    }

    function load() {

        fetch('netfortress-api.php?action=blockpage')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    msg(data.message || 'The appliance is not reachable.', false);
                    return;
                }

                current = data.settings || {};

                document.getElementById('nfTitle').value = current.title || '';
                document.getElementById('nfOrg').value = current.organization || '';
                document.getElementById('nfMessage').value = current.message || '';
                document.getElementById('nfContact').value = current.support_contact || '';
                document.getElementById('nfAccent').value = current.accent_color || '#a68e17';
                document.getElementById('nfBackground').value = current.background_color || '#071019';
                document.getElementById('nfFooter').value = current.footer_text || '';
                document.getElementById('nfPolicyUrl').value = current.policy_url || '';
                document.getElementById('nfShowLogo').checked = !!current.show_logo;
                document.getElementById('nfCustomActive').checked = !!current.custom_html_active;
                document.getElementById('nfRedirect').value = current.redirect_url || '';
                document.getElementById('nfShowIp').checked = !!current.show_client_ip;
                document.getElementById('nfShowHostname').checked = !!current.show_hostname;
                document.getElementById('nfShowPolicy').checked = !!current.show_policy;
                document.getElementById('nfHttps').checked = !!current.https_block;
                document.getElementById('nfAllowRequests').checked = !!current.allow_access_requests;

                fetch('netfortress-api.php?action=dns-hostname')
                    .then(function (r) { return r.json(); })
                    .then(function (dns) {
                        if (dns.success) {
                            document.getElementById('nfHostname').value = dns.block_hostname || '';
                        }
                    })
                    .catch(function () {});

            })
            .catch(function () {
                msg('The appliance API is not reachable.', false);
            });

    }

    function post(action, payload, label) {

        msg('Working: ' + label + '...', true);

        return fetch('netfortress-api.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    msg(label + ' completed.', true);
                } else {
                    msg(data.message || 'The appliance rejected the request.', false);
                }
                return data;
            })
            .catch(function () {
                msg('The appliance API is not reachable.', false);
            });

    }

    document.getElementById('nfSave').addEventListener('click', function () {

        if (!current) {
            msg('Settings not loaded yet.', false);
            return;
        }

        current.title = document.getElementById('nfTitle').value.trim();
        current.organization = document.getElementById('nfOrg').value.trim();
        current.message = document.getElementById('nfMessage').value.trim();
        current.support_contact = document.getElementById('nfContact').value.trim();
        current.accent_color = document.getElementById('nfAccent').value;
        current.background_color = document.getElementById('nfBackground').value;
        current.footer_text = document.getElementById('nfFooter').value.trim();
        current.policy_url = document.getElementById('nfPolicyUrl').value.trim();
        current.show_logo = document.getElementById('nfShowLogo').checked;
        current.custom_html_active = document.getElementById('nfCustomActive').checked;
        current.redirect_url = document.getElementById('nfRedirect').value.trim();
        current.show_client_ip = document.getElementById('nfShowIp').checked;
        current.show_hostname = document.getElementById('nfShowHostname').checked;
        current.show_policy = document.getElementById('nfShowPolicy').checked;
        current.https_block = document.getElementById('nfHttps').checked;
        current.allow_access_requests = document.getElementById('nfAllowRequests').checked;

        if (current.redirect_url && !/^https?:\/\//.test(current.redirect_url)) {
            msg('The redirect URL must start with http:// or https://.', false);
            return;
        }

        post('blockpage-set', current, 'Saving block page').then(function () {
            const hostname = document.getElementById('nfHostname').value.trim();
            if (hostname || current._hadHostname) {
                post('dns-hostname-set', { hostname: hostname }, 'Saving block URL hostname');
            }
        });

    });

    /* logo uploads on file change, like the appliance console */

    document.getElementById('nfLogoFile').addEventListener('change', function () {

        const file = this.files && this.files[0];
        const box = document.getElementById('nfLogoStatus');

        if (!file) { return; }

        if (file.size > 262144) {
            status(box, 'Logo must be under 256 KB.', false);
            return;
        }

        file.arrayBuffer().then(function (buffer) {

            fetch('netfortress-api.php?action=blockpage-logo-upload', {
                method: 'POST',
                headers: { 'Content-Type': file.type || 'application/octet-stream' },
                body: buffer
            })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.success) {
                        status(box, 'Logo uploaded (' +
                            (file.size / 1024).toFixed(0) +
                            ' KB). Save the block page to apply it.', true);
                        document.getElementById('nfLogoImg').src =
                            'netfortress-api.php?action=blockpage-logo&r=' + Date.now();
                    } else {
                        status(box, data.message || 'The appliance rejected the logo.', false);
                    }
                })
                .catch(function () {
                    status(box, 'The appliance API is not reachable.', false);
                });

        });

    });

    /* custom page uploads on file change, like the appliance console */

    document.getElementById('nfCustomFile').addEventListener('change', function () {

        const file = this.files && this.files[0];
        const box = document.getElementById('nfCustomStatus');

        if (!file) { return; }

        if (file.size > 204800) {
            status(box, 'The custom page must be under 200 KB.', false);
            return;
        }

        file.text().then(function (html) {

            fetch('netfortress-api.php?action=blockpage-custom', {
                method: 'POST',
                headers: { 'Content-Type': 'text/html; charset=utf-8' },
                body: html
            })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.success) {
                        const result = data.result && data.result.result;
                        status(box, (result && result.message) ||
                            'Your custom page is live.', true);
                        load();
                    } else {
                        status(box, data.message || 'The appliance rejected the page.', false);
                    }
                })
                .catch(function () {
                    status(box, 'The appliance API is not reachable.', false);
                });

        });

    });

    /* appliance certificate: probe first, download when it exists */

    document.getElementById('nfCaButton').addEventListener('click', function () {

        const button = this;
        const note = document.getElementById('nfCaNote');

        button.disabled = true;
        note.textContent = '';

        fetch('netfortress-api.php?action=ca')
            .then(function (r) {

                const type = r.headers.get('Content-Type') || '';

                if (type.indexOf('json') >= 0 || !r.ok) {
                    return r.json().then(function (data) {
                        note.textContent = data.message ||
                            'The HTTPS block service has not generated a certificate yet.';
                        button.disabled = false;
                    });
                }

                return r.blob().then(function (blob) {
                    const link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = 'firewall-appliance-ca.crt';
                    document.body.appendChild(link);
                    link.click();
                    link.remove();
                    setTimeout(function () {
                        URL.revokeObjectURL(link.href);
                    }, 4000);
                    button.disabled = false;
                });

            })
            .catch(function () {
                note.textContent = 'The appliance API is not reachable.';
                button.disabled = false;
            });

    });

    load();

})();
</script>

</body>

</html>
