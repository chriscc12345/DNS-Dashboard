<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('Network')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-network';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Network</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;white-space:nowrap}
        .nf-ok{background:var(--theme-basic-success,#237a4b);color:#fff}
        .nf-err{background:var(--theme-basic-error,#b83b3b);color:#fff}
        .nf-warn{background:var(--theme-basic-warning,#c79a00);color:#111827}
        .nf-off{background:var(--theme-basic-button-secondary,#24313a);color:#fff}
        .nf-panel{margin-top:18px;padding:16px;border:1px solid var(--theme-basic-card-border,#637681);border-radius:8px;background:var(--theme-basic-card-background,#18232a);color:var(--theme-basic-card-text,#fff)}
        .nf-panel h3{margin:0 0 6px 0}
        .nf-panel p{margin:0 0 12px 0;font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3)}
        .nf-input{width:180px;padding:6px 10px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:4px;background:var(--theme-basic-input-background,#202c34);color:var(--theme-basic-input-text,#fff);font-size:13px}
        .nf-input-wide{width:320px}
        .nf-btnrow{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
        #nfMsg{margin-top:10px;font-size:13px;display:none}
        #nfMsg.ok{color:var(--theme-basic-success,#237a4b);display:block}
        #nfMsg.err{color:var(--theme-basic-error,#b83b3b);display:block}
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress Network</h1>

            <p>
                Interfaces, hostname, DHCP, WireGuard and services of
                the local Firewall Appliance.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel um-table-panel">

        <div class="nf-btnrow" style="justify-content:space-between">
            <h3 style="margin:0">Interfaces</h3>
            <button type="button" class="table-btn" id="nfRefresh">Refresh</button>
        </div>

        <table id="nfIfTable">
            <thead>
            <tr>
                <th>Interface</th>
                <th>Label</th>
                <th>MAC Address</th>
                <th>State</th>
                <th>MTU</th>
                <th>Speed</th>
                <th>Addresses</th>
            </tr>
            </thead>
            <tbody id="nfIfBody">
            <tr><td colspan="7">Loading interfaces from the appliance...</td></tr>
            </tbody>
        </table>

        <div id="nfMsg"></div>

    </div>

    <div class="nf-panel">
        <h3>Appliance hostname</h3>
        <p>
            Changing the hostname runs the appliance's hostname
            transaction and updates its DNS identity.
        </p>
        <div class="nf-btnrow">
            <input type="text" class="nf-input nf-input-wide" id="nfHostname" placeholder="appliance hostname" autocomplete="off">
            <button type="button" class="approve-btn" id="nfHostnameSave">Save hostname</button>
        </div>
    </div>

    <div class="nf-panel">
        <h3>DHCP</h3>
        <div id="nfDhcpSummary" style="font-size:14px;margin-bottom:12px"></div>
        <div class="nf-btnrow">
            <button type="button" class="approve-btn" id="nfDhcpOn">Enable DHCP</button>
            <button type="button" class="deny-btn" id="nfDhcpOff">Disable DHCP</button>
        </div>

        <h4 style="margin:18px 0 8px 0">Active leases</h4>
        <table id="nfLeaseTable">
            <thead><tr><th>IP Address</th><th>MAC Address</th><th>Hostname</th><th>Expires</th></tr></thead>
            <tbody id="nfLeaseBody"></tbody>
        </table>

        <h4 style="margin:18px 0 8px 0">VLAN IP pools</h4>
        <table id="nfPoolTable">
            <thead><tr><th>Name</th><th>VLAN</th><th>Subnet</th><th>Pool range</th><th>Router</th><th>Action</th></tr></thead>
            <tbody id="nfPoolBody"></tbody>
        </table>
        <div class="nf-btnrow" style="margin-top:10px">
            <input type="text" class="nf-input" id="nfPoolName" placeholder="pool name">
            <input type="number" class="nf-input" id="nfPoolVlan" placeholder="vlan" min="2" max="4094">
            <input type="text" class="nf-input" id="nfPoolSubnet" placeholder="10.10.10.0/24">
            <input type="text" class="nf-input" id="nfPoolStart" placeholder="start ip">
            <input type="text" class="nf-input" id="nfPoolEnd" placeholder="end ip">
            <button type="button" class="approve-btn" id="nfPoolAdd">Add pool</button>
        </div>

        <h4 style="margin:18px 0 8px 0">Reservations</h4>
        <table id="nfResTable">
            <thead><tr><th>MAC Address</th><th>IP Address</th><th>Hostname</th><th>Action</th></tr></thead>
            <tbody id="nfResBody"></tbody>
        </table>
        <div class="nf-btnrow" style="margin-top:10px">
            <input type="text" class="nf-input" id="nfResMac" placeholder="mac address">
            <input type="text" class="nf-input" id="nfResIp" placeholder="ip address">
            <input type="text" class="nf-input" id="nfResHost" placeholder="hostname">
            <button type="button" class="approve-btn" id="nfResAdd">Add reservation</button>
        </div>
    </div>

    <div class="nf-panel">
        <h3>WireGuard VPN</h3>
        <div id="nfWgSummary" style="font-size:14px;margin-bottom:12px"></div>
        <div class="nf-btnrow">
            <button type="button" class="approve-btn" id="nfWgOn">Enable WireGuard</button>
            <button type="button" class="deny-btn" id="nfWgOff">Disable WireGuard</button>
        </div>

        <h4 style="margin:18px 0 8px 0">Peers</h4>
        <table id="nfWgTable">
            <thead><tr><th>Name</th><th>Kind</th><th>Allowed IPs</th><th>Endpoint</th><th>Action</th></tr></thead>
            <tbody id="nfWgBody"></tbody>
        </table>
        <div class="nf-btnrow" style="margin-top:10px">
            <select class="nf-input" id="nfWgKind">
                <option value="client">client (remote access)</option>
                <option value="site">site (another appliance)</option>
            </select>
            <input type="text" class="nf-input" id="nfWgName" placeholder="peer name">
            <input type="text" class="nf-input" id="nfWgAllowed" placeholder="allowed ips (auto)">
            <input type="text" class="nf-input" id="nfWgPubKey" placeholder="site public key">
            <input type="text" class="nf-input" id="nfWgEndpoint" placeholder="site endpoint host:port">
            <button type="button" class="approve-btn" id="nfWgAdd">Add peer</button>
        </div>
    </div>

    <div class="nf-panel">
        <h3>Appliance services</h3>
        <div id="nfServices" style="font-size:14px"></div>
    </div>

</div>

<script>
(function () {

    const ifBody = document.getElementById('nfIfBody');
    const message = document.getElementById('nfMsg');
    const dhcpSummary = document.getElementById('nfDhcpSummary');
    const leaseBody = document.getElementById('nfLeaseBody');
    const poolBody = document.getElementById('nfPoolBody');
    const resBody = document.getElementById('nfResBody');
    const wgSummary = document.getElementById('nfWgSummary');
    const wgBody = document.getElementById('nfWgBody');
    const servicesBox = document.getElementById('nfServices');

    function esc(v) {
        return String(v ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');
    }

    function msg(text, ok) {
        if (!text) { message.className = ''; message.textContent = ''; return; }
        message.className = ok ? 'ok' : 'err';
        message.textContent = text;
    }

    function badge(text, cls) {
        return '<span class="nf-badge ' + cls + '">' + esc(text) + '</span>';
    }

    function post(action, payload, label) {

        msg('Working: ' + label + '...', true);

        fetch('netfortress-api.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    msg(label + ' completed.', true);
                } else {
                    msg(data.message || 'The appliance rejected the request.', false);
                }
                loadAll();
            })
            .catch(function () {
                msg('The appliance API is not reachable.', false);
                loadAll();
            });

    }

    /* ---- interfaces + hostname ---- */

    function loadNetwork() {

        fetch('netfortress-api.php?action=network')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    ifBody.innerHTML = '<tr><td colspan="7">' +
                        esc(data.message || 'The appliance is not reachable.') + '</td></tr>';
                    return;
                }

                ifBody.innerHTML = '';

                (data.interfaces || []).forEach(function (info) {

                    const state = String(info.state || 'unknown');
                    const stateClass =
                        state === 'up' ? 'nf-ok'
                        : state === 'down' ? 'nf-err'
                        : 'nf-off';

                    const tr = document.createElement('tr');
                    tr.innerHTML =
                        '<td><strong>' + esc(info.name) + '</strong>' +
                        (info.is_virtual ? ' <small style="color:var(--theme-basic-text-secondary,#aebbc3)">(virtual)</small>' : '') + '</td>' +
                        '<td><div class="nf-btnrow" style="margin:0">' +
                        '<input type="text" class="nf-input nf-label-edit" data-interface="' + esc(info.name) + '"' +
                        ' value="' + esc(info.label || '') + '" maxlength="50" placeholder="no label" style="width:140px"> ' +
                        '<button type="button" class="table-btn nf-label-save" data-interface="' + esc(info.name) + '">Save</button>' +
                        '</div></td>' +
                        '<td>' + esc(info.mac_address || '-') + '</td>' +
                        '<td>' + badge(state, stateClass) + '</td>' +
                        '<td>' + esc(info.mtu ?? '-') + '</td>' +
                        '<td>' + esc(info.speed_mbps ? info.speed_mbps + ' Mbps' : '-') + '</td>' +
                        '<td>' + esc((info.addresses || []).join(', ') || '-') + '</td>';

                    ifBody.appendChild(tr);

                });

                const hostInput = document.getElementById('nfHostname');
                if (document.activeElement !== hostInput) {
                    hostInput.value = data.hostname || '';
                }

            })
            .catch(function () {
                ifBody.innerHTML = '<tr><td colspan="7">The appliance API is not reachable.</td></tr>';
            });

    }

    /* ---- DHCP ---- */

    function loadDhcp() {

        fetch('netfortress-api.php?action=dhcp')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    dhcpSummary.textContent = data.message || 'DHCP information is not available.';
                    return;
                }

                const s = data.settings || {};

                dhcpSummary.innerHTML =
                    badge(s.enabled ? 'enabled' : 'disabled', s.enabled ? 'nf-ok' : 'nf-off') +
                    ' on <strong>' + esc(s.interface || '-') + '</strong>' +
                    ' - subnet ' + esc(s.subnet || '-') +
                    ', pool ' + esc(s.pool_start || '-') + ' - ' + esc(s.pool_end || '-') +
                    ', router ' + esc(s.router || '-') +
                    ', lease ' + esc(Math.round((s.lease_seconds || 0) / 3600)) + 'h';

                /* leases */

                const leases = (data.leases && data.leases.leases) || [];
                leaseBody.innerHTML = '';

                if (leases.length === 0) {
                    leaseBody.innerHTML = '<tr><td colspan="4">No active leases.</td></tr>';
                } else {
                    dhcpSummary.innerHTML += ' - <strong>' + esc(data.leases.active) + '</strong> active leases';
                    leases.forEach(function (lease) {
                        const tr = document.createElement('tr');
                        tr.innerHTML =
                            '<td>' + esc(lease.ip_address || '-') + '</td>' +
                            '<td>' + esc(lease.mac_address || '-') + '</td>' +
                            '<td>' + esc(lease.hostname || '-') + '</td>' +
                            '<td>' + esc(lease.expires_at ? new Date(lease.expires_at).toLocaleString() : '-') + '</td>';
                        leaseBody.appendChild(tr);
                    });
                }

                /* pools */

                const pools = data.pools || [];
                poolBody.innerHTML = '';

                if (pools.length === 0) {
                    poolBody.innerHTML = '<tr><td colspan="6">No VLAN pools.</td></tr>';
                } else {
                    pools.forEach(function (pool) {
                        const tr = document.createElement('tr');
                        tr.innerHTML =
                            '<td><strong>' + esc(pool.name) + '</strong>' +
                            (pool.enabled ? '' : ' ' + badge('disabled', 'nf-off')) + '</td>' +
                            '<td>' + esc(pool.vlan_id) + '</td>' +
                            '<td>' + esc(pool.subnet) + '</td>' +
                            '<td>' + esc(pool.pool_start) + ' - ' + esc(pool.pool_end) + '</td>' +
                            '<td>' + esc(pool.router || '-') + '</td>' +
                            '<td><button type="button" class="deny-btn nf-pool-del" data-id="' + esc(pool.id) + '">Delete</button></td>';
                        poolBody.appendChild(tr);
                    });
                }

                /* reservations */

                const reservations = data.reservations || [];
                resBody.innerHTML = '';

                if (reservations.length === 0) {
                    resBody.innerHTML = '<tr><td colspan="4">No reservations.</td></tr>';
                } else {
                    reservations.forEach(function (res) {
                        const tr = document.createElement('tr');
                        tr.innerHTML =
                            '<td>' + esc(res.mac_address || '-') + '</td>' +
                            '<td>' + esc(res.ip_address || '-') + '</td>' +
                            '<td>' + esc(res.hostname || '-') + '</td>' +
                            '<td><button type="button" class="deny-btn nf-res-del" data-id="' + esc(res.id) + '">Delete</button></td>';
                        resBody.appendChild(tr);
                    });
                }

            })
            .catch(function () {
                dhcpSummary.textContent = 'The appliance API is not reachable.';
            });

    }

    /* ---- WireGuard ---- */

    function loadWireguard() {

        fetch('netfortress-api.php?action=wireguard')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    wgSummary.textContent = data.message || 'WireGuard information is not available.';
                    return;
                }

                const s = data.settings || {};

                wgSummary.innerHTML =
                    badge(s.enabled ? 'enabled' : 'disabled', s.enabled ? 'nf-ok' : 'nf-off') +
                    ' - port <strong>' + esc(s.listen_port || '-') + '</strong>' +
                    ', tunnel ' + esc(s.tunnel_subnet || '-') +
                    (data.status ? ' - ' + esc(JSON.stringify(data.status)) : '');

                const peers = data.peers || [];
                wgBody.innerHTML = '';

                if (peers.length === 0) {
                    wgBody.innerHTML = '<tr><td colspan="5">No peers.</td></tr>';
                } else {
                    peers.forEach(function (peer) {
                        const tr = document.createElement('tr');
                        tr.innerHTML =
                            '<td><strong>' + esc(peer.name) + '</strong></td>' +
                            '<td>' + esc(peer.kind) + '</td>' +
                            '<td>' + esc(peer.allowed_ips || '-') + '</td>' +
                            '<td>' + esc([peer.endpoint_host, peer.endpoint_port].filter(Boolean).join(':') || '-') + '</td>' +
                            '<td><button type="button" class="deny-btn nf-wg-del" data-id="' + esc(peer.id) + '">Delete</button></td>';
                        wgBody.appendChild(tr);
                    });
                }

            })
            .catch(function () {
                wgSummary.textContent = 'The appliance API is not reachable.';
            });

    }

    /* ---- services ---- */

    function loadServices() {

        fetch('netfortress-api.php?action=operations')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    servicesBox.textContent = data.message || 'Service information is not available.';
                    return;
                }

                servicesBox.innerHTML = (data.services || []).map(function (service) {
                    return badge(
                        service.name + (service.installed ? '' : ' (not installed)'),
                        service.installed ? 'nf-ok' : 'nf-off'
                    );
                }).join(' ');

            })
            .catch(function () {
                servicesBox.textContent = 'The appliance API is not reachable.';
            });

    }

    function loadAll() {
        loadNetwork();
        loadDhcp();
        loadWireguard();
        loadServices();
    }

    /* ---- events ---- */

    document.addEventListener('click', function (event) {

        const labelSave = event.target.closest('.nf-label-save');
        if (labelSave) {
            const input = ifBody.querySelector(
                '.nf-label-edit[data-interface="' + labelSave.dataset.interface + '"]'
            );
            if (input) {
                post('label', {
                    interface: labelSave.dataset.interface,
                    label: input.value
                }, 'Saving label for ' + labelSave.dataset.interface);
            }
            return;
        }

        const poolDel = event.target.closest('.nf-pool-del');
        if (poolDel) {
            post('pool-delete', { pool_id: parseInt(poolDel.dataset.id, 10) }, 'Deleting pool');
            return;
        }

        const resDel = event.target.closest('.nf-res-del');
        if (resDel) {
            post('reservation-delete', { reservation_id: parseInt(resDel.dataset.id, 10) }, 'Deleting reservation');
            return;
        }

        const wgDel = event.target.closest('.nf-wg-del');
        if (wgDel) {
            post('wg-peer-delete', { peer_id: parseInt(wgDel.dataset.id, 10) }, 'Deleting peer');
        }

    });

    document.getElementById('nfHostnameSave').addEventListener('click', function () {
        const value = document.getElementById('nfHostname').value.trim();
        if (value) { post('hostname', { hostname: value }, 'Applying hostname change'); }
    });

    document.getElementById('nfDhcpOn').addEventListener('click', function () {
        post('dhcp-enabled', { enabled: true }, 'Enabling DHCP');
    });

    document.getElementById('nfDhcpOff').addEventListener('click', function () {
        post('dhcp-enabled', { enabled: false }, 'Disabling DHCP');
    });

    document.getElementById('nfPoolAdd').addEventListener('click', function () {
        post('pool-add', {
            name: document.getElementById('nfPoolName').value.trim(),
            vlan_id: parseInt(document.getElementById('nfPoolVlan').value, 10),
            subnet: document.getElementById('nfPoolSubnet').value.trim(),
            pool_start: document.getElementById('nfPoolStart').value.trim(),
            pool_end: document.getElementById('nfPoolEnd').value.trim()
        }, 'Adding pool');
    });

    document.getElementById('nfResAdd').addEventListener('click', function () {
        post('reservation-add', {
            mac_address: document.getElementById('nfResMac').value.trim(),
            ip_address: document.getElementById('nfResIp').value.trim(),
            hostname: document.getElementById('nfResHost').value.trim()
        }, 'Adding reservation');
    });

    document.getElementById('nfWgOn').addEventListener('click', function () {
        post('wg-enabled', { enabled: true }, 'Enabling WireGuard');
    });

    document.getElementById('nfWgOff').addEventListener('click', function () {
        post('wg-enabled', { enabled: false }, 'Disabling WireGuard');
    });

    document.getElementById('nfWgAdd').addEventListener('click', function () {

        const endpoint = document.getElementById('nfWgEndpoint').value.trim();
        let host = '';
        let port = 0;

        if (endpoint) {
            const parts = endpoint.split(':');
            host = parts[0];
            port = parseInt(parts[1] || '0', 10);
        }

        post('wg-peer-add', {
            kind: document.getElementById('nfWgKind').value,
            name: document.getElementById('nfWgName').value.trim(),
            allowed_ips: document.getElementById('nfWgAllowed').value.trim() || 'auto',
            public_key: document.getElementById('nfWgPubKey').value.trim(),
            endpoint_host: host,
            endpoint_port: port
        }, 'Adding peer');

    });

    document.getElementById('nfRefresh').addEventListener('click', loadAll);

    loadAll();

})();
</script>

</body>

</html>
