<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('Network')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-network';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Network</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-net-state {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
        }
        .nf-net-state-up {
            background: #097a27;
            color: #fff;
        }
        .nf-net-state-down {
            background: #b50b0b;
            color: #fff;
        }
        .nf-net-state-unknown {
            background: #777;
            color: #fff;
        }
        .nf-label-input {
            width: 160px;
            padding: 5px 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 13px;
        }
        .nf-hostname-panel {
            margin-top: 18px;
            padding: 16px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: #f9f9f9;
        }
        .nf-hostname-panel h3 {
            margin: 0 0 6px 0;
        }
        .nf-hostname-panel p {
            margin: 0 0 12px 0;
            font-size: 13px;
            color: #555;
        }
        .nf-hostname-row {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nf-hostname-input {
            width: 240px;
            padding: 6px 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 13px;
        }
        #nfNetworkMessage {
            margin-top: 10px;
            font-size: 13px;
            display: none;
        }
        #nfNetworkMessage.nf-message-error {
            color: #b50b0b;
            display: block;
        }
        #nfNetworkMessage.nf-message-ok {
            color: #097a27;
            display: block;
        }
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress Network</h1>

            <p>
                Interfaces and hostname of the local Firewall Appliance.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel um-table-panel">

        <div style="display:flex;justify-content:flex-end;margin-bottom:10px;">
            <button type="button" class="table-btn" id="nfNetworkRefresh">Refresh</button>
        </div>

        <table id="nfInterfacesTable">
            <thead>
            <tr>
                <th>Interface</th>
                <th>Label</th>
                <th>MAC Address</th>
                <th>State</th>
                <th>MTU</th>
                <th>Speed</th>
                <th>Addresses</th>
            </tr>
            </thead>
            <tbody id="nfInterfacesBody">
            <tr>
                <td colspan="7">Loading interfaces from the appliance...</td>
            </tr>
            </tbody>
        </table>

        <div id="nfNetworkMessage"></div>

    </div>

    <div class="nf-hostname-panel">
        <h3>Appliance hostname</h3>
        <p>
            Changing the hostname runs the appliance's hostname transaction
            and updates its DNS identity.
        </p>
        <div class="nf-hostname-row">
            <input type="text" class="nf-hostname-input" id="nfHostnameInput"
                   placeholder="appliance hostname" autocomplete="off">
            <button type="button" class="approve-btn" id="nfHostnameSave">Save hostname</button>
        </div>
    </div>

</div>

<script>
(function () {

    const body = document.getElementById('nfInterfacesBody');
    const message = document.getElementById('nfNetworkMessage');
    const hostnameInput = document.getElementById('nfHostnameInput');
    const hostnameSave = document.getElementById('nfHostnameSave');
    const refresh = document.getElementById('nfNetworkRefresh');

    function showMessage(text, ok) {

        if (!text) {
            message.className = '';
            message.textContent = '';
            return;
        }

        message.className = ok
            ? 'nf-message-ok'
            : 'nf-message-error';
        message.textContent = text;

    }

    function escapeHtml(value) {

        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');

    }

    function renderRow(info) {

        const row = document.createElement('tr');

        const state = String(info.state || 'unknown');
        const stateClass =
            state === 'up' ? 'nf-net-state-up'
            : state === 'down' ? 'nf-net-state-down'
            : 'nf-net-state-unknown';

        const addresses = (info.addresses || []).join(', ') || '-';

        row.innerHTML =
            '<td><strong>' + escapeHtml(info.name) + '</strong>' +
            (info.is_virtual ? ' <small style="color:#888">(virtual)</small>' : '') +
            '</td>' +
            '<td>' +
            '<div class="nf-hostname-row">' +
            '<input type="text" class="nf-label-input nf-label-edit" ' +
            'data-interface="' + escapeHtml(info.name) + '" ' +
            'value="' + escapeHtml(info.label || '') + '" ' +
            'maxlength="50" placeholder="no label">' +
            '<button type="button" class="table-btn nf-label-save" ' +
            'data-interface="' + escapeHtml(info.name) + '">Save</button>' +
            '</div>' +
            '</td>' +
            '<td>' + escapeHtml(info.mac_address || '-') + '</td>' +
            '<td><span class="nf-net-state ' + stateClass + '">' +
            escapeHtml(state) + '</span></td>' +
            '<td>' + escapeHtml(info.mtu ?? '-') + '</td>' +
            '<td>' + escapeHtml(info.speed_mbps ? info.speed_mbps + ' Mbps' : '-') + '</td>' +
            '<td>' + escapeHtml(addresses) + '</td>';

        return row;

    }

    function loadNetwork() {

        fetch('netfortress-api.php?action=network')
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {

                if (!data.success) {
                    body.innerHTML =
                        '<tr><td colspan="7">' +
                        escapeHtml(data.message || 'The appliance is not reachable.') +
                        '</td></tr>';
                    hostnameInput.disabled = true;
                    hostnameSave.disabled = true;
                    return;
                }

                body.innerHTML = '';

                (data.interfaces || []).forEach(function (info) {
                    body.appendChild(renderRow(info));
                });

                if (document.activeElement !== hostnameInput) {
                    hostnameInput.value = data.hostname || '';
                }

            })
            .catch(function () {

                body.innerHTML =
                    '<tr><td colspan="7">' +
                    'The appliance API is not reachable.</td></tr>';

            });

    }

    function saveLabel(button) {

        const input = body.querySelector(
            '.nf-label-edit[data-interface="' + button.dataset.interface + '"]'
        );

        if (!input) {
            return;
        }

        button.disabled = true;
        showMessage('Saving label for ' + button.dataset.interface + '...', true);

        fetch('netfortress-api.php?action=label', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                interface: button.dataset.interface,
                label: input.value
            })
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {

                button.disabled = false;

                if (data.success) {
                    showMessage('Label saved for ' + button.dataset.interface + '.', true);
                } else {
                    showMessage(data.message || 'The appliance rejected the request.', false);
                }

            })
            .catch(function () {
                button.disabled = false;
                showMessage('The appliance API is not reachable.', false);
            });

    }

    function saveHostname() {

        const value = hostnameInput.value.trim();

        if (!value) {
            showMessage('Enter a hostname first.', false);
            return;
        }

        hostnameSave.disabled = true;
        showMessage('Applying hostname change on the appliance...', true);

        fetch('netfortress-api.php?action=hostname', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ hostname: value })
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {

                hostnameSave.disabled = false;

                if (data.success) {
                    showMessage('Hostname set to ' + data.hostname + '.', true);
                    hostnameInput.value = data.hostname || value;
                } else {
                    showMessage(data.message || 'The appliance rejected the request.', false);
                }

            })
            .catch(function () {
                hostnameSave.disabled = false;
                showMessage('The appliance API is not reachable.', false);
            });

    }

    document.addEventListener(
        'click',
        function (event) {

            const labelButton = event.target.closest('.nf-label-save');

            if (labelButton) {
                saveLabel(labelButton);
            }

        }
    );

    hostnameSave.addEventListener('click', saveHostname);
    refresh.addEventListener('click', loadNetwork);

    loadNetwork();

})();
</script>

</body>

</html>
