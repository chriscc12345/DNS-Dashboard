<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Policy acceptance')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-policy';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Policy acceptance</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;white-space:nowrap}
        .nf-ok{background:var(--theme-basic-success,#237a4b);color:#fff}
        .nf-warn{background:var(--theme-basic-warning,#c79a00);color:#111827}
        .nf-panel{margin-top:18px;padding:16px;border:1px solid var(--theme-basic-card-border,#637681);border-radius:8px;background:var(--theme-basic-card-background,#18232a);color:var(--theme-basic-card-text,#fff)}
        .nf-panel h3{margin:0 0 6px 0}
        .nf-panel p{margin:0 0 12px 0;font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3)}
        .nf-input{width:200px;padding:6px 10px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:4px;background:var(--theme-basic-input-background,#202c34);color:var(--theme-basic-input-text,#fff);font-size:13px}
        .nf-input-wide{width:420px}
        .nf-btnrow{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
        .nf-form-grid{display:grid;grid-template-columns:220px 1fr;gap:10px 12px;align-items:start;max-width:640px;font-size:14px}
        .nf-form-grid textarea{width:100%;min-height:80px;padding:6px 10px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:4px;background:var(--theme-basic-input-background,#202c34);color:var(--theme-basic-input-text,#fff);font-size:13px;font-family:inherit;box-sizing:border-box}
        #nfMsg{margin-top:10px;font-size:13px;display:none}
        #nfMsg.ok{color:var(--theme-basic-success,#237a4b);display:block}
        #nfMsg.err{color:var(--theme-basic-error,#b83b3b);display:block}
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Policy acceptance - devices must accept the network
                policy before traffic flows.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel">

        <h3 style="margin-top:0">Acceptance portal settings</h3>

        <div class="nf-form-grid">
            <label for="nfEnabled">Require policy acceptance</label>
            <input type="checkbox" id="nfEnabled">

            <label for="nfTitle">Title</label>
            <input type="text" class="nf-input nf-input-wide" id="nfTitle">

            <label for="nfOrg">Organization</label>
            <input type="text" class="nf-input nf-input-wide" id="nfOrg">

            <label for="nfMessage">Message</label>
            <textarea id="nfMessage"></textarea>

            <label for="nfContact">Support contact</label>
            <input type="text" class="nf-input nf-input-wide" id="nfContact">
        </div>

        <div class="nf-btnrow" style="margin-top:14px">
            <button type="button" class="approve-btn" id="nfSave">Save settings</button>
        </div>

        <div id="nfMsg"></div>

    </div>

    <div class="appearance-panel um-table-panel">

        <h3 style="margin-top:0">Accepted devices</h3>

        <table id="nfTable">
            <thead>
            <tr>
                <th>MAC Address</th>
                <th>IP Address</th>
                <th>Accepted</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody id="nfBody">
            <tr>
                <td colspan="4">Loading accepted devices...</td>
            </tr>
            </tbody>
        </table>

    </div>

</div>

<script>
(function () {

    const message = document.getElementById('nfMsg');
    const body = document.getElementById('nfBody');

    let current = null;
    let lastSignature = null;

    function esc(v) {
        return String(v ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');
    }

    function msg(text, ok) {
        if (!text) { message.className = ''; message.textContent = ''; return; }
        message.className = ok ? 'ok' : 'err';
        message.textContent = text;
    }

    function load() {

        fetch('netfortress-api.php?action=policy')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    lastSignature = null;
                    msg(data.message || 'The appliance is not reachable.', false);
                    body.innerHTML = '<tr><td colspan="4">' +
                        esc(data.message || '') + '</td></tr>';
                    return;
                }

                /* Only re-render when the data changed AND no form field
                   is focused - a rebuild every poll causes a visible flash
                   and would wipe in-progress edits. */

                const signature = JSON.stringify(data);

                if (signature === lastSignature) {
                    return;
                }

                if (document.activeElement &&
                    document.querySelector('.nf-form-grid').contains(document.activeElement)) {
                    return;
                }

                lastSignature = signature;

                current = data.settings || {};

                document.getElementById('nfEnabled').checked = !!current.enabled;
                document.getElementById('nfTitle').value = current.title || '';
                document.getElementById('nfOrg').value = current.organization || '';
                document.getElementById('nfMessage').value = current.message || '';
                document.getElementById('nfContact').value = current.support_contact || '';

                body.innerHTML = '';

                const accepted = data.accepted || [];

                if (accepted.length === 0) {
                    body.innerHTML = '<tr><td colspan="4">No devices have accepted yet.</td></tr>';
                    return;
                }

                accepted.forEach(function (row) {

                    const tr = document.createElement('tr');

                    const when = row.accepted_at
                        ? new Date(row.accepted_at).toLocaleString()
                        : '-';

                    tr.innerHTML =
                        '<td>' + esc(row.mac_address || '-') + '</td>' +
                        '<td>' + esc(row.ip_address || '-') + '</td>' +
                        '<td>' + esc(when) + '</td>' +
                        '<td><button type="button" class="deny-btn nf-revoke" data-id="' +
                        esc(row.id) + '">Revoke</button></td>';

                    body.appendChild(tr);

                });

            })
            .catch(function () {
                msg('The appliance API is not reachable.', false);
            });

    }

    function post(action, payload, label) {

        msg('Working: ' + label + '...', true);

        fetch('netfortress-api.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    msg(label + ' completed.', true);
                } else {
                    msg(data.message || 'The appliance rejected the request.', false);
                }
                load();
            })
            .catch(function () {
                msg('The appliance API is not reachable.', false);
            });

    }

    document.getElementById('nfSave').addEventListener('click', function () {

        if (!current) {
            msg('Settings not loaded yet.', false);
            return;
        }

        current.enabled = document.getElementById('nfEnabled').checked;
        current.title = document.getElementById('nfTitle').value.trim();
        current.organization = document.getElementById('nfOrg').value.trim();
        current.message = document.getElementById('nfMessage').value.trim();
        current.support_contact = document.getElementById('nfContact').value.trim();

        post('policy-set', current, 'Saving policy acceptance settings');

    });

    document.addEventListener('click', function (event) {

        const revoke = event.target.closest('.nf-revoke');
        if (revoke) {
            post('policy-revoke', { item_id: parseInt(revoke.dataset.id, 10) }, 'Revoking acceptance');
        }

    });

    load();
    setInterval(load, 30000);

})();
</script>

</body>

</html>
