<?php

require_once 'auth.php';
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');


function appearanceRespond(
    bool $success,
    string $message,
    int $status = 200,
    array $extra = []
): void {

    http_response_code($status);

    echo json_encode(
        array_merge(
            [
                'success' => $success,
                'message' => $message
            ],
            $extra
        )
    );

    exit;
}


function appearanceApiRequest(
    string $method,
    string $path,
    ?array $payload = null
): array {

    $url =
        'http://127.0.0.1:8000' .
        $path;

    $ch = curl_init($url);

    if ($ch === false) {

        appearanceRespond(
            false,
            'Unable to initialise the Portal API connection.',
            500
        );
    }


    $options = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json'
        ]
    ];


    if ($payload !== null) {

        $encoded =
            json_encode($payload);

        if ($encoded === false) {

            appearanceRespond(
                false,
                'Unable to encode the Appearance settings.',
                500
            );
        }

        $options[CURLOPT_POSTFIELDS] =
            $encoded;

        $options[CURLOPT_HTTPHEADER][] =
            'Content-Type: application/json';
    }


    curl_setopt_array(
        $ch,
        $options
    );


    $body =
        curl_exec($ch);

    $curlError =
        curl_error($ch);

    $status =
        (int)curl_getinfo(
            $ch,
            CURLINFO_HTTP_CODE
        );

    curl_close($ch);


    if ($body === false) {

        appearanceRespond(
            false,
            'Portal API request failed: ' . $curlError,
            502
        );
    }


    $decoded =
        json_decode(
            (string)$body,
            true
        );


    if (!is_array($decoded)) {

        appearanceRespond(
            false,
            'Portal API returned an invalid response.',
            502
        );
    }


    return [
        'status' => $status,
        'data'   => $decoded
    ];
}


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    appearanceRespond(
        false,
        'Method not allowed.',
        405
    );
}


$input =
    json_decode(
        file_get_contents('php://input'),
        true
    );


if (!is_array($input)) {

    appearanceRespond(
        false,
        'Invalid request.',
        400
    );
}


$action =
    trim(
        (string)(
            $input['action']
            ?? ''
        )
    );


if ($action !== 'save') {

    appearanceRespond(
        false,
        'Unsupported Appearance action.',
        400
    );
}


$settings =
    $input['settings']
    ?? null;


if (!is_array($settings)) {

    appearanceRespond(
        false,
        'Appearance settings were not supplied.',
        400
    );
}


/*
 * Browser-writable Appearance settings.
 *
 * Permission is enforced per setting family.
 */

$allowed = [
    'theme' => [
        'permission' => 'Theme'
    ],

    'company_logo' => [
        'permission' => 'Logo'
    ],

    'portal_favicon' => [
        'permission' => 'Logo'
    ],

    'show_logo_banner' => [
        'permission' => 'Logo'
    ],

    'show_logo_sidebar' => [
        'permission' => 'Logo'
    ],

    'banner_logo_size' => [
        'permission' => 'Logo'
    ],

    'sidebar_logo_size' => [
        'permission' => 'Logo'
    ],

    'sidebar_width' => [
        'permission' => 'Sidebar'
    ],

    'sidebar_avatar_size' => [
        'permission' => 'Sidebar'
    ],

    'sidebar_nav_text_size' => [
        'permission' => 'Sidebar'
    ],


    'sidebar_collapse_button_size' => [
        'permission' => 'Sidebar'
    ],


    'user_disclaimer_enabled' => [
        'permission' => 'User Disclaimer'
    ],

    'user_disclaimer_title' => [
        'permission' => 'User Disclaimer'
    ],

    'user_disclaimer_text' => [
        'permission' => 'User Disclaimer'
    ],

    'user_disclaimer_checklist' => [
        'permission' => 'User Disclaimer'
    ],

    'user_disclaimer_note' => [
        'permission' => 'User Disclaimer'
    ],

    'banner_image' => [
        'permission' => 'Banner'
    ],

    'banner_zoom' => [
        'permission' => 'Banner'
    ],

    'banner_position_x' => [
        'permission' => 'Banner'
    ],

    'banner_position_y' => [
        'permission' => 'Banner'
    ],

    'banner_fit_mode' => [
        'permission' => 'Banner'
    ],

    'banner_animation_enabled' => [
        'permission' => 'Banner'
    ],

    'banner_animation_style' => [
        'permission' => 'Banner'
    ],

    'banner_animation_intensity' => [
        'permission' => 'Banner'
    ],

    'login_title' => [
        'permission' => 'Login'
    ],

    'login_subtitle' => [
        'permission' => 'Login'
    ],

    'login_logo_size' => [
        'permission' => 'Login'
    ],

    'login_background_image' => [
        'permission' => 'Login'
    ],

    'login_background_overlay' => [
        'permission' => 'Login'
    ],

    'login_card_position' => [
        'permission' => 'Login'
    ],

    'show_logo_login' => [
        'permission' => 'Login'
    ],

    'show_login_footer' => [
        'permission' => 'Login'
    ],

    'login_footer_text' => [
        'permission' => 'Login'
    ],

    'login_animation_enabled' => [
        'permission' => 'Login'
    ],

    'login_animation_style' => [
        'permission' => 'Login'
    ],

    'login_animation_intensity' => [
        'permission' => 'Login'
    ]
];


/*
 * UPDATE003 - Basic theme colour tokens.
 *
 * Basic theme colour settings use the existing Theme
 * permission. FastAPI retains the explicit authoritative
 * whitelist of valid token names.
 */
foreach (array_keys($settings) as $themeSettingKey) {

    if (
        is_string($themeSettingKey)
        &&
        str_starts_with(
            $themeSettingKey,
            'theme_basic_'
        )
    ) {
        $allowed[$themeSettingKey] = [
            'permission' => 'Theme'
        ];
    }
}


$forward = [];


foreach ($settings as $key => $value) {

    if (
        !is_string($key)
        ||
        !isset($allowed[$key])
    ) {

        appearanceRespond(
            false,
            'Unsupported Appearance setting.',
            400
        );
    }


    $permission =
        $allowed[$key]['permission'];


    if (!hasPermission($permission)) {

        appearanceRespond(
            false,
            'You do not have permission to change ' .
            $permission .
            ' settings.',
            403
        );
    }


    if (
        !is_string($value)
        &&
        !is_numeric($value)
        &&
        !is_bool($value)
    ) {

        appearanceRespond(
            false,
            'Invalid Appearance setting value.',
            400
        );
    }


    if (is_bool($value)) {

        $value =
            $value
                ? 'true'
                : 'false';
    }


    $forward[$key] =
        (string)$value;
}


if (empty($forward)) {

    appearanceRespond(
        false,
        'No Appearance settings were supplied.',
        400
    );
}


$result =
    appearanceApiRequest(
        'POST',
        '/portal-settings/appearance',
        [
            'settings' => $forward
        ]
    );


if (
    $result['status'] < 200
    ||
    $result['status'] >= 300
) {

    $detail =
        $result['data']['detail']
        ?? 'Unable to save Appearance settings.';

    appearanceRespond(
        false,
        (string)$detail,
        $result['status']
    );
}


appearanceRespond(
    true,
    'Appearance settings saved.',
    200,
    [
        'settings' =>
            $result['data']['settings']
            ?? $forward
    ]
);
