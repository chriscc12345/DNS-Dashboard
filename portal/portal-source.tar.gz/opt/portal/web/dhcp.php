<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';

if (
    !hasPermission(
        'DHCP'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'dhcp';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>Technitium - DHCP</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Technitium</h1>

            <p>
                Manage the Technitium DNS server.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="settings-saved" id="dhcp_saved" hidden>
        Settings saved.
    </div>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>DHCP Scopes</h2>

                <p>
                    Network ranges the built-in DHCP server allocates leases from.
                </p>
            </div>

        </div>

        <table class="ssl-table">

            <thead>
                <tr>
                    <th>Name</th>
                    <th>Range</th>
                    <th>Subnet Mask</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>

            <tbody id="dhcp_scopes_body">
                <tr>
                    <td colspan="5">
                        Loading scopes...
                    </td>
                </tr>
            </tbody>

        </table>

        <div class="settings-form">

            <div class="settings-field">

                <label for="scope_name">
                    Add New Scope
                </label>

                <input
                    type="text"
                    id="scope_name"
                    placeholder="Name"
                    class="table-control">

            </div>

            <div class="settings-field-row">

                <div class="settings-field">

                    <label for="scope_start">
                        Starting Address
                    </label>

                    <input
                        type="text"
                        id="scope_start"
                        placeholder="192.168.10.100"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label for="scope_end">
                        Ending Address
                    </label>

                    <input
                        type="text"
                        id="scope_end"
                        placeholder="192.168.10.200"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label for="scope_mask">
                        Subnet Mask
                    </label>

                    <input
                        type="text"
                        id="scope_mask"
                        placeholder="255.255.255.0"
                        class="table-control">

                </div>

            </div>

            <div class="settings-field-row">

                <div class="settings-field">

                    <label for="scope_lease_days">
                        Lease Days
                    </label>

                    <input
                        type="number"
                        id="scope_lease_days"
                        min="0"
                        max="365"
                        value="7"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label for="scope_lease_hours">
                        Lease Hours
                    </label>

                    <input
                        type="number"
                        id="scope_lease_hours"
                        min="0"
                        max="23"
                        value="0"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label for="scope_lease_minutes">
                        Lease Minutes
                    </label>

                    <input
                        type="number"
                        id="scope_lease_minutes"
                        min="0"
                        max="59"
                        value="0"
                        class="table-control">

                </div>

            </div>

            <p class="appearance-help">
                The starting and ending addresses
                must be inside the network defined
                by the subnet mask.
            </p>

            <button
                type="button"
                id="add_scope"
                class="approve-btn">
                Add Scope
            </button>

        </div>

    </div>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>DHCP Leases</h2>

                <p>
                    Allocated leases across all scopes.
                </p>
            </div>

        </div>

        <table class="ssl-table">

            <thead>
                <tr>
                    <th>IP Address</th>
                    <th>MAC Address</th>
                    <th>Hostname</th>
                    <th>Type</th>
                    <th>Expires</th>
                    <th>Scope</th>
                    <th></th>
                </tr>
            </thead>

            <tbody id="dhcp_leases_body">
                <tr>
                    <td colspan="7">
                        Loading leases...
                    </td>
                </tr>
            </tbody>

        </table>

    </div>

</div>

<script>
const dhcpApi =
    'technitium-dhcp-api.php';

const dhcpScopesBody =
    document.getElementById('dhcp_scopes_body');
const dhcpLeasesBody =
    document.getElementById('dhcp_leases_body');
const dhcpSavedBox =
    document.getElementById('dhcp_saved');

let dhcpFlashTimer = null;

function showDhcpMessage(message) {

    dhcpSavedBox.hidden = false;
    dhcpSavedBox.textContent = message;

    if (dhcpFlashTimer) {
        clearTimeout(dhcpFlashTimer);
    }

    dhcpFlashTimer = setTimeout(() => {
        dhcpSavedBox.hidden = true;
    }, 4000);
}

function dhcpCell(row, text) {

    const cell =
        document.createElement('td');

    cell.textContent = text ?? '';

    row.appendChild(cell);
    return cell;
}

function dhcpStatusButton(enabled) {

    const button =
        document.createElement('button');

    button.type = 'button';

    button.className =
        enabled
            ? 'badge-active'
            : 'badge-disabled';

    button.textContent =
        enabled ? 'Enabled' : 'Disabled';

    return button;
}

function dhcpActionButton(label, className) {

    const button =
        document.createElement('button');

    button.type = 'button';
    button.className = className;
    button.textContent = label;

    return button;
}

function renderDhcpScopes(scopes) {

    dhcpScopesBody.textContent = '';

    if (!scopes || scopes.length === 0) {

        const row =
            document.createElement('tr');

        const cell =
            document.createElement('td');

        cell.colSpan = 5;
        cell.textContent =
            'No DHCP scopes configured.';

        row.appendChild(cell);
        dhcpScopesBody.appendChild(row);
        return;
    }

    for (const scope of scopes) {

        const row =
            document.createElement('tr');

        dhcpCell(row, scope.name);
        dhcpCell(
            row,
            (scope.startingAddress || '')
                + ' - '
                + (scope.endingAddress || '')
        );
        dhcpCell(row, scope.subnetMask);

        const statusCell =
            document.createElement('td');

        const statusButton =
            dhcpStatusButton(
                !!scope.enabled
            );

        statusButton.addEventListener(
            'click',
            () => dhcpAction(
                scope.enabled
                    ? 'scope_disable'
                    : 'scope_enable',
                { name: scope.name }
            )
        );

        statusCell.appendChild(
            statusButton
        );

        row.appendChild(statusCell);

        const actionsCell =
            document.createElement('td');

        const deleteButton =
            dhcpActionButton(
                'Delete',
                'deny-btn'
            );

        deleteButton.addEventListener(
            'click',
            () => {

                if (
                    !confirm(
                        'Delete DHCP scope "'
                        + scope.name
                        + '"? This permanently '
                        + 'removes the scope from '
                        + 'disk.'
                    )
                ) {
                    return;
                }

                dhcpAction(
                    'scope_delete',
                    { name: scope.name }
                );
            }
        );

        actionsCell.appendChild(
            deleteButton
        );

        row.appendChild(actionsCell);

        dhcpScopesBody.appendChild(row);
    }
}

function renderDhcpLeases(leases) {

    dhcpLeasesBody.textContent = '';

    if (!leases || leases.length === 0) {

        const row =
            document.createElement('tr');

        const cell =
            document.createElement('td');

        cell.colSpan = 7;
        cell.textContent =
            'No DHCP leases allocated.';

        row.appendChild(cell);
        dhcpLeasesBody.appendChild(row);
        return;
    }

    for (const lease of leases) {

        const row =
            document.createElement('tr');

        dhcpCell(row, lease.address);
        dhcpCell(row, lease.hardwareAddress);
        dhcpCell(row, lease.hostName);
        dhcpCell(row, lease.type);
        dhcpCell(row, lease.leaseExpires);
        dhcpCell(row, lease.scope);

        const actionsCell =
            document.createElement('td');

        const removeButton =
            dhcpActionButton(
                'Remove',
                'deny-btn'
            );

        removeButton.addEventListener(
            'click',
            () => {

                if (
                    !confirm(
                        'Remove lease '
                        + lease.address
                        + ' ('
                        + lease.hardwareAddress
                        + ')?'
                    )
                ) {
                    return;
                }

                dhcpAction(
                    'lease_remove',
                    {
                        name: lease.scope,
                        hardware_address:
                            lease.hardwareAddress
                    }
                );
            }
        );

        actionsCell.appendChild(
            removeButton
        );

        row.appendChild(actionsCell);

        dhcpLeasesBody.appendChild(row);
    }
}

function applyDhcpState(state) {

    if (!state || state.success !== true) {
        return;
    }

    renderDhcpScopes(state.scopes);
    renderDhcpLeases(state.leases);
}

async function refreshDhcp() {

    try {

        const response = await fetch(
            dhcpApi + '?action=get'
        );

        applyDhcpState(
            await response.json()
        );

    } catch (error) {

        dhcpScopesBody.textContent = '';

        const row =
            document.createElement('tr');

        const cell =
            document.createElement('td');

        cell.colSpan = 5;
        cell.textContent =
            'Failed to load the DHCP server '
            + 'state.';

        row.appendChild(cell);
        dhcpScopesBody.appendChild(row);
    }
}

async function dhcpAction(action, params) {

    try {

        const response = await fetch(
            dhcpApi,
            {
                method: 'POST',
                body: new URLSearchParams(
                    Object.assign(
                        { action: action },
                        params
                    )
                )
            }
        );

        const json =
            await response.json();

        if (json.success !== true) {
            showDhcpMessage(
                json.message
                    || 'Update failed.'
            );
            return;
        }

        applyDhcpState(json);
        showDhcpMessage(
            json.message || 'Done.'
        );

    } catch (error) {
        showDhcpMessage(
            'Update failed.'
        );
    }
}

document
    .getElementById('add_scope')
    .addEventListener('click', () => {

        dhcpAction(
            'scope_add',
            {
                name:
                    document
                        .getElementById(
                            'scope_name'
                        ).value,
                starting_address:
                    document
                        .getElementById(
                            'scope_start'
                        ).value,
                ending_address:
                    document
                        .getElementById(
                            'scope_end'
                        ).value,
                subnet_mask:
                    document
                        .getElementById(
                            'scope_mask'
                        ).value,
                lease_days:
                    document
                        .getElementById(
                            'scope_lease_days'
                        ).value,
                lease_hours:
                    document
                        .getElementById(
                            'scope_lease_hours'
                        ).value,
                lease_minutes:
                    document
                        .getElementById(
                            'scope_lease_minutes'
                        ).value
            }
        );
    }
);

refreshDhcp();
</script>

</body>

</html>
