<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Monitor board background image
 * upload. Follows the banner upload
 * conventions: the image is stored as
 * a webp file under uploads/appearance,
 * the path is kept in the portal
 * settings and the previous
 * background is removed.
 */

header('Content-Type: application/json');

function bgResponse(
    bool $success,
    string $message,
    array $extra = []
): void {

    echo json_encode(
        array_merge(
            [
                'success' => $success,
                'message' => $message
            ],
            $extra
        )
    );

    exit;
}

if (!hasPermission('Edit Monitor')) {

    http_response_code(403);

    bgResponse(
        false,
        'Access denied.'
    );
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    bgResponse(
        false,
        'POST required.'
    );
}

$uploadDirectory =
    '/opt/portal/web/uploads/appearance';

$relativeDirectory =
    'uploads/appearance';

$pattern =
    '#^uploads/appearance/'
    . 'monitor_bg_[a-f0-9]{32}\.webp$#';

function bgCurrentSetting(
    string $fastApiUrl
): array {

    $settings =
        @file_get_contents(
            $fastApiUrl . '/portal-settings'
        );

    if ($settings === false) {
        return [];
    }

    $decoded =
        json_decode(
            $settings,
            true
        );

    return is_array($decoded)
        ? $decoded
        : [];
}

function bgSaveSetting(
    string $fastApiUrl,
    string $key,
    string $value
): bool {

    $payload =
        json_encode([
            'settings' => [
                $key => $value
            ]
        ]);

    $result =
        @file_get_contents(
            $fastApiUrl
            . '/portal-settings/appearance',
            false,
            stream_context_create([
                'http' => [
                    'method' => 'POST',
                    'header' =>
                        "Content-Type: "
                        . "application/json\r\n",
                    'content' => $payload
                ]
            ])
        );

    return $result !== false;
}

function bgDeleteOld(
    string $relativePath,
    string $uploadDirectory,
    string $pattern
): void {

    if (
        $relativePath === ''
        || !preg_match($pattern, $relativePath)
    ) {
        return;
    }

    $absolute =
        '/opt/portal/web/'
        . $relativePath;

    if (is_file($absolute)) {
        @unlink($absolute);
    }
}

$current = bgCurrentSetting(
    $FASTAPI_URL
);

$oldImage =
    trim(
        (string)(
            $current['monitor_background_image']
            ?? ''
        )
    );

$file =
    $_FILES['background']
    ?? null;

if (
    !is_array($file)
    || ($file['error'] ?? UPLOAD_ERR_NO_FILE)
    !== UPLOAD_ERR_OK
) {

    http_response_code(400);

    bgResponse(
        false,
        'No image received.'
    );
}

if (
    ($file['size'] ?? 0) > 12 * 1024 * 1024
) {

    http_response_code(400);

    bgResponse(
        false,
        'The image is too large (max 12MB).'
    );
}

$info =
    @getimagesize(
        (string)$file['tmp_name']
    );

if ($info === false) {

    http_response_code(400);

    bgResponse(
        false,
        'The file is not a valid image.'
    );
}

$source = null;

switch ($info[2]) {

    case IMAGETYPE_JPEG:
        $source =
            imagecreatefromjpeg(
                (string)$file['tmp_name']
            );
        break;

    case IMAGETYPE_PNG:
        $source =
            imagecreatefrompng(
                (string)$file['tmp_name']
            );
        break;

    case IMAGETYPE_WEBP:
        $source =
            imagecreatefromwebp(
                (string)$file['tmp_name']
            );
        break;

    case IMAGETYPE_GIF:
        $source =
            imagecreatefromgif(
                (string)$file['tmp_name']
            );
        break;
}

if ($source === false) {

    http_response_code(400);

    bgResponse(
        false,
        'The image type is not supported.'
    );
}

/* keep big photos reasonable */

$maxSide = 2560;

$width = imagesx($source);
$height = imagesy($source);

$scale = min(
    1,
    $maxSide / max($width, $height)
);

if ($scale < 1) {

    $newWidth = (int)round(
        $width * $scale
    );

    $newHeight = (int)round(
        $height * $scale
    );

    $resized =
        imagescale(
            $source,
            $newWidth,
            $newHeight
        );

    if ($resized !== false) {
        imagedestroy($source);
        $source = $resized;
        $width = $newWidth;
        $height = $newHeight;
    }
}

$filename =
    'monitor_bg_'
    . md5_file(
        (string)$file['tmp_name']
    )
    . '.webp';

$absolutePath =
    $uploadDirectory
    . '/'
    . $filename;

$written =
    imagewebp(
        $source,
        $absolutePath,
        85
    );

imagedestroy($source);

if (
    !$written
    || !is_file($absolutePath)
) {

    http_response_code(500);

    bgResponse(
        false,
        'Unable to save the image.'
    );
}

@chmod(
    $absolutePath,
    0644
);

$relativePath =
    $relativeDirectory
    . '/'
    . $filename;

if (
    !bgSaveSetting(
        $FASTAPI_URL,
        'monitor_background_image',
        $relativePath
    )
) {

    @unlink($absolutePath);

    http_response_code(502);

    bgResponse(
        false,
        'Unable to save the setting.'
    );
}

bgDeleteOld(
    $oldImage,
    $uploadDirectory,
    $pattern
);

bgResponse(
    true,
    'Background uploaded.',
    [
        'monitor_background_image'
            => $relativePath
    ]
);
