<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Technitium proxy and forwarders
 * proxy. Serves the Network Proxy tab
 * on the Technitium hub page. The
 * caller must hold the Network Proxy
 * permission.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

if (
    !hasPermission(
        'Network Proxy'
    )
) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

function technitiumProxyCall(
    $path,
    $params = null
) {

    global $TECHNITIUM_HOST, $TECHNITIUM_TOKEN;

    $ch = curl_init(
        'http://' . $TECHNITIUM_HOST
        . ':5380' . $path
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer '
            . $TECHNITIUM_TOKEN
        ],
        CURLOPT_TIMEOUT => 10
    ]);

    if ($params !== null) {
        curl_setopt(
            $ch,
            CURLOPT_POSTFIELDS,
            http_build_query($params)
        );
    }

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    return json_decode($body, true);
}

function proxyView($settings) {

    $proxy =
        $settings['proxy'] ?? null;

    $view = [
        'success' => true,
        'proxy_type' => 'None',
        'proxy_address' => '',
        'proxy_port' => '',
        'proxy_username' => '',
        'proxy_password' => '',
        'proxy_bypass' => [],
        'forwarders' => [],
        'forwarder_protocol' =>
            (string)(
                $settings[
                    'forwarderProtocol'
                ]
                ?? 'Udp'
            ),
        'concurrent_forwarding' =>
            (bool)(
                $settings[
                    'concurrentForwarding'
                ]
                ?? false
            ),
        'forwarder_retries' =>
            (int)(
                $settings[
                    'forwarderRetries'
                ]
                ?? 2
            ),
        'forwarder_timeout' =>
            (int)(
                $settings[
                    'forwarderTimeout'
                ]
                ?? 2000
            ),
        'forwarder_concurrency' =>
            (int)(
                $settings[
                    'forwarderConcurrency'
                ]
                ?? 2
            )
    ];

    if (
        is_array(
            $settings['forwarders']
            ?? null
        )
    ) {
        $view['forwarders'] =
            array_values(
                $settings['forwarders']
            );
    }

    if (is_array($proxy)) {

        $view['proxy_type'] =
            (string)(
                $proxy['type']
                ?? 'None'
            );

        $view['proxy_address'] =
            (string)(
                $proxy['address']
                ?? ''
            );

        $view['proxy_port'] =
            (string)(
                $proxy['port']
                ?? ''
            );

        $view['proxy_username'] =
            (string)(
                $proxy['username']
                ?? ''
            );

        $view['proxy_password'] =
            (string)(
                $proxy['password']
                ?? ''
            );

        if (
            is_array(
                $proxy['bypass']
                ?? null
            )
        ) {
            $view['proxy_bypass'] =
                array_values(
                    $proxy['bypass']
                );
        }
    }

    return $view;
}

$action =
    $_GET['action']
    ?? ($_POST['action'] ?? '');

if ($action === 'get') {

    $result = technitiumProxyCall(
        '/api/settings/get'
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Failed to read the Technitium '
                . 'DNS server settings.'
        ]);
        exit;
    }

    echo json_encode(
        proxyView(
            $result['response'] ?? []
        )
    );
    exit;
}

if ($action === 'set') {

    $params = [];

    if (isset($_POST['proxy_type'])) {

        $proxyType =
            (string)$_POST['proxy_type'];

        if (
            !in_array(
                $proxyType,
                ['None', 'Http', 'Socks5'],
                true
            )
        ) {
            echo json_encode([
                'success' => false,
                'message' =>
                    'Invalid proxy type.'
            ]);
            exit;
        }

        $proxyPort =
            trim(
                (string)(
                    $_POST['proxy_port']
                    ?? ''
                )
            );

        if (
            $proxyPort !== ''
            && (
                (int)$proxyPort < 1
                || (int)$proxyPort > 65535
            )
        ) {
            echo json_encode([
                'success' => false,
                'message' =>
                    'Proxy port must be between '
                    . '1 and 65535.'
            ]);
            exit;
        }

        $bypass = array_values(
            array_filter(
                array_map(
                    'trim',
                    explode(
                        "\n",
                        (string)(
                            $_POST[
                                'proxy_bypass'
                            ]
                            ?? ''
                        )
                    )
                )
            )
        );

        $params['proxyType'] = $proxyType;
        $params['proxyAddress'] =
            trim(
                (string)(
                    $_POST['proxy_address']
                    ?? ''
                )
            );
        $params['proxyPort'] = $proxyPort;
        $params['proxyUsername'] =
            trim(
                (string)(
                    $_POST['proxy_username']
                    ?? ''
                )
            );
        $params['proxyPassword'] =
            trim(
                (string)(
                    $_POST['proxy_password']
                    ?? ''
                )
            );
        $params['proxyBypass'] =
            implode(',', $bypass);
    }

    if (
        isset(
            $_POST[
                'forwarders_submitted'
            ]
        )
    ) {

        $forwarders = array_values(
            array_filter(
                array_map(
                    'trim',
                    explode(
                        "\n",
                        (string)(
                            $_POST['forwarders']
                            ?? ''
                        )
                    )
                )
            )
        );

        foreach ($forwarders as $forwarder) {

            $isValid =
                filter_var(
                    $forwarder,
                    FILTER_VALIDATE_IP
                )
                || preg_match(
                    '/^[a-zA-Z0-9]([a-zA-Z0-9\-]'
                    . '*[a-zA-Z0-9])?'
                    . '(\.[a-zA-Z0-9]([a-zA-Z0-9\-]'
                    . '*[a-zA-Z0-9])?)+$/',
                    $forwarder
                )
                || preg_match(
                    '/^https?:\/\/.+$/',
                    $forwarder
                );

            if (!$isValid) {
                echo json_encode([
                    'success' => false,
                    'message' =>
                        'Invalid forwarder: '
                        . $forwarder
                ]);
                exit;
            }
        }

        $protocol =
            (string)(
                $_POST[
                    'forwarder_protocol'
                ]
                ?? 'Udp'
            );

        if (
            !in_array(
                $protocol,
                [
                    'Udp',
                    'Tcp',
                    'Tls',
                    'Https',
                    'Quic'
                ],
                true
            )
        ) {
            echo json_encode([
                'success' => false,
                'message' =>
                    'Invalid forwarder '
                    . 'protocol.'
            ]);
            exit;
        }

        $retries = (int)(
            $_POST['forwarder_retries']
            ?? 2
        );

        $timeout = (int)(
            $_POST['forwarder_timeout']
            ?? 2000
        );

        $concurrency = (int)(
            $_POST[
                'forwarder_concurrency'
            ]
            ?? 2
        );

        if (
            $retries < 0
            || $retries > 15
            || $timeout < 100
            || $timeout > 60000
            || $concurrency < 1
            || $concurrency > 100
        ) {
            echo json_encode([
                'success' => false,
                'message' =>
                    'Forwarder values are out '
                    . 'of range.'
            ]);
            exit;
        }

        $params['forwarders'] =
            $forwarders === []
                ? 'false'
                : implode(',', $forwarders);

        $params[
            'forwarderProtocol'
        ] = $protocol;

        $params[
            'concurrentForwarding'
        ] =
            in_array(
                (string)(
                    $_POST[
                        'concurrent_forwarding'
                    ]
                    ?? ''
                ),
                ['true', '1', 'on'],
                true
            )
                ? 'true'
                : 'false';

        $params[
            'forwarderRetries'
        ] = (string)$retries;

        $params[
            'forwarderTimeout'
        ] = (string)$timeout;

        $params[
            'forwarderConcurrency'
        ] = (string)$concurrency;
    }

    if ($params === []) {
        echo json_encode([
            'success' => false,
            'message' => 'Nothing to update.'
        ]);
        exit;
    }

    $result = technitiumProxyCall(
        '/api/settings/set',
        $params
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'The Technitium DNS server '
                . 'rejected the update.'
        ]);
        exit;
    }

    echo json_encode(
        proxyView(
            $result['response'] ?? []
        )
    );
    exit;
}

echo json_encode([
    'success' => false,
    'message' => 'Unknown action.'
]);
