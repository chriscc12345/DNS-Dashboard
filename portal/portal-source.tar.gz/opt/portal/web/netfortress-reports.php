<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Reports')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-reports';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Reports</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-event-action {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
        }
        .nf-event-blocked {
            background: #b50b0b;
            color: #fff;
        }
        .nf-event-allowed {
            background: #097a27;
            color: #fff;
        }
        .nf-event-alert {
            background: #c07a00;
            color: #fff;
        }
        .nf-window-bar {
            display: flex;
            gap: 8px;
            margin-bottom: 14px;
            flex-wrap: wrap;
            align-items: center;
        }
        .nf-window-btn {
            padding: 6px 14px;
            border: 1px solid #ccc;
            border-radius: 6px;
            background: #fff;
            cursor: pointer;
            font-size: 13px;
        }
        .nf-window-btn.nf-window-selected {
            background: #333;
            color: #fff;
            border-color: #333;
        }
        #nfReportsMessage {
            margin-top: 10px;
            font-size: 13px;
            display: none;
        }
        #nfReportsMessage.nf-message-error {
            color: #b50b0b;
            display: block;
        }
        #nfReportsMessage.nf-message-ok {
            color: #097a27;
            display: block;
        }
        .nf-details pre {
            margin: 4px 0 0 0;
            font-size: 11px;
            white-space: pre-wrap;
            word-break: break-all;
            max-width: 340px;
        }
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Recent events from the local Firewall Appliance.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel um-table-panel">

        <div class="nf-window-bar">
            <strong style="font-size:13px;margin-right:4px;">Show:</strong>
            <button type="button" class="nf-window-btn" data-hours="1">Last hour</button>
            <button type="button" class="nf-window-btn nf-window-selected" data-hours="24">Last 24 hours</button>
            <button type="button" class="nf-window-btn" data-hours="168">Last 7 days</button>
            <button type="button" class="nf-window-btn" data-hours="0">Most recent 100</button>
        </div>

        <table id="nfEventsTable">
            <thead>
            <tr>
                <th>Time</th>
                <th>Type</th>
                <th>Action</th>
                <th>Client</th>
                <th>Destination</th>
                <th>Category / Policy</th>
                <th>Details</th>
            </tr>
            </thead>
            <tbody id="nfEventsBody">
            <tr>
                <td colspan="7">Loading recent events from the appliance...</td>
            </tr>
            </tbody>
        </table>

        <div id="nfReportsMessage"></div>

        <p style="margin-top:10px;font-size:13px;color:#666;">
            Only recent events are shown. Older history stays on the
            appliance. The list refreshes automatically every 15 seconds.
        </p>

    </div>

</div>

<script>
(function () {

    const body = document.getElementById('nfEventsBody');
    const message = document.getElementById('nfReportsMessage');

    let windowHours = 24;
    let events = [];
    let loading = false;

    function showMessage(text, ok) {

        if (!text) {
            message.className = '';
            message.textContent = '';
            return;
        }

        message.className = ok
            ? 'nf-message-ok'
            : 'nf-message-error';
        message.textContent = text;

    }

    function escapeHtml(value) {

        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');

    }

    function formatTime(value) {

        const date = new Date(value);

        if (isNaN(date.getTime())) {
            return escapeHtml(value);
        }

        return escapeHtml(date.toLocaleString());

    }

    function renderEvent(event) {

        const row = document.createElement('tr');

        const actionClass =
            event.action === 'blocked' ? 'nf-event-blocked'
            : event.action === 'allowed' ? 'nf-event-allowed'
            : 'nf-event-alert';

        let details = '';
        const d = event.details;

        if (d && typeof d === 'object' && Object.keys(d).length > 0) {
            details =
                '<details class="nf-details"><summary>view</summary>' +
                '<pre>' + escapeHtml(JSON.stringify(d, null, 1)) + '</pre>' +
                '</details>';
        }

        const destination =
            event.destination || event.hostname || '-';

        const category =
            [event.category, event.policy]
                .filter(function (value) { return value; })
                .join(' / ') || '-';

        row.innerHTML =
            '<td>' + formatTime(event.occurred_at) + '</td>' +
            '<td>' + escapeHtml(event.event_type || '-') + '</td>' +
            '<td><span class="nf-event-action ' + actionClass + '">' +
            escapeHtml(event.action || '-') + '</span></td>' +
            '<td>' + escapeHtml(event.client_ip || '-') + '</td>' +
            '<td>' + escapeHtml(destination) + '</td>' +
            '<td>' + escapeHtml(category) + '</td>' +
            '<td>' + details + '</td>';

        return row;

    }

    function render() {

        const now = Date.now();

        let visible = events;

        if (windowHours > 0) {
            visible = events.filter(function (event) {

                const time = new Date(event.occurred_at).getTime();

                if (isNaN(time)) {
                    return false;
                }

                return (now - time) <= windowHours * 3600 * 1000;

            });
        } else {
            visible = events.slice(0, 100);
        }

        body.innerHTML = '';

        if (visible.length === 0) {
            body.innerHTML =
                '<tr><td colspan="7">No events in this period.</td></tr>';
            return;
        }

        visible.forEach(function (event) {
            body.appendChild(renderEvent(event));
        });

    }

    function loadEvents() {

        if (loading) {
            return;
        }

        loading = true;

        fetch('netfortress-api.php?action=events')
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {

                loading = false;

                if (!data.success) {
                    body.innerHTML =
                        '<tr><td colspan="7">' +
                        escapeHtml(data.message || 'The appliance is not reachable.') +
                        '</td></tr>';
                    return;
                }

                events = data.events || [];

                render();

            })
            .catch(function () {

                loading = false;

                body.innerHTML =
                    '<tr><td colspan="7">' +
                    'The appliance API is not reachable.</td></tr>';

            });

    }

    document.querySelectorAll('.nf-window-btn').forEach(function (button) {

        button.addEventListener(
            'click',
            function () {

                document
                    .querySelectorAll('.nf-window-btn')
                    .forEach(function (other) {
                        other.classList.remove('nf-window-selected');
                    });

                button.classList.add('nf-window-selected');

                windowHours = parseInt(button.dataset.hours, 10);

                render();

            }
        );

    });

    loadEvents();
    setInterval(loadEvents, 15000);

})();
</script>

</body>

</html>
