<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (!hasPermission('User Disclaimer')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'appearance-user-disclaimer';
$pageHeading = 'Customization';
$showSidebarPageHeading = true;

$portalSettings =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];


$disclaimerEnabled =
    strtolower(
        trim(
            (string)(
                $portalSettings['user_disclaimer_enabled']
                ?? 'true'
            )
        )
    ) === 'true';


$disclaimerTitle =
    (string)(
        $portalSettings['user_disclaimer_title']
        ?? 'User Information'
    );


$disclaimerText =
    (string)(
        $portalSettings['user_disclaimer_text']
        ?? 'Create a new user account for the portal and assign the appropriate group and permissions.'
    );


$disclaimerChecklist =
    (string)(
        $portalSettings['user_disclaimer_checklist']
        ?? "User will be created in the portal\nProfile details will be saved\nGroup permissions will apply\nUser will be able to log in once created"
    );


$disclaimerNote =
    (string)(
        $portalSettings['user_disclaimer_note']
        ?? 'Make sure the information is correct before creating the user.'
    );


$checklistItems =
    preg_split(
        '/\r\n|\r|\n/',
        $disclaimerChecklist
    );

$checklistItems =
    array_values(
        array_filter(
            array_map(
                'trim',
                $checklistItems
            ),
            static function ($item) {
                return $item !== '';
            }
        )
    );

?>
<!DOCTYPE html>
<html>
<head>

    <title>Appearance - User Disclaimer</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined"
        rel="stylesheet">

</head>

<body>

<?php include 'includes/banner.php'; ?>
<?php include 'includes/sidebar.php'; ?>


<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Appearance</h1>

            <p>
                Configure the information panel displayed beside
                the Add User form.
            </p>
        </div>

    </div>


        <?php include __DIR__ . '/includes/page-tabs.php'; ?>


    <div class="appearance-panel">

        <div class="appearance-disclaimer-layout">


            <!-- =========================
                 LIVE PREVIEW
                 ========================= -->

            <div class="appearance-disclaimer-preview-column">

                <div class="appearance-disclaimer-preview-heading">

                    <div>
                        <strong>Live Preview</strong>

                        <small>
                            Preview of the panel shown in Add User.
                        </small>
                    </div>

                    <span
                        class="appearance-disclaimer-status"
                        id="disclaimerPreviewStatus">
                        <?= $disclaimerEnabled ? 'Visible' : 'Hidden' ?>
                    </span>

                </div>


                <div class="appearance-disclaimer-preview-stage">

                    <aside
                        class="appearance-disclaimer-preview"
                        id="disclaimerPreview"
                        <?= $disclaimerEnabled ? '' : 'hidden' ?>>

                        <div class="disclaimer-heading">

                            <span class="disclaimer-icon">
                                i
                            </span>

                            <h4 id="disclaimerPreviewTitle">
                                <?= htmlspecialchars($disclaimerTitle) ?>
                            </h4>

                        </div>


                        <p id="disclaimerPreviewText">
                            <?= htmlspecialchars($disclaimerText) ?>
                        </p>


                        <div class="disclaimer-divider"></div>


                        <ul id="disclaimerPreviewChecklist">

                            <?php foreach($checklistItems as $item): ?>

                            <li>
                                <?= htmlspecialchars($item) ?>
                            </li>

                            <?php endforeach; ?>

                        </ul>


                        <div
                            class="disclaimer-note"
                            id="disclaimerPreviewNote">
                            <?= htmlspecialchars($disclaimerNote) ?>
                        </div>

                    </aside>


                    <div
                        class="appearance-disclaimer-hidden-preview"
                        id="disclaimerHiddenPreview"
                        <?= $disclaimerEnabled ? 'hidden' : '' ?>>

                        <span class="material-symbols-outlined">
                            visibility_off
                        </span>

                        <strong>User Disclaimer Hidden</strong>

                        <small>
                            The information panel will not be displayed
                            in Add User.
                        </small>

                    </div>

                </div>

            </div>


            <!-- =========================
                 SETTINGS
                 ========================= -->

            <div class="appearance-disclaimer-options">


                <div class="appearance-disclaimer-control">

                    <div class="appearance-disclaimer-control-heading">

                        <div>
                            <strong>Show User Disclaimer</strong>

                            <small>
                                Display the information panel beside
                                the Add User form.
                            </small>
                        </div>


                        <label class="appearance-disclaimer-switch">

                            <input
                                type="checkbox"
                                id="disclaimerEnabled"
                                <?= $disclaimerEnabled ? 'checked' : '' ?>>

                            <span></span>

                        </label>

                    </div>

                </div>


                <div class="appearance-disclaimer-control">

                    <label for="disclaimerTitle">
                        <strong>Title</strong>
                    </label>

                    <small>
                        Heading displayed at the top of the panel.
                    </small>

                    <input
                        type="text"
                        id="disclaimerTitle"
                        maxlength="120"
                        value="<?= htmlspecialchars($disclaimerTitle) ?>">

                </div>


                <div class="appearance-disclaimer-control">

                    <label for="disclaimerText">
                        <strong>Main Text</strong>
                    </label>

                    <small>
                        Introductory information displayed below the title.
                    </small>

                    <textarea
                        id="disclaimerText"
                        maxlength="1500"
                        rows="4"><?= htmlspecialchars($disclaimerText) ?></textarea>

                </div>


                <div class="appearance-disclaimer-control">

                    <label for="disclaimerChecklist">
                        <strong>Checklist Items</strong>
                    </label>

                    <small>
                        Enter one checklist item per line.
                        Leave empty if no checklist is required.
                    </small>

                    <textarea
                        id="disclaimerChecklist"
                        maxlength="3000"
                        rows="7"><?= htmlspecialchars($disclaimerChecklist) ?></textarea>

                </div>


                <div class="appearance-disclaimer-control">

                    <label for="disclaimerNote">
                        <strong>Highlighted Note</strong>
                    </label>

                    <small>
                        Optional footer message shown at the bottom
                        of the panel.
                    </small>

                    <textarea
                        id="disclaimerNote"
                        maxlength="1000"
                        rows="3"><?= htmlspecialchars($disclaimerNote) ?></textarea>

                </div>


                <div class="appearance-disclaimer-info">

                    <span class="material-symbols-outlined">
                        info
                    </span>

                    <div>
                        <strong>Display information only</strong>

                        <p>
                            User Disclaimer content does not change
                            user permissions or user creation logic.
                        </p>
                    </div>

                </div>


                <div class="appearance-disclaimer-actions">

                    <button
                        type="button"
                        class="table-btn"
                        id="disclaimerSave">
                        Save User Disclaimer
                    </button>

                    <button
                        type="button"
                        class="table-btn appearance-secondary-btn"
                        id="disclaimerReset">
                        Basic Defaults
                    </button>

                </div>

            </div>

        </div>

    </div>

</div>


<div
    id="appearanceDisclaimerMessage"
    class="appearance-theme-message"
    role="status"
    aria-live="polite">
</div>


<script>
(function () {

    const enabled =
        document.getElementById('disclaimerEnabled');

    const title =
        document.getElementById('disclaimerTitle');

    const text =
        document.getElementById('disclaimerText');

    const checklist =
        document.getElementById('disclaimerChecklist');

    const note =
        document.getElementById('disclaimerNote');

    const preview =
        document.getElementById('disclaimerPreview');

    const hiddenPreview =
        document.getElementById('disclaimerHiddenPreview');

    const previewStatus =
        document.getElementById('disclaimerPreviewStatus');

    const previewTitle =
        document.getElementById('disclaimerPreviewTitle');

    const previewText =
        document.getElementById('disclaimerPreviewText');

    const previewChecklist =
        document.getElementById('disclaimerPreviewChecklist');

    const previewNote =
        document.getElementById('disclaimerPreviewNote');

    const saveButton =
        document.getElementById('disclaimerSave');

    const resetButton =
        document.getElementById('disclaimerReset');

    const message =
        document.getElementById('appearanceDisclaimerMessage');


    const defaults = {
        enabled: true,

        title:
            'User Information',

        text:
            'Create a new user account for the portal and assign the appropriate group and permissions.',

        checklist:
            [
                'User will be created in the portal',
                'Profile details will be saved',
                'Group permissions will apply',
                'User will be able to log in once created'
            ].join('\n'),

        note:
            'Make sure the information is correct before creating the user.'
    };


    function showMessage(messageText, success) {

        message.textContent = messageText;

        message.classList.remove(
            'success',
            'error'
        );

        message.classList.add(
            success
                ? 'success'
                : 'error'
        );

        message.classList.add(
            'appearance-disclaimer-message-visible'
        );

        window.clearTimeout(
            showMessage.timer
        );

        showMessage.timer =
            window.setTimeout(
                function () {
                    message.classList.remove(
                        'appearance-disclaimer-message-visible'
                    );
                },
                3200
            );
    }


    function updatePreview() {

        const isEnabled =
            enabled.checked;

        preview.hidden =
            !isEnabled;

        hiddenPreview.hidden =
            isEnabled;

        previewStatus.textContent =
            isEnabled
                ? 'Visible'
                : 'Hidden';


        previewTitle.textContent =
            title.value.trim()
            || 'User Information';


        previewText.textContent =
            text.value.trim();


        previewChecklist.innerHTML = '';

        checklist.value
            .split(/\r?\n/)
            .map(function (item) {
                return item.trim();
            })
            .filter(function (item) {
                return item !== '';
            })
            .forEach(function (item) {

                const li =
                    document.createElement('li');

                li.textContent =
                    item;

                previewChecklist.appendChild(li);
            });


        const noteValue =
            note.value.trim();

        previewNote.textContent =
            noteValue;

        previewNote.hidden =
            noteValue === '';
    }


    [
        enabled,
        title,
        text,
        checklist,
        note
    ].forEach(
        function (control) {

            control.addEventListener(
                'input',
                updatePreview
            );

            control.addEventListener(
                'change',
                updatePreview
            );
        }
    );


    resetButton.addEventListener(
        'click',
        function () {

            enabled.checked =
                defaults.enabled;

            title.value =
                defaults.title;

            text.value =
                defaults.text;

            checklist.value =
                defaults.checklist;

            note.value =
                defaults.note;

            updatePreview();
        }
    );


    saveButton.addEventListener(
        'click',
        async function () {

            saveButton.disabled = true;

            try {

                const response =
                    await fetch(
                        'appearance-api.php',
                        {
                            method: 'POST',

                            headers: {
                                'Content-Type':
                                    'application/json'
                            },

                            body: JSON.stringify({
                                action: 'save',

                                settings: {
                                    user_disclaimer_enabled:
                                        enabled.checked
                                            ? 'true'
                                            : 'false',

                                    user_disclaimer_title:
                                        title.value.trim(),

                                    user_disclaimer_text:
                                        text.value.trim(),

                                    user_disclaimer_checklist:
                                        checklist.value,

                                    user_disclaimer_note:
                                        note.value.trim()
                                }
                            })
                        }
                    );


                const data =
                    await response.json();


                if (
                    !response.ok
                    ||
                    !data.success
                ) {
                    throw new Error(
                        data.message
                        || 'Unable to save User Disclaimer settings.'
                    );
                }


                showMessage(
                    'User Disclaimer settings saved.',
                    true
                );

            } catch (error) {

                showMessage(
                    error.message
                    || 'Unable to save User Disclaimer settings.',
                    false
                );

            } finally {

                saveButton.disabled =
                    false;
            }
        }
    );


    updatePreview();

})();
</script>

</body>
</html>
