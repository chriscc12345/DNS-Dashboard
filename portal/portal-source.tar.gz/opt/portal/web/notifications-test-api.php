<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Test notification proxy. The browser calls
 * this endpoint; it forwards the request to
 * the portal API which performs the real
 * channel test. The caller must hold the
 * permission of the channel being tested.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

if (
    $_SERVER['REQUEST_METHOD'] !== 'POST'
) {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'POST required.'
    ]);
    exit;
}

$body = json_decode(
    (string)file_get_contents(
        'php://input'
    ),
    true
) ?? [];

/*
 * Rule test: fires a test alert through a
 * configured login notification rule.
 * Gated by the Login Notification
 * permission (same as rule management).
 */

if (
    isset($body['rule_id'])
    && (string)$body['rule_id'] !== ''
) {

    if (
        !hasPermission(
            'Notification Channel'
        )
    ) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Access denied.'
        ]);
        exit;
    }

    $ruleId =
        (int)$body['rule_id'];

    $ch = curl_init(
        'http://127.0.0.1:8000'
        . '/monitor/login-notifications/'
        . $ruleId
        . '/test'
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CUSTOMREQUEST => 'POST'
    ]);

    $response = curl_exec($ch);

    $status =
        (int)curl_getinfo(
            $ch,
            CURLINFO_RESPONSE_CODE
        );

    curl_close($ch);

    if (
        $response === false
        || $status !== 200
    ) {
        http_response_code(502);
        echo json_encode([
            'success' => false,
            'message' =>
                'The portal API did not answer '
                . 'the test request.'
        ]);
        exit;
    }

    echo $response;
    exit;
}

$channel =
    strtolower(
        trim(
            (string)(
                $body['channel']
                ?? ''
            )
        )
    );

$to =
    trim(
        (string)(
            $body['to']
            ?? ''
        )
    );

$channelPermissions = [
    'email' =>
        'Email Notifications',
    'push' =>
        'Push Notifications',
    'whatsapp' => 'WhatsApp',
    'telegram' => 'Telegram',
    'pushbullet' => 'Pushbullet'
];

$permission =
    $channelPermissions[$channel]
        ?? null;

if ($permission === null) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Unknown channel.'
    ]);
    exit;
}

if (!hasPermission($permission)) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

$ch = curl_init(
    'http://127.0.0.1:8000'
    . '/notifications/test'
);

curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json'
    ],
    CURLOPT_POSTFIELDS =>
        json_encode([
            'channel' => $channel,
            'to' => $to
        ])
]);

$response =
    curl_exec($ch);

$status =
    (int)curl_getinfo(
        $ch,
        CURLINFO_RESPONSE_CODE
    );

curl_close($ch);

if ($response === false || $status !== 200) {
    http_response_code(502);
    echo json_encode([
        'success' => false,
        'message' =>
            'The portal API did not answer '
            . 'the test request.'
    ]);
    exit;
}

echo $response;
