<?php

session_start();

require_once 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

      $url = $FASTAPI_URL . "/login";
      
      $data = json_encode([
          'username' => $username,
          'password' => $password
      ]);
      
      $response = file_get_contents(
          $url,
          false,
          stream_context_create([
              'http' => [
                  'method'  => 'POST',
                  'header'  => "Content-Type: application/json\r\n",
                  'content' => $data
              ]
          ])
      );
      
      $result = json_decode($response, true);

    if (
        isset($result['status']) &&
        $result['status'] === 'ok'
    ) {

        session_regenerate_id(true);

        $_SESSION['username'] =
            $result['username'];

        $_SESSION['displayName'] =
            $result['displayName'];

        $_SESSION['token'] =
            $result['token'];
        
        $permissions = json_decode(
            file_get_contents(
                $FASTAPI_URL .
                "/users/" .
                urlencode($username) .
                "/permissions"
            ),
            true
        );
        
        $_SESSION['permissions'] =
            $permissions ?? [];
        
        header("Location: dashboard.php");
        exit;

    } else {

        $error = "Invalid username or password";

    }
}

?>

<!DOCTYPE html>
<html>
<head>
  
  <title>Login</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
    <link
        rel="icon"
        type="image/png"
        href="images/favicon.png">
        
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>
<body class="login-body">

<div class="login-container">

    <h1>DNS Security Dashboard</h1>

    <?php if($error): ?>
        <p style="color:red;">
            <?= $error ?>
        </p>
    <?php endif; ?>

    <form method="post">

        <input
            type="text"
            name="username"
            placeholder="Username"
            required>

        <br><br>

        <input
            type="password"
            name="password"
            placeholder="Password"
            required>

        <br><br>

        <button
            type="submit"
            class="approve-btn">

            Sign In

        </button>

    </form>

</div>

</body>
</html>