<?php

session_start();

require_once 'config.php';

/*
 * Fresh installations must complete the initial administrator
 * password setup before the normal Portal login is available.
 *
 * Legacy installations do not have installed-at and are therefore
 * not forced through initial setup.
 */
if (
    is_file('/var/lib/portal/installed-at') &&
    !is_file('/var/lib/portal/initial-setup-complete')
) {
    header('Location: setup.php');
    exit;
}

$error = '';
$twofaError = '';
$twofaNonce = '';

/*
 * UPDATE005 - Login notification engine.
 * Fired after the auth result is known;
 * short timeout so sign-in is never
 * delayed by the notification sends
 * (the API keeps sending in the
 * background).
 */

function fireLoginNotification(
    $event,
    $username
) {

    global $FASTAPI_URL;

    if (trim((string)$username) === '') {
        return;
    }

    /*
     * UPDATE - portal-owned sign-in tracking.
     * The client IP is recorded with every login
     * event so the Users page (Last Login / Source
     * IP) no longer depends on Technitium.
     */

    $clientIp = '';

    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {

        $forwarded = explode(
            ',',
            (string)$_SERVER['HTTP_X_FORWARDED_FOR']
        );

        $clientIp = trim((string)$forwarded[0]);

    } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        $clientIp = trim((string)$_SERVER['REMOTE_ADDR']);
    }

    @file_get_contents(
        $FASTAPI_URL
        . '/monitor/login-notifications'
        . '/dispatch',
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  =>
                    "Content-Type: application/json\r\n",
                'content' => json_encode([
                    'event' => $event,
                    'username' => $username,
                    'source_ip' => $clientIp
                ]),
                'timeout' => 2
            ]
        ])
    );
}

/*
 * UPDATE - Portal two-factor sign-in.
 *
 * complete_portal_login() performs the session setup shared
 * by the password step and the 2FA verification step.
 */

function complete_portal_login($result, $FASTAPI_URL) {

    session_regenerate_id(true);

    $_SESSION['username'] =
        $result['username'];

    $_SESSION['displayName'] =
        $result['displayName'];

    $_SESSION['token'] =
        $result['token'];

    $permissions = json_decode(
        file_get_contents(
            $FASTAPI_URL .
            "/users/" .
            urlencode($result['username']) .
            "/permissions"
        ),
        true
    );

    $_SESSION['permissions'] =
        $permissions ?? [];

    fireLoginNotification(
        'successful_login',
        $result['username']
    );

    header("Location: dashboard.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
     * Step 2 - the 2FA verification code.
     */

    if (isset($_POST['twofa_code'])) {

        $nonce = trim((string)($_POST['twofa_nonce'] ?? ''));
        $code = trim((string)$_POST['twofa_code']);

        $response = file_get_contents(
            $FASTAPI_URL . "/login/2fa",
            false,
            stream_context_create([
                'http' => [
                    'method'  => 'POST',
                    'header'  => "Content-Type: application/json\r\n",
                    'content' => json_encode([
                        'nonce' => $nonce,
                        'code'  => $code
                    ])
                ]
            ])
        );

        $result = json_decode($response, true);

        if (
            is_array($result) &&
            isset($result['status']) &&
            $result['status'] === 'ok'
        ) {

            complete_portal_login($result, $FASTAPI_URL);

        }

        $twofaError = (
            is_array($result) && !empty($result['message'])
        )
            ? $result['message']
            : 'Invalid verification code';

        $twofaNonce = $nonce;

    } else {

    /*
     * Step 1 - username and password.
     */

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

      $url = $FASTAPI_URL . "/login";
      
      $data = json_encode([
          'username' => $username,
          'password' => $password
      ]);
      
      $response = file_get_contents(
          $url,
          false,
          stream_context_create([
              'http' => [
                  'method'  => 'POST',
                  'header'  => "Content-Type: application/json\r\n",
                  'content' => $data
              ]
          ])
      );
      
      $result = json_decode($response, true);

    if (
        is_array($result) &&
        isset($result['status']) &&
        $result['status'] === '2fa_required'
    ) {

        /*
         * Password accepted - the account has portal 2FA
         * enabled, so the verification code is requested
         * before the session is created.
         */

        $twofaNonce = (string)$result['nonce'];

    } elseif (
        is_array($result) &&
        isset($result['status']) &&
        $result['status'] === 'ok'
    ) {

        complete_portal_login($result, $FASTAPI_URL);

    } else {

        fireLoginNotification(
            'failed_login',
            $username
        );

        $error = "Invalid username or password";

    }

    } // end step 1
}

/*
 * UPDATE003 - Public Login Appearance
 *
 * These are presentation settings only. Authentication and
 * initial-setup behaviour above remain unchanged.
 */
$loginAppearance = [];

$settingsResponse = @file_get_contents(
    $FASTAPI_URL . '/portal-settings'
);

if ($settingsResponse !== false) {

    $decodedSettings = json_decode(
        $settingsResponse,
        true
    );

    if (is_array($decodedSettings)) {

        if (
            isset($decodedSettings['settings']) &&
            is_array($decodedSettings['settings'])
        ) {
            $loginAppearance =
                $decodedSettings['settings'];
        } else {
            $loginAppearance =
                $decodedSettings;
        }
    }
}


$loginTitle = trim(
    (string)(
        $loginAppearance['login_title']
        ?? 'DNS Security Dashboard'
    )
);

if ($loginTitle === '') {
    $loginTitle = 'DNS Security Dashboard';
}


$loginSubtitle = trim(
    (string)(
        $loginAppearance['login_subtitle']
        ?? ''
    )
);


$loginLogoSize = (int)(
    $loginAppearance['login_logo_size']
    ?? 180
);

if (
    $loginLogoSize < 60 ||
    $loginLogoSize > 300
) {
    $loginLogoSize = 180;
}


/*
 * Keep the normal Login card compact.
 * Larger company logos progressively widen the card so the
 * Login title has enough horizontal space.
 *
 *  60-180px logo = 400px card
 *  181-300px      = 400-500px card
 */
$loginCardWidth = 400;

if ($loginLogoSize > 180) {

    $loginCardWidth =
        400 +
        (int) round(
            (($loginLogoSize - 180) / 120) * 100
        );

}

$loginCardWidth = max(
    400,
    min(500, $loginCardWidth)
);


$showLoginLogo =
    strtolower(
        (string)(
            $loginAppearance['show_logo_login']
            ?? 'true'
        )
    ) === 'true';


$companyLogo = trim(
    (string)(
        $loginAppearance['company_logo']
        ?? ''
    )
);

if (
    !preg_match(
        '#^uploads/appearance/logo_[a-f0-9]{32}\.webp$#',
        $companyLogo
    )
) {
    $companyLogo = '';
}


$loginBackground = trim(
    (string)(
        $loginAppearance['login_background_image']
        ?? ''
    )
);

if (
    $loginBackground !== '' &&
    !preg_match(
        '#^uploads/appearance/login_[a-f0-9]{32}\.webp$#',
        $loginBackground
    )
) {
    $loginBackground = '';
}


$loginOverlay = (int)(
    $loginAppearance['login_background_overlay']
    ?? 0
);

$loginOverlay = max(
    0,
    min(100, $loginOverlay)
);


$loginCardPosition = strtolower(
    trim(
        (string)(
            $loginAppearance['login_card_position']
            ?? 'center'
        )
    )
);

if (
    !in_array(
        $loginCardPosition,
        ['left', 'center', 'right'],
        true
    )
) {
    $loginCardPosition = 'center';
}


$showLoginFooter =
    strtolower(
        (string)(
            $loginAppearance['show_login_footer']
            ?? 'false'
        )
    ) === 'true';


$loginFooterText = trim(
    (string)(
        $loginAppearance['login_footer_text']
        ?? ''
    )
);


$loginAnimationEnabled =
    strtolower(
        trim(
            (string)(
                $loginAppearance[
                    'login_animation_enabled'
                ]
                ?? 'false'
            )
        )
    ) === 'true';


$loginAnimationStyle =
    strtolower(
        trim(
            (string)(
                $loginAppearance[
                    'login_animation_style'
                ]
                ?? 'cyber'
            )
        )
    );

$loginAnimationStyles = [
    'cyber',
    'digital_rain',
    'network_grid',
    'security_scanner'
];

if (
    !in_array(
        $loginAnimationStyle,
        $loginAnimationStyles,
        true
    )
) {
    $loginAnimationStyle = 'cyber';
}


$loginAnimationIntensity =
    strtolower(
        trim(
            (string)(
                $loginAppearance[
                    'login_animation_intensity'
                ]
                ?? 'low'
            )
        )
    );

if (
    !in_array(
        $loginAnimationIntensity,
        ['low', 'medium', 'high', 'ultra'],
        true
    )
) {
    $loginAnimationIntensity = 'low';
}


/*
 * UPDATE003 - Basic Theme runtime colours for the public
 * Login page.
 *
 * Authenticated pages receive these variables through the
 * Sidebar. Login has no Sidebar, so reuse the Portal settings
 * already fetched above and render the variables here.
 */
$basicThemeSettings = $loginAppearance;

ob_start();
include __DIR__ . '/includes/basic-theme.php';
$basicThemeRuntimeCss = ob_get_clean();

?>

<!DOCTYPE html>
<html>
<head>
  
  <title><?= htmlspecialchars($loginTitle) ?></title>

    <link
        rel="stylesheet"
        href="css/style.css">

    <?= $basicThemeRuntimeCss ?>
    
<?php include __DIR__ . '/includes/favicon.php'; ?>

        
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>
<body
    class="login-body login-position-<?= htmlspecialchars($loginCardPosition) ?>"
    <?php if ($loginBackground !== ''): ?>
        style="background-image:url('<?= htmlspecialchars($loginBackground) ?>');"
    <?php endif; ?>>

<canvas
    class="login-background-animation"
    id="loginBackgroundAnimation"
    aria-hidden="true"
    <?= $loginAnimationEnabled ? '' : 'hidden' ?>>
</canvas>

<div
    class="login-background-overlay"
    style="background:rgba(0,0,0,<?= number_format($loginOverlay / 100, 2, '.', '') ?>);">
</div>

<div
    class="login-container"
    style="--login-card-width:<?= $loginCardWidth ?>px;">

    <?php if ($showLoginLogo && $companyLogo !== ''): ?>

        <div class="login-company-logo">

            <img
                src="<?= htmlspecialchars($companyLogo) ?>"
                alt="Company logo"
                style="width:<?= $loginLogoSize ?>px;">

        </div>

    <?php endif; ?>

    <h1><?= htmlspecialchars($loginTitle) ?></h1>

    <?php if ($loginSubtitle !== ''): ?>

        <div class="login-subtitle">
            <?= htmlspecialchars($loginSubtitle) ?>
        </div>

    <?php endif; ?>

    <?php if($error): ?>
        <p style="color:red;">
            <?= $error ?>
        </p>
    <?php endif; ?>

    <?php if($twofaError): ?>
        <p style="color:red;">
            <?= htmlspecialchars($twofaError) ?>
        </p>
    <?php endif; ?>

    <?php if($twofaNonce !== ''): ?>

        <!--
            UPDATE - Portal two-factor step 2: the password
            was accepted and the account has 2FA enabled, so
            only the verification code is requested here.
        -->

        <form
            method="post"
            autocomplete="off">

            <input
                type="hidden"
                name="twofa_nonce"
                value="<?= htmlspecialchars($twofaNonce) ?>">

            <input
                type="text"
                name="twofa_code"
                inputmode="numeric"
                pattern="[0-9]*"
                maxlength="6"
                placeholder="Verification code"
                style="text-align:center;
                    letter-spacing:6px;
                    font-size:18px;"
                autofocus
                required>

            <br><br>

            <button
                type="submit"
                class="approve-btn">

                Verify

            </button>

        </form>

    <?php else: ?>

    <form method="post">

        <input
            type="text"
            name="username"
            placeholder="Username"
            required>

        <br><br>

        <input
            type="password"
            name="password"
            placeholder="Password"
            required>

        <br><br>

        <button
            type="submit"
            class="approve-btn">

            Sign In

        </button>

    </form>

    <?php endif; ?>

    <?php if (
        $showLoginFooter &&
        $loginFooterText !== ''
    ): ?>

        <div class="login-footer-text">
            <?= htmlspecialchars($loginFooterText) ?>
        </div>

    <?php endif; ?>

</div>

<script src="js/portal-animation.js"></script>

<script>
(function () {

    const canvas =
        document.getElementById(
            'loginBackgroundAnimation'
        );

    if (
        !canvas
        || !window.PortalAnimation
    ) {
        return;
    }

    window.loginPortalAnimation =
        new window.PortalAnimation({
            canvas: canvas,
            container: document.body,

            enabled:
                <?= $loginAnimationEnabled
                    ? 'true'
                    : 'false' ?>,

            style:
                <?= json_encode(
                    $loginAnimationStyle
                ) ?>,

            intensity:
                <?= json_encode(
                    $loginAnimationIntensity
                ) ?>
        });

})();
</script>

</body>
</html>