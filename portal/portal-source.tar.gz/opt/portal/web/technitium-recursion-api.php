<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Technitium recursion proxy. Serves the
 * Recursion tab on the Technitium hub
 * page: the recursion policy and the
 * network ACL used with the specified
 * network ACL policy. The caller must
 * hold the Recursion permission.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

if (
    !hasPermission(
        'Recursion'
    )
) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

function technitiumRecursionCall(
    $path,
    $params = null
) {

    global $TECHNITIUM_HOST, $TECHNITIUM_TOKEN;

    $ch = curl_init(
        'http://' . $TECHNITIUM_HOST
        . ':5380' . $path
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer '
            . $TECHNITIUM_TOKEN
        ],
        CURLOPT_TIMEOUT => 10
    ]);

    if ($params !== null) {
        curl_setopt(
            $ch,
            CURLOPT_POSTFIELDS,
            http_build_query($params)
        );
    }

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    return json_decode($body, true);
}

function recursionView($settings) {

    return [
        'success' => true,
        'recursion' =>
            (string)(
                $settings['recursion']
                ?? 'Deny'
            ),
        'recursion_networks' =>
            is_array(
                $settings[
                    'recursionNetworkACL'
                ]
                ?? null
            )
                ? array_values(
                    $settings[
                        'recursionNetworkACL'
                    ]
                )
                : []
    ];
}

$action =
    $_GET['action']
    ?? ($_POST['action'] ?? '');

if ($action === 'get') {

    $result = technitiumRecursionCall(
        '/api/settings/get'
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Failed to read the Technitium '
                . 'DNS server settings.'
        ]);
        exit;
    }

    echo json_encode(
        recursionView(
            $result['response'] ?? []
        )
    );
    exit;
}

if ($action === 'set') {

    $params = [];

    if (isset($_POST['recursion'])) {

        $recursion =
            (string)$_POST['recursion'];

        if (
            !in_array(
                $recursion,
                [
                    'Deny',
                    'Allow',
                    'AllowOnlyForPrivateNetworks',
                    'UseSpecifiedNetworkACL'
                ],
                true
            )
        ) {
            echo json_encode([
                'success' => false,
                'message' =>
                    'Invalid recursion policy.'
            ]);
            exit;
        }

        $params['recursion'] = $recursion;
    }

    if (
        isset(
            $_POST['recursion_networks']
        )
    ) {

        $networks = array_values(
            array_filter(
                array_map(
                    'trim',
                    explode(
                        "\n",
                        (string)$_POST[
                            'recursion_networks'
                        ]
                    )
                )
            )
        );

        foreach ($networks as $network) {

            $entry = $network;

            if (
                strpos($entry, '!') === 0
            ) {
                $entry = substr($entry, 1);
            }

            $isValid =
                filter_var(
                    $entry,
                    FILTER_VALIDATE_IP
                )
                || preg_match(
                    '/^[0-9a-fA-F:.]+'
                    . '\/\d{1,3}$/',
                    $entry
                );

            if (!$isValid) {
                echo json_encode([
                    'success' => false,
                    'message' =>
                        'Invalid network entry: '
                        . $network
                ]);
                exit;
            }
        }

        $params[
            'recursionNetworkACL'
        ] = $networks === []
            ? 'false'
            : implode(',', $networks);
    }

    if ($params === []) {
        echo json_encode([
            'success' => false,
            'message' => 'Nothing to update.'
        ]);
        exit;
    }

    $result = technitiumRecursionCall(
        '/api/settings/set',
        $params
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'The Technitium DNS server '
                . 'rejected the update.'
        ]);
        exit;
    }

    echo json_encode(
        recursionView(
            $result['response'] ?? []
        )
    );
    exit;
}

echo json_encode([
    'success' => false,
    'message' => 'Unknown action.'
]);
