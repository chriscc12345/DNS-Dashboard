<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (!hasPermission('Theme')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'appearance-theme';
$pageHeading = 'Customization';
$showSidebarPageHeading = true;

$portalSettings =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];


/*
 * UPDATE003 - Basic Theme Editor
 *
 * Theme owns visual identity / colours.
 * Other Appearance pages continue to own assets,
 * layout and behaviour.
 */
$themeSections = [

    'Global' => [
        'theme_basic_page_background'    => 'Page Background',
        'theme_basic_content_background' => 'Content Background',
        'theme_basic_text_primary'       => 'Primary Text',
        'theme_basic_text_secondary'     => 'Secondary Text',
        'theme_basic_border'             => 'Borders / Dividers',
        'theme_basic_accent'             => 'Gold Accent',
        'theme_basic_accent_bright'      => 'Bright Accent',
        'theme_basic_success'            => 'Success',
        'theme_basic_warning'            => 'Warning',
        'theme_basic_error'              => 'Error'
    ],

    'Sidebar' => [
        'theme_basic_sidebar_background_top' =>
            'Background Top',
        'theme_basic_sidebar_background_bottom' =>
            'Background Bottom',
        'theme_basic_sidebar_text' =>
            'Navigation Text',
        'theme_basic_sidebar_icon' =>
            'Navigation Icons',
        'theme_basic_sidebar_hover' =>
            'Hover Background',
        'theme_basic_sidebar_active' =>
            'Active Background',
        'theme_basic_sidebar_active_text' =>
            'Active Text',
        'theme_basic_sidebar_active_accent' =>
            'Active Accent',
        'theme_basic_sidebar_profile_background' =>
            'Profile Background'
    ],

    'Banner' => [
        'theme_basic_banner_fallback' =>
            'Fallback Background',
        'theme_basic_banner_text' =>
            'Primary Text',
        'theme_basic_banner_secondary_text' =>
            'Secondary Text',
        'theme_basic_banner_accent' =>
            'Accent'
    ],

    'Cards & Panels' => [
        'theme_basic_card_background' =>
            'Background',
        'theme_basic_card_background_alt' =>
            'Alternate Background',
        'theme_basic_card_border' =>
            'Border',
        'theme_basic_card_text' =>
            'Text'
    ],

    'Forms' => [
        'theme_basic_input_background' =>
            'Input Background',
        'theme_basic_input_background_readonly' =>
            'Read-only Background',
        'theme_basic_input_text' =>
            'Input Text',
        'theme_basic_input_border' =>
            'Input Border',
        'theme_basic_input_focus' =>
            'Focus Border',
        'theme_basic_input_placeholder' =>
            'Placeholder Text'
    ],

    'Buttons' => [
        'theme_basic_button_primary' =>
            'Primary Background',
        'theme_basic_button_primary_hover' =>
            'Primary Hover',
        'theme_basic_button_primary_text' =>
            'Primary Text',
        'theme_basic_button_secondary' =>
            'Secondary Background',
        'theme_basic_button_secondary_hover' =>
            'Secondary Hover',
        'theme_basic_button_secondary_text' =>
            'Secondary Text'
    ],

    'Tables' => [
        'theme_basic_table_header' =>
            'Header Background',
        'theme_basic_table_row' =>
            'Row Background',
        'theme_basic_table_row_alt' =>
            'Alternate Row',
        'theme_basic_table_hover' =>
            'Row Hover',
        'theme_basic_table_border' =>
            'Border',
        'theme_basic_table_text' =>
            'Text'
    ],

    'Modals' => [
        'theme_basic_modal_background' =>
            'Background',
        'theme_basic_modal_header' =>
            'Header Background',
        'theme_basic_modal_border' =>
            'Border',
        'theme_basic_modal_text' =>
            'Text'
    ],

    'Login' => [
        'theme_basic_login_card_background' =>
            'Card Background',
        'theme_basic_login_text' =>
            'Primary Text',
        'theme_basic_login_secondary_text' =>
            'Secondary Text',
        'theme_basic_login_input_background' =>
            'Input Background',
        'theme_basic_login_input_border' =>
            'Input Border',
        'theme_basic_login_button' =>
            'Button Background',
        'theme_basic_login_button_text' =>
            'Button Text'
    ],

    'Controls' => [
        'theme_basic_control_accent' =>
            'Accent',
        'theme_basic_control_hover' =>
            'Hover',
        'theme_basic_control_focus' =>
            'Focus'
    ]

];

$defaults = [
    'theme_basic_page_background' => '#111c23',
    'theme_basic_content_background' => '#111c23',
    'theme_basic_text_primary' => '#ffffff',
    'theme_basic_text_secondary' => '#aebbc3',
    'theme_basic_border' => '#637681',
    'theme_basic_accent' => '#c79a00',
    'theme_basic_accent_bright' => '#ebc100',
    'theme_basic_success' => '#237a4b',
    'theme_basic_warning' => '#c79a00',
    'theme_basic_error' => '#b83b3b',

    'theme_basic_sidebar_background_top' => '#142330',
    'theme_basic_sidebar_background_bottom' => '#101d28',
    'theme_basic_sidebar_text' => '#ffffff',
    'theme_basic_sidebar_icon' => '#ffffff',
    'theme_basic_sidebar_hover' => '#25333d',
    'theme_basic_sidebar_active' => '#a88400',
    'theme_basic_sidebar_active_text' => '#ffffff',
    'theme_basic_sidebar_active_accent' => '#ebc100',
    'theme_basic_sidebar_profile_background' => '#142330',

    'theme_basic_banner_fallback' => '#18232a',
    'theme_basic_banner_text' => '#ffffff',
    'theme_basic_banner_secondary_text' => '#aebbc3',
    'theme_basic_banner_accent' => '#c79a00',

    'theme_basic_card_background' => '#18232a',
    'theme_basic_card_background_alt' => '#202c34',
    'theme_basic_card_border' => '#637681',
    'theme_basic_card_text' => '#ffffff',

    'theme_basic_input_background' => '#202c34',
    'theme_basic_input_background_readonly' => '#1c272e',
    'theme_basic_input_text' => '#ffffff',
    'theme_basic_input_border' => '#637681',
    'theme_basic_input_focus' => '#db9812',
    'theme_basic_input_placeholder' => '#aebbc3',

    'theme_basic_button_primary' => '#c79a00',
    'theme_basic_button_primary_hover' => '#a88400',
    'theme_basic_button_primary_text' => '#111827',
    'theme_basic_button_secondary' => '#24313a',
    'theme_basic_button_secondary_hover' => '#2b3942',
    'theme_basic_button_secondary_text' => '#ffffff',

    'theme_basic_table_header' => '#18232a',
    'theme_basic_table_row' => '#111c23',
    'theme_basic_table_row_alt' => '#18232a',
    'theme_basic_table_hover' => '#202c34',
    'theme_basic_table_border' => '#637681',
    'theme_basic_table_text' => '#ffffff',

    'theme_basic_modal_background' => '#18232a',
    'theme_basic_modal_header' => '#142330',
    'theme_basic_modal_border' => '#637681',
    'theme_basic_modal_text' => '#ffffff',

    'theme_basic_login_card_background' => '#ffffff',
    'theme_basic_login_text' => '#111827',
    'theme_basic_login_secondary_text' => '#64748b',
    'theme_basic_login_input_background' => '#ffffff',
    'theme_basic_login_input_border' => '#d1d5db',
    'theme_basic_login_button' => '#c79a00',
    'theme_basic_login_button_text' => '#111827',

    'theme_basic_control_accent' => '#c79a00',
    'theme_basic_control_hover' => '#d4af37',
    'theme_basic_control_focus' => '#db9812'
];

function themeColour(
    array $settings,
    array $defaults,
    string $key
): string {

    $value =
        strtolower(
            trim(
                (string)(
                    $settings[$key]
                    ?? $defaults[$key]
                    ?? '#000000'
                )
            )
        );

    if (!preg_match('/^#[0-9a-f]{6}$/', $value)) {
        return $defaults[$key] ?? '#000000';
    }

    return $value;
}

?>
<!DOCTYPE html>
<html>
<head>

    <title>Appearance - Basic Theme</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined"
        rel="stylesheet">

</head>

<body>

<?php include 'includes/banner.php'; ?>
<?php include 'includes/sidebar.php'; ?>


<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>

            <h1>Basic Theme</h1>

            <p>
                Customize the colours used throughout the Basic portal theme.
            </p>

        </div>

        <a
            href="appearance-theme.php"
            class="table-btn appearance-theme-basic-back">

            <span class="material-symbols-outlined">
                arrow_back
            </span>

            Themes

        </a>

    </div>


        <?php include __DIR__ . '/includes/page-tabs.php'; ?>


    <div class="appearance-theme-basic-layout">

        <div class="appearance-theme-basic-editor">

            <?php foreach($themeSections as $sectionName => $fields): ?>

            <section
                class="appearance-panel appearance-theme-basic-section"
                data-theme-section="<?= htmlspecialchars($sectionName) ?>">

                <div class="appearance-panel-heading">

                    <div>

                        <h2>
                            <?= htmlspecialchars($sectionName) ?>
                        </h2>

                        <p>
                            Customize <?= htmlspecialchars(
                                strtolower($sectionName)
                            ) ?> colours.
                        </p>

                    </div>

                    <button
                        type="button"
                        class="table-btn theme-section-reset"
                        data-section="<?= htmlspecialchars($sectionName) ?>">

                        Reset Section

                    </button>

                </div>


                <div class="appearance-theme-colour-grid">

                    <?php foreach($fields as $key => $label): ?>

                    <?php
                        $colour =
                            themeColour(
                                $portalSettings,
                                $defaults,
                                $key
                            );
                    ?>

                    <label
                        class="appearance-theme-colour-row"
                        data-theme-key="<?= htmlspecialchars($key) ?>">

                        <span class="appearance-theme-colour-label">
                            <?= htmlspecialchars($label) ?>
                        </span>

                        <span class="appearance-theme-colour-control">

                            <input
                                type="color"
                                class="theme-colour-picker"
                                value="<?= htmlspecialchars($colour) ?>"
                                data-key="<?= htmlspecialchars($key) ?>">

                            <input
                                type="text"
                                class="theme-colour-hex"
                                value="<?= htmlspecialchars($colour) ?>"
                                maxlength="7"
                                spellcheck="false"
                                autocomplete="off"
                                data-key="<?= htmlspecialchars($key) ?>">

                        </span>

                    </label>

                    <?php endforeach; ?>

                </div>

            </section>

            <?php endforeach; ?>

    
        <div class="appearance-theme-basic-actions">

            <button
                type="button"
                id="resetBasicTheme"
                class="table-btn">

                Reset Basic Theme

            </button>

            <button
                type="button"
                id="saveBasicTheme"
                class="table-btn"
                disabled>

                Save Theme
                <span class="material-symbols-outlined">
                    save
                </span>

            </button>

        </div>

    </div>


        <aside class="appearance-theme-basic-preview-wrap">

            <div class="appearance-panel appearance-theme-basic-preview-panel">

                <div class="appearance-panel-heading">

                    <div>
                        <h2>Live Preview</h2>
                        <p>
                            Preview changes before saving.
                        </p>
                    </div>

                </div>


                <div
                    id="basicThemePreview"
                    class="basic-theme-preview">

                    <div class="basic-theme-preview-sidebar">

                        <div class="basic-theme-preview-avatar"></div>

                        <div class="basic-theme-preview-nav active">
                            Dashboard
                        </div>

                        <div class="basic-theme-preview-nav hover">
                            Users
                        </div>

                        <div class="basic-theme-preview-nav">
                            Groups
                        </div>

                        <div class="basic-theme-preview-nav">
                            Settings
                        </div>

                        <div class="basic-theme-preview-profile">
                            Administrator
                        </div>

                    </div>


                    <div class="basic-theme-preview-main">

                        <div class="basic-theme-preview-banner">

                            <strong>Welcome back</strong>

                            <span>
                                Portal Dashboard
                            </span>

                            <small>
                                Monday · 01:27
                            </small>

                        </div>


                        <div class="basic-theme-preview-content">

                            <div class="basic-theme-preview-status-row">

                                <span class="preview-status success">
                                    Success
                                </span>

                                <span class="preview-status warning">
                                    Warning
                                </span>

                                <span class="preview-status error">
                                    Error
                                </span>

                            </div>


                            <div class="basic-theme-preview-card">

                                <strong>Example Panel</strong>

                                <span>
                                    Primary and secondary content
                                </span>


                                <div class="basic-theme-preview-form-row">

                                    <input
                                        type="text"
                                        value="Example input">

                                    <input
                                        type="text"
                                        value="Read only"
                                        readonly>

                                </div>


                                <input
                                    type="text"
                                    placeholder="Placeholder text">


                                <div class="basic-theme-preview-buttons">

                                    <button
                                        type="button"
                                        class="preview-primary-button">
                                        Primary
                                    </button>

                                    <button
                                        type="button"
                                        class="preview-secondary-button">
                                        Secondary
                                    </button>

                                </div>

                            </div>


                            <div class="basic-theme-preview-card alternate">

                                <div class="basic-theme-preview-table-heading">
                                    <strong>Users Table</strong>
                                    <span>Live table colours</span>
                                </div>

                                <div class="basic-theme-preview-table">

                                    <div class="preview-table-row header">
                                        <span>ID</span>
                                        <span>User</span>
                                        <span>Group</span>
                                        <span>Status</span>
                                    </div>

                                    <div class="preview-table-row">
                                        <span>1</span>
                                        <span>Administrator</span>
                                        <span>Administrators</span>
                                        <span>Active</span>
                                    </div>

                                    <div class="preview-table-row alternate">
                                        <span>7</span>
                                        <span>Operator</span>
                                        <span>Operators</span>
                                        <span>Active</span>
                                    </div>

                                    <div class="preview-table-row hover">
                                        <span>12</span>
                                        <span>Support</span>
                                        <span>Users</span>
                                        <span>Active</span>
                                    </div>

                                </div>

                            </div>


                            <div class="basic-theme-preview-bottom-row">

                                <div class="basic-theme-preview-controls">

                                    <label>
                                        <input
                                            type="checkbox"
                                            checked>
                                        Enabled
                                    </label>

                                    <div class="preview-slider">
                                        <span></span>
                                    </div>

                                </div>


                                <div class="basic-theme-preview-modal">

                                    <div class="preview-modal-header">
                                        Edit User
                                    </div>

                                    <div class="preview-modal-body">
                                        Modal content
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </aside>

    </div>




</div>


<script>

const BASIC_THEME_DEFAULTS =
    <?= json_encode(
        $defaults,
        JSON_UNESCAPED_SLASHES
    ) ?>;


function normalizeThemeHex(value) {

    value =
        String(value || '')
            .trim()
            .toLowerCase();

    return /^#[0-9a-f]{6}$/.test(value)
        ? value
        : null;
}


function refreshBasicThemePreview() {

    const values = {};

    document
        .querySelectorAll('.theme-colour-hex')
        .forEach(input => {

            const normalized =
                normalizeThemeHex(input.value);

            if (normalized) {
                values[input.dataset.key] =
                    normalized;
            }

        });


    const preview =
        document.getElementById(
            'basicThemePreview'
        );

    if (!preview) {
        return;
    }


    preview.style.setProperty(
        '--preview-page',
        values.theme_basic_page_background
            || '#111c23'
    );

    preview.style.setProperty(
        '--preview-content',
        values.theme_basic_content_background
            || '#111c23'
    );

    preview.style.setProperty(
        '--preview-text',
        values.theme_basic_text_primary
            || '#ffffff'
    );

    preview.style.setProperty(
        '--preview-secondary',
        values.theme_basic_text_secondary
            || '#aebbc3'
    );

    preview.style.setProperty(
        '--preview-accent',
        values.theme_basic_accent
            || '#c79a00'
    );

    preview.style.setProperty(
        '--preview-sidebar-top',
        values.theme_basic_sidebar_background_top
            || '#142330'
    );

    preview.style.setProperty(
        '--preview-sidebar-bottom',
        values.theme_basic_sidebar_background_bottom
            || '#101d28'
    );

    preview.style.setProperty(
        '--preview-sidebar-text',
        values.theme_basic_sidebar_text
            || '#ffffff'
    );

    preview.style.setProperty(
        '--preview-sidebar-active',
        values.theme_basic_sidebar_active
            || '#a88400'
    );

    preview.style.setProperty(
        '--preview-banner',
        values.theme_basic_banner_fallback
            || '#18232a'
    );

    preview.style.setProperty(
        '--preview-card',
        values.theme_basic_card_background
            || '#18232a'
    );

    preview.style.setProperty(
        '--preview-border',
        values.theme_basic_card_border
            || '#637681'
    );

    preview.style.setProperty(
        '--preview-input',
        values.theme_basic_input_background
            || '#202c34'
    );

    preview.style.setProperty(
        '--preview-button',
        values.theme_basic_button_primary
            || '#c79a00'
    );

    preview.style.setProperty(
        '--preview-button-text',
        values.theme_basic_button_primary_text
            || '#111827'
    );

    const mappings = {

        '--preview-global-border':
            'theme_basic_border',

        '--preview-success':
            'theme_basic_success',

        '--preview-warning':
            'theme_basic_warning',

        '--preview-error':
            'theme_basic_error',

        '--preview-sidebar-icon':
            'theme_basic_sidebar_icon',

        '--preview-sidebar-hover':
            'theme_basic_sidebar_hover',

        '--preview-sidebar-active-text':
            'theme_basic_sidebar_active_text',

        '--preview-sidebar-active-accent':
            'theme_basic_sidebar_active_accent',

        '--preview-sidebar-profile':
            'theme_basic_sidebar_profile_background',

        '--preview-banner-text':
            'theme_basic_banner_text',

        '--preview-banner-secondary':
            'theme_basic_banner_secondary_text',

        '--preview-banner-accent':
            'theme_basic_banner_accent',

        '--preview-card-alt':
            'theme_basic_card_background_alt',

        '--preview-card-text':
            'theme_basic_card_text',

        '--preview-input-readonly':
            'theme_basic_input_background_readonly',

        '--preview-input-text':
            'theme_basic_input_text',

        '--preview-input-border':
            'theme_basic_input_border',

        '--preview-input-focus':
            'theme_basic_input_focus',

        '--preview-input-placeholder':
            'theme_basic_input_placeholder',

        '--preview-primary-hover':
            'theme_basic_button_primary_hover',

        '--preview-secondary-button':
            'theme_basic_button_secondary',

        '--preview-secondary-hover':
            'theme_basic_button_secondary_hover',

        '--preview-secondary-button-text':
            'theme_basic_button_secondary_text',

        '--preview-table-header':
            'theme_basic_table_header',

        '--preview-table-row':
            'theme_basic_table_row',

        '--preview-table-row-alt':
            'theme_basic_table_row_alt',

        '--preview-table-hover':
            'theme_basic_table_hover',

        '--preview-table-border':
            'theme_basic_table_border',

        '--preview-table-text':
            'theme_basic_table_text',

        '--preview-modal':
            'theme_basic_modal_background',

        '--preview-modal-header':
            'theme_basic_modal_header',

        '--preview-modal-border':
            'theme_basic_modal_border',

        '--preview-modal-text':
            'theme_basic_modal_text',

        '--preview-control':
            'theme_basic_control_accent',

        '--preview-control-hover':
            'theme_basic_control_hover',

        '--preview-control-focus':
            'theme_basic_control_focus'

    };


    Object.entries(mappings).forEach(
        ([property, key]) => {

            if (values[key]) {
                preview.style.setProperty(
                    property,
                    values[key]
                );
            }

        }
    );

}


document
    .querySelectorAll('.theme-colour-picker')
    .forEach(picker => {

        picker.addEventListener(
            'input',
            () => {

                const hex =
                    document.querySelector(
                        '.theme-colour-hex[data-key="' +
                        picker.dataset.key +
                        '"]'
                    );

                if (hex) {
                    hex.value =
                        picker.value.toLowerCase();
                }

                refreshBasicThemePreview();

            }
        );

    });


document
    .querySelectorAll('.theme-colour-hex')
    .forEach(input => {

        input.addEventListener(
            'input',
            () => {

                const normalized =
                    normalizeThemeHex(input.value);

                const picker =
                    document.querySelector(
                        '.theme-colour-picker[data-key="' +
                        input.dataset.key +
                        '"]'
                    );

                if (normalized && picker) {
                    picker.value = normalized;
                }

                refreshBasicThemePreview();

            }
        );

    });


document
    .querySelectorAll('.theme-section-reset')
    .forEach(button => {

        button.addEventListener(
            'click',
            () => {

                const section =
                    button.closest(
                        '.appearance-theme-basic-section'
                    );

                if (!section) {
                    return;
                }

                section
                    .querySelectorAll(
                        '.theme-colour-hex'
                    )
                    .forEach(input => {

                        const defaultValue =
                            BASIC_THEME_DEFAULTS[
                                input.dataset.key
                            ];

                        if (!defaultValue) {
                            return;
                        }

                        input.value =
                            defaultValue;

                        const picker =
                            section.querySelector(
                                '.theme-colour-picker[data-key="' +
                                input.dataset.key +
                                '"]'
                            );

                        if (picker) {
                            picker.value =
                                defaultValue;
                        }

                    });

                refreshBasicThemePreview();

            }
        );

    });


document
    .getElementById('resetBasicTheme')
    .addEventListener(
        'click',
        () => {

            document
                .querySelectorAll(
                    '.theme-colour-hex'
                )
                .forEach(input => {

                    const defaultValue =
                        BASIC_THEME_DEFAULTS[
                            input.dataset.key
                        ];

                    if (!defaultValue) {
                        return;
                    }

                    input.value =
                        defaultValue;

                    const picker =
                        document.querySelector(
                            '.theme-colour-picker[data-key="' +
                            input.dataset.key +
                            '"]'
                        );

                    if (picker) {
                        picker.value =
                            defaultValue;
                    }

                });

            refreshBasicThemePreview();

        }
    );


/*
 * UPDATE003_BASIC_THEME_SAVE
 *
 * Saving is explicit. Preview changes and reset actions remain
 * local until Save Theme is clicked.
 */

const saveBasicThemeButton =
    document.getElementById('saveBasicTheme');

let savedBasicThemeValues = {};


function collectBasicThemeValues(requireValid = false) {

    const values = {};
    let invalidInput = null;

    document
        .querySelectorAll('.theme-colour-hex')
        .forEach(input => {

            const normalized =
                normalizeThemeHex(input.value);

            if (!normalized) {

                if (!invalidInput) {
                    invalidInput = input;
                }

                return;
            }

            values[input.dataset.key] =
                normalized;

        });


    if (requireValid && invalidInput) {

        invalidInput.focus();

        throw new Error(
            'Every theme colour must be a valid HEX value in #RRGGBB format.'
        );
    }


    return values;
}


function captureSavedBasicThemeValues() {

    savedBasicThemeValues =
        collectBasicThemeValues(false);
}


function basicThemeIsDirty() {

    const current =
        collectBasicThemeValues(false);

    const inputs =
        document.querySelectorAll(
            '.theme-colour-hex'
        );

    if (
        Object.keys(current).length
        !== inputs.length
    ) {
        return true;
    }

    return Object.keys(savedBasicThemeValues)
        .some(key =>
            current[key]
            !== savedBasicThemeValues[key]
        );
}


function updateBasicThemeSaveState() {

    if (!saveBasicThemeButton) {
        return;
    }

    saveBasicThemeButton.disabled =
        !basicThemeIsDirty();
}


function showBasicThemeMessage(
    message,
    type = 'success'
) {

    let box =
        document.getElementById(
            'basicThemeMessage'
        );

    if (!box) {

        box =
            document.createElement('div');

        box.id =
            'basicThemeMessage';

        box.className =
            'appearance-theme-message';

        document.body.appendChild(box);
    }


    box.textContent = message;

    box.className =
        'appearance-theme-message ' +
        type +
        ' show';


    clearTimeout(
        showBasicThemeMessage.timer
    );

    showBasicThemeMessage.timer =
        setTimeout(
            () => {
                box.classList.remove('show');
            },
            3200
        );
}


document
    .querySelectorAll(
        '.theme-colour-picker, .theme-colour-hex'
    )
    .forEach(control => {

        control.addEventListener(
            'input',
            updateBasicThemeSaveState
        );

    });


document
    .querySelectorAll('.theme-section-reset')
    .forEach(button => {

        button.addEventListener(
            'click',
            updateBasicThemeSaveState
        );

    });


document
    .getElementById('resetBasicTheme')
    .addEventListener(
        'click',
        updateBasicThemeSaveState
    );


if (saveBasicThemeButton) {

    saveBasicThemeButton.addEventListener(
        'click',
        async () => {

            if (
                saveBasicThemeButton.disabled
            ) {
                return;
            }


            let settings;

            try {

                settings =
                    collectBasicThemeValues(
                        true
                    );

            } catch (error) {

                showBasicThemeMessage(
                    error.message,
                    'error'
                );

                return;
            }


            if (
                Object.keys(settings).length
                !== 59
            ) {

                showBasicThemeMessage(
                    'Theme save stopped: expected 59 Basic theme colours.',
                    'error'
                );

                return;
            }


            const originalText =
                saveBasicThemeButton.innerHTML;

            saveBasicThemeButton.disabled =
                true;

            saveBasicThemeButton.textContent =
                'Saving...';


            try {

                const response =
                    await fetch(
                        'appearance-api.php',
                        {
                            method: 'POST',

                            headers: {
                                'Content-Type':
                                    'application/json'
                            },

                            body: JSON.stringify({
                                action: 'save',
                                settings: settings
                            })
                        }
                    );


                let result = null;

                try {
                    result =
                        await response.json();
                } catch (_) {
                    result = null;
                }


                if (
                    !response.ok
                    ||
                    !result
                    ||
                    result.success !== true
                ) {

                    throw new Error(
                        result?.message
                        || result?.detail
                        || 'Unable to save Basic theme.'
                    );
                }


                const returnedSettings =
                    result.settings
                    || settings;


                document
                    .querySelectorAll(
                        '.theme-colour-hex'
                    )
                    .forEach(input => {

                        const returned =
                            normalizeThemeHex(
                                returnedSettings[
                                    input.dataset.key
                                ]
                            );

                        if (!returned) {
                            return;
                        }

                        input.value =
                            returned;

                        const picker =
                            document.querySelector(
                                '.theme-colour-picker[data-key="' +
                                input.dataset.key +
                                '"]'
                            );

                        if (picker) {
                            picker.value =
                                returned;
                        }

                    });


                refreshBasicThemePreview();

                captureSavedBasicThemeValues();

                updateBasicThemeSaveState();


                showBasicThemeMessage(
                    'Basic theme saved.',
                    'success'
                );

            } catch (error) {

                showBasicThemeMessage(
                    error.message
                    || 'Unable to save Basic theme.',
                    'error'
                );

            } finally {

                saveBasicThemeButton.innerHTML =
                    originalText;

                updateBasicThemeSaveState();
            }

        }
    );

}


captureSavedBasicThemeValues();

refreshBasicThemePreview();

updateBasicThemeSaveState();

</script>

</body>
</html>
