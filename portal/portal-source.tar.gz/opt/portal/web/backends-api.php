<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Network services backend proxy. The Settings
 * -> System Status card polls this endpoint to
 * show backend state and to start provisioning;
 * it forwards to the portal API. The caller must
 * hold the System Status permission.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

if (
    !hasPermission(
        'System Status'
    )
) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

if (
    $_SERVER['REQUEST_METHOD']
    === 'POST'
) {

    $payload =
        json_decode(
            file_get_contents(
                'php://input'
            ),
            true
        ) ?? [];

    $context =
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => json_encode([
                    'backend' =>
                        (string)(
                            $payload['backend']
                            ?? ''
                        ),
                    'appliance_admin_password' =>
                        (string)(
                            $payload['appliance_admin_password']
                            ?? ''
                        )
                ])
            ]
        ]);

    echo @file_get_contents(
        $FASTAPI_URL
        . '/api/backends/select',
        false,
        $context
    );

    exit;
}

echo @file_get_contents(
    $FASTAPI_URL
    . '/api/backends/status'
);
