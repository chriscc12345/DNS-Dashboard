<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (
    !hasPermission(
        'Email Notifications'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'notifications-email';
$pageHeading = 'Communications';
$showSidebarPageHeading = true;

$portalSettings =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];

function savePortalSettings($settings) {

    global $FASTAPI_URL;

    $payload =
        json_encode(
            ['settings' => $settings]
        );

    return file_get_contents(
        $FASTAPI_URL . '/portal-settings/appearance',
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $payload
            ]
        ])
    );
}

if (isset($_POST['save_notifications'])) {

    savePortalSettings([
        'notify_email_host' =>
            trim((string)$_POST['notify_email_host']),
        'notify_email_port' =>
            (string)(int)$_POST['notify_email_port'],
        'notify_email_encryption' =>
            trim((string)$_POST['notify_email_encryption']),
        'notify_email_from' =>
            trim((string)$_POST['notify_email_from']),
        'notify_email_username' =>
            trim((string)$_POST['notify_email_username']),
        'notify_email_password' =>
            (string)$_POST['notify_email_password']
    ]);

    header('Location: notifications-email.php?saved=1');
    exit;
}

$savedMessage = '';

if (($_GET['saved'] ?? '') === '1') {
    $savedMessage = 'Notification settings saved.';
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Notification Channels - Email</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Notification Channels</h1>

            <p>
                Configure how the portal communicates with users.
            </p>
        </div>

    </div>

    <?php if($savedMessage !== ''): ?>

    <div class="settings-saved">
        <?= htmlspecialchars($savedMessage) ?>
    </div>

    <?php endif; ?>

        <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Email Notifications</h2>

                <p>
                    Configure the SMTP server used to send portal email notifications.
                </p>
            </div>

        </div>

        <form method="post" class="settings-form">

            <div class="settings-field-row">

            <div class="settings-field">

                <label for="notify_email_host">
                    SMTP Host
                </label>

                <input
                    type="text"
                    id="notify_email_host"
                    name="notify_email_host"
                    value="<?= htmlspecialchars((string)($portalSettings['notify_email_host'] ?? '')) ?>"
                    class="table-control">

            </div>

            <div class="settings-field">

                <label for="notify_email_port">
                    SMTP Port
                </label>

                <input
                    type="number" step="any"
                    id="notify_email_port"
                    name="notify_email_port"
                    value="<?= htmlspecialchars((string)($portalSettings['notify_email_port'] ?? 587)) ?>"
                    class="table-control">

            </div>

            </div>

            <div class="settings-field-row">

            <div class="settings-field">

                <label for="notify_email_encryption">
                    Encryption
                </label>

                <select
                    id="notify_email_encryption"
                    name="notify_email_encryption"
                    class="table-control">

                    <option
                        value="none"
                        <?= $portalSettings['notify_email_encryption'] ?? 'tls' === 'none' ? 'selected' : '' ?>>
                        None
                    </option>
                    <option
                        value="tls"
                        <?= $portalSettings['notify_email_encryption'] ?? 'tls' === 'tls' ? 'selected' : '' ?>>
                        TLS
                    </option>
                    <option
                        value="ssl"
                        <?= $portalSettings['notify_email_encryption'] ?? 'tls' === 'ssl' ? 'selected' : '' ?>>
                        SSL
                    </option>

                </select>

            </div>

            <div class="settings-field">

                <label for="notify_email_from">
                    From Address
                </label>

                <input
                    type="text"
                    id="notify_email_from"
                    name="notify_email_from"
                    value="<?= htmlspecialchars((string)($portalSettings['notify_email_from'] ?? '')) ?>"
                    class="table-control">

            </div>

            </div>

            <div class="settings-field-row">

            <div class="settings-field">

                <label for="notify_email_username">
                    Username
                </label>

                <input
                    type="text"
                    id="notify_email_username"
                    name="notify_email_username"
                    value="<?= htmlspecialchars((string)($portalSettings['notify_email_username'] ?? '')) ?>"
                    class="table-control">

            </div>

            <div class="settings-field">

                <label for="notify_email_password">
                    Password
                </label>

                <input
                    type="password"
                    id="notify_email_password"
                    name="notify_email_password"
                    value="<?= htmlspecialchars((string)($portalSettings['notify_email_password'] ?? '')) ?>"
                    class="table-control">

            </div>

            </div>

            <p class="appearance-help">
                Credentials for the SMTP server used by portal email notifications. Encryption is usually TLS on port 587 or SSL on port 465.
            </p>

            <button
                type="submit"
                name="save_notifications"
                value="1"
                class="approve-btn">
                Save
            </button>

                    <button
                type="button"
                class="table-btn"
                style="margin-left:10px;"
                onclick="sendTestNotification()">
                Send Test Notification
            </button>

</form>

            <div
                id="testResult"
                style="display:none;
                       margin-top:12px;">
            </div>

            <script>

            function sendTestNotification(){

                var to = '';


                fetch(
                    'notifications-test-api.php',
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type':
                                'application/json'
                        },
                        body: JSON.stringify({
                            channel: 'email',
                            to: to
                        })
                    }
                )
                .then(function(response){
                    return response.json();
                })
                .then(function(data){

                    var box = document
                        .getElementById(
                            'testResult'
                        );

                    box.style.display =
                        'block';

                    box.className =
                        data.success
                            ? 'settings-saved'
                            : 'error-message';

                    box.textContent =
                        data.message
                        || 'No response.';

                })
                .catch(function(){
                    var box = document
                        .getElementById(
                            'testResult'
                        );

                    box.style.display =
                        'block';

                    box.className =
                        'error-message';

                    box.textContent =
                        'The test request failed.';
                });

            }

            </script>


    </div>

</div>
</body>
</html>
