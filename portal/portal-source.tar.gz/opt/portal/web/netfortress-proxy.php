<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Web Proxy and Cache')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-proxy';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Web Proxy and Cache</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;white-space:nowrap}
        .nf-ok{background:var(--theme-basic-success,#237a4b);color:#fff}
        .nf-err{background:var(--theme-basic-error,#b83b3b);color:#fff}
        .nf-warn{background:var(--theme-basic-warning,#c79a00);color:#111827}
        .nf-off{background:var(--theme-basic-button-secondary,#24313a);color:#fff}
        .nf-panel{margin-top:18px;padding:16px;border:1px solid var(--theme-basic-card-border,#637681);border-radius:8px;background:var(--theme-basic-card-background,#18232a);color:var(--theme-basic-card-text,#fff)}
        .nf-panel h3{margin:0 0 6px 0}
        .nf-panel p{margin:0 0 12px 0;font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3)}
        .nf-input{width:200px;padding:6px 10px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:4px;background:var(--theme-basic-input-background,#202c34);color:var(--theme-basic-input-text,#fff);font-size:13px}
        .nf-input-wide{width:420px}
        .nf-btnrow{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
        .nf-form-grid{display:grid;grid-template-columns:220px 1fr;gap:10px 12px;align-items:center;max-width:640px;font-size:14px}
        #nfMsg{margin-top:10px;font-size:13px;display:none}
        #nfMsg.ok{color:var(--theme-basic-success,#237a4b);display:block}
        #nfMsg.err{color:var(--theme-basic-error,#b83b3b);display:block}
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Web proxy and cache - the appliance's Squid proxy
                settings and cache status.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel">

        <h3 style="margin-top:0">Proxy settings</h3>

        <div class="nf-form-grid">
            <label for="nfEnabled">Proxy enabled</label>
            <input type="checkbox" id="nfEnabled">

            <label for="nfPort">Listen port</label>
            <input type="number" class="nf-input" id="nfPort" min="1024" max="65535">

            <label for="nfCacheEnabled">Cache enabled</label>
            <input type="checkbox" id="nfCacheEnabled">

            <label for="nfCacheSize">Cache size (MB)</label>
            <input type="number" class="nf-input" id="nfCacheSize" min="128" max="1048576">

            <label for="nfMemCache">Memory cache (MB)</label>
            <input type="number" class="nf-input" id="nfMemCache" min="16" max="65536">

            <label for="nfMaxObject">Max object size (MB)</label>
            <input type="number" class="nf-input" id="nfMaxObject" min="1" max="10240">
        </div>

        <div class="nf-btnrow" style="margin-top:14px">
            <button type="button" class="approve-btn" id="nfSave">Save settings</button>
        </div>

        <div id="nfMsg"></div>

    </div>

    <div class="nf-panel">
        <h3>Cache status</h3>
        <div id="nfCacheInfo" style="font-size:14px"></div>
        <div class="nf-btnrow" style="margin-top:12px">
            <input type="text" class="nf-input nf-input-wide" id="nfPurgeUrl" placeholder="https://url.to/purge">
            <button type="button" class="deny-btn" id="nfPurge">Purge URL from cache</button>
        </div>
    </div>

</div>

<script>
(function () {

    const message = document.getElementById('nfMsg');
    const cacheInfo = document.getElementById('nfCacheInfo');

    let current = null;
    let lastSignature = null;

    function esc(v) {
        return String(v ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');
    }

    function msg(text, ok) {
        if (!text) { message.className = ''; message.textContent = ''; return; }
        message.className = ok ? 'ok' : 'err';
        message.textContent = text;
    }

    function formatBytes(value) {

        const bytes = Number(value) || 0;

        if (bytes <= 0) { return '0'; }

        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        let index = 0;
        let size = bytes;

        while (size >= 1024 && index < units.length - 1) {
            size /= 1024;
            index += 1;
        }

        return size.toFixed(index ? 1 : 0) + ' ' + units[index];

    }

    function load() {

        fetch('netfortress-api.php?action=proxy')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    lastSignature = null;
                    msg(data.message || 'The appliance is not reachable.', false);
                    return;
                }

                /* Only re-fill the form when the data changed AND nothing
                   is focused - re-writing inputs every poll causes a flash
                   and would wipe in-progress edits. */

                const signature = JSON.stringify(data);

                if (signature === lastSignature) {
                    return;
                }

                if (document.activeElement &&
                    document.querySelector('.appearance-panel').contains(document.activeElement)) {
                    return;
                }

                lastSignature = signature;

                current = data.settings || {};

                document.getElementById('nfEnabled').checked = !!current.enabled;
                document.getElementById('nfPort').value = current.listen_port ?? 3128;
                document.getElementById('nfCacheEnabled').checked = !!current.cache_enabled;
                document.getElementById('nfCacheSize').value = current.cache_size_mb ?? 4096;
                document.getElementById('nfMemCache').value = current.memory_cache_mb ?? 256;
                document.getElementById('nfMaxObject').value = current.max_object_mb ?? 512;

                const cache = data.cache;

                if (cache) {
                    cacheInfo.innerHTML =
                        '<strong>Directory:</strong> ' + esc(cache.cache_directory || '-') +
                        (cache.directory_present
                            ? ' <span class="nf-badge nf-ok">present</span>'
                            : ' <span class="nf-badge nf-warn">missing</span>') +
                        '<br>' +
                        '<strong>Disk:</strong> ' + formatBytes(cache.disk_used_bytes) +
                        ' used of ' + formatBytes(cache.disk_total_bytes) +
                        ' (free: ' + formatBytes(cache.disk_free_bytes) + ')';
                } else {
                    cacheInfo.textContent = 'Cache status is not available.';
                }

            })
            .catch(function () {
                msg('The appliance API is not reachable.', false);
            });

    }

    function post(action, payload, label) {

        msg('Working: ' + label + '...', true);

        fetch('netfortress-api.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    msg(label + ' completed.', true);
                } else {
                    msg(data.message || 'The appliance rejected the request.', false);
                }
                load();
            })
            .catch(function () {
                msg('The appliance API is not reachable.', false);
            });

    }

    document.getElementById('nfSave').addEventListener('click', function () {

        if (!current) {
            msg('Settings not loaded yet.', false);
            return;
        }

        current.enabled = document.getElementById('nfEnabled').checked;
        current.listen_port = parseInt(document.getElementById('nfPort').value, 10) || 3128;
        current.cache_enabled = document.getElementById('nfCacheEnabled').checked;
        current.cache_size_mb = parseInt(document.getElementById('nfCacheSize').value, 10) || 4096;
        current.memory_cache_mb = parseInt(document.getElementById('nfMemCache').value, 10) || 256;
        current.max_object_mb = parseInt(document.getElementById('nfMaxObject').value, 10) || 512;

        post('proxy-set', current, 'Saving proxy settings');

    });

    document.getElementById('nfPurge').addEventListener('click', function () {

        const url = document.getElementById('nfPurgeUrl').value.trim();

        if (!url) {
            msg('Enter a URL to purge.', false);
            return;
        }

        post('cache-purge', { url: url }, 'Purging ' + url);

    });

    load();
    setInterval(load, 30000);

})();
</script>

</body>

</html>
