<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if(
    !hasPermission(
        'HTTPS/SSL'
    )
){
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'https-ssl';
$pageHeading = 'Security';
$showSidebarPageHeading = true;

$portalCertificate = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/ssl/portal"
    ),
    true
);

$portalCertificate = $portalCertificate ?? [];


?>

<!DOCTYPE html>
<html>
<head>
    <title>HTTPS/SSL - Portal Certificate</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
<?php include __DIR__ . '/includes/favicon.php'; ?>

        
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
    
</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

  <div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>HTTPS/SSL</h1>

            <p>
                Manage the certificates securing portal and DNS server access.
            </p>
        </div>

    </div>

        <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel ssl-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Portal Certificate</h2>

                <p>
                    Upload the certificate and configure HTTPS for the portal.
                </p>
            </div>

        </div>

      <div class="ssl-container">
      
          <div class="ssl-upload">
      
              <label>Certificate File</label>
              <input 
                  type="file" 
                  name="certificate"
                  id="portal_certificate">
      
              <br><br>
      
              <label>Private Key File</label>
              <input 
                  type="file" 
                  name="private_key"
                  id="portal_private_key">
      
              <br><br>
      
              <button
                  type="button"
                  class="approve-btn"
                  id="upload_portal_ssl">
                  Upload
              </button>
      
          </div>
      
          <div class="ssl-row">
      
              <table class="ssl-table">
                  <tr>
                      <th>Status</th>
                      <td>                  
                          <span class="<?=
                              ($portalCertificate['status'] ?? '') === 'Configured'
                                  ? 'badge-active'
                                  : 'badge-disabled'
                          ?>">
                              <?= htmlspecialchars(
                                  $portalCertificate['status'] ?? 'Not Configured'
                              ) ?>
                          </span>                  
                      </td>
                  </tr>
                  <tr>
                      <th>Issuer</th>
                      <td>
                          <span class="<?=
                              !empty($portalCertificate['issuer'])
                                  ? 'badge-active'
                                  : 'badge-disabled'
                          ?>">
                              <?= htmlspecialchars(
                                  $portalCertificate['issuer'] ?? 'Not Configured'
                              ) ?>
                          </span>
                      </td>
                  </tr>
                  <tr>
                      <th>Expires</th>
                      <td>
                        <span class="<?=
                            !empty($portalCertificate['expires'])
                                ? 'badge-active'
                                : 'badge-disabled'
                        ?>">
                            <?= htmlspecialchars(
                                $portalCertificate['expires'] ?? 'Not Configured'
                            ) ?>
                        </span>
                      </td>
                  </tr>
                  <tr>
                      <th>HTTPS Status</th>
                      <td>
                          <span class="<?=
                              ($portalCertificate['https_enabled'] ?? false)
                                  ? 'badge-active'
                                  : 'badge-disabled'
                          ?>">
                              <?= ($portalCertificate['https_enabled'] ?? false)
                                  ? 'Enabled'
                                  : 'Disabled' ?>
                          </span>

                      </td>
                  </tr>
                  
                  <tr>
                      <th>HTTPS Port</th>
                      <td>
                          <input
                              type="number"
                              id="https_port"
                              value="<?= htmlspecialchars(
                                  $portalCertificate['https_port'] ?? 443
                              ) ?>"
                              class="table-control"
                          >
                          
                          <button
                              type="button"
                              id="save_https_port"
                              class="approve-btn">
                              Save
                          </button>

                      </td>
                  </tr>
              </table>
      
          </div>
      
      </div> 

    </div>

  </div>
</body>

<script>
document
    .getElementById("save_https_port")
    .addEventListener("click", async () => {

        const port = parseInt(
            document.getElementById("https_port").value
        );

        const response = await fetch(
            "/api/ssl/portal/save",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    https_port: port
                })
            }
        );

        const result = await response.json();

        alert(
            result.success
                ? "HTTPS port updated"
                : result.message
        );
    });

document
    .getElementById("upload_portal_ssl")
    .addEventListener("click", async () => {

        const cert =
            document.getElementById(
                "portal_certificate"
            ).files[0];

        const key =
            document.getElementById(
                "portal_private_key"
            ).files[0];

        if (!cert || !key) {

            alert(
                "Select server.crt and server.key"
            );

            return;
        }

        if (cert.name !== "server.crt") {

            alert(
                "Certificate file must be named server.crt"
            );

            return;
        }

        if (key.name !== "server.key") {

            alert(
                "Private key file must be named server.key"
            );

            return;
        }

        const formData = new FormData();

        formData.append(
            "certificate",
            cert
        );

        formData.append(
            "private_key",
            key
        );

        const response = await fetch(
            "/api/ssl/portal/upload",
            {
                method: "POST",
                body: formData
            }
        );

        const result =
            await response.json();

        if (result.success) {

            alert(
                "Certificate uploaded successfully"
            );

            location.reload();

        } else {

            alert(
                result.message
            );
        }
    });
</script>

</html>
