<?php

require_once 'auth.php';
require_once 'config.php';

if(
    !hasPermission(
        'HTTPS/SSL'
    )
){
    include 'includes/access-denied.php';
    exit;
}

$currentPage = 'https-ssl';

$portalCertificate = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/ssl/portal"
    ),
    true
);

$dnsCertificate = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/ssl/dns"
    ),
    true
);

$portalCertificate = $portalCertificate ?? [];
$dnsCertificate = $dnsCertificate ?? [];

?>

<!DOCTYPE html>
<html>
<head>
    <title>HTTPS/SSL</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
    <link
        rel="icon"
        type="image/png"
        href="images/favicon.png">
        
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
    
</head>

<body>

<div class="banner">
  <img src="images/banner.jpg">
</div>

<?php include 'includes/sidebar.php'; ?>

  <div class="content">
    
    <h1>HTTPS/SSL</h1>
                 
    <div class="settings-section">
        
      <h2>Portal Certificate</h2>
      
      <div class="ssl-container">
      
          <div class="ssl-upload">
      
              <label>Certificate File</label>
              <input 
                  type="file" 
                  name="certificate"
                  id="portal_certificate">
      
              <br><br>
      
              <label>Private Key File</label>
              <input 
                  type="file" 
                  name="private_key"
                  id="portal_private_key">
      
              <br><br>
      
              <button
                  type="button"
                  class="approve-btn"
                  id="upload_portal_ssl">
                  Upload
              </button>
      
          </div>
      
          <div class="ssl-row">
      
              <table class="ssl-table">
                  <tr>
                      <th>Status</th>
                      <td>                  
                          <span class="<?=
                              ($portalCertificate['status'] ?? '') === 'Configured'
                                  ? 'badge-active'
                                  : 'badge-disabled'
                          ?>">
                              <?= htmlspecialchars(
                                  $portalCertificate['status'] ?? 'Not Configured'
                              ) ?>
                          </span>                  
                      </td>
                  </tr>
                  <tr>
                      <th>Issuer</th>
                      <td>
                          <span class="<?=
                              !empty($portalCertificate['issuer'])
                                  ? 'badge-active'
                                  : 'badge-disabled'
                          ?>">
                              <?= htmlspecialchars(
                                  $portalCertificate['issuer'] ?? 'Not Configured'
                              ) ?>
                          </span>
                      </td>
                  </tr>
                  <tr>
                      <th>Expires</th>
                      <td>
                        <span class="<?=
                            !empty($portalCertificate['expires'])
                                ? 'badge-active'
                                : 'badge-disabled'
                        ?>">
                            <?= htmlspecialchars(
                                $portalCertificate['expires'] ?? 'Not Configured'
                            ) ?>
                        </span>
                      </td>
                  </tr>
                  <tr>
                      <th>HTTPS Status</th>
                      <td>
                          <span class="<?=
                              ($portalCertificate['https_enabled'] ?? false)
                                  ? 'badge-active'
                                  : 'badge-disabled'
                          ?>">
                              <?= ($portalCertificate['https_enabled'] ?? false)
                                  ? 'Enabled'
                                  : 'Disabled' ?>
                          </span>

                      </td>
                  </tr>
                  
                  <tr>
                      <th>HTTPS Port</th>
                      <td>
                          <input
                              type="number"
                              id="https_port"
                              value="<?= htmlspecialchars(
                                  $portalCertificate['https_port'] ?? 443
                              ) ?>"
                              class="table-control"
                          >
                          
                          <button
                              type="button"
                              id="save_https_port"
                              class="approve-btn">
                              Save
                          </button>

                      </td>
                  </tr>
              </table>
      
          </div>
      
      </div> 
      </div>              
      <div class="settings-section">
        
      <h2>DNS Server Certificate</h2>
       
      <div class="ssl-container">
      
          <div class="ssl-upload">
      
              <label>Certificate File</label>
              <input
                  type="file"
                  id="dns_certificate">
                  
              <br><br>
              
              <input
                  type="file"
                  id="dns_private_key">
              
              <br><br>
              
              <button
                  type="button"
                  id="upload_dns_ssl"
                  class="approve-btn">
                  Upload
              </button>
      
          </div>
      
          <div class="ssl-row">
      
              <table class="ssl-table">
                  <tr>
                      <th>Status</th>
                      <td>
                          <span class="<?=
                              ($dnsCertificate['status'] ?? '') === 'Configured'
                                  ? 'badge-active'
                                  : 'badge-disabled'
                          ?>">
                              <?= htmlspecialchars(
                                  $dnsCertificate['status'] ?? 'Not Configured'
                              ) ?>
                          </span>
                      </td>
                  </tr>
                  <tr>
                      <th>Issuer</th>
                      <td>
                          <span class="<?=
                              !empty($dnsCertificate['issuer'])
                                  ? 'badge-active'
                                  : 'badge-disabled'
                          ?>">
                              <?= htmlspecialchars(
                                  $dnsCertificate['issuer'] ?? 'Not Configured'
                              ) ?>
                          </span>
                      </td>
                  </tr>
                  <tr>
                      <th>Expires</th>
                      <td>
                          <span class="<?=
                              !empty($dnsCertificate['expires'])
                                  ? 'badge-active'
                                  : 'badge-disabled'
                          ?>">
                              <?= htmlspecialchars(
                                  $dnsCertificate['expires'] ?? 'Not Configured'
                              ) ?>
                          </span>
                      </td>
                  </tr>
                  <tr>
                      <th>HTTPS Status</th>
                        <td>                        
                            <button
                                type="button"
                                id="toggle_dns_https"
                                data-enabled="<?= ($dnsCertificate['https_enabled'] ?? false)
                                    ? 'true'
                                    : 'false' ?>"
                                class="<?=
                                    ($dnsCertificate['https_enabled'] ?? false)
                                        ? 'badge-active'
                                        : 'badge-disabled'
                                ?>">
                                <?= ($dnsCertificate['https_enabled'] ?? false)
                                    ? 'Enabled'
                                    : 'Disabled' ?>
                            </button>                        
                        </td>
                  </tr>
                  
                  <tr>
                      <th>HTTPS Port</th>
                      <td>
                          <input
                              type="number"
                              id="dns_https_port"
                              value="<?= htmlspecialchars(
                                  $dnsCertificate['https_port'] ?? 53443
                              ) ?>"
                              class="table-control">
                          <button
                              type="button"
                              id="save_dns_https_port"
                              class="approve-btn">
                              Save
                          </button>

                      </td>
                  </tr>
              </table>
      
          </div>
      
      </div>  
      </div>
      
      <div class="settings-section">
        
          <h2>Connectivity Status</h2>
          
          <table class="ssl-table">
                <tr>
                    <th>Portal</th>
                      <td>
                          <span class="badge-disabled">
                              Not Configured
                          </span>
                      </td>
                </tr>
                <tr>
                    <th>Technitium</th>
                      <td>
                          <span class="badge-disabled">
                              Not Configured
                          </span>
                      </td>
                </tr>
                <tr>
                    <th>FastAPI</th>
                      <td>
                          <span class="badge-disabled">
                              Not Configured
                          </span>
                      </td>
                </tr>
                <tr>
                    <th>PostgreSQL</th>
                      <td>
                          <span class="badge-disabled">
                              Not Configured
                          </span>
                      </td>
                </tr>
          </table>
      </div>
  </div>
</body>

<script>

document
    .getElementById("save_https_port")
    .addEventListener("click", async () => {

        const port = parseInt(
            document.getElementById("https_port").value
        );

        const response = await fetch(
            "/api/ssl/portal/save",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    https_port: port
                })
            }
        );

        const result = await response.json();

        alert(
            result.success
                ? "HTTPS port updated"
                : result.message
        );
    });
    
document
    .getElementById("upload_portal_ssl")
    .addEventListener("click", async () => {

        const cert =
            document.getElementById(
                "portal_certificate"
            ).files[0];

        const key =
            document.getElementById(
                "portal_private_key"
            ).files[0];

        if (!cert || !key) {

            alert(
                "Select server.crt and server.key"
            );

            return;
        }

        if (cert.name !== "server.crt") {

            alert(
                "Certificate file must be named server.crt"
            );

            return;
        }

        if (key.name !== "server.key") {

            alert(
                "Private key file must be named server.key"
            );

            return;
        }

        const formData = new FormData();

        formData.append(
            "certificate",
            cert
        );

        formData.append(
            "private_key",
            key
        );

        const response = await fetch(
            "/api/ssl/portal/upload",
            {
                method: "POST",
                body: formData
            }
        );

        const result =
            await response.json();

        if (result.success) {

            alert(
                "Certificate uploaded successfully"
            );

            location.reload();

        } else {

            alert(
                result.message
            );
        }
    });
    
document
    .getElementById("upload_dns_ssl")
    .addEventListener("click", async () => {

        const cert =
            document.getElementById(
                "dns_certificate"
            ).files[0];

        const key =
            document.getElementById(
                "dns_private_key"
            ).files[0];

        if (!cert || !key) {

            alert(
                "Select server.crt and server.key"
            );

            return;
        }

        if (cert.name !== "server.crt") {

            alert(
                "Certificate file must be named server.crt"
            );

            return;
        }

        if (key.name !== "server.key") {

            alert(
                "Private key file must be named server.key"
            );

            return;
        }

        const formData = new FormData();

        formData.append(
            "certificate",
            cert
        );

        formData.append(
            "private_key",
            key
        );

        const response = await fetch(
            "/api/ssl/dns/upload",
            {
                method: "POST",
                body: formData
            }
        );

        const result =
            await response.json();

        if (result.success) {

            alert(
                "DNS certificate uploaded successfully"
            );

            location.reload();

        } else {

            alert(
                result.message
            );
        }
    });
    
document
    .getElementById("save_dns_https_port")
    .addEventListener("click", async () => {

        const port = parseInt(
            document.getElementById(
                "dns_https_port"
            ).value
        );

        const response = await fetch(
            "/api/ssl/dns/save",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    https_port: port
                })
            }
        );

        const result =
            await response.json();

        alert(
            result.success
                ? "DNS HTTPS port updated"
                : result.message
        );

        if (result.success) {
            location.reload();
        }
    });
    
document
    .getElementById("toggle_dns_https")
    .addEventListener("click", async () => {

        const button =
            document.getElementById(
                "toggle_dns_https"
            );

        const currentState =
            button.dataset.enabled === "true";

        const response = await fetch(
            "/api/ssl/dns/https",
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/json"
                },
                body: JSON.stringify({
                    enabled: !currentState
                })
            }
        );

        const result =
            await response.json();

        if (result.success) {

            location.reload();

        } else {

            alert(
                result.message ||
                "Failed to update HTTPS status"
            );
        }
    });
</Script>

</html>