<?php

require_once 'auth.php';
require_once 'config.php';

if(
    !hasPermission(
        'Deny Requests'
    )
){
    include 'includes/access-denied.php';
    exit;
}

$currentPage = 'denied';

if (isset($_POST['allow'])) {

    $id = intval($_POST['id']);
    $type = $_POST['allow_type'];
    $duration = intval($_POST['duration']);

    $data = json_encode([
        'allow_type' => $type,
        'duration' => $duration
    ]);

    $url = $FASTAPI_URL . "/allow/" . $id;

    $result = file_get_contents(
        $url,
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: denied.php");
    exit;

}

$json = file_get_contents(
    $FASTAPI_URL . "/denied"
);

$requests = json_decode($json, true);

$search = isset($_GET['search'])
    ? strtolower(trim($_GET['search']))
    : '';

if($search !== ''){

    $requests = array_filter(
        $requests,
        function($row) use ($search){

            return strpos(
                strtolower(
                    implode(' ', $row)
                ),
                $search
            ) !== false;

        }
    );

}

$totalRecords = count($requests);

$perPage = isset($_GET['per_page'])
    ? $_GET['per_page']
    : 10;

$page = isset($_GET['page'])
    ? max(1, intval($_GET['page']))
    : 1;

$totalPages = 1;

$showingFrom = $totalRecords > 0 ? 1 : 0;
$showingTo = $totalRecords;

if($perPage !== 'all'){

    $totalPages = ceil(
        $totalRecords / intval($perPage)
    );

    $offset =
        ($page - 1) * intval($perPage);

    $requests = array_slice(
        $requests,
        $offset,
        intval($perPage)
    );

    $showingFrom = $totalRecords > 0
        ? $offset + 1
        : 0;

    $showingTo = min(
        $offset + intval($perPage),
        $totalRecords
    );
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Denied Requests</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
    <link
        rel="icon"
        type="image/png"
        href="images/favicon.png">
        
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
    
</head>


<body>

<div class="banner">
  <img src="images/banner.jpg">
</div>

<?php include 'includes/sidebar.php'; ?>



<div class="content">

        <h1>Denied Requests</h1>
                
        <div class="table-controls">
        
            <div class="table-controls-right">
        
                <form method="get">
              
                    <input
                        type="text"
                        placeholder="Search Here"
                        class="table-control"
                        name="search"
                        value="<?= htmlspecialchars($search) ?>">
        
        
                        <select 
                            name="per_page"
                            class="table-control">
                        
                            <option value="10"
                                <?= $perPage == 10 ? 'selected' : '' ?>>
                                10
                            </option>
                        
                            <option value="25"
                                <?= $perPage == 25 ? 'selected' : '' ?>>
                                25
                            </option>
                        
                            <option value="50"
                                <?= $perPage == 50 ? 'selected' : '' ?>>
                                50
                            </option>
                        
                            <option value="100"
                                <?= $perPage == 100 ? 'selected' : '' ?>>
                                100
                            </option>
                        
                            <option value="all"
                                <?= $perPage == 'all' ? 'selected' : '' ?>>
                                All
                            </option>
                        
                        </select>
        
                        <button 
                            type="submit"
                            class="table-btn">
                            Search
                        </button>
                        
                        <a href="denied.php" class="clear-btn">
                            Clear
                        </a>
                </form>
               
            </div>
        
        </div>
        
        <table>
        
        <tr>
            <th>ID</th>
            <th>Domain</th>
            <th>Client IP</th>
            <th>Block Type</th>
            <th>Blocked At</th>
            <th>Action</th>
        
            
        </tr>
        
        <?php foreach($requests as $row): ?>
        
        <tr>
        
            <td><?= htmlspecialchars($row[0]) ?></td>
            <td><?= htmlspecialchars($row[1]) ?></td>
            <td><?= htmlspecialchars($row[2]) ?></td>
            <td>
            <?=
                htmlspecialchars(
                    !empty($row[6])
                        ? $row[6]
                        : ($row[3] ?? '-')
                )
            ?>
            </td>
            <td>
            <?php
            if (!empty($row[5])) {
                echo date('d M Y H:i', strtotime($row[5]));
            } else {
                echo "-";
            }
            ?>
            </td>
            <td>
            
                <form method="post">
            
                    <input
                        type="hidden"
                        name="id"
                        value="<?= $row[0] ?>">
            
                    <button
                        type="button"
                        class="approve-btn"
                        onclick="openAllowModal(<?= $row[0] ?>)">
                    
                        Allow
                    
                    </button>
            
                </form>
            
            </td>
        
            
        
        </tr>
        
        <?php endforeach; ?>
        
        </table>
                
        <div class="table-summary">
             Total Records:
             <strong><?= $totalRecords ?></strong>
        </div>
        
        <div id="allowModal" class="modal">

            <div class="modal-content">
        
                <h3>Allow Access</h3>
        
                <form method="post">
        
                    <input
                        type="hidden"
                        id="allowRequestId"
                        name="id">
        
                    <label>
        
                        <input
                            type="radio"
                            name="allow_type"
                            value="permanent"
                            checked
                            onchange="toggleDuration()">
                        
                        Permanent
        
                    </label>
        
                    <br><br>
        
                    <label>
        
                        <input
                            type="radio"
                            name="allow_type"
                            value="timed"
                            onchange="toggleDuration()">
                            
                        Timed
        
                    </label>
        
                    <br><br>
        
                    <div id="durationContainer">
                    
                        <select
                            name="duration"
                            id="durationSelect">
                    
                            <option value="15">15 Minutes</option>
                            <option value="30">30 Minutes</option>
                            <option value="60">1 Hour</option>
                            <option value="240">4 Hours</option>
                            <option value="1440">24 Hours</option>
                    
                        </select>
                    
                    </div>
        
                    <br><br>
        
                    <button
                        type="submit"
                        name="allow"
                        class="approve-btn">
        
                        Confirm
        
                    </button>
        
                    <button
                        type="button"
                        class="deny-btn"
                        onclick="closeAllowModal()">
        
                        Cancel
        
                    </button>
        
                </form>
        
            </div>
        
        </div>
        
        <script>
        
        const ws = new WebSocket(
            `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`
        );
        
        ws.onmessage = function(event){
        
            if(event.data === "refresh"){
        
                location.reload();
        
            }
        
        };
        
        </script>
        <script>

        function openAllowModal(id){
        
            document
                .getElementById('allowRequestId')
                .value = id;
        
            document
                .getElementById('allowModal')
                .style.display = 'flex';
        
        }
        
        function closeAllowModal(){
        
            document
                .getElementById('allowModal')
                .style.display = 'none';
        
        }
        
        function toggleDuration(){

                const timed =
                    document.querySelector(
                        'input[value="timed"]'
                    ).checked;
            
                document
                    .getElementById('durationContainer')
                    .style.display =
                        timed ? 'block' : 'none';
            
            }
            
            document
                .querySelectorAll(
                    'input[name="allow_type"]'
                )
                .forEach(radio => {
            
                    radio.addEventListener(
                        'change',
                        toggleDuration
                    );
            
                });
            
            toggleDuration();
        
        </script>
</div>
</body>
</html>