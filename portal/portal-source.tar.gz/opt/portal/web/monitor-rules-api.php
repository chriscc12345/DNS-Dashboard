<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Monitor channel rules proxy. The browser
 * calls this endpoint from the channel pages
 * (monitor-<channel>.php); it forwards the
 * request to the portal API which performs
 * the real rule changes. The caller must
 * hold the Notification Channel permission -
 * the same permission that gates the rules
 * UI - so direct POSTs cannot bypass it.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

if (
    $_SERVER['REQUEST_METHOD'] !== 'POST'
) {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'POST required.'
    ]);
    exit;
}

if (
    !hasPermission(
        'Notification Channel'
    )
) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

$body = json_decode(
    (string)file_get_contents(
        'php://input'
    ),
    true
) ?? [];

$action =
    trim(
        (string)($body['action'] ?? '')
    );

$payload = [
    'notification_channel' =>
        trim(
            (string)(
                $body['notification_channel']
                ?? ''
            )
        ),
    'rule_function' =>
        trim(
            (string)(
                $body['rule_function']
                ?? 'Login Notification'
            )
        ),
    'notification_type' =>
        trim(
            (string)(
                $body['notification_type']
                ?? ''
            )
        ),
    'target_username' =>
        trim(
            (string)(
                $body['target_username']
                ?? ''
            )
        ),
    'login_custom_message' =>
        trim(
            (string)(
                $body['login_custom_message']
                ?? ''
            )
        ),
    'failed_custom_message' =>
        trim(
            (string)(
                $body['failed_custom_message']
                ?? ''
            )
        ),
    'logout_custom_message' =>
        trim(
            (string)(
                $body['logout_custom_message']
                ?? ''
            )
        )
];

$path = '';

if ($action === 'create') {

    $path =
        '/monitor/login-notifications/create';

    // New rules always start enabled -
    // the popup has no enabled field.

    $payload['enabled'] = true;

} elseif ($action === 'update') {

    $ruleId =
        (int)(
            $body['rule_id'] ?? 0
        );

    $path =
        '/monitor/login-notifications/'
        . $ruleId
        . '/update';

    $payload['enabled'] =
        (($body['enabled'] ?? '') === true)
            || (($body['enabled'] ?? '') === '1');

} elseif ($action === 'delete') {

    $ruleId =
        (int)(
            $body['rule_id'] ?? 0
        );

    $path =
        '/monitor/login-notifications/'
        . $ruleId
        . '/delete';

    $payload = [];

} else {

    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Unknown action.'
    ]);
    exit;

}

$response =
    @file_get_contents(
        $FASTAPI_URL . $path,
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  =>
                    "Content-Type: application/json\r\n",
                'content' => json_encode($payload)
            ]
        ])
    );

if ($response === false) {
    http_response_code(502);
    echo json_encode([
        'success' => false,
        'message' =>
            'The portal API did not '
            . 'respond.'
    ]);
    exit;
}

echo $response;
