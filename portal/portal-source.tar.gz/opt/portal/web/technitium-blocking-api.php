<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Technitium blocking settings proxy.
 * The Blocking tab talks to this
 * endpoint; it forwards only the five
 * whitelisted settings to the Technitium
 * DNS server API using the portal token.
 * The caller must hold the Blocking
 * permission.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

if (
    !hasPermission(
        'Blocking'
    )
) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

function technitiumBlockingCall(
    $path,
    $params = null
) {

    global $TECHNITIUM_HOST, $TECHNITIUM_TOKEN;

    $ch = curl_init(
        'http://' . $TECHNITIUM_HOST
        . ':5380' . $path
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer '
            . $TECHNITIUM_TOKEN
        ],
        CURLOPT_TIMEOUT => 10
    ]);

    if ($params !== null) {
        curl_setopt(
            $ch,
            CURLOPT_POSTFIELDS,
            http_build_query($params)
        );
    }

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    return json_decode($body, true);
}

function blockingView($settings) {

    return [
        'success' => true,
        'enable_blocking' =>
            (bool)(
                $settings['enableBlocking']
                ?? false
            ),
        'blocking_type' =>
            (string)(
                $settings['blockingType']
                ?? 'NxDomain'
            ),
        'block_list_urls' =>
            is_array(
                $settings['blockListUrls']
                ?? null
            )
                ? array_values(
                    $settings['blockListUrls']
                )
                : [],
        'block_list_update_interval_hours' =>
            (int)(
                $settings[
                    'blockListUpdateIntervalHours'
                ]
                ?? 24
            ),
        'block_list_next_updated_on' =>
            $settings['blockListNextUpdatedOn']
            ?? null,
        'custom_blocking_addresses' =>
            is_array(
                $settings['customBlockingAddresses']
                ?? null
            )
                ? array_values(
                    $settings[
                        'customBlockingAddresses'
                    ]
                )
                : []
    ];
}

$action =
    $_GET['action']
    ?? (
        $_POST['action']
        ?? (
            ($_SERVER['REQUEST_METHOD'] ?? '')
            === 'POST'
                ? 'set'
                : ''
        )
    );

if ($action === 'get') {

    $result = technitiumBlockingCall(
        '/api/settings/get'
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Failed to read the Technitium '
                . 'DNS server settings.'
        ]);
        exit;
    }

    echo json_encode(
        blockingView(
            $result['response'] ?? []
        )
    );
    exit;
}

if ($action === 'set') {

    $params = [];

    if (isset($_POST['enable_blocking'])) {

        $params['enableBlocking'] =
            in_array(
                (string)$_POST['enable_blocking'],
                ['true', '1', 'on'],
                true
            )
                ? 'true'
                : 'false';
    }

    if (isset($_POST['blocking_type'])) {

        $type =
            (string)$_POST['blocking_type'];

        if (
            !in_array(
                $type,
                [
                    'AnyAddress',
                    'NxDomain',
                    'CustomAddress'
                ],
                true
            )
        ) {
            echo json_encode([
                'success' => false,
                'message' =>
                    'Invalid blocking type.'
            ]);
            exit;
        }

        $params['blockingType'] = $type;
    }

    if (isset($_POST['block_list_urls'])) {

        $urls = array_values(
            array_filter(
                array_map(
                    'trim',
                    explode(
                        "\n",
                        (string)$_POST['block_list_urls']
                    )
                )
            )
        );

        $params['blockListUrls'] =
            $urls === []
                ? 'false'
                : implode(',', $urls);
    }

    if (
        isset(
            $_POST['custom_blocking_addresses']
        )
    ) {

        $addresses = array_values(
            array_filter(
                array_map(
                    'trim',
                    explode(
                        "\n",
                        (string)$_POST[
                            'custom_blocking_addresses'
                        ]
                    )
                )
            )
        );

        foreach ($addresses as $address) {

            if (
                !filter_var(
                    $address,
                    FILTER_VALIDATE_IP
                )
            ) {
                echo json_encode([
                    'success' => false,
                    'message' =>
                        'Invalid custom '
                        . 'blocking address: '
                        . $address
                ]);
                exit;
            }
        }

        $params[
            'customBlockingAddresses'
        ] = implode(',', $addresses);
    }

    if (
        isset(
            $_POST[
                'block_list_update_interval_hours'
            ]
        )
    ) {

        $hours = (int)(
            $_POST[
                'block_list_update_interval_hours'
            ]
        );

        if (
            $hours < 0
            || $hours > 168
        ) {
            echo json_encode([
                'success' => false,
                'message' =>
                    'Update interval must be '
                    . 'between 0 and 168 hours.'
            ]);
            exit;
        }

        $params[
            'blockListUpdateIntervalHours'
        ] = (string)$hours;
    }

    if ($params === []) {
        echo json_encode([
            'success' => false,
            'message' => 'Nothing to update.'
        ]);
        exit;
    }

    $result = technitiumBlockingCall(
        '/api/settings/set',
        $params
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'The Technitium DNS server '
                . 'rejected the update.'
        ]);
        exit;
    }

    echo json_encode(
        blockingView(
            $result['response'] ?? []
        )
    );
    exit;
}

if ($action === 'force_update') {

    $result = technitiumBlockingCall(
        '/api/settings/forceUpdateBlockLists'
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'The Technitium DNS server '
                . 'failed to start the update.'
        ]);
        exit;
    }

    $fresh = technitiumBlockingCall(
        '/api/settings/get'
    );

    if (
        $fresh === null
        || ($fresh['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Block lists update started but '
                . 'the settings could not be '
                . 're-read.'
        ]);
        exit;
    }

    echo json_encode(
        blockingView(
            $fresh['response'] ?? []
        )
    );
    exit;
}

echo json_encode([
    'success' => false,
    'message' => 'Unknown action.'
]);
