<?php

require_once 'auth.php';
require_once 'config.php';

/* The page carries all of its board
   logic inline, so the browser must
   always revalidate it. */

header(
    'Cache-Control: no-cache, '
    . 'must-revalidate'
);

if (
    !hasPermission(
        'Monitor'
    )
    && !hasPermission(
        'View Monitor'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentPage = 'monitor';

/*
 * Dashboard request stats for the
 * initial render; the page keeps
 * them fresh with /api/stats.
 */

$monitorStats = [
    'pending' => 0,
    'approved' => 0,
    'denied' => 0
];

$monitorStatsJson =
    @file_get_contents(
        $FASTAPI_URL . '/stats'
    );

if ($monitorStatsJson !== false) {

    $monitorStatsDecoded =
        json_decode(
            $monitorStatsJson,
            true
        );

    if (is_array($monitorStatsDecoded)) {
        $monitorStats =
            array_merge(
                $monitorStats,
                $monitorStatsDecoded
            );
    }
}

/*
 * Clock time zone and weather
 * location, the same settings
 * the banner clock uses.
 */

$monitorSettings = [];

$monitorSettingsJson =
    @file_get_contents(
        $FASTAPI_URL . '/portal-settings'
    );

if ($monitorSettingsJson !== false) {

    $monitorSettingsDecoded =
        json_decode(
            $monitorSettingsJson,
            true
        );

    if (is_array($monitorSettingsDecoded)) {
        $monitorSettings =
            $monitorSettingsDecoded;
    }
}

$monitorTimezone =
    trim(
        (string)(
            $monitorSettings['portal_timezone']
            ?? ''
        )
    );

$monitorLatitude =
    trim(
        (string)(
            $monitorSettings['weather_latitude']
            ?? '-26.2041'
        )
    );

$monitorLongitude =
    trim(
        (string)(
            $monitorSettings['weather_longitude']
            ?? '28.0473'
        )
    );

/*
 * Board background: an optional
 * colour and image kept in the
 * portal settings.
 */

$monitorBgColor =
    trim(
        (string)(
            $monitorSettings['monitor_background_color']
            ?? ''
        )
    );

$monitorBgImage =
    trim(
        (string)(
            $monitorSettings['monitor_background_image']
            ?? ''
        )
    );

$monitorCardBackground =
    trim(
        (string)(
            $monitorSettings['monitor_card_background']
            ?? ''
        )
    );

/*
 * Card transparency: one value for
 * every card on the board. 0 is a
 * solid card, 100 is fully
 * see-through. 12 matches the old
 * default look.
 */

$monitorCardOpacity =
    (int)(
        $monitorSettings['monitor_card_opacity']
        ?? 12
    );

$monitorCardOpacity =
    max(
        0,
        min(
            100,
            $monitorCardOpacity
        )
    );

$monitorCardBase =
    preg_match(
        '/^#[0-9a-fA-F]{6}$/',
        $monitorCardBackground
    )
        ? $monitorCardBackground
        : '#1e2a33';

$monitorCardAlpha =
    round(
        (100 - $monitorCardOpacity)
        / 100,
        2
    );

$monitorCardBgCss =
    'rgba('
    . hexdec(
        substr(
            $monitorCardBase,
            1,
            2
        )
    )
    . ','
    . hexdec(
        substr(
            $monitorCardBase,
            3,
            2
        )
    )
    . ','
    . hexdec(
        substr(
            $monitorCardBase,
            5,
            2
        )
    )
    . ','
    . $monitorCardAlpha
    . ')';

/*
 * Table styling: the header colour,
 * the alternate row colour and the
 * grid line colour, one shared
 * transparency, plus a page text
 * colour. Everything is optional;
 * empty settings keep the designed
 * defaults.
 */

$monitorTableColor =
    trim(
        (string)(
            $monitorSettings['monitor_table_color']
            ?? ''
        )
    );

$monitorTableAltColor =
    trim(
        (string)(
            $monitorSettings['monitor_table_alt_color']
            ?? ''
        )
    );

$monitorTableGridColor =
    trim(
        (string)(
            $monitorSettings['monitor_table_grid_color']
            ?? ''
        )
    );

$monitorTableGridEnabled =
    trim(
        (string)(
            $monitorSettings[
                'monitor_table_grid_enabled'
            ]
            ?? '1'
        )
    ) !== '0';

$monitorTextColor =
    trim(
        (string)(
            $monitorSettings['monitor_text_color']
            ?? ''
        )
    );

$monitorTableOpacity =
    (int)(
        $monitorSettings['monitor_table_opacity']
        ?? 100
    );

$monitorTableOpacity =
    max(
        0,
        min(
            100,
            $monitorTableOpacity
        )
    );

$monitorTableAlpha =
    round(
        (100 - $monitorTableOpacity)
        / 100,
        2
    );

$monitorHexOk =
    fn($hex) =>
        is_string($hex)
        && preg_match(
            '/^#[0-9a-fA-F]{6}$/',
            $hex
        ) === 1;

$monitorCardVars =
    '--monitor-card-background: '
    . $monitorCardBgCss
    . ';';

/* the table colours are always emitted so the
   transparency slider alone changes the table:
   unset colours fall back to white */

$monitorTableBase =
    $monitorHexOk($monitorTableColor)
        ? $monitorTableColor
        : '#ffffff';

$monitorTableAltBase =
    $monitorHexOk($monitorTableAltColor)
        ? $monitorTableAltColor
        : '#ffffff';

$monitorCardVars .=
    '--monitor-table-bg: rgba('
    . hexdec(
        substr(
            $monitorTableBase,
            1,
            2
        )
    )
    . ','
    . hexdec(
        substr(
            $monitorTableBase,
            3,
            2
        )
    )
    . ','
    . hexdec(
        substr(
            $monitorTableBase,
            5,
            2
        )
    )
    . ','
    . $monitorTableAlpha
    . ');';

$monitorCardVars .=
    '--monitor-table-alt: rgba('
    . hexdec(
        substr(
            $monitorTableAltBase,
            1,
            2
        )
    )
    . ','
    . hexdec(
        substr(
            $monitorTableAltBase,
            3,
            2
        )
    )
    . ','
    . hexdec(
        substr(
            $monitorTableAltBase,
            5,
            2
        )
    )
    . ','
    . $monitorTableAlpha
    . ');';

if ($monitorHexOk($monitorTableGridColor)) {

    $monitorCardVars .=
        '--monitor-table-grid: '
        . $monitorTableGridColor
        . ';';
}

$monitorCardAttr = '';

$monitorCardStylesRaw =
    (string)(
        $monitorSettings[
            'monitor_card_styles'
        ]
        ?? '{}'
    );

if ($monitorHexOk($monitorTextColor)) {

    $monitorCardVars .=
        '--monitor-text: '
        . $monitorTextColor
        . ';';

    $monitorCardAttr =
        ' data-text-set="1"';
}

$monitorBgStyle = '';

if ($monitorBgImage !== '') {

    $monitorBgStyle .=
        'background-image: url('
        . htmlspecialchars(
            $monitorBgImage
        )
        . ') !important; '
        . 'background-size: cover !important; '
        . 'background-position: '
        . 'center !important; '
        . 'background-repeat: '
        . 'no-repeat !important; ';
}

if ($monitorBgColor !== '') {

    $monitorBgStyle .=
        'background-color: '
        . htmlspecialchars(
            $monitorBgColor
        )
        . ' !important; ';
}

$monitorBgStyle =
    trim($monitorBgStyle);

/*
 * The connectivity widget is only
 * offered to viewers who may see
 * the connectivity status.
 */

$monitorCanConnectivity =
    hasPermission(
        'Connectivity Status'
    );

/*
 * The DNS graph and top users
 * widgets are only offered to
 * viewers who may see the
 * Technitium server.
 */

$monitorBackendCapabilities =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL
            . '/api/backends/capabilities'
        ),
        true
    ) ?? [];

$monitorCanTechnitium =
    hasPermission(
        'Technitium'
    )
    && (
        (string)(
            $monitorBackendCapabilities['provider']
            ?? ''
        )
        === 'technitium'
    );

/*
 * The unblock queue widget is
 * only offered to viewers who
 * may work the pending request
 * queue.
 */

$monitorCanPending =
    hasPermission(
        'Pending Requests'
    );

/*
 * The login feed and live
 * activity widgets are only
 * offered to viewers who may
 * see user management.
 */

$monitorCanUsers =
    hasPermission(
        'User Management'
    );

/*
 * Viewing the board and editing
 * the board are separate
 * permissions: a viewer only
 * ever sees the finished wall.
 */

$monitorCanEdit =
    hasPermission(
        'Edit Monitor'
    );

?>
<!DOCTYPE html>
<html>
<head>
    <title>Monitor</title>

    <link
        rel="stylesheet"
        href="css/style.css?v=<?= filemtime(
            __DIR__ . '/css/style.css'
        ) ?>">

<?php
/*
 * Theme runtime variables: the theme css
 * rules use --theme-basic-* variables that
 * the banner and sidebar normally render.
 * This page has neither, so include the
 * shared theme block here.
 */

$basicThemeSettings = $monitorSettings;
include __DIR__ . '/includes/basic-theme.php';
?>

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body
    class="monitor-page">

<div class="monitor-shell">

    <div
        class="monitor-card<?= $monitorTableGridEnabled
            ? ''
            : ' hide-table-grid'
        ?>"
        style="<?= htmlspecialchars(
            $monitorCardVars
        ) ?>"<?= $monitorCardAttr ?>>

        <div class="monitor-topbar">

            <a
                href="dashboard.php"
                class="monitor-back-btn">
                <span
                    class="material-symbols-outlined">
                    arrow_back
                </span>
                <span class="monitor-back-text">
                    Back
                </span>
            </a>

            <div class="monitor-title">
                Monitor
            </div>

            <?php if ($monitorCanEdit): ?>

            <button
                type="button"
                class="monitor-edit-btn"
                id="monitorToolbarToggle"
                title="Open the controls in a floating window">
                <span
                    class="material-symbols-outlined">
                    tune
                </span>
                Controls
            </button>

            <button
                type="button"
                class="monitor-edit-btn"
                id="monitorEditBtn">
                <span
                    class="material-symbols-outlined">
                    edit
                </span>
                <span
                    class="monitor-edit-label">
                    Edit Board
                </span>
            </button>

            <?php endif; ?>

            <div class="monitor-topbar-spacer"></div>

        </div>

        <?php if ($monitorCanEdit): ?>

        <div
            class="monitor-view-hint"
            id="monitorViewHint"
            hidden>
            Double-click the board to edit it
        </div>

        <?php endif; ?>

        <?php if ($monitorCanEdit): ?>

        <div
            class="monitor-palette"
            hidden>

            <div
                class="monitor-palette-drag">
                <span
                    class="material-symbols-outlined">
                    drag_indicator
                </span>
                Controls
            </div>

            <div
                class="monitor-slider-wrap
                    monitor-slides-row">

                <button
                    type="button"
                    class="monitor-reset-btn"
                    id="monitorSlidePrev"
                    title="Previous slide">
                    &lsaquo;
                </button>

                <span
                    class="monitor-slider-label"
                    id="monitorSlideLabel">
                    Slide 1
                </span>

                <button
                    type="button"
                    class="monitor-reset-btn"
                    id="monitorSlideNext"
                    title="Next slide">
                    &rsaquo;
                </button>

                <button
                    type="button"
                    class="monitor-reset-btn"
                    id="monitorSlideAdd"
                    title="Add a new empty slide">
                    +
                </button>

                <button
                    type="button"
                    class="monitor-reset-btn"
                    id="monitorSlideDel"
                    title="Delete this slide">
                    Delete
                </button>

                <span
                    class="monitor-slider-label">
                    Rotate
                </span>

                <input
                    type="number"
                    min="0"
                    max="600"
                    step="5"
                    class="monitor-rotate-input"
                    id="monitorRotateInput"
                    title="Seconds per slide in view mode; 0 = off">

                <span
                    class="monitor-slider-label">
                    s
                </span>

            </div>

            <span class="monitor-palette-hint">
                Click a chip to add or remove
                its card — drag cards to move,
                drag a corner to resize
            </span>

            <button
                type="button"
                class="monitor-reset-btn"
                id="monitorResetBtn"
                title="Remove every card from the board">
                Clear Board
            </button>

            <input
                type="color"
                class="monitor-bg-color"
                id="monitorBgColor"
                title="Board background colour"
                value="<?= htmlspecialchars(
                    $monitorBgColor !== ''
                        ? $monitorBgColor
                        : '#10161c'
                ) ?>">

            <input
                type="color"
                class="monitor-bg-color"
                id="monitorCardColor"
                title="Card background colour"
                value="<?= htmlspecialchars(
                    $monitorCardBackground !== ''
                        ? $monitorCardBackground
                        : '#1e2a33'
                ) ?>">

            <div
                class="monitor-slider-wrap">
                <span
                    class="monitor-slider-label">
                    Transparency
                </span>
                <input
                    type="range"
                    min="0"
                    max="100"
                    step="1"
                    class="monitor-slider"
                    id="monitorCardOpacity"
                    title="Card transparency: 0 is solid, 100 is fully see-through"
                    value="<?= (int)$monitorCardOpacity ?>">
            </div>

            <div
                class="monitor-slider-wrap">
                <span
                    class="monitor-slider-label">
                    Table
                </span>
                <input
                    type="color"
                    class="monitor-bg-color"
                    id="monitorTableColor"
                    title="Table header colour"
                    value="<?= htmlspecialchars(
                        $monitorHexOk(
                            $monitorTableColor
                        )
                            ? $monitorTableColor
                            : '#ffffff'
                    ) ?>">
                <input
                    type="color"
                    class="monitor-bg-color"
                    id="monitorTableAltColor"
                    title="Table alternate row colour"
                    value="<?= htmlspecialchars(
                        $monitorHexOk(
                            $monitorTableAltColor
                        )
                            ? $monitorTableAltColor
                            : '#ffffff'
                    ) ?>">
                <input
                    type="color"
                    class="monitor-bg-color"
                    id="monitorTableGridColor"
                    title="Table grid line colour"
                    value="<?= htmlspecialchars(
                        $monitorHexOk(
                            $monitorTableGridColor
                        )
                            ? $monitorTableGridColor
                            : '#ffffff'
                    ) ?>">
                <input
                    type="color"
                    class="monitor-bg-color"
                    id="monitorTextColor"
                    title="Page text colour"
                    value="<?= htmlspecialchars(
                        $monitorHexOk(
                            $monitorTextColor
                        )
                            ? $monitorTextColor
                            : '#ffffff'
                    ) ?>">
                <input
                    type="range"
                    min="0"
                    max="100"
                    step="1"
                    class="monitor-slider"
                    id="monitorTableOpacity"
                    title="Table transparency: 0 is solid, 100 is fully see-through"
                    value="<?= (int)$monitorTableOpacity ?>">

                <button
                    type="button"
                    class="monitor-reset-btn
                        monitor-toggle-btn"
                    id="monitorTableGridToggle"
                    aria-pressed="<?= $monitorTableGridEnabled
                        ? 'false'
                        : 'true'
                    ?>"
                    title="Show or hide the table grid lines">
                    Table Grid
                </button>

                <button
                    type="button"
                    class="monitor-reset-btn"
                    id="monitorTableReset"
                    title="Remove all table colours and styling">
                    Defaults
                </button>
            </div>

            <button
                type="button"
                class="monitor-reset-btn"
                id="monitorBgImageBtn"
                title="Upload a background image">
                Upload Image
            </button>

            <input
                type="file"
                id="monitorBgFile"
                accept="image/*"
                hidden>

            <button
                type="button"
                class="monitor-reset-btn"
                id="monitorBgClearBtn"
                title="Remove the background">
                Clear
            </button>

            <button
                type="button"
                class="monitor-reset-btn monitor-toggle-btn"
                id="monitorHeadingsToggle"
                aria-pressed="false"
                title="Hide the card headings on the finished board">
                Card Headings
            </button>

            <button
                type="button"
                class="monitor-reset-btn monitor-toggle-btn"
                id="monitorTopbarToggle"
                aria-pressed="false"
                title="Hide the page title bar on the finished board">
                Page Title
            </button>

            <button
                type="button"
                class="monitor-reset-btn monitor-toggle-btn"
                id="monitorGridToggle"
                aria-pressed="false"
                title="Hide the background grid lines">
                Grid Lines
            </button>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="back">
                <span
                    class="material-symbols-outlined">
                    arrow_back
                </span>
                Back
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="clock">
                <span
                    class="material-symbols-outlined">
                    schedule
                </span>
                Clock
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="pending">
                <span
                    class="material-symbols-outlined">
                    pending_actions
                </span>
                Pending
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="approved">
                <span
                    class="material-symbols-outlined">
                    check_circle
                </span>
                Approved
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="denied">
                <span
                    class="material-symbols-outlined">
                    cancel
                </span>
                Denied
            </div>

            <?php if ($monitorCanConnectivity): ?>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="connectivity">
                <span
                    class="material-symbols-outlined">
                    monitor_heart
                </span>
                Connectivity
            </div>

            <?php endif; ?>

            <?php if ($monitorCanTechnitium): ?>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="dnsgraph">
                <span
                    class="material-symbols-outlined">
                    monitoring
                </span>
                DNS Graph
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="dnstop">
                <span
                    class="material-symbols-outlined">
                    group
                </span>
                Top Users
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="dnsblocked">
                <span
                    class="material-symbols-outlined">
                    block
                </span>
                Top Blocked
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="dnsratio">
                <span
                    class="material-symbols-outlined">
                    data_usage
                </span>
                Blocked Ratio
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="dnsserver">
                <span
                    class="material-symbols-outlined">
                    dns
                </span>
                DNS Server
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="dnstotals">
                <span
                    class="material-symbols-outlined">
                    stacked_bar_chart
                </span>
                DNS Totals
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="dhcp">
                <span
                    class="material-symbols-outlined">
                    lan
                </span>
                DHCP Leases
            </div>

            <?php endif; ?>

            <?php if ($monitorCanPending): ?>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="unblocks">
                <span
                    class="material-symbols-outlined">
                    lock_open
                </span>
                Unblock Queue
            </div>

            <?php endif; ?>

            <?php if ($monitorCanUsers): ?>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="logins">
                <span
                    class="material-symbols-outlined">
                    login
                </span>
                Login Feed
            </div>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="events">
                <span
                    class="material-symbols-outlined">
                    bolt
                </span>
                Live Activity
            </div>

            <?php endif; ?>

            <div
                class="monitor-chip"
                draggable="true"
                data-widget="weather">
                <span
                    class="material-symbols-outlined">
                    partly_cloudy_day
                </span>
                Weather
            </div>

        </div>

        <?php endif; ?>

        <div
            class="monitor-canvas"
            id="monitorCanvas"<?=
                $monitorBgStyle !== ''
                    ? ' style="'
                    . $monitorBgStyle
                    . '"'
                    : ''
            ?>>

            <div
                class="monitor-board"
                id="monitorBoard">

            <div
                class="monitor-drop-preview"
                id="monitorDropPreview"
                hidden></div>

            <div
                class="monitor-empty"
                id="monitorEmpty"
                hidden>
                Drag cards from the list above
                to build your monitoring board.
            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="back">

                <span
                    class="monitor-widget-resize"
                    data-widget="back"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Back
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="back"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <a
                    href="dashboard.php"
                    class="monitor-back-card"
                    draggable="false">
                    <span
                        class="material-symbols-outlined">
                        arrow_back
                    </span>
                    <span
                        class="monitor-back-card-label">
                        Dashboard
                    </span>
                </a>

            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="clock">

                <span
                    class="monitor-widget-resize"
                    data-widget="clock"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Clock
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="clock"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="basic-banner-clock monitor-clock"
                    id="basicBannerClock"
                    data-tz="<?= htmlspecialchars(
                        $monitorTimezone
                    ) ?>">

                    <div
                        class="basic-banner-weather"
                        id="basicBannerWeather"
                        data-lat="<?= htmlspecialchars(
                            $monitorLatitude
                        ) ?>"
                        data-lon="<?= htmlspecialchars(
                            $monitorLongitude
                        ) ?>"
                        hidden>

                        <span
                            class="weather-badge"
                            id="weatherBadge"
                            aria-hidden="true">
                        </span>

                        <span class="weather-stack">

                            <span
                                class="weather-temp"
                                id="weatherTemp"></span>

                            <span
                                class="weather-cond"
                                id="weatherCond"></span>

                        </span>

                    </div>

                    <div class="basic-banner-clock-divider"></div>

                    <div class="basic-banner-clock-stack">

                        <div
                            class="basic-banner-day"
                            id="basicBannerDay">
                        </div>

                        <div
                            class="basic-banner-date"
                            id="basicBannerDate">
                        </div>

                        <div
                            class="basic-banner-time"
                            id="basicBannerTime">
                        </div>

                    </div>

                </div>

            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="pending">

                <span
                    class="monitor-widget-resize"
                    data-widget="pending"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Pending Requests
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="pending"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div class="dash-card pending">

                    <div
                        class="dash-card-number"
                        id="monitor_pending">
                        <?= (int)(
                            $monitorStats['pending']
                        ) ?>
                    </div>

                </div>

            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="approved">

                <span
                    class="monitor-widget-resize"
                    data-widget="approved"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Approved Requests
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="approved"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div class="dash-card approved">

                    <div
                        class="dash-card-number"
                        id="monitor_approved">
                        <?= (int)(
                            $monitorStats['approved']
                        ) ?>
                    </div>

                </div>

            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="denied">

                <span
                    class="monitor-widget-resize"
                    data-widget="denied"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Denied Requests
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="denied"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div class="dash-card denied">

                    <div
                        class="dash-card-number"
                        id="monitor_denied">
                        <?= (int)(
                            $monitorStats['denied']
                        ) ?>
                    </div>

                </div>

            </div>

            <?php if ($monitorCanConnectivity): ?>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="connectivity">

                <span
                    class="monitor-widget-resize"
                    data-widget="connectivity"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Connectivity Status
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="connectivity"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <table class="monitor-table">

                    <thead>
                        <tr>
                            <th>Server</th>
                            <th>IP Address</th>
                            <th>CPU</th>
                            <th>Memory</th>
                            <th>Disk</th>
                            <th>Last Seen</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody id="monitor_connectivity_body">
                        <tr>
                            <td colspan="7">
                                Loading...
                            </td>
                        </tr>
                    </tbody>

                </table>

            </div>

            <?php endif; ?>

            <?php if ($monitorCanTechnitium): ?>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="dnsgraph">

                <span
                    class="monitor-widget-resize"
                    data-widget="dnsgraph"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        DNS Queries — Last Hour
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="dnsgraph"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="monitor-dns-totals">

                    <div
                        class="monitor-dns-total">
                        <span
                            class="monitor-dns-total-label">
                            Queries
                        </span>
                        <span
                            class="monitor-dns-total-value"
                            id="monitor_dns_total">
                            –
                        </span>
                    </div>

                    <div
                        class="monitor-dns-total">
                        <span
                            class="monitor-dns-total-label">
                            Blocked
                        </span>
                        <span
                            class="monitor-dns-total-value"
                            id="monitor_dns_blocked">
                            –
                        </span>
                    </div>

                    <div
                        class="monitor-dns-total">
                        <span
                            class="monitor-dns-total-label">
                            Clients
                        </span>
                        <span
                            class="monitor-dns-total-value"
                            id="monitor_dns_clients">
                            –
                        </span>
                    </div>

                </div>

                <div
                    class="monitor-dns-chart-wrap">
                    <svg
                        class="monitor-dns-chart"
                        id="monitor_dns_graph"
                        preserveAspectRatio="none"></svg>
                </div>

                <div
                    class="monitor-dns-legend">

                    <span
                        class="monitor-dns-legend-item">
                        <span
                            class="monitor-dns-swatch total">
                        </span>
                        Total
                    </span>

                    <span
                        class="monitor-dns-legend-item">
                        <span
                            class="monitor-dns-swatch blocked">
                        </span>
                        Blocked
                    </span>

                </div>

            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="dnstop">

                <span
                    class="monitor-widget-resize"
                    data-widget="dnstop"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Top DNS Users
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="dnstop"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="monitor-top-list"
                    id="monitor_dns_top">
                    <div
                        class="monitor-top-empty">
                        Loading...
                    </div>
                </div>

            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="dnsblocked">

                <span
                    class="monitor-widget-resize"
                    data-widget="dnsblocked"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Top Blocked
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="dnsblocked"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="monitor-top-list"
                    id="monitor_dns_blocked_list">
                    <div
                        class="monitor-top-empty">
                        Loading...
                    </div>
                </div>

            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="dnsratio">

                <span
                    class="monitor-widget-resize"
                    data-widget="dnsratio"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Blocked Ratio
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="dnsratio"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="monitor-ratio-wrap">

                    <svg
                        class="monitor-ratio-donut"
                        id="monitor_dns_ratio_donut"
                        viewBox="0 0 120 120"></svg>

                    <div
                        class="monitor-ratio-center">
                        <span
                            class="monitor-ratio-value"
                            id="monitor_dns_ratio_value">
                            –
                        </span>
                        <span
                            class="monitor-ratio-label">
                            Blocked
                        </span>
                    </div>

                </div>

                <p
                    class="monitor-ratio-detail"
                    id="monitor_dns_ratio_detail">
                </p>

            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="dnsserver">

                <span
                    class="monitor-widget-resize"
                    data-widget="dnsserver"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        DNS Server
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="dnsserver"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="monitor-dns-totals">

                    <div
                        class="monitor-dns-total">
                        <span
                            class="monitor-dns-total-label">
                            Cache Entries
                        </span>
                        <span
                            class="monitor-dns-total-value"
                            id="monitor_dns_server_cache">
                            –
                        </span>
                    </div>

                    <div
                        class="monitor-dns-total">
                        <span
                            class="monitor-dns-total-label">
                            Block List
                        </span>
                        <span
                            class="monitor-dns-total-value"
                            id="monitor_dns_server_blocklists">
                            –
                        </span>
                    </div>

                    <div
                        class="monitor-dns-total">
                        <span
                            class="monitor-dns-total-label">
                            Zones
                        </span>
                        <span
                            class="monitor-dns-total-value"
                            id="monitor_dns_server_zones">
                            –
                        </span>
                    </div>

                </div>

            </div>

            <?php endif; ?>

            <?php if ($monitorCanConnectivity): ?>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="gauges">

                <span
                    class="monitor-widget-resize"
                    data-widget="gauges"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Server Health
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="gauges"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="monitor-gauges"
                    id="monitor_gauges_body">
                    <div
                        class="monitor-top-empty">
                        Loading...
                    </div>
                </div>

            </div>

            <?php endif; ?>

            <?php if ($monitorCanTechnitium): ?>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="dnstotals">

                <span
                    class="monitor-widget-resize"
                    data-widget="dnstotals"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        DNS Totals
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="dnstotals"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div class="monitor-tiles">

                    <div class="monitor-tile">
                        <span
                            class="monitor-tile-label">
                            Queries
                        </span>
                        <span
                            class="monitor-tile-value"
                            id="monitor_dns_totals_queries">
                            &ndash;
                        </span>
                    </div>

                    <div class="monitor-tile">
                        <span
                            class="monitor-tile-label">
                            Blocked
                        </span>
                        <span
                            class="monitor-tile-value"
                            id="monitor_dns_totals_blocked">
                            &ndash;
                        </span>
                    </div>

                    <div class="monitor-tile">
                        <span
                            class="monitor-tile-label">
                            Blocked %
                        </span>
                        <span
                            class="monitor-tile-value"
                            id="monitor_dns_totals_pct">
                            &ndash;
                        </span>
                    </div>

                    <div class="monitor-tile">
                        <span
                            class="monitor-tile-label">
                            Clients
                        </span>
                        <span
                            class="monitor-tile-value"
                            id="monitor_dns_totals_clients">
                            &ndash;
                        </span>
                    </div>

                    <div class="monitor-tile">
                        <span
                            class="monitor-tile-label">
                            Cached
                        </span>
                        <span
                            class="monitor-tile-value"
                            id="monitor_dns_totals_cached">
                            &ndash;
                        </span>
                    </div>

                    <div class="monitor-tile">
                        <span
                            class="monitor-tile-label">
                            Block Lists
                        </span>
                        <span
                            class="monitor-tile-value"
                            id="monitor_dns_totals_blocklists">
                            &ndash;
                        </span>
                    </div>

                </div>

            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="dhcp">

                <span
                    class="monitor-widget-resize"
                    data-widget="dhcp"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        DHCP Leases
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="dhcp"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div class="monitor-dhcp-wrap">

                    <div
                        class="monitor-dhcp-scopes"
                        id="monitor_dhcp_scopes">
                        <div
                            class="monitor-top-empty">
                            Loading...
                        </div>
                    </div>

                    <div
                        class="monitor-dhcp-leases-title">
                        Leases
                    </div>

                    <div
                        id="monitor_dhcp_leases">
                        <div
                            class="monitor-top-empty">
                            Loading...
                        </div>
                    </div>

                </div>

            </div>

            <?php endif; ?>

            <?php if ($monitorCanPending): ?>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="unblocks">

                <span
                    class="monitor-widget-resize"
                    data-widget="unblocks"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Unblock Queue
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="unblocks"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="monitor-feed"
                    id="monitor_unblocks_body">
                    <div
                        class="monitor-top-empty">
                        Loading...
                    </div>
                </div>

            </div>

            <?php endif; ?>

            <?php if ($monitorCanUsers): ?>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="logins">

                <span
                    class="monitor-widget-resize"
                    data-widget="logins"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Login Feed
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="logins"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="monitor-feed"
                    id="monitor_logins_body">
                    <div
                        class="monitor-top-empty">
                        Loading...
                    </div>
                </div>

            </div>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="events">

                <span
                    class="monitor-widget-resize"
                    data-widget="events"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Live Activity
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="events"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="monitor-feed"
                    id="monitor_events_body">
                    <div
                        class="monitor-top-empty">
                        Loading...
                    </div>
                </div>

            </div>

            <?php endif; ?>

            <div
                class="monitor-widget"
                draggable="true"
                data-widget="weather">

                <span
                    class="monitor-widget-resize"
                    data-widget="weather"></span>

                <div
                    class="monitor-widget-header">

                    <div
                        class="monitor-widget-title">
                        Weather
                    </div>

                    <button
                        type="button"
                        class="monitor-widget-close"
                        data-widget="weather"
                        aria-label="Remove">
                        &times;
                    </button>

                </div>

                <div
                    class="monitor-weather"
                    id="monitorWeatherCard"
                    data-lat="<?= htmlspecialchars(
                        $monitorLatitude
                    ) ?>"
                    data-lon="<?= htmlspecialchars(
                        $monitorLongitude
                    ) ?>">

                    <div
                        class="monitor-weather-now">

                        <div
                            class="monitor-weather-icon"
                            id="monitor_weather_icon">
                            <div
                                class="monitor-top-empty">
                                Loading...
                            </div>
                        </div>

                        <div>

                            <div
                                class="monitor-weather-temp"
                                id="monitor_weather_temp">
                                &ndash;
                            </div>

                            <div
                                class="monitor-weather-cond"
                                id="monitor_weather_cond">
                            </div>

                        </div>

                    </div>

                    <div
                        class="monitor-weather-forecast"
                        id="monitor_weather_forecast">
                    </div>

                </div>

            </div>

            </div>

        </div>

    </div>

</div>

<?php if ($monitorCanEdit): ?>

<div
    class="monitor-card-editor"
    id="monitorCardEditor"
    hidden>

    <div
        class="monitor-card-editor-panel">

        <div
            class="monitor-card-editor-head">

            <span
                id="monitorCardEditorName">
                Card
            </span>

            <button
                type="button"
                class="monitor-widget-close"
                id="monitorCardEditorClose"
                aria-label="Close">
                &times;
            </button>

        </div>

        <label
            class="monitor-editor-row">
            Title
            <input
                type="text"
                id="monitorCardEditorTitle"
                maxlength="40"
                placeholder="Empty hides it">
        </label>

        <label
            class="monitor-editor-row">
            Text size
            <input
                type="range"
                min="10"
                max="30"
                step="1"
                id="monitorCardEditorFont">
            <span
                id="monitorCardEditorFontValue">
                13
            </span>
        </label>

        <label
            class="monitor-editor-row">
            Text colour
            <input
                type="color"
                id="monitorCardEditorColor"
                value="#ffffff">
        </label>

        <label
            class="monitor-editor-row">
            Refresh
            <select
                id="monitorCardEditorRefresh">
                <option value="fast">
                    Fast (10s)
                </option>
                <option value="normal">
                    Normal
                </option>
                <option value="slow">
                    Slow (60s)
                </option>
                <option value="paused">
                    Paused
                </option>
            </select>
        </label>

        <div
            class="monitor-editor-actions">

            <button
                type="button"
                class="monitor-reset-btn"
                id="monitorCardEditorReset">
                Defaults
            </button>

            <button
                type="button"
                class="monitor-reset-btn"
                id="monitorCardEditorRemove">
                Remove Card
            </button>

            <button
                type="button"
                class="approve-btn"
                id="monitorCardEditorSave">
                Save
            </button>

        </div>

    </div>

</div>

<?php endif; ?>

<?php include __DIR__ . '/includes/banner-clock-js.php'; ?>

<script>
const monitorCanvas =
    document.getElementById(
        'monitorCanvas'
    );

const monitorBoard =
    document.getElementById(
        'monitorBoard'
    );

const monitorEmpty =
    document.getElementById(
        'monitorEmpty'
    );

const monitorPreview =
    document.getElementById(
        'monitorDropPreview'
    );

const monitorLayoutKey =
    'monitorWidgetLayout';

/*
 * Free placement board: every widget
 * sits at an exact grid cell. The
 * position and size are kept in grid
 * units and rendered against the
 * current board width.
 */

const monitorCols = 192;
const monitorRowHeight = 6.5;
const monitorGap = 0;
const monitorPad = 1;

const monitorDefaultSizes = {
    back: {w: 32, h: 32},
    clock: {w: 80, h: 32},
    pending: {w: 48, h: 32},
    approved: {w: 48, h: 32},
    denied: {w: 48, h: 32},
    connectivity: {w: 192, h: 80},
    dnsgraph: {w: 128, h: 64},
    dnstop: {w: 64, h: 80},
    dnsblocked: {w: 64, h: 80},
    dnsratio: {w: 64, h: 48},
    dnsserver: {w: 96, h: 40},
    gauges: {w: 96, h: 80},
    dnstotals: {w: 64, h: 40},
    dhcp: {w: 80, h: 80},
    unblocks: {w: 64, h: 80},
    logins: {w: 64, h: 80},
    events: {w: 64, h: 96},
    weather: {w: 80, h: 56}
};

const monitorSizes = {};

let monitorDrag = null;

function monitorWidgets() {

    return Array.from(
        monitorBoard.querySelectorAll(
            '.monitor-widget'
        )
    );
}

function monitorWidgetNode(id) {

    return monitorBoard.querySelector(
        '.monitor-widget[data-widget="' + id + '"]'
    );
}

function monitorMetrics() {

    /* a few px stay clear of the
       scrollbar track on the right
       so edge cards never look
       cut off */

    const inner =
        monitorCanvas.clientWidth
        - (monitorPad * 2)
        - 4;

    return {
        colWidth:
            (inner
            - (monitorCols - 1)
                * monitorGap)
            / monitorCols,
        rowHeight: monitorRowHeight,

        /* the rows fully visible in the
           viewport: cards may never be
           placed below them */

        rows: Math.max(
            8,
            Math.floor(
                (
                    monitorCanvas
                        .clientHeight
                    - (monitorPad * 2)
                    - 14
                )
                / (
                    monitorRowHeight
                    + monitorGap
                )
            )
        )
    };
}

function monitorOverlaps(a, ignoreId) {

    for (
        const widget
        of monitorWidgets()
    ) {

        if (widget.hidden) {
            continue;
        }

        const id =
            widget.dataset.widget;

        if (id === ignoreId) {
            continue;
        }

        const entry =
            monitorSizes[id];

        if (!entry) {
            continue;
        }

        if (
            a.x < entry.x + entry.w
            && a.x + a.w > entry.x
            && a.y < entry.y + entry.h
            && a.y + a.h > entry.y
        ) {
            return true;
        }
    }

    return false;
}

function monitorFindFree(w, h, ignoreId) {

    for (let y = 0; y < 1024; y++) {

        for (
            let x = 0;
            x <= monitorCols - w;
            x++
        ) {

            const spot =
                {x: x, y: y, w: w, h: h};

            if (
                !monitorOverlaps(
                    spot,
                    ignoreId
                )
            ) {
                return {x: x, y: y};
            }
        }
    }

    return {x: 0, y: 0};
}

function monitorNearestFree(
    x,
    y,
    w,
    h,
    ignoreId
) {

    x = Math.max(
        0,
        Math.min(x, monitorCols - w)
    );

    y = Math.max(0, y);

    if (
        !monitorOverlaps(
            {x: x, y: y, w: w, h: h},
            ignoreId
        )
    ) {
        return {x: x, y: y};
    }

    /* search outwards from the
       wanted spot until a free
       cell is found */

    for (
        let radius = 1;
        radius < 600;
        radius++
    ) {

        for (
            let dy = -radius;
            dy <= radius;
            dy++
        ) {

            for (
                let dx = -radius;
                dx <= radius;
                dx++
            ) {

                if (
                    Math.max(
                        Math.abs(dx),
                        Math.abs(dy)
                    ) !== radius
                ) {
                    continue;
                }

                const cx = x + dx;
                const cy = y + dy;

                if (
                    cx < 0
                    || cx > monitorCols - w
                    || cy < 0
                ) {
                    continue;
                }

                if (
                    !monitorOverlaps(
                        {
                            x: cx,
                            y: cy,
                            w: w,
                            h: h
                        },
                        ignoreId
                    )
                ) {
                    return {x: cx, y: cy};
                }
            }
        }
    }

    return monitorFindFree(
        w,
        h,
        ignoreId
    );
}

function monitorPositionWidget(id) {

    const node =
        monitorWidgetNode(id);

    const entry =
        monitorSizes[id];

    if (!node || !entry) {
        return;
    }

    const m = monitorMetrics();

    node.style.position = 'absolute';

    node.style.left =
        entry.x
        * (m.colWidth + monitorGap)
        + 'px';

    node.style.top =
        entry.y
        * (m.rowHeight + monitorGap)
        + 'px';

    node.style.width =
        entry.w * m.colWidth
        + (entry.w - 1) * monitorGap
        + 'px';

    node.style.height =
        entry.h * m.rowHeight
        + (entry.h - 1) * monitorGap
        + 'px';
}

/* monitor slides: every slide keeps its own
   layout. The active slide is written into the
   regular layout key so all the existing load
   and save machinery keeps working unchanged */

const monitorSlidesKey =
    'monitorSlidesStore';

let monitorSlides = null;

try {
    monitorSlides =
        JSON.parse(
            localStorage.getItem(
                monitorSlidesKey
            )
        );
} catch (error) {
    /* storage unavailable */
}

if (
    !monitorSlides
    || !Array.isArray(
        monitorSlides.slides
    )
    || monitorSlides.slides.length
        === 0
) {

    /* first run: the existing board
       becomes slide 1 */

    let firstLayout = null;

    try {
        firstLayout =
            JSON.parse(
                localStorage.getItem(
                    monitorLayoutKey
                )
            );
    } catch (error) {
        /* storage unavailable */
    }

    monitorSlides = {
        rotate: 0,
        active: 0,
        slides: [
            {
                name: 'Slide 1',
                layout:
                    firstLayout
                    || {v: 5, items: []}
            }
        ]
    };
}

if (
    typeof monitorSlides.rotate
        !== 'number'
) {
    monitorSlides.rotate = 0;
}

if (
    typeof monitorSlides.active
        !== 'number'
    || monitorSlides.active
        >= monitorSlides.slides.length
) {
    monitorSlides.active = 0;
}

function monitorSlidesSave() {

    try {
        localStorage.setItem(
            monitorSlidesKey,
            JSON.stringify(
                monitorSlides
            )
        );
    } catch (error) {
        /* storage unavailable */
    }
}

function monitorSyncActiveSlide() {

    try {

        const raw =
            localStorage.getItem(
                monitorLayoutKey
            );

        monitorSlides
            .slides[monitorSlides.active]
            .layout =
            raw
                ? JSON.parse(raw)
                : {v: 5, items: []};
    } catch (error) {
        /* storage unavailable */
    }
}

function monitorUpdateSlideLabel() {

    const label =
        document.getElementById(
            'monitorSlideLabel'
        );

    if (label) {

        label.textContent =
            'Slide '
            + (
                monitorSlides.active
                + 1
            )
            + '/'
            + monitorSlides
                .slides.length;
    }

    const rotateInput =
        document.getElementById(
            'monitorRotateInput'
        );

    if (rotateInput) {
        rotateInput.value =
            monitorSlides.rotate
            || '';
    }
}

function monitorGoSlide(index) {

    monitorSyncActiveSlide();

    monitorSlides.active =
        Math.max(
            0,
            Math.min(
                index,
                monitorSlides
                    .slides.length
                    - 1
            )
        );

    const target =
        monitorSlides
            .slides[
                monitorSlides.active
            ];

    try {
        localStorage.setItem(
            monitorLayoutKey,
            JSON.stringify(
                target.layout
                || {v: 5, items: []}
            )
        );
    } catch (error) {
        /* storage unavailable */
    }

    monitorSlidesSave();

    monitorUpdateSlideLabel();

    monitorLoadLayout();

    monitorArmRotation();
}

/* view mode rotation: armed when the
   board is idle, cleared while editing -
   the master ticker re-arms it */

let monitorRotateTimer = null;

function monitorArmRotation() {

    if (monitorRotateTimer) {
        return;
    }

    if (
        monitorEditing
        || !monitorSlides.rotate
        || monitorSlides
            .slides.length < 2
    ) {
        return;
    }

    monitorRotateTimer =
        window.setTimeout(
            () => {

                monitorRotateTimer =
                    null;

                monitorGoSlide(
                    (
                        monitorSlides
                            .active
                        + 1
                    )
                    % monitorSlides
                        .slides
                        .length
                );
            },
            monitorSlides.rotate
                * 1000
        );
}

monitorSlidesSave();

monitorUpdateSlideLabel();

const monitorSlidePrev =
    document.getElementById(
        'monitorSlidePrev'
    );

const monitorSlideNext =
    document.getElementById(
        'monitorSlideNext'
    );

const monitorSlideAdd =
    document.getElementById(
        'monitorSlideAdd'
    );

const monitorSlideDel =
    document.getElementById(
        'monitorSlideDel'
    );

if (monitorSlidePrev) {

    monitorSlidePrev
        .addEventListener(
            'click',
            () => {

                monitorSyncActiveSlide();

                monitorGoSlide(
                    (
                        monitorSlides
                            .active
                        - 1
                        + monitorSlides
                            .slides
                            .length
                    )
                    % monitorSlides
                        .slides
                        .length
                );
            }
        );
}

if (monitorSlideNext) {

    monitorSlideNext
        .addEventListener(
            'click',
            () => {

                monitorSyncActiveSlide();

                monitorGoSlide(
                    (
                        monitorSlides
                            .active
                        + 1
                    )
                    % monitorSlides
                        .slides
                        .length
                );
            }
        );
}

if (monitorSlideAdd) {

    monitorSlideAdd
        .addEventListener(
            'click',
            () => {

                monitorSyncActiveSlide();

                monitorSlides
                    .slides
                    .push({
                        name:
                            'Slide '
                            + (
                                monitorSlides
                                    .slides
                                    .length
                                + 1
                            ),
                        layout: {
                            v: 5,
                            items: []
                        }
                    });

                monitorGoSlide(
                    monitorSlides
                        .slides
                        .length
                        - 1
                );
            }
        );
}

if (monitorSlideDel) {

    monitorSlideDel
        .addEventListener(
            'click',
            () => {

                if (
                    monitorSlides
                        .slides
                        .length
                    < 2
                ) {

                    /* the last slide clears
                       instead of deleting */

                    try {
                        localStorage
                            .setItem(
                                monitorLayoutKey,
                                JSON.stringify(
                                    {
                                        v: 5,
                                        items: []
                                    }
                                )
                        );
                    } catch (error) {
                        /* storage unavailable */
                    }

                    monitorLoadLayout();

                    return;
                }

                monitorSlides
                    .slides
                    .splice(
                        monitorSlides
                            .active,
                        1
                    );

                monitorGoSlide(
                    Math.max(
                        0,
                        monitorSlides
                            .active
                        - 1
                    )
                );
            }
        );
}

const monitorRotateInput =
    document.getElementById(
        'monitorRotateInput'
    );

if (monitorRotateInput) {

    monitorRotateInput
        .addEventListener(
            'change',
            () => {

                monitorSlides.rotate =
                    Math.max(
                        0,
                        Math.min(
                            600,
                            Number(
                                monitorRotateInput
                                    .value
                            )
                            || 0
                        )
                    );

                monitorSlidesSave();
            }
        );
}

/* viewport changes re-fit the board live:
   the grid spacing, the board height and
   every card clamp follow the new canvas
   size immediately - F11 fullscreen space
   is usable without a refresh */

window.addEventListener(
    'resize',
    () => {

        const m =
            monitorMetrics();

        for (
            const id
            in monitorSizes
        ) {

            const entry =
                monitorSizes[id];

            if (!entry) {
                continue;
            }

            entry.x = Math.max(
                0,
                Math.min(
                    entry.x,
                    monitorCols
                        - entry.w
                )
            );

            entry.y = Math.max(
                0,
                Math.min(
                    entry.y,
                    m.rows
                        - entry.h
                )
            );

            monitorPositionWidget(
                id
            );
        }

        monitorRelayout();
    }
);

function monitorRelayout() {

    const m = monitorMetrics();

    /* the background cell grid
       follows the live column
       width */

    monitorBoard.style.backgroundSize =
        (m.colWidth + monitorGap)
        + 'px '
        + (m.rowHeight + monitorGap)
        + 'px';

    let bottom = 0;

    for (
        const widget
        of monitorWidgets()
    ) {

        if (widget.hidden) {
            continue;
        }

        const entry =
            monitorSizes[
                widget.dataset.widget
            ];

        monitorPositionWidget(
            widget.dataset.widget
        );

        if (entry) {
            bottom = Math.max(
                bottom,
                entry.y + entry.h
            );
        }
    }

    /* the board always fills the visible canvas:
       the grid must reach the bottom and drops
       below the cards must land on the board.
       An explicit height only applies when the
       content grows beyond one screen. */

    const visiblePx =
        m.rows
        * (m.rowHeight + monitorGap)
        - monitorGap;

    const contentPx =
        bottom
        * (m.rowHeight + monitorGap)
        - monitorGap;

    monitorBoard.style.height =
        contentPx > visiblePx
            ? contentPx + 'px'
            : '';
}

function monitorSaveLayout() {

    const order =
        monitorWidgets()
            .filter(
                (widget) => !widget.hidden
            )
            .map(
                (widget) => {

                    const id =
                        widget.dataset.widget;

                    const entry =
                        monitorSizes[id]
                        ?? {
                            x: 0,
                            y: 0,
                            w: 3,
                            h: 2
                        };

                    return {
                        id: id,
                        x: entry.x,
                        y: entry.y,
                        w: entry.w,
                        h: entry.h
                    };
                }
            );

    try {
        localStorage.setItem(
            monitorLayoutKey,
            JSON.stringify({
                v: 5,
                items: order
            })
        );
    } catch (error) {
        /* storage unavailable */
    }

    monitorEmpty.hidden =
        order.length > 0;

    monitorRelayout();
}

/*
 * A widget that was hidden needs
 * one refresh as soon as it is
 * placed on the board so it does
 * not show a stale loading state.
 */

function monitorAfterPlace(id) {

    if (
        id === 'dnsgraph'
        || id === 'dnsratio'
        || id === 'dnsserver'
    ) {
        refreshMonitorDnsGraph();
    }

    if (id === 'dnstop') {
        refreshMonitorDnsTop();
    }

    if (id === 'dnsblocked') {
        refreshMonitorDnsBlocked();
    }

    if (id === 'gauges') {
        refreshMonitorGauges();
    }

    if (id === 'dnstotals') {
        refreshMonitorDnsTotals();
    }

    if (id === 'dhcp') {
        refreshMonitorDhcp();
    }

    if (id === 'unblocks') {
        refreshMonitorUnblocks();
    }

    if (id === 'logins') {
        refreshMonitorLogins();
    }

    if (id === 'events') {
        refreshMonitorEvents();
    }

    if (id === 'weather') {
        refreshMonitorWeather();
    }
}

function monitorPlaceWidget(id) {

    const node =
        monitorWidgetNode(id);

    if (!node) {
        return;
    }

    if (!monitorSizes[id]) {

        const size =
            monitorDefaultSizes[id]
            ?? {w: 3, h: 2};

        const spot =
            monitorFindFree(
                size.w,
                size.h,
                null
            );

        monitorSizes[id] = {
            x: spot.x,
            y: spot.y,
            w: size.w,
            h: size.h
        };
    }

    node.hidden = false;

    monitorPositionWidget(id);

    monitorAfterPlace(id);

    monitorSaveLayout();
}

function monitorLoadLayout() {

    let order = null;
    let scale = 4;

    try {
        const saved =
            localStorage.getItem(
                monitorLayoutKey
            );

        if (saved) {

            const parsed =
                JSON.parse(saved);

            if (
                parsed
                && typeof parsed === 'object'
                && !Array.isArray(parsed)
                && Array.isArray(parsed.items)
            ) {

                order = parsed.items;

                /* each grid generation is
                   twice as fine as the one
                   before it */

                scale =
                    parsed.v === 5
                        ? 1
                        : (parsed.v === 4
                            ? 2
                            : (parsed.v === 3
                                ? 4
                                : 8));

            } else if (
                Array.isArray(parsed)
            ) {
                order = parsed;
                scale = 16;
            }
        }
    } catch (error) {
        /* storage unavailable */
    }

    if (!Array.isArray(order)) {

        /* first visit: the default board */

        scale = 1;

        order = [];
    }

    /* normalize: older saves used the
       coarser grids, their cells scale
       up into the 48 column grid
       (12 column saves x4, 24 column
       saves x2); older saves have no
       x/y and flow from the top left */

    const items = [];

    for (const entry of order) {

        if (typeof entry === 'string') {

            items.push({
                id: entry,
                x: null,
                y: null,
                w: null,
                h: null
            });

        } else if (
            entry
            && typeof entry === 'object'
        ) {

            items.push({
                id: String(
                    entry.id ?? ''
                ),
                x: entry.x == null
                    ? null
                    : entry.x * scale,
                y: entry.y == null
                    ? null
                    : entry.y * scale,
                w: entry.w == null
                    ? null
                    : Math.min(
                        monitorCols,
                        entry.w * scale
                    ),
                h: entry.h == null
                    ? null
                    : Math.min(
                        256,
                        entry.h * scale
                    )
            });
        }
    }

    monitorWidgets().forEach(
        (widget) => {
            widget.hidden = true;
        }
    );

    for (const item of items) {

        const node =
            monitorWidgetNode(item.id);

        if (!node) {
            continue;
        }

        const size =
            monitorDefaultSizes[item.id]
            ?? {w: 3, h: 2};

        const entry = {
            x: item.x,
            y: item.y,
            w: item.w ?? size.w,
            h: item.h ?? size.h
        };

        if (
            entry.x === null
            || entry.y === null
        ) {

            const spot =
                monitorFindFree(
                    entry.w,
                    entry.h,
                    null
                );

            entry.x = spot.x;
            entry.y = spot.y;
        }

        entry.x = Math.max(
            0,
            Math.min(
                entry.x,
                monitorCols - entry.w
            )
        );

        /* every card must sit fully on
           the screen: saved positions
           from a taller window are
           pulled back into view */

        const loadMetrics =
            monitorMetrics();

        entry.y = Math.max(
            0,
            Math.min(
                entry.y,
                loadMetrics.rows
                    - entry.h
            )
        );

        monitorSizes[item.id] = entry;

        node.hidden = false;

        monitorPositionWidget(item.id);

        monitorAfterPlace(item.id);
    }

    monitorEmpty.hidden =
        monitorWidgets().some(
            (widget) => !widget.hidden
        );

    /* cards can end up overlapping
       after earlier resizes; every
       load untangles them so no
       card ever covers another */

    for (const item of items) {

        const entry =
            monitorSizes[item.id];

        if (
            !entry
            || !monitorWidgetNode(item.id)
        ) {
            continue;
        }

        if (
            monitorOverlaps(
                {
                    x: entry.x,
                    y: entry.y,
                    w: entry.w,
                    h: entry.h
                },
                item.id
            )
        ) {

            const spot =
                monitorNearestFree(
                    entry.x,
                    entry.y,
                    entry.w,
                    entry.h,
                    item.id
                );

            entry.x = spot.x;
            entry.y = spot.y;

            monitorPositionWidget(
                item.id
            );
        }
    }

    monitorRelayout();
}

/*
 * Drag and drop: the palette chips
 * and the cards all use the same
 * drop logic - the card lands on
 * the cell under the cursor and a
 * preview outline follows along.
 */

function monitorCellFromPoint(
    clientX,
    clientY,
    w,
    h
) {

    /* the board rect is used directly: it already
       includes the canvas padding, the board top
       margin and the live scroll position, so the
       drag math stays exact with the close buttons
       floating outside the frames */

    const rect =
        monitorBoard
            .getBoundingClientRect();

    const m = monitorMetrics();

    const x = Math.round(
        (clientX - rect.left)
        / (m.colWidth + monitorGap)
    );

    const y = Math.round(
        (clientY - rect.top)
        / (m.rowHeight + monitorGap)
    );

    return {
        x: Math.max(
            0,
            Math.min(x, monitorCols - w)
        ),

        /* the card stays fully on
           the screen while dragging */

        y: Math.max(
            0,
            Math.min(
                y,
                m.rows - h
            )
        )
    };
}

function monitorShowPreview(x, y, w, h) {

    const m = monitorMetrics();

    monitorPreview.hidden = false;

    monitorPreview.style.left =
        x * (m.colWidth + monitorGap)
        + 'px';

    monitorPreview.style.top =
        y * (m.rowHeight + monitorGap)
        + 'px';

    monitorPreview.style.width =
        w * m.colWidth
        + (w - 1) * monitorGap
        + 'px';

    monitorPreview.style.height =
        h * m.rowHeight
        + (h - 1) * monitorGap
        + 'px';
}

document
    .querySelectorAll('.monitor-chip')
    .forEach((chip) => {

        chip.addEventListener(
            'dragstart',
            (event) => {

                const id =
                    chip.dataset.widget;

                const size =
                    monitorDefaultSizes[id]
                    ?? {w: 3, h: 2};

                monitorDrag = {
                    type: 'add',
                    id: id,
                    w: size.w,
                    h: size.h
                };

                event.dataTransfer.setData(
                    'text/plain',
                    id
                );
            }
        );

        chip.addEventListener(
            'dragend',
            () => {
                monitorDrag = null;
                monitorPreview.hidden = true;
            }
        );

        chip.addEventListener(
            'click',
            () => {

                /* clicking a chip toggles
                   its card: on the board it
                   removes it, off the
                   board it adds it */

                const id =
                    chip.dataset.widget;

                const node =
                    monitorWidgetNode(id);

                if (
                    node
                    && !node.hidden
                ) {
                    node.hidden = true;
                    monitorSaveLayout();
                    return;
                }

                monitorPlaceWidget(id);
            }
        );
    });

/*
 * Resize: drag a card's corner
 * handle to snap it to a bigger
 * or smaller footprint.
 */

function monitorStartResize(event, id) {

    const node =
        monitorWidgetNode(id);

    const entry = monitorSizes[id];

    if (!node || !entry) {
        return;
    }

    /* resizing is disabled on the
       single column phone layout */

    if (
        window.matchMedia(
            '(max-width: 900px)'
        ).matches
    ) {
        return;
    }

    const m = monitorMetrics();

    const startX = event.clientX;
    const startY = event.clientY;

    /* the resize works in grid units:
       the number of cells crossed by
       the pointer is added to the
       starting span, so the card
       always snaps to exact cells */

    const startW = entry.w;
    const startH = entry.h;

    function onMove(moveEvent) {

        const dw = Math.round(
            (moveEvent.clientX - startX)
            / (m.colWidth + monitorGap)
        );

        const dh = Math.round(
            (moveEvent.clientY - startY)
            / (m.rowHeight + monitorGap)
        );

        entry.w = Math.max(
            1,
            Math.min(
                monitorCols,
                startW + dw
            )
        );

        entry.h = Math.max(
            1,
            Math.min(
                Math.min(
                    256,
                    m.rows - entry.y
                ),
                startH + dh
            )
        );

        if (entry.x + entry.w > monitorCols) {
            entry.x = Math.max(
                0,
                monitorCols - entry.w
            );
        }

        monitorPositionWidget(id);
        monitorRelayout();
    }

    function onUp() {

        document.removeEventListener(
            'pointermove',
            onMove
        );

        document.removeEventListener(
            'pointerup',
            onUp
        );

        /* a resize can push over a
           neighbour: keep the new size
           but slide to the nearest
           free cell so no card ends up
           covered */

        if (
            monitorOverlaps(
                {
                    x: entry.x,
                    y: entry.y,
                    w: entry.w,
                    h: entry.h
                },
                id
            )
        ) {

            const spot =
                monitorNearestFree(
                    entry.x,
                    entry.y,
                    entry.w,
                    entry.h,
                    id
                );

            entry.x = spot.x;
            entry.y = spot.y;

            monitorPositionWidget(id);
        }

        monitorSaveLayout();

        /* redraw the DNS chart so it
           fits the new card width */

        if (id === 'dnsgraph') {
            refreshMonitorDnsGraph();
        }
    }

    document.addEventListener(
        'pointermove',
        onMove
    );

    document.addEventListener(
        'pointerup',
        onUp
    );
}

/*
 * Widgets: drag to move anywhere on
 * the board, X to remove, corner to
 * resize.
 */

monitorWidgets().forEach(
    (widget) => {

        widget.addEventListener(
            'dragstart',
            (event) => {

                /* the corner handle resizes
                   and the X removes: neither
                   must turn into a drag */

                if (
                    event.target.closest(
                        '.monitor-widget-resize, '
                        + '.monitor-widget-close'
                    )
                ) {
                    event.preventDefault();
                    return;
                }

                const id =
                    widget.dataset.widget;

                const entry =
                    monitorSizes[id]
                    ?? {w: 3, h: 2};

                monitorDrag = {
                    type: 'move',
                    id: id,
                    w: entry.w,
                    h: entry.h
                };

                event.dataTransfer.setData(
                    'text/plain',
                    id
                );

                widget.classList.add(
                    'dragging'
                );
            }
        );

        widget.addEventListener(
            'dragend',
            () => {
                widget.classList.remove(
                    'dragging'
                );
                monitorDrag = null;
                monitorPreview.hidden = true;
            }
        );

        const close = widget.querySelector(
            '.monitor-widget-close'
        );

        if (close) {

            /* the button sits inside a
               draggable card: on a real
               mouse a click with the
               smallest movement starts
               a card drag and eats the
               click. Act on pointer down
               and stop the drag before
               it can begin. */

            close.addEventListener(
                'pointerdown',
                (event) => {

                    event.stopPropagation();
                    event.preventDefault();

                    const node =
                        monitorWidgetNode(
                            close.dataset.widget
                        );

                    if (node) {
                        node.hidden = true;
                    }

                    monitorSaveLayout();
                }
            );

            close.addEventListener(
                'click',
                (event) => {

                    event.stopPropagation();

                    const node =
                        monitorWidgetNode(
                            close.dataset.widget
                        );

                    if (node) {
                        node.hidden = true;
                    }

                    monitorSaveLayout();
                }
            );
        }

        const resizeHandle =
            widget.querySelector(
                '.monitor-widget-resize'
            );

        if (resizeHandle) {

            resizeHandle.addEventListener(
                'pointerdown',
                (event) => {

                    event.stopPropagation();
                    event.preventDefault();

                    monitorStartResize(
                        event,
                        resizeHandle.dataset.widget
                    );
                }
            );
        }
    }
);

/* belt and braces: the board itself
   handles close presses in the
   capture phase, so a card can
   never get stuck on the board
   even if a per widget wire
   failed */

monitorBoard.addEventListener(
    'pointerdown',
    (event) => {

        const closeBtn =
            event.target.closest(
                '.monitor-widget-close'
            );

        if (!closeBtn) {
            return;
        }

        event.stopPropagation();
        event.preventDefault();

        window.__diag.closeFired =
            'fired for '
            + closeBtn.dataset.widget;

        const node =
            monitorWidgetNode(
                closeBtn.dataset.widget
            );

        if (node) {
            node.hidden = true;
        }

        monitorSaveLayout();
    },
    true
);

/* right click a card: the per card
   editor popup. Title, text size,
   text colour, refresh speed and
   removal all live in the popup now
   instead of the toolbar */

const monitorCardEditor =
    document.getElementById(
        'monitorCardEditor'
    );

let monitorCardEditorId = null;

function monitorOpenCardEditor(id) {

    const widget =
        monitorWidgetNode(id);

    if (
        !widget
        || !monitorCardEditor
    ) {
        return;
    }

    monitorCardEditorId = id;

    const entry =
        monitorCardStyles[id]
        || {};

    const titleEl =
        widget.querySelector(
            '.monitor-widget-title'
        );

    const nameEl =
        document.getElementById(
            'monitorCardEditorName'
        );

    if (nameEl) {
        nameEl.textContent =
            titleEl
                ? titleEl.textContent
                : id;
    }

    const titleInput =
        document.getElementById(
            'monitorCardEditorTitle'
        );

    if (titleInput) {

        titleInput.value =
            entry.title !== undefined
                ? entry.title
                : (
                    titleEl
                        ? titleEl.textContent
                        : ''
                  );
    }

    const fontInput =
        document.getElementById(
            'monitorCardEditorFont'
        );

    if (fontInput) {

        fontInput.value =
            entry.font
                ? String(entry.font)
                : '13';

        const fontValue =
            document.getElementById(
                'monitorCardEditorFontValue'
            );

        if (fontValue) {
            fontValue.textContent =
                fontInput.value;
        }
    }

    const colorInput =
        document.getElementById(
            'monitorCardEditorColor'
        );

    if (colorInput) {
        colorInput.value =
            entry.color
                ? entry.color
                : '#ffffff';
    }

    const refreshInput =
        document.getElementById(
            'monitorCardEditorRefresh'
        );

    if (refreshInput) {
        refreshInput.value =
            entry.refresh
                ? entry.refresh
                : 'normal';
    }

    monitorCardEditor.hidden =
        false;
}

function monitorCloseCardEditor() {

    if (!monitorCardEditor) {
        return;
    }

    monitorCardEditor.hidden =
        true;

    monitorCardEditorId = null;
}

if (monitorCardEditor) {

    monitorBoard.addEventListener(
        'contextmenu',
        (event) => {

            if (!monitorEditing) {
                return;
            }

            const widget =
                event.target.closest(
                    '.monitor-widget'
                );

            if (!widget) {
                return;
            }

            event.preventDefault();

            monitorOpenCardEditor(
                widget.dataset.widget
            );
        }
    );

    document
        .getElementById(
            'monitorCardEditorClose'
        )
        .addEventListener(
            'click',
            () => {
                monitorCloseCardEditor();
            }
        );

    document
        .getElementById(
            'monitorCardEditorTitle'
        )
        .addEventListener(
            'input',
            (event) => {
                if (event.key === 'Enter') {
                    monitorCloseCardEditor();
                }
            }
        );

    const monitorEditorFontInput =
        document.getElementById(
            'monitorCardEditorFont'
        );

    monitorEditorFontInput
        .addEventListener(
            'input',
            () => {

                document
                    .getElementById(
                        'monitorCardEditorFontValue'
                    )
                    .textContent =
                        monitorEditorFontInput
                            .value;
            }
        );

    document
        .getElementById(
            'monitorCardEditorSave'
        )
        .addEventListener(
            'click',
            () => {

                if (
                    !monitorCardEditorId
                ) {
                    monitorCloseCardEditor();
                    return;
                }

                const entry =
                    monitorCardStyles[
                        monitorCardEditorId
                    ]
                    || {};

                entry.title =
                    document
                        .getElementById(
                            'monitorCardEditorTitle'
                        )
                        .value;

                entry.font =
                    Number(
                        document
                            .getElementById(
                                'monitorCardEditorFont'
                            )
                            .value
                    );

                entry.color =
                    document
                        .getElementById(
                            'monitorCardEditorColor'
                        )
                        .value;

                entry.refresh =
                    document
                        .getElementById(
                            'monitorCardEditorRefresh'
                        )
                        .value;

                monitorCardStyles[
                    monitorCardEditorId
                ] = entry;

                /* the legacy title store
                   follows along so the old
                   inline editing stays in
                   sync */

                monitorTitles[
                    monitorCardEditorId
                ] = entry.title;

                try {
                    localStorage.setItem(
                        'monitorTitles',
                        JSON.stringify(
                            monitorTitles
                        )
                    );
                } catch (error) {
                    /* storage unavailable */
                }

                monitorApplyCardStyles();

                monitorSaveCardStyles();

                monitorCloseCardEditor();
            }
        );

    document
        .getElementById(
            'monitorCardEditorReset'
        )
        .addEventListener(
            'click',
            () => {

                if (
                    !monitorCardEditorId
                ) {
                    monitorCloseCardEditor();
                    return;
                }

                delete monitorCardStyles[
                    monitorCardEditorId
                ];

                const widget =
                    monitorWidgetNode(
                        monitorCardEditorId
                    );

                if (widget) {

                    widget.style
                        .removeProperty(
                            '--card-font'
                        );

                    widget.style
                        .removeProperty(
                            'color'
                        );
                }

                monitorSaveCardStyles();

                monitorApplyTitles();

                monitorOpenCardEditor(
                    monitorCardEditorId
                );
            }
        );

    document
        .getElementById(
            'monitorCardEditorRemove'
        )
        .addEventListener(
            'click',
            () => {

                if (
                    !monitorCardEditorId
                ) {
                    monitorCloseCardEditor();
                    return;
                }

                const node =
                    monitorWidgetNode(
                        monitorCardEditorId
                    );

                if (node) {
                    node.hidden = true;
                }

                monitorSaveLayout();

                monitorCloseCardEditor();
            }
        );
}

/* third path: a captured click
   also removes the card, so even
   exotic pointer environments
   cannot leave a card stuck */

monitorBoard.addEventListener(
    'click',
    (event) => {

        const closeBtn =
            event.target.closest(
                '.monitor-widget-close'
            );

        if (!closeBtn) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();

        const node =
            monitorWidgetNode(
                closeBtn.dataset.widget
            );

        if (node) {
            node.hidden = true;
        }

        monitorSaveLayout();
    },
    true
);

/* clear: empty the board so it can
   be rebuilt from scratch */

const monitorResetBtn =
    document.getElementById(
        'monitorResetBtn'
    );

if (monitorResetBtn) {

    /* two clicks, no browser
       dialog: the first click
       arms the button, the
       second clears */

    let clearArmed = false;
    let clearTimer = null;

    monitorResetBtn.addEventListener(
        'click',
        () => {

            if (!clearArmed) {

                clearArmed = true;

                monitorResetBtn
                    .textContent =
                        'Confirm Clear?';

                monitorResetBtn
                    .classList.add(
                        'armed'
                    );

                clearTimer =
                    window.setTimeout(
                        () => {
                            clearArmed =
                                false;
                            monitorResetBtn
                                .textContent =
                                    'Clear Board';
                            monitorResetBtn
                                .classList.remove(
                                    'armed'
                                );
                        },
                        3000
                    );

                return;
            }

            window.clearTimeout(
                clearTimer
            );

            clearArmed = false;

            monitorResetBtn
                .textContent =
                    'Clear Board';

            monitorResetBtn
                .classList.remove(
                    'armed'
                );

            for (
                const id
                of Object.keys(
                    monitorSizes
                )
            ) {
                delete monitorSizes[id];
            }

            monitorWidgets().forEach(
                (widget) => {
                    widget.hidden =
                        true;
                }
            );

            monitorSaveLayout();
        }
    );
}

/*
 * Diagnostics: the panel records
 * what the page actually receives
 * so a misbehaving browser can be
 * read straight off the board.
 */

window.__diag = {
    pointerTarget: '',
    fromPoint: '',
    closeFired: '',
    ctxTarget: '',
    errors: [],
    storage: ''
};

window.addEventListener(
    'error',
    (event) => {
        window.__diag.errors.push(
            (event.message || 'error')
            + ' @'
            + (event.lineno || '?')
        );
    }
);

function monitorDescribe(element) {

    if (!element) {
        return 'null';
    }

    const tag =
        element.tagName
            ? element.tagName.toLowerCase()
            : '#text';

    let first = '';

    if (
        typeof element.className
            === 'string'
        && element.className !== ''
    ) {
        first = '.'
            + element.className
                .trim()
                .split(/\s+/)[0];
    }

    return tag + first;
}

function monitorDiagRender() {

    const panel =
        document.getElementById(
            'monitorDiagPanel'
        );

    if (!panel || panel.hidden) {
        return;
    }

    panel.innerHTML =
        '<b>editing:</b> '
        + monitorEditing
        + '<br><b>last press on:</b> '
        + window.__diag.pointerTarget
        + '<br><b>hit test found:</b> '
        + window.__diag.fromPoint
        + '<br><b>close handler:</b> '
        + (window.__diag.closeFired
            || 'not fired yet')
        + '<br><b>right click on:</b> '
        + (window.__diag.ctxTarget
            || 'none yet')
        + '<br><b>storage:</b> '
        + (window.__diag.storage
            || 'unknown')
        + '<br><b>errors:</b> '
        + (window.__diag.errors.length
            ? window.__diag.errors
                .join(' ; ')
            : 'none');
}

document.addEventListener(
    'pointerdown',
    (event) => {

        window.__diag.pointerTarget =
            monitorDescribe(
                event.target
            );

        window.__diag.fromPoint =
            monitorDescribe(
                document.elementFromPoint(
                    event.clientX,
                    event.clientY
                )
            );

        monitorDiagRender();
    },
    true
);

document.addEventListener(
    'contextmenu',
    (event) => {

        window.__diag.ctxTarget =
            monitorDescribe(
                event.target
            );

        monitorDiagRender();
    },
    true
);

const monitorDiagBtn =
    document.getElementById(
        'monitorDiagBtn'
    );

if (monitorDiagBtn) {

    monitorDiagBtn.addEventListener(
        'click',
        () => {

            const panel =
                document.getElementById(
                    'monitorDiagPanel'
                );

            if (!panel) {
                return;
            }

            panel.hidden = !panel.hidden;

            if (!panel.hidden) {

                try {

                    localStorage.setItem(
                        'monitorDiagTest',
                        'ok'
                    );

                    window.__diag.storage =
                        localStorage.getItem(
                            'monitorDiagTest'
                        ) === 'ok'
                            ? 'works'
                            : 'BROKEN';

                    localStorage.removeItem(
                        'monitorDiagTest'
                    );

                } catch (error) {
                    window.__diag.storage =
                        'BLOCKED: '
                        + error.message;
                }

                monitorDiagRender();
            }
        }
    );
}

/* watchdog: an interrupted drag can
   leave a card dimmed and the drag
   state stuck. Any later press or
   drag end heals the board. */

document.addEventListener(
    'dragend',
    () => {

        monitorWidgets().forEach(
            (widget) => {
                widget.classList.remove(
                    'dragging'
                );
            }
        );
    },
    true
);

document.addEventListener(
    'pointerdown',
    () => {

        if (monitorDrag) {
            monitorDrag = null;
            monitorPreview.hidden = true;
        }

        monitorWidgets().forEach(
            (widget) => {
                widget.classList.remove(
                    'dragging'
                );
            }
        );
    },
    true
);

monitorCanvas.addEventListener(
    'dragover',
    (event) => {

        if (!monitorDrag) {
            return;
        }

        event.preventDefault();

        const cell =
            monitorCellFromPoint(
                event.clientX,
                event.clientY,
                monitorDrag.w,
                monitorDrag.h
            );

        monitorDrag.target = cell;

        monitorShowPreview(
            cell.x,
            cell.y,
            monitorDrag.w,
            monitorDrag.h
        );
    }
);

monitorCanvas.addEventListener(
    'drop',
    (event) => {

        event.preventDefault();

        if (!monitorDrag) {
            return;
        }

        const id = monitorDrag.id;

        const cell =
            monitorDrag.target
            ?? {x: 0, y: 0};

        const node =
            monitorWidgetNode(id);

        monitorDrag = null;

        monitorPreview.hidden = true;

        if (!node) {
            return;
        }

        const entry =
            monitorSizes[id]
            ?? {
                x: 0,
                y: 0,
                w:
                    (monitorDefaultSizes[id]
                        ?? {w: 3})
                    .w,
                h:
                    (monitorDefaultSizes[id]
                        ?? {h: 2})
                    .h
            };

        const spot =
            monitorNearestFree(
                cell.x,
                cell.y,
                entry.w,
                entry.h,
                id
            );

        entry.x = spot.x;
        entry.y = spot.y;

        monitorSizes[id] = entry;

        node.hidden = false;

        monitorPositionWidget(id);

        monitorAfterPlace(id);

        monitorSaveLayout();
    }
);

/*
 * Window resizes re-render the
 * board against the new column
 * width.
 */

let monitorResizeTimer = null;

window.addEventListener(
    'resize',
    () => {

        window.clearTimeout(
            monitorResizeTimer
        );

        monitorResizeTimer =
            window.setTimeout(
                function () {
                    monitorRelayout();
                    refreshMonitorDnsGraph();
                },
                150
            );
    }
);

monitorLoadLayout();

const monitorCanEdit = <?= json_encode(
    $monitorCanEdit
) ?>;

/*
 * Edit mode: while arranging the
 * board the palette, the grid and
 * the handles show. The Done
 * button switches to a clean wall
 * view and the choice is kept.
 */

const monitorEditBtn =
    document.getElementById(
        'monitorEditBtn'
    );

const monitorCardEl =
    document.querySelector(
        '.monitor-card'
    );

let monitorEditing = true;

function monitorApplyEditMode() {

    monitorCardEl.classList.toggle(
        'viewing',
        !monitorEditing
    );

    monitorWidgets().forEach(
        (widget) => {
            widget.draggable =
                monitorEditing;
        }
    );

    if (monitorEditBtn) {

        const label =
            monitorEditBtn.querySelector(
                '.monitor-edit-label'
            );

        if (label) {
            label.textContent =
                monitorEditing
                    ? 'Done'
                    : 'Edit Board';
        }
    }

    const viewHint =
        document.getElementById(
            'monitorViewHint'
        );

    if (viewHint) {
        viewHint.hidden = monitorEditing;
    }
}

function monitorToggleEditMode() {

    monitorEditing =
        !monitorEditing;

    try {
        localStorage.setItem(
            'monitorEditMode',
            monitorEditing
                ? 'edit'
                : 'view'
        );
    } catch (error) {
        /* storage unavailable */
    }

    monitorApplyEditMode();
}

try {
    monitorEditing =
        monitorCanEdit
        && (localStorage.getItem(
            'monitorEditMode'
        ) ?? 'edit') !== 'view';
} catch (error) {
    /* storage unavailable */
}

if (monitorEditBtn) {
    monitorEditBtn.addEventListener(
        'click',
        monitorToggleEditMode
    );
}

/* double-clicking the board always
   returns to edit mode so the view
   can never trap the viewer */

monitorCanvas.addEventListener(
    'dblclick',
    () => {

        if (
            monitorCanEdit
            && !monitorEditing
        ) {
            monitorToggleEditMode();
        }
    }
);

monitorApplyEditMode();

/*
 * View options: headings and the
 * page title bar can hide on the
 * finished wall. Kept per browser.
 */

let monitorViewHide = {
    headings: false,
    topbar: false,
    gridlines: false
};

try {

    const savedView =
        localStorage.getItem(
            'monitorViewOptions'
        );

    if (savedView) {

        const parsedView =
            JSON.parse(savedView);

        if (
            parsedView
            && typeof parsedView === 'object'
        ) {
            monitorViewHide.headings =
                !!parsedView.headings;
            monitorViewHide.topbar =
                !!parsedView.topbar;
            monitorViewHide.gridlines =
                !!parsedView.gridlines;
        }
    }
} catch (error) {
    /* storage unavailable */
}

function monitorApplyViewOptions() {

    monitorCardEl.classList.toggle(
        'hide-headings',
        monitorViewHide.headings
    );

    monitorCardEl.classList.toggle(
        'hide-topbar',
        monitorViewHide.topbar
    );

    monitorCardEl.classList.toggle(
        'hide-gridlines',
        monitorViewHide.gridlines
    );

    const gridBtn =
        document.getElementById(
            'monitorGridToggle'
        );

    if (gridBtn) {
        gridBtn.setAttribute(
            'aria-pressed',
            monitorViewHide.gridlines
                ? 'true'
                : 'false'
        );
    }

    const headingsBtn =
        document.getElementById(
            'monitorHeadingsToggle'
        );

    if (headingsBtn) {
        headingsBtn.setAttribute(
            'aria-pressed',
            monitorViewHide.headings
                ? 'true'
                : 'false'
        );
    }

    const topbarBtn =
        document.getElementById(
            'monitorTopbarToggle'
        );

    if (topbarBtn) {
        topbarBtn.setAttribute(
            'aria-pressed',
            monitorViewHide.topbar
                ? 'true'
                : 'false'
        );
    }
}

function monitorToggleViewOption(key) {

    monitorViewHide[key] =
        !monitorViewHide[key];

    try {
        localStorage.setItem(
            'monitorViewOptions',
            JSON.stringify(monitorViewHide)
        );
    } catch (error) {
        /* storage unavailable */
    }

    monitorApplyViewOptions();
}

const monitorHeadingsBtn =
    document.getElementById(
        'monitorHeadingsToggle'
    );

if (monitorHeadingsBtn) {

    monitorHeadingsBtn.addEventListener(
        'click',
        () => {
            monitorToggleViewOption(
                'headings'
            );
        }
    );
}

const monitorTopbarBtn =
    document.getElementById(
        'monitorTopbarToggle'
    );

if (monitorTopbarBtn) {

    monitorTopbarBtn.addEventListener(
        'click',
        () => {
            monitorToggleViewOption(
                'topbar'
            );
        }
    );
}

const monitorGridBtn =
    document.getElementById(
        'monitorGridToggle'
    );

if (monitorGridBtn) {

    monitorGridBtn.addEventListener(
        'click',
        () => {
            monitorToggleViewOption(
                'gridlines'
            );
        }
    );
}

monitorApplyViewOptions();

/*
 * Custom titles: double click a card
 * heading (or the page heading) in
 * edit mode to rename it. Kept per
 * browser.
 */

let monitorTitles = {};

try {

    const savedTitles =
        localStorage.getItem(
            'monitorTitles'
        );

    if (savedTitles) {

        const parsedTitles =
            JSON.parse(savedTitles);

        if (
            parsedTitles
            && typeof parsedTitles === 'object'
        ) {
            monitorTitles = parsedTitles;
        }
    }
} catch (error) {
    /* storage unavailable */
}

function monitorApplyTitles() {

    monitorWidgets().forEach(
        (widget) => {

            const titleEl =
                widget.querySelector(
                    '.monitor-widget-title'
                );

            if (
                titleEl
                && monitorTitles[
                    widget.dataset.widget
                ] !== undefined
            ) {

                titleEl.textContent =
                    monitorTitles[
                        widget.dataset.widget
                    ];

                titleEl
                    .classList
                    .toggle(
                        'no-title',
                        monitorTitles[
                            widget
                                .dataset
                                .widget
                        ] === ''
                    );
            }
        }
    );

    const pageTitle =
        document.querySelector(
            '.monitor-title'
        );

    if (
        pageTitle
        && monitorTitles.__page
    ) {
        pageTitle.textContent =
            monitorTitles.__page;
    }
}

function monitorEditTitle(
    element,
    key
) {

    element.setAttribute(
        'contenteditable',
        'true'
    );

    element.focus();

    const range =
        document.createRange();

    range.selectNodeContents(
        element
    );

    const selection =
        window.getSelection();

    selection.removeAllRanges();
    selection.addRange(range);

    let finished = false;

    function finish(save) {

        if (finished) {
            return;
        }

        finished = true;

        element.setAttribute(
            'contenteditable',
            'false'
        );

        if (save) {

            const text =
                element.textContent
                    .replace(
                        /\s+/g,
                        ' '
                    )
                    .trim();

            /* an empty title is kept:
               it means 'show no title',
               not 'restore the default' */

            monitorTitles[key] = text;

            try {
                localStorage.setItem(
                    'monitorTitles',
                    JSON.stringify(
                        monitorTitles
                    )
                );
            } catch (error) {
                /* storage unavailable */
            }
        }

        monitorApplyTitles();
    }

    element.addEventListener(
        'blur',
        () => {
            finish(true);
        },
        {
            once: true
        }
    );

    element.addEventListener(
        'keydown',
        (event) => {

            if (event.key === 'Enter') {
                event.preventDefault();
                element.blur();
            }

            if (event.key === 'Escape') {
                event.preventDefault();
                finish(false);
            }
        },
        {
            once: true
        }
    );
}

monitorBoard.addEventListener(
    'dblclick',
    (event) => {

        if (!monitorEditing) {
            return;
        }

        const titleEl =
            event.target.closest(
                '.monitor-widget-title'
            );

        if (
            titleEl
            && titleEl.closest(
                '.monitor-widget'
            )
        ) {
            monitorEditTitle(
                titleEl,
                titleEl
                    .closest(
                        '.monitor-widget'
                    )
                    .dataset.widget
            );
        }
    }
);

const monitorPageTitle =
    document.querySelector(
        '.monitor-title'
    );

if (monitorPageTitle) {

    monitorPageTitle.addEventListener(
        'dblclick',
        () => {

            if (monitorEditing) {
                monitorEditTitle(
                    monitorPageTitle,
                    '__page'
                );
            }
        }
    );
}

monitorApplyTitles();

/*
 * Background: colour, image and
 * clear. The choice is kept in the
 * portal settings so every viewer
 * of the board sees it.
 */

/* the controls open in their own
   floating window: drag it by the
   handle anywhere, close it with the
   topbar button. The open state and
   the position are kept per browser */

const monitorToolbarToggle =
    document.getElementById(
        'monitorToolbarToggle'
    );

const monitorPaletteEl =
    document.querySelector(
        '.monitor-palette'
    );

if (
    monitorToolbarToggle
    && monitorPaletteEl
) {

    let monitorPanelOpen = false;

    try {
        monitorPanelOpen =
            localStorage.getItem(
                'monitorPanelOpen'
            ) === '1';
    } catch (error) {
        /* storage unavailable */
    }

    function monitorPanelApply() {

        monitorPaletteEl.hidden =
            !monitorPanelOpen;

        monitorToolbarToggle
            .setAttribute(
                'aria-pressed',
                monitorPanelOpen
                    ? 'true'
                    : 'false'
            );
    }

    monitorPanelApply();

    monitorToolbarToggle
        .addEventListener(
            'click',
            () => {

                monitorPanelOpen =
                    !monitorPanelOpen;

                monitorPanelApply();

                try {
                    localStorage.setItem(
                        'monitorPanelOpen',
                        monitorPanelOpen
                            ? '1'
                            : '0'
                    );
                } catch (error) {
                    /* storage unavailable */
                }
            }
        );

    /* remembered position */

    try {

        const savedLeft =
            localStorage.getItem(
                'monitorPanelLeft'
            );

        const savedTop =
            localStorage.getItem(
                'monitorPanelTop'
            );

        if (savedLeft && savedTop) {

            monitorPaletteEl.style.left =
                savedLeft;

            /* never over the topbar */

            monitorPaletteEl.style.top =
                Math.max(
                    64,
                    parseInt(
                        savedTop,
                        10
                    )
                )
                + 'px';

            monitorPaletteEl.style.right =
                'auto';
        }
    } catch (error) {
        /* storage unavailable */
    }

    /* drag by the handle */

    const monitorPaletteDrag =
        monitorPaletteEl.querySelector(
            '.monitor-palette-drag'
        );

    if (monitorPaletteDrag) {

        let monitorPanelMove = null;

        monitorPaletteDrag
            .addEventListener(
                'pointerdown',
                (event) => {

                    if (
                        event.button
                        !== 0
                    ) {
                        return;
                    }

                    const rect =
                        monitorPaletteEl
                            .getBoundingClientRect();

                    monitorPanelMove = {
                        dx:
                            event.clientX
                            - rect.left,
                        dy:
                            event.clientY
                            - rect.top
                    };

                    event.preventDefault();
                }
            );

        document.addEventListener(
            'pointermove',
            (event) => {

                if (!monitorPanelMove) {
                    return;
                }

                const left =
                    event.clientX
                    - monitorPanelMove.dx;

                const top =
                    event.clientY
                    - monitorPanelMove.dy;

                monitorPaletteEl
                    .style.left =
                        Math.max(
                            0,
                            Math.min(
                                left,
                                window
                                    .innerWidth
                                    - 80
                            )
                        )
                        + 'px';

                monitorPaletteEl
                    .style.top =
                        Math.max(
                            64,
                            Math.min(
                                top,
                                window
                                    .innerHeight
                                    - 40
                            )
                        )
                        + 'px';

                monitorPaletteEl
                    .style.right = 'auto';
            }
        );

        document.addEventListener(
            'pointerup',
            () => {

                if (!monitorPanelMove) {
                    return;
                }

                monitorPanelMove = null;

                try {
                    localStorage.setItem(
                        'monitorPanelLeft',
                        monitorPaletteEl
                            .style.left
                    );

                    localStorage.setItem(
                        'monitorPanelTop',
                        monitorPaletteEl
                            .style.top
                    );
                } catch (error) {
                    /* storage unavailable */
                }
            }
        );
    }
}

let monitorBgState = {
    color: <?= json_encode(
        $monitorBgColor
    ) ?>,
    image: <?= json_encode(
        $monitorBgImage
    ) ?>
};

const monitorCardState = {
    color: <?= json_encode(
        $monitorCardBase
    ) ?>,
    transparency: <?= (int)$monitorCardOpacity ?>
};

let monitorCardStyles = {};

try {
    monitorCardStyles =
        JSON.parse(
            <?= json_encode(
                $monitorCardStylesRaw
            ) ?>
        )
        || {};
} catch (error) {
    monitorCardStyles = {};
}

function monitorSaveCardStyles() {

    monitorSaveBackground({
        monitor_card_styles:
            JSON.stringify(
                monitorCardStyles
            )
    })
        .catch(() => {});
}

function monitorApplyCardStyles() {

    monitorWidgets().forEach(
        (widget) => {

            const id =
                widget.dataset.widget;

            const entry =
                monitorCardStyles[id]
                || {};

            const titleEl =
                widget.querySelector(
                    '.monitor-widget-title'
                );

            if (
                titleEl
                && entry.title !== undefined
            ) {

                titleEl.textContent =
                    entry.title;

                titleEl
                    .classList
                    .toggle(
                        'no-title',
                        entry.title === ''
                    );
            }

            if (entry.font) {

                /* a multiplier, not an inherited
                   size: the content font rules
                   scale themselves with calc() */

                widget.style.setProperty(
                    '--card-font',
                    (
                        entry.font / 13
                    ).toFixed(3)
                );
            }

            if (entry.color) {
                widget.style.color =
                    entry.color;
            }
        }
    );
}

/* apply the saved per card styles once the
   state above them is declared */

monitorApplyCardStyles();

const monitorTableState = {
    color: <?= json_encode(
        $monitorHexOk($monitorTableColor)
            ? $monitorTableColor
            : '#ffffff'
    ) ?>,
    alt: <?= json_encode(
        $monitorHexOk($monitorTableAltColor)
            ? $monitorTableAltColor
            : '#ffffff'
    ) ?>,
    transparency: <?= (int)$monitorTableOpacity ?>
};

function monitorCardCss(
    color,
    transparency
) {

    const r =
        parseInt(
            String(color).slice(1, 3),
            16
        );

    const g =
        parseInt(
            String(color).slice(3, 5),
            16
        );

    const b =
        parseInt(
            String(color).slice(5, 7),
            16
        );

    const alpha =
        (
            (100 - transparency)
            / 100
        ).toFixed(2);

    return (
        'rgba('
        + r + ',' + g + ',' + b + ','
        + alpha + ')'
    );
}

function monitorSetBodyBg(
    property,
    value
) {

    /* the background is painted
       with important so it always
       beats the theme */

    if (value === '') {
        monitorCanvas.style
            .removeProperty(property);
    } else {
        monitorCanvas.style
            .setProperty(
                property,
                value,
                'important'
            );
    }
}

function monitorSaveBackground(
    settings
) {

    return fetch(
        'monitor-background-api.php',
        {
            method: 'POST',
            headers: {
                'Content-Type':
                    'application/json'
            },
            body: JSON.stringify({
                settings: settings
            })
        }
    )
        .then(
            (response) => response.json()
        )
        .then((data) => {

            if (
                !data
                || !data.success
            ) {
                throw new Error(
                    (data && data.message)
                    || 'save failed'
                );
            }

            return data;
        });
}

const monitorBgColorInput =
    document.getElementById(
        'monitorBgColor'
    );

if (monitorBgColorInput) {

    /* live preview while the picker
       is open, save when it closes */

    monitorBgColorInput
        .addEventListener(
            'input',
            () => {
                monitorSetBodyBg(
                    'background-color',
                    monitorBgColorInput.value
                );
            }
        );

    monitorBgColorInput
        .addEventListener(
            'change',
            () => {

                monitorBgState.color =
                    monitorBgColorInput.value;

                monitorSaveBackground({
                    monitor_background_color:
                        monitorBgColorInput.value
                })
                    .catch(() => {});
            }
        );
}

const monitorBgImageBtn =
    document.getElementById(
        'monitorBgImageBtn'
    );

const monitorBgFile =
    document.getElementById(
        'monitorBgFile'
    );

if (
    monitorBgImageBtn
    && monitorBgFile
) {

    monitorBgImageBtn.addEventListener(
        'click',
        () => {
            monitorBgFile.click();
        }
    );

    monitorBgFile.addEventListener(
        'change',
        () => {

            const file =
                monitorBgFile.files
                ? monitorBgFile.files[0]
                : null;

            if (!file) {
                return;
            }

            const form =
                new FormData();

            form.append(
                'background',
                file
            );

            fetch(
                'monitor-background-upload.php',
                {
                    method: 'POST',
                    body: form
                }
            )
                .then(
                    (response) =>
                        response.json()
                )
                .then((data) => {

                    if (
                        !data
                        || !data.success
                    ) {
                        throw new Error(
                            'upload failed'
                        );
                    }

                    monitorBgState.image =
                        data.monitor_background_image;

                    monitorSetBodyBg(
                        'background-image',
                        'url('
                        + data.monitor_background_image
                        + ')'
                    );

                    monitorSetBodyBg(
                        'background-size',
                        'cover'
                    );

                    monitorSetBodyBg(
                        'background-position',
                        'center'
                    );

                    monitorSetBodyBg(
                        'background-repeat',
                        'no-repeat'
                    );
                })
                .catch(() => {
                    window.alert(
                        'The background upload '
                        + 'failed.'
                    );
                });

            monitorBgFile.value = '';
        }
    );
}

/* card background colour */

const monitorCardColorInput =
    document.getElementById(
        'monitorCardColor'
    );

if (monitorCardColorInput) {

    monitorCardColorInput
        .addEventListener(
            'input',
            () => {
                monitorCardEl.style
                    .setProperty(
                        '--monitor-card-background',
                        monitorCardCss(
                            monitorCardColorInput.value,
                            monitorCardState
                                .transparency
                        )
                    );
            }
        );

    monitorCardColorInput
        .addEventListener(
            'change',
            () => {

                monitorCardState.color =
                    monitorCardColorInput.value;

                monitorSaveBackground({
                    monitor_card_background:
                        monitorCardColorInput.value
                })
                    .catch(() => {});
            }
        );
}

/* the transparency slider: live
   preview while sliding, saved on
   release like the colour pickers */

const monitorCardOpacityInput =
    document.getElementById(
        'monitorCardOpacity'
    );

if (monitorCardOpacityInput) {

    monitorCardOpacityInput
        .addEventListener(
            'input',
            () => {
                monitorCardEl.style
                    .setProperty(
                        '--monitor-card-background',
                        monitorCardCss(
                            monitorCardState.color,
                            Number(
                                monitorCardOpacityInput.value
                            )
                        )
                    );
            }
        );

    monitorCardOpacityInput
        .addEventListener(
            'change',
            () => {

                monitorCardState.transparency =
                    Number(
                        monitorCardOpacityInput.value
                    );

                monitorSaveBackground({
                    monitor_card_opacity:
                        String(
                            monitorCardState
                                .transparency
                        )
                })
                    .catch(() => {});
            }
        );
}

/* table colour controls: the header and
   alternate row colours share one
   transparency, exactly like the cards */

function monitorTableApply() {

    monitorCardEl.style
        .setProperty(
            '--monitor-table-bg',
            monitorCardCss(
                monitorTableState.color,
                monitorTableState.transparency
            )
        );

    monitorCardEl.style
        .setProperty(
            '--monitor-table-alt',
            monitorCardCss(
                monitorTableState.alt,
                monitorTableState.transparency
            )
        );
}

const monitorTableColorInput =
    document.getElementById(
        'monitorTableColor'
    );

if (monitorTableColorInput) {

    monitorTableColorInput
        .addEventListener(
            'input',
            () => {

                monitorTableState.color =
                    monitorTableColorInput.value;

                monitorTableApply();
            }
        );

    monitorTableColorInput
        .addEventListener(
            'change',
            () => {
                monitorSaveBackground({
                    monitor_table_color:
                        monitorTableColorInput.value
                })
                    .catch(() => {});
            }
        );
}

const monitorTableAltInput =
    document.getElementById(
        'monitorTableAltColor'
    );

if (monitorTableAltInput) {

    monitorTableAltInput
        .addEventListener(
            'input',
            () => {

                monitorTableState.alt =
                    monitorTableAltInput.value;

                monitorTableApply();
            }
        );

    monitorTableAltInput
        .addEventListener(
            'change',
            () => {
                monitorSaveBackground({
                    monitor_table_alt_color:
                        monitorTableAltInput.value
                })
                    .catch(() => {});
            }
        );
}

const monitorTableGridInput =
    document.getElementById(
        'monitorTableGridColor'
    );

if (monitorTableGridInput) {

    monitorTableGridInput
        .addEventListener(
            'input',
            () => {
                monitorCardEl.style
                    .setProperty(
                        '--monitor-table-grid',
                        monitorTableGridInput.value
                    );
            }
        );

    monitorTableGridInput
        .addEventListener(
            'change',
            () => {
                monitorSaveBackground({
                    monitor_table_grid_color:
                        monitorTableGridInput.value
                })
                    .catch(() => {});
            }
        );
}

const monitorTextInput =
    document.getElementById(
        'monitorTextColor'
    );

if (monitorTextInput) {

    monitorTextInput
        .addEventListener(
            'input',
            () => {
                monitorCardEl.style
                    .setProperty(
                        '--monitor-text',
                        monitorTextInput.value
                    );

                monitorCardEl
                    .setAttribute(
                        'data-text-set',
                        '1'
                    );
            }
        );

    monitorTextInput
        .addEventListener(
            'change',
            () => {
                monitorSaveBackground({
                    monitor_text_color:
                        monitorTextInput.value
                })
                    .catch(() => {});
            }
        );
}

const monitorTableOpacityInput =
    document.getElementById(
        'monitorTableOpacity'
    );

if (monitorTableOpacityInput) {

    monitorTableOpacityInput
        .addEventListener(
            'input',
            () => {

                monitorTableState.transparency =
                    Number(
                        monitorTableOpacityInput.value
                    );

                monitorTableApply();
            }
        );

    monitorTableOpacityInput
        .addEventListener(
            'change',
            () => {
                monitorSaveBackground({
                    monitor_table_opacity:
                        String(
                            monitorTableState
                                .transparency
                        )
                })
                    .catch(() => {});
            }
        );
}

/* table defaults: strip every custom
   table + text style in one click -
   colour pickers can hold no 'empty'
   value, so removal needs a button */

const monitorTableResetBtn =
    document.getElementById(
        'monitorTableReset'
    );

if (monitorTableResetBtn) {

    monitorTableResetBtn
        .addEventListener(
            'click',
            () => {

                [
                    '--monitor-table-bg',
                    '--monitor-table-alt',
                    '--monitor-table-grid',
                    '--monitor-text'
                ].forEach((property) => {
                    monitorCardEl.style
                        .removeProperty(
                            property
                        );
                });

                monitorCardEl
                    .removeAttribute(
                        'data-text-set'
                    );

                monitorTableState.color =
                    '#ffffff';

                monitorTableState.alt =
                    '#ffffff';

                monitorTableState
                    .transparency = 100;

                if (monitorTableColorInput) {
                    monitorTableColorInput
                        .value = '#ffffff';
                }

                if (monitorTableAltInput) {
                    monitorTableAltInput
                        .value = '#ffffff';
                }

                if (monitorTableGridInput) {
                    monitorTableGridInput
                        .value = '#ffffff';
                }

                if (monitorTextInput) {
                    monitorTextInput
                        .value = '#ffffff';
                }

                if (monitorTableOpacityInput) {
                    monitorTableOpacityInput
                        .value = 100;
                }

                monitorSaveBackground({
                    monitor_table_color: '',
                    monitor_table_alt_color: '',
                    monitor_table_grid_color: '',
                    monitor_text_color: '',
                    monitor_table_opacity: '100'
                })
                    .catch(() => {});
            }
        );
}

/* table grid on/off */

const monitorTableGridToggle =
    document.getElementById(
        'monitorTableGridToggle'
    );

if (monitorTableGridToggle) {

    monitorTableGridToggle
        .addEventListener(
            'click',
            () => {

                const off =
                    monitorCardEl
                        .classList
                        .toggle(
                            'hide-table-grid'
                        );

                monitorTableGridToggle
                    .setAttribute(
                        'aria-pressed',
                        off
                            ? 'true'
                            : 'false'
                    );

                monitorSaveBackground({
                    monitor_table_grid_enabled:
                        off ? '0' : '1'
                })
                    .catch(() => {});
            }
        );
}

const monitorBgClearBtn =
    document.getElementById(
        'monitorBgClearBtn'
    );

if (monitorBgClearBtn) {

    monitorBgClearBtn.addEventListener(
        'click',
        () => {

            monitorBgState.image = '';
            monitorBgState.color = '';

            [
                'background-image',
                'background-size',
                'background-position',
                'background-repeat',
                'background-color'
            ].forEach((property) => {
                monitorSetBodyBg(
                    property,
                    ''
                );
            });

            if (monitorBgColorInput) {
                monitorBgColorInput.value =
                    '#10161c';
            }

            if (monitorCardColorInput) {
                monitorCardColorInput.value =
                    '#1e2a33';
            }

            if (monitorCardOpacityInput) {
                monitorCardOpacityInput.value =
                    12;
            }

            monitorCardState.color = '#1e2a33';

            monitorCardState.transparency = 12;

            monitorCardEl.style
                .setProperty(
                    '--monitor-card-background',
                    monitorCardCss(
                        '#1e2a33',
                        12
                    )
                );

            /* the table styling resets with
               everything else */

            [
                '--monitor-table-bg',
                '--monitor-table-alt',
                '--monitor-table-grid',
                '--monitor-text'
            ].forEach((property) => {
                monitorCardEl.style
                    .removeProperty(
                        property
                    );
            });

            monitorCardEl
                .removeAttribute(
                    'data-text-set'
                );

            monitorTableState.color = '#ffffff';

            monitorTableState.alt = '#ffffff';

            monitorTableState.transparency =
                100;

            if (monitorTableColorInput) {
                monitorTableColorInput.value =
                    '#ffffff';
            }

            if (monitorTableAltInput) {
                monitorTableAltInput.value =
                    '#ffffff';
            }

            if (monitorTableGridInput) {
                monitorTableGridInput.value =
                    '#ffffff';
            }

            if (monitorTextInput) {
                monitorTextInput.value =
                    '#ffffff';
            }

            if (monitorTableOpacityInput) {
                monitorTableOpacityInput.value =
                    100;
            }

            monitorCardEl.classList
                .remove(
                    'hide-table-grid'
                );

            if (monitorTableGridToggle) {
                monitorTableGridToggle
                    .setAttribute(
                        'aria-pressed',
                        'false'
                    );
            }

            monitorSaveBackground({
                monitor_background_image: '',
                monitor_background_color: '',
                monitor_card_background: '',
                monitor_card_opacity: '12',
                monitor_table_color: '',
                monitor_table_alt_color: '',
                monitor_table_grid_color: '',
                monitor_text_color: '',
                monitor_table_opacity: '100',
                monitor_table_grid_enabled: '1'
            })
                .catch(() => {});
        }
    );
}

/*
 * Live data.
 */

function refreshMonitorStats() {

    fetch('api/stats')
        .then(
            (response) => response.json()
        )
        .then((data) => {

            if (!data) {
                return;
            }

            const pending =
                document.getElementById(
                    'monitor_pending'
                );

            const approved =
                document.getElementById(
                    'monitor_approved'
                );

            const denied =
                document.getElementById(
                    'monitor_denied'
                );

            if (pending) {
                pending.textContent =
                    data.pending ?? 0;
            }

            if (approved) {
                approved.textContent =
                    data.approved ?? 0;
            }

            if (denied) {
                denied.textContent =
                    data.denied ?? 0;
            }

        })
        .catch(() => {
            /* keep the last known values */
        });
}

function monitorRelativeTime(value) {

    if (!value) {
        return '';
    }

    const seen = new Date(value);

    if (isNaN(seen)) {
        return value;
    }

    const seconds =
        Math.max(
            0,
            Math.floor(
                (Date.now() - seen) / 1000
            )
        );

    if (seconds < 180) {
        return 'Just now';
    }

    const minutes =
        Math.floor(seconds / 60);

    if (minutes < 60) {
        return minutes + 'm ago';
    }

    const hours =
        Math.floor(minutes / 60);

    if (hours < 24) {
        return hours + 'h ago';
    }

    return Math.floor(hours / 24)
        + 'd ago';
}

function refreshMonitorConnectivity() {

    const body =
        document.getElementById(
            'monitor_connectivity_body'
        );

    if (!body) {
        return;
    }

    fetch('connectivity-api.php')
        .then(
            (response) => response.json()
        )
        .then((data) => {

            if (!Array.isArray(data)) {
                return;
            }

            body.textContent = '';

            if (data.length === 0) {

                const row =
                    document.createElement(
                        'tr'
                    );

                const cell =
                    document.createElement(
                        'td'
                    );

                cell.colSpan = 7;
                cell.textContent =
                    'No servers have '
                    + 'reported yet.';

                row.appendChild(cell);
                body.appendChild(row);
                return;
            }

            for (const server of data) {

                const row =
                    document.createElement(
                        'tr'
                    );

                const cells = [
                    server.hostname ?? '',
                    server.ip_address ?? '',
                    server.cpu_percent === null
                        ? '-'
                        : server.cpu_percent + '%',
                    server.memory_percent === null
                        ? '-'
                        : server.memory_percent + '%',
                    server.disk_percent === null
                        ? '-'
                        : server.disk_percent + '%',
                    monitorRelativeTime(
                        server.last_seen
                    )
                ];

                for (const value of cells) {

                    const cell =
                        document.createElement(
                            'td'
                        );

                    cell.textContent = value;
                    row.appendChild(cell);
                }

                const statusCell =
                    document.createElement(
                        'td'
                    );

                const badge =
                    document.createElement(
                        'span'
                    );

                const online =
                    server.online === true
                    || (server.status ?? '')
                        === 'online';

                badge.className =
                    online
                        ? 'badge-active'
                        : 'badge-disabled';

                badge.textContent =
                    online
                        ? 'Online'
                        : 'Offline';

                statusCell.appendChild(
                    badge
                );

                row.appendChild(
                    statusCell
                );

                body.appendChild(row);
            }

        })
        .catch(() => {
            /* keep the last known state */
        });
}

/*
 * Technitium DNS widgets: the live
 * queries graph and the top users
 * list. Both read the dashboard
 * stats proxy and refresh every 10
 * seconds; hidden widgets are
 * skipped until they are placed.
 */

function monitorDrawDnsGraph(data) {

    const svg =
        document.getElementById(
            'monitor_dns_graph'
        );

    const wrap = svg.parentElement;

    const width =
        Math.max(320, wrap.clientWidth);

    /* the chart fills the card's
       free vertical space */

    const height =
        Math.max(
            140,
            Math.round(wrap.clientHeight)
        );

    const padLeft = 8;
    const padRight = 8;
    const padTop = 12;
    const padBottom = 22;

    const total = data.total;
    const blocked = data.blocked;
    const labels = data.labels;

    const count = total.length;

    if (count < 2) {
        return;
    }

    let maxValue = 1;

    for (let i = 0; i < count; i++) {

        if (total[i] > maxValue) {
            maxValue = total[i];
        }
    }

    const stepX =
        (width - padLeft - padRight)
        / (count - 1);

    const pointX = (i) =>
        padLeft + (i * stepX);

    const pointY = (v) =>
        height - padBottom
        - ((v / maxValue)
            * (height - padTop - padBottom));

    const linePoints =
        (series) => {

            let path = '';

            for (
                let i = 0;
                i < count;
                i++
            ) {
                path +=
                    (i === 0 ? 'M' : 'L')
                    + pointX(i).toFixed(1)
                    + ' '
                    + pointY(series[i])
                        .toFixed(1)
                    + ' ';
            }

            return path;
        };

    const areaPoints =
        (series) => {

            let path = linePoints(series);

            path +=
                'L'
                + pointX(count - 1).toFixed(1)
                + ' '
                + (height - padBottom)
                + ' L'
                + pointX(0).toFixed(1)
                + ' '
                + (height - padBottom)
                + ' Z';

            return path;
        };

    let parts = '';

    /* horizontal grid lines */

    const gridSteps = [0, 0.5, 1];

    for (const step of gridSteps) {

        const y =
            padTop
            + (
                step
                * (
                    height
                    - padTop
                    - padBottom
                )
            );

        parts +=
            '<line x1="' + padLeft
            + '" y1="' + y.toFixed(1)
            + '" x2="'
            + (width - padRight).toFixed(1)
            + '" y2="' + y.toFixed(1)
            + '" stroke="'
            + 'rgba(255,255,255,0.14)'
            + '" stroke-width="1" />';
    }

    /* peak marker at the top right */

    parts +=
        '<text x="'
        + (width - padRight).toFixed(1)
        + '" y="' + (padTop - 1)
        + '" fill="'
        + 'rgba(255,255,255,0.45)'
        + '" font-size="11" '
        + 'font-weight="600" '
        + 'text-anchor="end">'
        + 'peak '
        + maxValue.toLocaleString()
        + '</text>';

    /* total series */

    parts +=
        '<path d="' + areaPoints(total)
        + '" fill="'
        + 'rgba(102,153,255,0.16)'
        + '" stroke="none" />';

    parts +=
        '<path d="' + linePoints(total)
        + '" fill="none" stroke="'
        + 'rgb(102,153,255)'
        + '" stroke-width="2" '
        + 'stroke-linejoin="round" '
        + 'stroke-linecap="round" />';

    /* blocked series */

    parts +=
        '<path d="' + areaPoints(blocked)
        + '" fill="'
        + 'rgba(217,83,79,0.22)'
        + '" stroke="none" />';

    parts +=
        '<path d="' + linePoints(blocked)
        + '" fill="none" stroke="'
        + 'rgb(217,83,79)'
        + '" stroke-width="2" '
        + 'stroke-linejoin="round" '
        + 'stroke-linecap="round" />';

    /* time labels, sparse */

    const labelEvery =
        Math.max(
            1,
            Math.round(count / 6)
        );

    for (
        let i = 0;
        i < count;
        i++
    ) {

        if (
            i % labelEvery !== 0
            && i !== count - 1
        ) {
            continue;
        }

        /* the first and last labels are
           anchored to the edges so they
           stay inside the chart */

        let anchor = 'middle';

        let labelX = pointX(i);

        if (i === 0) {
            anchor = 'start';
            labelX = padLeft;
        }

        if (i === count - 1) {
            anchor = 'end';
            labelX = width - padRight;
        }

        parts +=
            '<text x="'
            + labelX.toFixed(1)
            + '" y="'
            + (height - 6)
            + '" fill="'
            + 'rgba(255,255,255,0.55)'
            + '" font-size="12" '
            + 'font-weight="600" '
            + 'text-anchor="'
            + anchor
            + '">'
            + (labels[i] ?? '')
            + '</text>';
    }

    svg.setAttribute(
        'viewBox',
        '0 0 ' + width + ' ' + height
    );

    svg.innerHTML = parts;
}

function refreshMonitorDnsGraph() {

    const node =
        monitorWidgetNode('dnsgraph');

    if (
        !node
        || node.hidden
    ) {
        return;
    }

    fetch(
        'technitium-stats-api.php?action=graph'
    )
        .then(
            (response) => response.json()
        )
        .then((data) => {

            if (
                !data
                || !data.success
                || !Array.isArray(data.total)
            ) {
                return;
            }

            const queries =
                document.getElementById(
                    'monitor_dns_total'
                );

            const blocked =
                document.getElementById(
                    'monitor_dns_blocked'
                );

            const clients =
                document.getElementById(
                    'monitor_dns_clients'
                );

            if (queries) {
                queries.textContent =
                    (data.total_queries ?? 0)
                        .toLocaleString();
            }

            if (blocked) {
                blocked.textContent =
                    (data.total_blocked ?? 0)
                        .toLocaleString();
            }

            if (clients) {
                clients.textContent =
                    (data.total_clients ?? 0)
                        .toLocaleString();
            }

            monitorDrawDnsGraph(data);

            /* the ratio donut and the
               server tiles share this
               payload */

            monitorUpdateDnsRatio(data);
            monitorUpdateDnsServer(data);

        })
        .catch(() => {
            /* keep the last known chart */
        });
}

function refreshMonitorDnsTopList(
    id,
    statsType,
    listId,
    barClass
) {

    const node =
        monitorWidgetNode(id);

    if (
        !node
        || node.hidden
    ) {
        return;
    }

    fetch(
        'technitium-stats-api.php'
        + '?action=top'
        + '&statsType=' + statsType
        + '&limit=10'
    )
        .then(
            (response) => response.json()
        )
        .then((data) => {

            const list =
                document.getElementById(
                    listId
                );

            if (
                !list
                || !data
                || !data.success
                || !Array.isArray(data.items)
            ) {
                return;
            }

            list.textContent = '';

            if (data.items.length === 0) {

                const empty =
                    document.createElement(
                        'div'
                    );

                empty.className =
                    'monitor-top-empty';

                empty.textContent =
                    'No DNS clients yet.';

                list.appendChild(empty);

                return;
            }

            const maxHits =
                Math.max(
                    1,
                    ...data.items.map(
                        (item) => item.hits
                    )
                );

            data.items.forEach(
                (item, index) => {

                    const row =
                        document.createElement(
                            'div'
                        );

                    row.className =
                        'monitor-top-row';

                    const rank =
                        document.createElement(
                            'span'
                        );

                    rank.className =
                        'monitor-top-rank';

                    rank.textContent =
                        index + 1;

                    const name =
                        document.createElement(
                            'div'
                        );

                    name.className =
                        'monitor-top-name';

                    const nameText =
                        document.createElement(
                            'span'
                        );

                    nameText.className =
                        'monitor-top-name-text';

                    nameText.textContent =
                        item.name || '-';

                    const bar =
                        document.createElement(
                            'div'
                        );

                    bar.className =
                        'monitor-top-bar';

                    const barFill =
                        document.createElement(
                            'div'
                        );

                    barFill.className =
                        'monitor-top-bar-fill'
                        + (barClass
                            ? ' ' + barClass
                            : '');

                    barFill.style.width =
                        ((item.hits / maxHits)
                            * 100)
                        + '%';

                    bar.appendChild(barFill);

                    name.appendChild(nameText);
                    name.appendChild(bar);

                    const hits =
                        document.createElement(
                            'span'
                        );

                    hits.className =
                        'monitor-top-hits';

                    hits.textContent =
                        (item.hits ?? 0)
                            .toLocaleString();

                    row.appendChild(rank);
                    row.appendChild(name);
                    row.appendChild(hits);

                    list.appendChild(row);
                }
            );

        })
        .catch(() => {
            /* keep the last known list */
        });
}

function refreshMonitorDnsTop() {

    refreshMonitorDnsTopList(
        'dnstop',
        'TopClients',
        'monitor_dns_top',
        ''
    );
}

function refreshMonitorDnsBlocked() {

    refreshMonitorDnsTopList(
        'dnsblocked',
        'TopBlockedDomains',
        'monitor_dns_blocked_list',
        'blocked'
    );
}

/*
 * The Blocked Ratio donut and the
 * DNS Server tiles read the same
 * stats the graph fetch brings in.
 */

function monitorUpdateDnsRatio(data) {

    const node =
        monitorWidgetNode('dnsratio');

    if (
        !node
        || node.hidden
    ) {
        return;
    }

    const queries =
        data.total_queries ?? 0;

    const blocked =
        data.total_blocked ?? 0;

    const ratio =
        queries > 0
            ? blocked / queries
            : 0;

    const value =
        document.getElementById(
            'monitor_dns_ratio_value'
        );

    if (value) {
        value.textContent =
            (ratio * 100).toFixed(1)
                + '%';
    }

    const detail =
        document.getElementById(
            'monitor_dns_ratio_detail'
        );

    if (detail) {
        detail.textContent =
            blocked.toLocaleString()
            + ' blocked of '
            + queries.toLocaleString()
            + ' queries';
    }

    const donut =
        document.getElementById(
            'monitor_dns_ratio_donut'
        );

    if (!donut) {
        return;
    }

    const radius = 52;

    const circumference =
        2 * Math.PI * radius;

    const dash =
        circumference * Math.min(
            1,
            ratio
        );

    donut.innerHTML =
        '<circle'
        + ' cx="60" cy="60"'
        + ' r="' + radius + '"'
        + ' fill="none"'
        + ' stroke="'
        + 'rgba(255,255,255,0.09)"'
        + ' stroke-width="12"'
        + ' />'
        + '<circle'
        + ' cx="60" cy="60"'
        + ' r="' + radius + '"'
        + ' fill="none"'
        + ' stroke="#ef4444"'
        + ' stroke-width="12"'
        + ' stroke-linecap="round"'
        + ' stroke-dasharray="'
        + dash.toFixed(1)
        + ' '
        + circumference.toFixed(1)
        + '"'
        + ' transform="'
        + 'rotate(-90 60 60)"'
        + ' />';
}

function monitorUpdateDnsServer(data) {

    const node =
        monitorWidgetNode('dnsserver');

    if (
        !node
        || node.hidden
    ) {
        return;
    }

    const cache =
        document.getElementById(
            'monitor_dns_server_cache'
        );

    const blockLists =
        document.getElementById(
            'monitor_dns_server_blocklists'
        );

    const zones =
        document.getElementById(
            'monitor_dns_server_zones'
        );

    if (cache) {
        cache.textContent =
            (data.cached_entries ?? 0)
                .toLocaleString();
    }

    if (blockLists) {
        blockLists.textContent =
            (data.block_list_zones ?? 0)
                .toLocaleString();
    }

    if (zones) {
        zones.textContent =
            (data.zones ?? 0)
                .toLocaleString();
    }
}

refreshMonitorStats();
refreshMonitorConnectivity();
refreshMonitorDnsGraph();
refreshMonitorDnsTop();
refreshMonitorDnsBlocked();
refreshMonitorGauges();
refreshMonitorDnsTotals();
refreshMonitorDhcp();
refreshMonitorUnblocks();
refreshMonitorLogins();
refreshMonitorEvents();
refreshMonitorWeather();

/* one master ticker: every card
   refreshes on its own speed,
   chosen in the card editor.
   Hidden and paused cards are
   skipped entirely */

const monitorRefreshCards = {
    pending: {
        fn: refreshMonitorStats,
        every: 30
    },
    approved: {
        fn: refreshMonitorStats,
        every: 30
    },
    denied: {
        fn: refreshMonitorStats,
        every: 30
    },
    connectivity: {
        fn: refreshMonitorConnectivity,
        every: 30
    },
    gauges: {
        fn: refreshMonitorGauges,
        every: 30
    },
    dnstotals: {
        fn: refreshMonitorDnsTotals,
        every: 30
    },
    dhcp: {
        fn: refreshMonitorDhcp,
        every: 30
    },
    unblocks: {
        fn: refreshMonitorUnblocks,
        every: 30
    },
    logins: {
        fn: refreshMonitorLogins,
        every: 30
    },
    events: {
        fn: refreshMonitorEvents,
        every: 30
    },
    weather: {
        fn: refreshMonitorWeather,
        every: 60
    },
    dnsgraph: {
        fn: refreshMonitorDnsGraph,
        every: 10
    },
    dnsratio: {
        fn: refreshMonitorDnsGraph,
        every: 10
    },
    dnsserver: {
        fn: refreshMonitorDnsGraph,
        every: 10
    },
    dnstop: {
        fn: refreshMonitorDnsTop,
        every: 10
    },
    dnsblocked: {
        fn: refreshMonitorDnsBlocked,
        every: 10
    }
};

const monitorRefreshState = {};

window.setInterval(() => {

    const now = Date.now();

    const ran = [];

    for (
        const id
        in monitorRefreshCards
    ) {

        const node =
            monitorWidgetNode(id);

        if (!node || node.hidden) {
            continue;
        }

        const entry =
            monitorCardStyles[id]
            || {};

        const speed =
            entry.refresh
            || 'normal';

        if (speed === 'paused') {
            continue;
        }

        const cfg =
            monitorRefreshCards[id];

        let every = cfg.every;

        if (speed === 'fast') {
            every = Math.min(
                every,
                10
            );
        }

        if (speed === 'slow') {
            every = Math.max(
                every,
                60
            );
        }

        const last =
            monitorRefreshState[id]
            || 0;

        if (now - last < every * 1000) {
            continue;
        }

        monitorRefreshState[id] =
            now;

        if (ran.includes(cfg.fn)) {
            continue;
        }

        ran.push(cfg.fn);

        cfg.fn();
    }

    /* the slide rotation re-arms here
       while the board is idle; editing
       keeps it disarmed */

    if (!monitorRotateTimer) {
        monitorArmRotation();
    }
}, 5000);

/*
 * Server gauges widget: CPU, memory
 * and disk bars for every reporting
 * server, plus its heartbeat age.
 */

function refreshMonitorGauges() {

    const body =
        document.getElementById(
            'monitor_gauges_body'
        );

    if (!body) {
        return;
    }

    fetch('connectivity-api.php')
        .then(
            (response) =>
                response.json()
        )
        .then((data) => {

            if (!Array.isArray(data)) {
                return;
            }

            body.textContent = '';

            if (data.length === 0) {

                body.textContent =
                    'No servers have '
                    + 'reported yet.';

                return;
            }

            for (const server of data) {

                const row =
                    document.createElement(
                        'div'
                    );

                row.className =
                    'monitor-gauge-row';

                const head =
                    document.createElement(
                        'div'
                    );

                head.className =
                    'monitor-gauge-head';

                const name =
                    document.createElement(
                        'span'
                    );

                name.className =
                    'monitor-gauge-name';

                name.textContent =
                    server.hostname
                    ?? 'Server';

                const age =
                    document.createElement(
                        'span'
                    );

                age.className =
                    'monitor-gauge-age';

                age.textContent =
                    monitorRelativeTime(
                        server.last_seen
                    );

                head.appendChild(name);
                head.appendChild(age);

                const bars =
                    document.createElement(
                        'div'
                    );

                bars.className =
                    'monitor-gauge-bars';

                const items = [
                    ['CPU', server.cpu_percent],
                    ['Mem', server.memory_percent],
                    ['Disk', server.disk_percent]
                ];

                for (const item of items) {

                    const bar =
                        document.createElement(
                            'div'
                        );

                    bar.className =
                        'monitor-gauge-bar';

                    const label =
                        document.createElement(
                            'span'
                        );

                    label.className =
                        'monitor-gauge-bar-label';

                    label.textContent = item[0];

                    const track =
                        document.createElement(
                            'span'
                        );

                    track.className =
                        'monitor-gauge-track';

                    const fill =
                        document.createElement(
                            'span'
                        );

                    fill.className =
                        'monitor-gauge-fill';

                    const value =
                        item[1];

                    if (
                        value === null
                        || value === undefined
                    ) {

                        fill.style.width = '0%';

                    } else {

                        const pct =
                            Math.min(
                                100,
                                Math.max(
                                    0,
                                    value
                                )
                            );

                        fill.style.width =
                            pct + '%';

                        fill.classList.add(
                            pct >= 85
                                ? 'monitor-gauge-fill-red'
                                : (
                                    pct >= 60
                                        ? 'monitor-gauge-fill-amber'
                                        : 'monitor-gauge-fill-green'
                                )
                        );
                    }

                    track.appendChild(fill);

                    bar.appendChild(label);
                    bar.appendChild(track);

                    bars.appendChild(bar);
                }

                row.appendChild(head);
                row.appendChild(bars);

                body.appendChild(row);
            }
        })
        .catch(() => {
            /* keep the last known state */
        });
}

/*
 * DNS totals widget: the dashboard
 * counters from the DNS server.
 */

function refreshMonitorDnsTotals() {

    const tiles = {
        total: document.getElementById(
            'monitor_dns_totals_queries'
        ),
        blocked: document.getElementById(
            'monitor_dns_totals_blocked'
        ),
        pct: document.getElementById(
            'monitor_dns_totals_pct'
        ),
        clients: document.getElementById(
            'monitor_dns_totals_clients'
        ),
        cached: document.getElementById(
            'monitor_dns_totals_cached'
        ),
        blocklists: document.getElementById(
            'monitor_dns_totals_blocklists'
        )
    };

    if (!tiles.total) {
        return;
    }

    fetch(
        'technitium-stats-api.php'
        + '?action=summary'
    )
        .then(
            (response) =>
                response.json()
        )
        .then((data) => {

            if (!data) {
                return;
            }

            const num = (value) =>
                value === null
                || value === undefined
                    ? '-'
                    : Number(
                        value
                    ).toLocaleString();

            tiles.total.textContent =
                num(data.totalQueries);

            tiles.blocked.textContent =
                num(data.totalBlocked);

            tiles.pct.textContent =
                data.totalQueries > 0
                    ? (
                        (
                            data.totalBlocked
                            / data.totalQueries
                        ) * 100
                    ).toFixed(1) + '%'
                    : '-';

            tiles.clients.textContent =
                num(data.totalClients);

            tiles.cached.textContent =
                num(data.cachedEntries);

            tiles.blocklists.textContent =
                num(data.blockListZones);
        })
        .catch(() => {
            /* keep the last known state */
        });
}

/*
 * DHCP widget: the DNS server's
 * scopes and their live leases.
 */

function refreshMonitorDhcp() {

    const scopesEl =
        document.getElementById(
            'monitor_dhcp_scopes'
        );

    const listEl =
        document.getElementById(
            'monitor_dhcp_leases'
        );

    if (!scopesEl || !listEl) {
        return;
    }

    fetch(
        'technitium-stats-api.php'
        + '?action=dhcp'
    )
        .then(
            (response) =>
                response.json()
        )
        .then((data) => {

            const scopes =
                Array.isArray(
                    data && data.scopes
                )
                    ? data.scopes
                    : [];

            const leases =
                Array.isArray(
                    data && data.leases
                )
                    ? data.leases
                    : [];

            scopesEl.textContent = '';

            if (scopes.length === 0) {

                scopesEl.textContent =
                    'No DHCP scopes '
                    + 'configured.';

            } else {

                for (const scope of scopes) {

                    const row =
                        document.createElement(
                            'div'
                        );

                    row.className =
                        'monitor-dhcp-scope';

                    const name =
                        document.createElement(
                            'span'
                        );

                    name.className =
                        'monitor-dhcp-scope-name';

                    name.textContent =
                        scope.name
                        ?? 'Scope';

                    const badge =
                        document.createElement(
                            'span'
                        );

                    badge.className =
                        scope.enabled
                            ? 'badge-active'
                            : 'badge-disabled';

                    badge.textContent =
                        scope.enabled
                            ? 'Active'
                            : 'Disabled';

                    const range =
                        document.createElement(
                            'span'
                        );

                    range.className =
                        'monitor-dhcp-scope-range';

                    range.textContent =
                        (scope.startingAddress ?? '')
                        + ' - '
                        + (scope.endingAddress ?? '');

                    row.appendChild(name);
                    row.appendChild(badge);
                    row.appendChild(range);

                    scopesEl.appendChild(row);
                }
            }

            listEl.textContent = '';

            if (leases.length === 0) {

                const empty =
                    document.createElement(
                        'div'
                    );

                empty.className =
                    'monitor-top-empty';

                empty.textContent =
                    'No DHCP leases.';

                listEl.appendChild(empty);

                return;
            }

            for (const lease of leases) {

                const row =
                    document.createElement(
                        'div'
                    );

                row.className =
                    'monitor-lease';

                const ip =
                    document.createElement(
                        'span'
                    );

                ip.className =
                    'monitor-lease-ip';

                ip.textContent =
                    lease.address
                    ?? lease.ip
                    ?? '-';

                const host =
                    document.createElement(
                        'span'
                    );

                host.className =
                    'monitor-lease-host';

                host.textContent =
                    lease.hostname
                    ?? lease.hostName
                    ?? '-';

                const mac =
                    document.createElement(
                        'span'
                    );

                mac.className =
                    'monitor-lease-mac';

                mac.textContent =
                    lease.macAddress
                    ?? lease.mac
                    ?? '-';

                const exp =
                    document.createElement(
                        'span'
                    );

                exp.className =
                    'monitor-lease-exp';

                const raw =
                    lease.leaseExpires
                    ?? lease.expiry;

                if (
                    raw === null
                    || raw === undefined
                    || raw === ''
                ) {

                    exp.textContent = '-';

                } else {

                    const when =
                        typeof raw === 'number'
                            ? new Date(
                                raw < 1e12
                                    ? raw * 1000
                                    : raw
                            )
                            : new Date(
                                String(raw)
                                    .replace(
                                        ' ',
                                        'T'
                                    )
                            );

                    exp.textContent =
                        isNaN(
                            when.getTime()
                        )
                            ? String(raw)
                            : monitorRelativeTime(
                                when.toISOString()
                            );
                }

                row.appendChild(ip);
                row.appendChild(host);
                row.appendChild(mac);
                row.appendChild(exp);

                listEl.appendChild(row);
            }
        })
        .catch(() => {
            /* keep the last known state */
        });
}

/*
 * Unblock queue widget: portal
 * unblock requests waiting for
 * a decision.
 */

function refreshMonitorUnblocks() {

    const body =
        document.getElementById(
            'monitor_unblocks_body'
        );

    if (!body) {
        return;
    }

    fetch(
        'monitor-activity-api.php'
        + '?action=unblocks'
    )
        .then(
            (response) =>
                response.json()
        )
        .then((data) => {

            if (!Array.isArray(data)) {
                return;
            }

            body.textContent = '';

            if (data.length === 0) {

                const empty =
                    document.createElement(
                        'div'
                    );

                empty.className =
                    'monitor-top-empty';

                empty.textContent =
                    'No unblock requests '
                    + 'waiting.';

                body.appendChild(empty);

                return;
            }

            for (const req of data) {

                const row =
                    document.createElement(
                        'div'
                    );

                row.className =
                    'monitor-feed-row';

                const dot =
                    document.createElement(
                        'span'
                    );

                dot.className =
                    'monitor-feed-dot '
                    + 'monitor-feed-dot-request';

                const main =
                    document.createElement(
                        'span'
                    );

                main.className =
                    'monitor-feed-main';

                main.textContent =
                    req.domain ?? '';

                const sub =
                    document.createElement(
                        'span'
                    );

                sub.className =
                    'monitor-feed-sub';

                sub.textContent =
                    (req.requested_by ?? '?')
                    + (
                        req.allow_minutes
                            ? ' - allow '
                            + req.allow_minutes
                            + ' min'
                            : ''
                    );

                const time =
                    document.createElement(
                        'span'
                    );

                time.className =
                    'monitor-feed-time';

                time.textContent =
                    monitorRelativeTime(
                        req.requested_at
                    );

                row.appendChild(dot);
                row.appendChild(main);
                row.appendChild(sub);
                row.appendChild(time);

                body.appendChild(row);
            }
        })
        .catch(() => {
            /* keep the last known state */
        });
}

/*
 * Login feed widget: the latest
 * sign-in and sign-out events.
 */

function refreshMonitorLogins() {

    const body =
        document.getElementById(
            'monitor_logins_body'
        );

    if (!body) {
        return;
    }

    fetch(
        'monitor-activity-api.php'
        + '?action=logins'
    )
        .then(
            (response) =>
                response.json()
        )
        .then((data) => {

            if (!Array.isArray(data)) {
                return;
            }

            body.textContent = '';

            if (data.length === 0) {

                const empty =
                    document.createElement(
                        'div'
                    );

                empty.className =
                    'monitor-top-empty';

                empty.textContent =
                    'No sign-in events yet.';

                body.appendChild(empty);

                return;
            }

            for (const entry of data) {

                const row =
                    document.createElement(
                        'div'
                    );

                row.className =
                    'monitor-login-row';

                const badge =
                    document.createElement(
                        'span'
                    );

                const event =
                    (entry.event ?? '')
                        .toLowerCase();

                if (
                    event.indexOf('failed')
                        !== -1
                ) {

                    badge.className =
                        'badge-disabled';

                    badge.textContent =
                        'Failed';

                } else if (
                    event.indexOf('logout')
                        !== -1
                ) {

                    badge.className =
                        'badge-disabled';

                    badge.textContent =
                        'Sign-out';

                } else {

                    badge.className =
                        'badge-active';

                    badge.textContent =
                        'Sign-in';
                }

                const user =
                    document.createElement(
                        'span'
                    );

                user.className =
                    'monitor-login-user';

                user.textContent =
                    entry.username ?? '?';

                const time =
                    document.createElement(
                        'span'
                    );

                time.className =
                    'monitor-login-time';

                time.textContent =
                    monitorRelativeTime(
                        entry.created_at
                    );

                row.appendChild(badge);
                row.appendChild(user);
                row.appendChild(time);

                body.appendChild(row);
            }
        })
        .catch(() => {
            /* keep the last known state */
        });
}

/*
 * Live activity widget: logins and
 * DNS request activity in one
 * time ordered ticker.
 */

function refreshMonitorEvents() {

    const body =
        document.getElementById(
            'monitor_events_body'
        );

    if (!body) {
        return;
    }

    fetch(
        'monitor-activity-api.php'
        + '?action=events'
    )
        .then(
            (response) =>
                response.json()
        )
        .then((data) => {

            if (!Array.isArray(data)) {
                return;
            }

            body.textContent = '';

            if (data.length === 0) {

                const empty =
                    document.createElement(
                        'div'
                    );

                empty.className =
                    'monitor-top-empty';

                empty.textContent =
                    'Nothing has happened '
                    + 'yet.';

                body.appendChild(empty);

                return;
            }

            for (const entry of data) {

                const row =
                    document.createElement(
                        'div'
                    );

                row.className =
                    'monitor-feed-row';

                const dot =
                    document.createElement(
                        'span'
                    );

                dot.className =
                    'monitor-feed-dot '
                    + 'monitor-feed-dot-'
                    + (entry.kind ?? 'request');

                const main =
                    document.createElement(
                        'span'
                    );

                main.className =
                    'monitor-feed-main';

                main.textContent =
                    entry.text ?? '';

                const time =
                    document.createElement(
                        'span'
                    );

                time.className =
                    'monitor-feed-time';

                time.textContent =
                    monitorRelativeTime(
                        entry.time
                    );

                row.appendChild(dot);
                row.appendChild(main);
                row.appendChild(time);

                body.appendChild(row);
            }
        })
        .catch(() => {
            /* keep the last known state */
        });
}

/*
 * Weather widget: the same animated
 * icon engine as the banner badge,
 * plus a three day forecast. Cached
 * for ten minutes like the badge.
 */

async function refreshMonitorWeather() {

    const wrap =
        document.getElementById(
            'monitorWeatherCard'
        );

    if (!wrap) {
        return;
    }

    const lat = wrap.dataset.lat;
    const lon = wrap.dataset.lon;

    const iconEl =
        document.getElementById(
            'monitor_weather_icon'
        );

    const tempEl =
        document.getElementById(
            'monitor_weather_temp'
        );

    const condEl =
        document.getElementById(
            'monitor_weather_cond'
        );

    const forecastEl =
        document.getElementById(
            'monitor_weather_forecast'
        );

    if (!lat || !lon) {
        return;
    }

    const cacheKey =
        'monitorWeather_' + lat + '_' + lon;

    let data = null;

    try {

        const cached =
            sessionStorage.getItem(
                cacheKey
            );

        if (cached) {

            const parsed =
                JSON.parse(cached);

            if (
                Date.now() - parsed.fetchedAt
                    < 600000
            ) {
                data = parsed;
            }
        }

    } catch (error) {
        /* cache unavailable */
    }

    if (!data || !data.current) {

        try {

            const url =
                'https://api.open-meteo.com'
                + '/v1/forecast'
                + '?latitude='
                + encodeURIComponent(lat)
                + '&longitude='
                + encodeURIComponent(lon)
                + '&current=weather_code,'
                + 'temperature_2m,is_day'
                + '&daily=weather_code,'
                + 'temperature_2m_max,'
                + 'temperature_2m_min'
                + '&forecast_days=4'
                + '&timezone=auto';

            const response = await fetch(url);

            const fresh = await response.json();

            fresh.fetchedAt = Date.now();

            try {
                sessionStorage.setItem(
                    cacheKey,
                    JSON.stringify(fresh)
                );
            } catch (error) {
                /* storage full */
            }

            data = fresh;

        } catch (error) {
            /* offline or blocked */
            return;
        }
    }

    const current = data.current;

    if (!current) {
        return;
    }

    const described =
        window.describeWeather
            ? window.describeWeather(
                current.weather_code,
                current.is_day === 1
                    ? 1
                    : 0
            )
            : null;

    if (iconEl && described) {
        iconEl.innerHTML = described.icon;
    }

    if (tempEl) {

        tempEl.textContent =
            Math.round(
                current.temperature_2m
            ) + '°C';
    }

    if (condEl) {

        condEl.textContent =
            described
                ? described.label
                : '';
    }

    if (forecastEl && data.daily) {

        forecastEl.textContent = '';

        const days = data.daily.time ?? [];
        const codes = data.daily.weather_code ?? [];
        const highs = data.daily.temperature_2m_max ?? [];
        const lows = data.daily.temperature_2m_min ?? [];

        const names = [
            'Sun', 'Mon', 'Tue',
            'Wed', 'Thu', 'Fri', 'Sat'
        ];

        for (let i = 1; i < days.length; i++) {

            const day =
                document.createElement(
                    'div'
                );

            day.className =
                'monitor-wday';

            const label =
                document.createElement(
                    'span'
                );

            const date = new Date(days[i]);

            label.textContent =
                isNaN(date.getTime())
                    ? days[i]
                    : names[date.getDay()];

            const dayIcon =
                document.createElement(
                    'span'
                );

            if (window.describeWeather) {

                dayIcon.innerHTML =
                    window.describeWeather(
                        codes[i],
                        1
                    ).icon;
            }

            const hi =
                document.createElement(
                    'span'
                );

            hi.className =
                'monitor-wday-hi';

            hi.textContent =
                Math.round(highs[i]) + '°';

            const lo =
                document.createElement(
                    'span'
                );

            lo.className =
                'monitor-wday-lo';

            lo.textContent =
                Math.round(lows[i]) + '°';

            day.appendChild(label);
            day.appendChild(dayIcon);
            day.appendChild(hi);
            day.appendChild(lo);

            forecastEl.appendChild(day);
        }
    }
}

/*
 * Real time badges: the API broadcasts a
 * refresh over the WebSocket whenever a
 * request changes. Instead of reloading
 * the whole display, just pull fresh
 * stats. Reconnects automatically so a
 * wall display keeps working after API
 * restarts.
 */

function connectMonitorRefresh() {

    const protocol =
        location.protocol === 'https:'
            ? 'wss'
            : 'ws';

    const socket = new WebSocket(
        protocol + '://' + location.host + '/ws'
    );

    socket.onmessage = function (event) {

        if (event.data === 'refresh') {
            refreshMonitorStats();
            refreshMonitorConnectivity();
            refreshMonitorDnsGraph();
            refreshMonitorDnsTop();
            refreshMonitorDnsBlocked();
            refreshMonitorUnblocks();
            refreshMonitorEvents();
        }
    };

    socket.onclose = function () {
        window.setTimeout(
            connectMonitorRefresh,
            5000
        );
    };
}

connectMonitorRefresh();
</script>

</body>

</html>
