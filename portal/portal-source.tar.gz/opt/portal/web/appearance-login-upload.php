<?php

require_once 'auth.php';
require_once 'config.php';

header('Content-Type: application/json');


function loginBackgroundResponse(
    bool $success,
    string $message,
    array $extra = []
): void {

    echo json_encode(
        array_merge(
            [
                'success' => $success,
                'message' => $message
            ],
            $extra
        )
    );

    exit;
}


if (!hasPermission('Login')) {

    http_response_code(403);

    loginBackgroundResponse(
        false,
        'You do not have permission to manage the Login Page.'
    );
}


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    loginBackgroundResponse(
        false,
        'POST required.'
    );
}


$action =
    trim(
        (string)(
            $_POST['action']
            ?? ''
        )
    );


$uploadDirectory =
    '/opt/portal/web/uploads/appearance';

$relativeDirectory =
    'uploads/appearance';


function getCurrentLoginBackground(
    string $fastApiUrl
): string {

    $response =
        @file_get_contents(
            $fastApiUrl . '/portal-settings'
        );

    if ($response === false) {
        return '';
    }

    $settings =
        json_decode(
            $response,
            true
        );

    if (!is_array($settings)) {
        return '';
    }

    return trim(
        (string)(
            $settings['login_background_image']
            ?? ''
        )
    );
}


function saveLoginBackgroundSetting(
    string $fastApiUrl,
    string $backgroundPath
): bool {

    $payload =
        json_encode(
            [
                'settings' => [
                    'login_background_image' =>
                        $backgroundPath
                ]
            ]
        );

    $context =
        stream_context_create(
            [
                'http' => [
                    'method' => 'POST',
                    'header' =>
                        "Content-Type: application/json\r\n",
                    'content' => $payload,
                    'ignore_errors' => true,
                    'timeout' => 10
                ]
            ]
        );

    $response =
        @file_get_contents(
            $fastApiUrl . '/portal-settings/appearance',
            false,
            $context
        );

    if ($response === false) {
        return false;
    }

    $decoded =
        json_decode(
            $response,
            true
        );

    return
        is_array($decoded)
        &&
        (
            ($decoded['success'] ?? false) === true
            ||
            (
                $decoded['settings']['login_background_image']
                ?? null
            ) === $backgroundPath
        );
}


function deleteManagedLoginBackground(
    string $relativePath,
    string $uploadDirectory
): void {

    if (
        !preg_match(
            '#^uploads/appearance/login_[a-f0-9]{32}\.webp$#',
            $relativePath
        )
    ) {
        return;
    }

    $absolutePath =
        $uploadDirectory
        . '/'
        . basename($relativePath);

    if (is_file($absolutePath)) {
        @unlink($absolutePath);
    }
}


if ($action === 'remove') {

    $oldBackground =
        getCurrentLoginBackground(
            $FASTAPI_URL
        );

    if (
        !saveLoginBackgroundSetting(
            $FASTAPI_URL,
            ''
        )
    ) {

        http_response_code(502);

        loginBackgroundResponse(
            false,
            'Unable to clear the Login background setting.'
        );
    }

    deleteManagedLoginBackground(
        $oldBackground,
        $uploadDirectory
    );

    loginBackgroundResponse(
        true,
        'Login background removed.',
        [
            'login_background_image' => ''
        ]
    );
}


if ($action !== 'upload') {

    http_response_code(400);

    loginBackgroundResponse(
        false,
        'Invalid action.'
    );
}


if (
    !isset($_FILES['background'])
    ||
    !is_array($_FILES['background'])
) {

    http_response_code(400);

    loginBackgroundResponse(
        false,
        'No background image was supplied.'
    );
}


$file =
    $_FILES['background'];


if (
    ($file['error'] ?? UPLOAD_ERR_NO_FILE)
    !== UPLOAD_ERR_OK
) {

    http_response_code(400);

    loginBackgroundResponse(
        false,
        'Background upload failed.'
    );
}


$fileSize =
    (int)(
        $file['size']
        ?? 0
    );


if (
    $fileSize <= 0
    ||
    $fileSize > (5 * 1024 * 1024)
) {

    http_response_code(400);

    loginBackgroundResponse(
        false,
        'Background image must be 5 MB or smaller.'
    );
}


$tempFile =
    (string)(
        $file['tmp_name']
        ?? ''
    );


if (
    $tempFile === ''
    ||
    !is_uploaded_file($tempFile)
) {

    http_response_code(400);

    loginBackgroundResponse(
        false,
        'Invalid uploaded file.'
    );
}


$finfo =
    new finfo(
        FILEINFO_MIME_TYPE
    );

$mimeType =
    $finfo->file(
        $tempFile
    );


$allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/webp'
];


if (
    !in_array(
        $mimeType,
        $allowedMimeTypes,
        true
    )
) {

    http_response_code(400);

    loginBackgroundResponse(
        false,
        'Only JPG, PNG or WebP background images are allowed.'
    );
}


$imageData =
    @file_get_contents(
        $tempFile
    );

if ($imageData === false) {

    http_response_code(400);

    loginBackgroundResponse(
        false,
        'Unable to read the uploaded image.'
    );
}


$source =
    @imagecreatefromstring(
        $imageData
    );

if ($source === false) {

    http_response_code(400);

    loginBackgroundResponse(
        false,
        'The uploaded file is not a valid image.'
    );
}


$width =
    imagesx(
        $source
    );

$height =
    imagesy(
        $source
    );


if (
    $width < 1
    ||
    $height < 1
) {

    imagedestroy($source);

    http_response_code(400);

    loginBackgroundResponse(
        false,
        'Invalid image dimensions.'
    );
}


/*
 * Limit extremely large decoded images.
 * 40 million pixels is already well above a normal
 * full-screen Login background.
 */
if (($width * $height) > 40000000) {

    imagedestroy($source);

    http_response_code(400);

    loginBackgroundResponse(
        false,
        'Background image dimensions are too large.'
    );
}


/*
 * Downscale oversized backgrounds while preserving
 * aspect ratio. Never upscale smaller images.
 */
$maximumWidth = 2560;
$maximumHeight = 1440;

$scale =
    min(
        1,
        $maximumWidth / $width,
        $maximumHeight / $height
    );

$targetWidth =
    max(
        1,
        (int)round(
            $width * $scale
        )
    );

$targetHeight =
    max(
        1,
        (int)round(
            $height * $scale
        )
    );


$output =
    imagecreatetruecolor(
        $targetWidth,
        $targetHeight
    );

if ($output === false) {

    imagedestroy($source);

    http_response_code(500);

    loginBackgroundResponse(
        false,
        'Unable to prepare the Login background.'
    );
}


imagealphablending(
    $output,
    false
);

imagesavealpha(
    $output,
    true
);


if (
    !imagecopyresampled(
        $output,
        $source,
        0,
        0,
        0,
        0,
        $targetWidth,
        $targetHeight,
        $width,
        $height
    )
) {

    imagedestroy($source);
    imagedestroy($output);

    http_response_code(500);

    loginBackgroundResponse(
        false,
        'Unable to resize the Login background.'
    );
}


if (
    !is_dir($uploadDirectory)
    &&
    !mkdir(
        $uploadDirectory,
        0755,
        true
    )
) {

    imagedestroy($source);
    imagedestroy($output);

    http_response_code(500);

    loginBackgroundResponse(
        false,
        'Unable to create the Appearance upload directory.'
    );
}


try {

    $token =
        bin2hex(
            random_bytes(16)
        );

} catch (Throwable $exception) {

    imagedestroy($source);
    imagedestroy($output);

    http_response_code(500);

    loginBackgroundResponse(
        false,
        'Unable to generate a secure background filename.'
    );
}


$filename =
    'login_'
    . $token
    . '.webp';

$absolutePath =
    $uploadDirectory
    . '/'
    . $filename;

$relativePath =
    $relativeDirectory
    . '/'
    . $filename;


if (
    !imagewebp(
        $output,
        $absolutePath,
        85
    )
) {

    imagedestroy($source);
    imagedestroy($output);

    @unlink($absolutePath);

    http_response_code(500);

    loginBackgroundResponse(
        false,
        'Unable to save the Login background.'
    );
}


imagedestroy($source);
imagedestroy($output);

@chmod(
    $absolutePath,
    0644
);


$oldBackground =
    getCurrentLoginBackground(
        $FASTAPI_URL
    );


if (
    !saveLoginBackgroundSetting(
        $FASTAPI_URL,
        $relativePath
    )
) {

    @unlink($absolutePath);

    http_response_code(502);

    loginBackgroundResponse(
        false,
        'Background uploaded but its Portal setting could not be saved.'
    );
}


if (
    $oldBackground !== ''
    &&
    $oldBackground !== $relativePath
) {

    deleteManagedLoginBackground(
        $oldBackground,
        $uploadDirectory
    );
}


loginBackgroundResponse(
    true,
    'Login background uploaded.',
    [
        'login_background_image' =>
            $relativePath
    ]
);
