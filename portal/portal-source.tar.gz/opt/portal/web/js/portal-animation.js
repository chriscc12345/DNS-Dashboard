(function (window) {
    'use strict';

    const VALID_STYLES = new Set([
        'cyber',
        'digital_rain',
        'network_grid',
        'security_scanner'
    ]);

    const VALID_INTENSITIES = new Set([
        'low',
        'medium',
        'high',
        'ultra'
    ]);

    class PortalAnimation {
        constructor(options) {
            this.canvas = options.canvas;
            this.container = options.container;

            this.style =
                VALID_STYLES.has(options.style)
                    ? options.style
                    : 'cyber';

            this.intensity =
                VALID_INTENSITIES.has(options.intensity)
                    ? options.intensity
                    : 'medium';

            this.enabled =
                options.enabled === true;

            this.context =
                this.canvas
                    ? this.canvas.getContext('2d')
                    : null;

            this.frame = null;

            /*
             * Animation colours follow the active theme.
             * The pages that host this canvas already emit the
             * --theme-basic-* custom properties; the gold rgb
             * values below are only fallbacks.
             */

            this.accentRgb =
                this.resolveThemeColor(
                    '--theme-basic-accent-bright',
                    '235,193,0'
                );

            this.accentBrightRgb =
                this.resolveThemeColor(
                    '--theme-basic-accent-bright',
                    '255,221,70',
                    40
                );

            this.nodes = [];
            this.pulses = [];
            this.rain = [];
            this.gridPackets = [];
            this.scannerTargets = [];

            this.lastPulse = 0;
            this.lastRainStep = 0;
            this.lastGridPacket = 0;
            this.lastScannerTarget = 0;

            this.boundDraw =
                this.draw.bind(this);

            this.boundResize =
                this.resize.bind(this);

            window.addEventListener(
                'resize',
                this.boundResize
            );

            this.refresh();
        }


        setOptions(options) {
            if (
                options.style
                && VALID_STYLES.has(options.style)
            ) {
                this.style = options.style;
            }

            if (
                options.intensity
                && VALID_INTENSITIES.has(options.intensity)
            ) {
                this.intensity = options.intensity;
            }

            if (
                typeof options.enabled === 'boolean'
            ) {
                this.enabled = options.enabled;
            }

            this.refresh();
        }


        getIntensityConfig() {
            const configs = {
                low: {
                    density: 9000,
                    speed: 0.12,
                    linkDistance: 105,
                    pulseInterval: 1500,
                    nodeAlpha: 0.42,
                    lineAlpha: 0.13,

                    rainFont: 15,
                    rainSpeed: 0.55,
                    rainAlpha: 0.34,

                    gridSpeed: 0.00011,
                    gridAlpha: 0.18,
                    gridPacketInterval: 1450,

                    scannerSpeed: 0.00020,
                    scannerAlpha: 0.22,
                    targetInterval: 1700
                },

                medium: {
                    density: 6500,
                    speed: 0.18,
                    linkDistance: 120,
                    pulseInterval: 950,
                    nodeAlpha: 0.55,
                    lineAlpha: 0.18,

                    rainFont: 14,
                    rainSpeed: 0.85,
                    rainAlpha: 0.48,

                    gridSpeed: 0.00017,
                    gridAlpha: 0.26,
                    gridPacketInterval: 950,

                    scannerSpeed: 0.00030,
                    scannerAlpha: 0.30,
                    targetInterval: 1100
                },

                high: {
                    density: 4300,
                    speed: 0.25,
                    linkDistance: 135,
                    pulseInterval: 620,
                    nodeAlpha: 0.70,
                    lineAlpha: 0.24,

                    rainFont: 13,
                    rainSpeed: 1.18,
                    rainAlpha: 0.62,

                    gridSpeed: 0.00024,
                    gridAlpha: 0.34,
                    gridPacketInterval: 620,

                    scannerSpeed: 0.00042,
                    scannerAlpha: 0.40,
                    targetInterval: 720
                },

                ultra: {
                    density: 2800,
                    speed: 0.34,
                    linkDistance: 150,
                    pulseInterval: 380,
                    nodeAlpha: 0.82,
                    lineAlpha: 0.31,

                    rainFont: 12,
                    rainSpeed: 1.55,
                    rainAlpha: 0.76,

                    gridSpeed: 0.00034,
                    gridAlpha: 0.46,
                    gridPacketInterval: 390,

                    scannerSpeed: 0.00058,
                    scannerAlpha: 0.52,
                    targetInterval: 440
                }
            };

            return configs[this.intensity]
                || configs.medium;
        }


        resize() {
            if (
                !this.canvas
                || !this.context
                || !this.container
            ) {
                return;
            }

            const rect =
                this.container.getBoundingClientRect();

            const ratio =
                Math.min(
                    window.devicePixelRatio || 1,
                    2
                );

            this.width =
                Math.max(1, rect.width);

            this.height =
                Math.max(1, rect.height);

            this.canvas.width =
                Math.round(
                    this.width * ratio
                );

            this.canvas.height =
                Math.round(
                    this.height * ratio
                );

            this.canvas.style.width =
                this.width + 'px';

            this.canvas.style.height =
                this.height + 'px';

            this.context.setTransform(
                ratio,
                0,
                0,
                ratio,
                0,
                0
            );

            this.buildState();
        }


        buildState() {
            this.nodes = [];
            this.pulses = [];
            this.rain = [];
            this.gridPackets = [];
            this.scannerTargets = [];

            this.lastPulse = 0;
            this.lastRainStep = 0;
            this.lastGridPacket = 0;
            this.lastScannerTarget = 0;

            if (
                !this.width
                || !this.height
            ) {
                return;
            }

            if (this.style === 'cyber') {
                this.buildCyber();
            }

            if (this.style === 'digital_rain') {
                this.buildRain();
            }

            if (this.style === 'security_scanner') {
                this.buildScannerTargets();
            }
        }


        buildCyber() {
            const config =
                this.getIntensityConfig();

            const area =
                this.width * this.height;

            const count =
                Math.max(
                    22,
                    Math.min(
                        95,
                        Math.round(
                            area / config.density
                        )
                    )
                );

            this.nodes =
                Array.from(
                    { length: count },
                    () => {
                        const angle =
                            Math.random()
                            * Math.PI
                            * 2;

                        const velocity =
                            config.speed
                            * (
                                0.55
                                + Math.random()
                                * 0.9
                            );

                        return {
                            x:
                                Math.random()
                                * this.width,

                            y:
                                Math.random()
                                * this.height,

                            vx:
                                Math.cos(angle)
                                * velocity,

                            vy:
                                Math.sin(angle)
                                * velocity,

                            radius:
                                1
                                + Math.random()
                                * 1.5
                        };
                    }
                );
        }


        buildRain() {
            const config =
                this.getIntensityConfig();

            const font =
                config.rainFont;

            const count =
                Math.max(
                    10,
                    Math.ceil(
                        this.width / font
                    )
                );

            this.rain =
                Array.from(
                    { length: count },
                    (_, index) => ({
                        x:
                            index * font,

                        y:
                            Math.random()
                            * this.height,

                        speed:
                            config.rainSpeed
                            * (
                                0.65
                                + Math.random()
                                * 0.8
                            ),

                        char:
                            this.randomRainChar()
                    })
                );
        }


        randomRainChar() {
            const chars =
                '01ABCDEF<>/{}[]#@$%';

            return chars[
                Math.floor(
                    Math.random()
                    * chars.length
                )
            ];
        }


        buildScannerTargets() {
            const count =
                this.intensity === 'high'
                    ? 11
                    : this.intensity === 'low'
                        ? 5
                        : 8;

            this.scannerTargets =
                Array.from(
                    { length: count },
                    () => ({
                        angle:
                            Math.random()
                            * Math.PI
                            * 2,

                        radius:
                            0.16
                            + Math.random()
                            * 0.70,

                        alpha:
                            0.22
                            + Math.random()
                            * 0.38,

                        phase:
                            Math.random()
                            * Math.PI
                            * 2
                    })
                );
        }


        resolveThemeColor(
            varName,
            fallbackRgb,
            lighten
        ) {
            let rgb = fallbackRgb;

            try {
                let value =
                    window
                        .getComputedStyle(
                            document.documentElement
                        )
                        .getPropertyValue(varName)
                        .trim();

                if (
                    value.charAt(0) === '#'
                    && value.length === 7
                ) {
                    let r =
                        parseInt(
                            value.slice(1, 3),
                            16
                        );

                    let g =
                        parseInt(
                            value.slice(3, 5),
                            16
                        );

                    let b =
                        parseInt(
                            value.slice(5, 7),
                            16
                        );

                    if (lighten) {
                        r = Math.min(255, r + lighten);
                        g = Math.min(255, g + lighten);
                        b = Math.min(255, b + lighten);
                    }

                    rgb =
                        r + ',' + g + ',' + b;
                }
            } catch (error) {
                /* keep the fallback colour */
            }

            return rgb;
        }

        stop() {
            if (this.frame !== null) {
                cancelAnimationFrame(
                    this.frame
                );

                this.frame = null;
            }

            if (
                this.context
                && this.canvas
            ) {
                this.context.clearRect(
                    0,
                    0,
                    this.width,
                    this.height
                );

                this.canvas.hidden = true;
            }
        }


        refresh() {
            this.stop();

            if (
                !this.enabled
                || !this.canvas
                || !this.context
                || !this.container
            ) {
                return;
            }

            this.resize();
            this.canvas.hidden = false;

            if (
                window.matchMedia(
                    '(prefers-reduced-motion: reduce)'
                ).matches
            ) {
                this.drawStatic();
                return;
            }

            this.frame =
                requestAnimationFrame(
                    this.boundDraw
                );
        }


        drawStatic() {
            if (!this.context) {
                return;
            }

            this.context.clearRect(
                0,
                0,
                this.width,
                this.height
            );

            if (this.style === 'cyber') {
                this.drawCyber(0, true);
            } else if (
                this.style === 'digital_rain'
            ) {
                this.drawRain(0, true);
            } else if (
                this.style === 'network_grid'
            ) {
                this.drawGrid(0, true);
            } else {
                this.drawScanner(0, true);
            }
        }


        draw(now) {
            if (
                !this.enabled
                || !this.context
                || !this.canvas
            ) {
                this.stop();
                return;
            }

            this.context.clearRect(
                0,
                0,
                this.width,
                this.height
            );

            if (this.style === 'cyber') {
                this.drawCyber(now, false);
            } else if (
                this.style === 'digital_rain'
            ) {
                this.drawRain(now, false);
            } else if (
                this.style === 'network_grid'
            ) {
                this.drawGrid(now, false);
            } else if (
                this.style === 'security_scanner'
            ) {
                this.drawScanner(now, false);
            }

            this.frame =
                requestAnimationFrame(
                    this.boundDraw
                );
        }


        drawCyber(now, staticMode) {
            const ctx =
                this.context;

            const config =
                this.getIntensityConfig();

            const scanY =
                staticMode
                    ? this.height * 0.48
                    : (
                        now
                        * (
                            this.intensity === 'high'
                                ? 0.055
                                : this.intensity === 'low'
                                    ? 0.025
                                    : 0.04
                        )
                    )
                    % (
                        this.height + 120
                    )
                    - 60;

            const scanner =
                ctx.createLinearGradient(
                    0,
                    scanY - 45,
                    0,
                    scanY + 45
                );

            scanner.addColorStop(
                0,
                'rgba(' + this.accentRgb + ',0)'
            );

            scanner.addColorStop(
                .5,
                'rgba(' + this.accentRgb + ',0.11)'
            );

            scanner.addColorStop(
                1,
                'rgba(' + this.accentRgb + ',0)'
            );

            ctx.fillStyle = scanner;

            ctx.fillRect(
                0,
                scanY - 45,
                this.width,
                90
            );

            if (!staticMode) {
                this.nodes.forEach(node => {
                    node.x += node.vx;
                    node.y += node.vy;

                    if (
                        node.x < -10
                        || node.x > this.width + 10
                    ) {
                        node.vx *= -1;
                    }

                    if (
                        node.y < -10
                        || node.y > this.height + 10
                    ) {
                        node.vy *= -1;
                    }
                });
            }

            for (
                let i = 0;
                i < this.nodes.length;
                i++
            ) {
                const a =
                    this.nodes[i];

                for (
                    let j = i + 1;
                    j < this.nodes.length;
                    j++
                ) {
                    const b =
                        this.nodes[j];

                    const dx =
                        a.x - b.x;

                    const dy =
                        a.y - b.y;

                    const distance =
                        Math.sqrt(
                            dx * dx
                            + dy * dy
                        );

                    if (
                        distance
                        > config.linkDistance
                    ) {
                        continue;
                    }

                    const alpha =
                        (
                            1
                            - distance
                            / config.linkDistance
                        )
                        * config.lineAlpha;

                    ctx.beginPath();
                    ctx.moveTo(a.x, a.y);
                    ctx.lineTo(b.x, b.y);

                    ctx.strokeStyle =
                        'rgba(' + this.accentRgb + ','
                        + alpha
                        + ')';

                    ctx.lineWidth = 0.8;
                    ctx.stroke();
                }
            }

            this.nodes.forEach(node => {
                ctx.beginPath();

                ctx.arc(
                    node.x,
                    node.y,
                    node.radius,
                    0,
                    Math.PI * 2
                );

                ctx.fillStyle =
                    'rgba(' + this.accentRgb + ','
                    + config.nodeAlpha
                    + ')';

                ctx.fill();
            });

            if (!staticMode) {
                this.spawnCyberPulse(now);
            }

            this.pulses.forEach(pulse => {
                if (!staticMode) {
                    pulse.radius +=
                        this.intensity === 'high'
                            ? 0.65
                            : this.intensity === 'low'
                                ? 0.32
                                : 0.48;

                    pulse.alpha -=
                        this.intensity === 'high'
                            ? 0.007
                            : 0.005;
                }

                ctx.beginPath();

                ctx.arc(
                    pulse.x,
                    pulse.y,
                    pulse.radius,
                    0,
                    Math.PI * 2
                );

                ctx.strokeStyle =
                    'rgba(' + this.accentRgb + ','
                    + Math.max(
                        0,
                        pulse.alpha
                    )
                    + ')';

                ctx.lineWidth = 1.2;
                ctx.stroke();
            });

            this.pulses =
                this.pulses.filter(
                    pulse =>
                        pulse.alpha > 0
                        && pulse.radius < 90
                );
        }


        spawnCyberPulse(now) {
            const config =
                this.getIntensityConfig();

            if (
                now - this.lastPulse
                < config.pulseInterval
            ) {
                return;
            }

            this.lastPulse = now;

            this.pulses.push({
                x:
                    Math.random()
                    * this.width,

                y:
                    Math.random()
                    * this.height,

                radius: 3,
                alpha: 0.75
            });

            if (this.pulses.length > 8) {
                this.pulses.shift();
            }
        }


        drawRain(now, staticMode) {
            const ctx =
                this.context;

            const config =
                this.getIntensityConfig();

            ctx.font =
                config.rainFont
                + 'px monospace';

            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';

            this.rain.forEach(
                (drop, index) => {

                    if (!staticMode) {
                        drop.y += drop.speed;

                        if (
                            drop.y
                            > this.height
                            + config.rainFont
                        ) {
                            drop.y =
                                -Math.random()
                                * this.height
                                * 0.35;
                        }

                        if (
                            Math.random() < 0.035
                        ) {
                            drop.char =
                                this.randomRainChar();
                        }
                    }

                    const pulse =
                        0.72
                        + 0.28
                        * Math.sin(
                            (
                                now * 0.003
                            )
                            + index
                        );

                    ctx.fillStyle =
                        'rgba(' + this.accentRgb + ','
                        + (
                            config.rainAlpha
                            * pulse
                        )
                        + ')';

                    ctx.fillText(
                        drop.char,
                        drop.x,
                        drop.y
                    );

                    ctx.fillStyle =
                        'rgba(' + this.accentRgb + ',0.10)';

                    ctx.fillText(
                        drop.char,
                        drop.x,
                        drop.y
                        - config.rainFont
                        * 1.35
                    );
                }
            );
        }


        drawGrid(now, staticMode) {
            const ctx =
                this.context;

            const config =
                this.getIntensityConfig();

            const horizon =
                this.height * 0.24;

            const vanishingX =
                this.width * 0.5;

            const bottom =
                this.height;

            const columns =
                this.intensity === 'high'
                    ? 18
                    : this.intensity === 'low'
                        ? 10
                        : 14;

            ctx.lineWidth = 1;

            for (
                let i = -columns;
                i <= columns;
                i++
            ) {
                const bottomX =
                    vanishingX
                    + (
                        i
                        / columns
                    )
                    * this.width;

                ctx.beginPath();
                ctx.moveTo(
                    vanishingX,
                    horizon
                );
                ctx.lineTo(
                    bottomX,
                    bottom
                );

                ctx.strokeStyle =
                    'rgba(' + this.accentRgb + ','
                    + config.gridAlpha
                    + ')';

                ctx.stroke();
            }

            const rows =
                this.intensity === 'high'
                    ? 15
                    : this.intensity === 'low'
                        ? 9
                        : 12;

            const offset =
                staticMode
                    ? 0.35
                    : (
                        now
                        * config.gridSpeed
                    )
                    % 1;

            for (
                let row = 0;
                row < rows;
                row++
            ) {
                let t =
                    (
                        row
                        + offset
                    )
                    / rows;

                t =
                    Math.min(
                        1,
                        Math.max(
                            0,
                            t
                        )
                    );

                const perspective =
                    t * t;

                const y =
                    horizon
                    + (
                        bottom - horizon
                    )
                    * perspective;

                const halfWidth =
                    this.width
                    * 0.5
                    * perspective;

                ctx.beginPath();

                ctx.moveTo(
                    vanishingX - halfWidth,
                    y
                );

                ctx.lineTo(
                    vanishingX + halfWidth,
                    y
                );

                ctx.strokeStyle =
                    'rgba(' + this.accentRgb + ','
                    + (
                        config.gridAlpha
                        * (
                            0.35
                            + perspective
                            * 0.65
                        )
                    )
                    + ')';

                ctx.stroke();
            }

            if (!staticMode) {
                this.spawnGridPacket(now);
            }

            this.gridPackets.forEach(packet => {
                if (!staticMode) {
                    packet.progress +=
                        packet.speed;
                }

                const p =
                    Math.min(
                        1,
                        packet.progress
                    );

                const perspective =
                    p * p;

                const targetX =
                    vanishingX
                    + packet.lane
                    * this.width
                    * 0.46;

                const x =
                    vanishingX
                    + (
                        targetX - vanishingX
                    )
                    * perspective;

                const y =
                    horizon
                    + (
                        bottom - horizon
                    )
                    * perspective;

                ctx.beginPath();

                ctx.arc(
                    x,
                    y,
                    2.2
                    + perspective * 2.8,
                    0,
                    Math.PI * 2
                );

                ctx.fillStyle =
                    'rgba(' + this.accentBrightRgb + ','
                    + (
                        0.35
                        + perspective
                        * 0.65
                    )
                    + ')';

                ctx.fill();
            });

            this.gridPackets =
                this.gridPackets.filter(
                    packet =>
                        packet.progress <= 1.05
                );
        }


        spawnGridPacket(now) {
            const config =
                this.getIntensityConfig();

            if (
                now - this.lastGridPacket
                < config.gridPacketInterval
            ) {
                return;
            }

            this.lastGridPacket = now;

            this.gridPackets.push({
                lane:
                    -1
                    + Math.random()
                    * 2,

                progress: 0,

                speed:
                    this.intensity === 'high'
                        ? 0.010
                        : this.intensity === 'low'
                            ? 0.0045
                            : 0.007
            });

            if (
                this.gridPackets.length > 10
            ) {
                this.gridPackets.shift();
            }
        }


        drawScanner(now, staticMode) {
            const ctx =
                this.context;

            const config =
                this.getIntensityConfig();

            const cx =
                this.width * 0.5;

            const cy =
                this.height * 0.53;

            const radius =
                Math.min(
                    this.width,
                    this.height
                )
                * 0.40;

            const rings =
                this.intensity === 'high'
                    ? 5
                    : 4;

            ctx.lineWidth = 1;

            for (
                let i = 1;
                i <= rings;
                i++
            ) {
                ctx.beginPath();

                ctx.arc(
                    cx,
                    cy,
                    radius
                    * (
                        i / rings
                    ),
                    0,
                    Math.PI * 2
                );

                ctx.strokeStyle =
                    'rgba(' + this.accentRgb + ','
                    + (
                        config.scannerAlpha
                        * 0.55
                    )
                    + ')';

                ctx.stroke();
            }

            ctx.beginPath();
            ctx.moveTo(
                cx - radius,
                cy
            );
            ctx.lineTo(
                cx + radius,
                cy
            );

            ctx.moveTo(
                cx,
                cy - radius
            );
            ctx.lineTo(
                cx,
                cy + radius
            );

            ctx.strokeStyle =
                'rgba(' + this.accentRgb + ',0.12)';

            ctx.stroke();

            const angle =
                staticMode
                    ? -Math.PI * 0.18
                    : (
                        now
                        * config.scannerSpeed
                    )
                    % (
                        Math.PI * 2
                    );

            const sweepWidth =
                this.intensity === 'high'
                    ? 0.55
                    : this.intensity === 'low'
                        ? 0.32
                        : 0.43;

            const gradient =
                ctx.createRadialGradient(
                    cx,
                    cy,
                    0,
                    cx,
                    cy,
                    radius
                );

            gradient.addColorStop(
                0,
                'rgba(' + this.accentRgb + ',0.24)'
            );

            gradient.addColorStop(
                1,
                'rgba(' + this.accentRgb + ',0)'
            );

            ctx.beginPath();
            ctx.moveTo(cx, cy);

            ctx.arc(
                cx,
                cy,
                radius,
                angle - sweepWidth,
                angle
            );

            ctx.closePath();
            ctx.fillStyle = gradient;
            ctx.fill();

            ctx.beginPath();
            ctx.moveTo(cx, cy);

            ctx.lineTo(
                cx
                + Math.cos(angle)
                * radius,

                cy
                + Math.sin(angle)
                * radius
            );

            ctx.strokeStyle =
                'rgba(' + this.accentBrightRgb + ',0.72)';

            ctx.lineWidth = 1.4;
            ctx.stroke();

            this.scannerTargets.forEach(
                target => {

                    const targetRadius =
                        radius
                        * target.radius;

                    const x =
                        cx
                        + Math.cos(
                            target.angle
                        )
                        * targetRadius;

                    const y =
                        cy
                        + Math.sin(
                            target.angle
                        )
                        * targetRadius;

                    const blink =
                        staticMode
                            ? 0.7
                            : (
                                0.45
                                + 0.55
                                * (
                                    0.5
                                    + 0.5
                                    * Math.sin(
                                        now * 0.004
                                        + target.phase
                                    )
                                )
                            );

                    ctx.beginPath();

                    ctx.arc(
                        x,
                        y,
                        2.2,
                        0,
                        Math.PI * 2
                    );

                    ctx.fillStyle =
                        'rgba(' + this.accentBrightRgb + ','
                        + (
                            target.alpha
                            * blink
                        )
                        + ')';

                    ctx.fill();

                    ctx.beginPath();

                    ctx.arc(
                        x,
                        y,
                        7,
                        0,
                        Math.PI * 2
                    );

                    ctx.strokeStyle =
                        'rgba(' + this.accentRgb + ','
                        + (
                            target.alpha
                            * blink
                            * 0.45
                        )
                        + ')';

                    ctx.lineWidth = 1;
                    ctx.stroke();
                }
            );
        }


        destroy() {
            this.stop();

            window.removeEventListener(
                'resize',
                this.boundResize
            );
        }
    }


    window.PortalAnimation =
        PortalAnimation;

})(window);
