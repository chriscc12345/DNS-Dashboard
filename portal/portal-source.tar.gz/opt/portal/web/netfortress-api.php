<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * NetFortress appliance console proxy. The Settings
 * -> Services -> NetFortress pages (Devices, Reports,
 * Audit Log, Block list, Application Blocking, Web
 * Proxy and Cache, Policy acceptance, Block Page,
 * Modules, Operations) and the Services -> Network
 * -> NetFortress page call this endpoint; it forwards
 * to the portal API, which drives the local Firewall
 * Appliance through the network services provider.
 *
 * Every action is gated by the permission of the tab
 * that owns it, so a group with access to one tab
 * cannot drive another tab's appliance features.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

function netfortressRequire(
    string $permission
) {

    if (
        !hasPermission(
            $permission
        )
    ) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Access denied.'
        ]);
        exit;
    }

}

function netfortressForward(
    string $path,
    array $payload = null
) {

    global $FASTAPI_URL;

    if (
        $payload === null
    ) {
        echo @file_get_contents(
            $FASTAPI_URL
            . $path
        );

        return;
    }

    $context =
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => json_encode(
                    $payload
                )
            ]
        ]);

    echo @file_get_contents(
        $FASTAPI_URL
        . $path,
        false,
        $context
    );

}

function netfortressForwardRaw(
    string $path,
    string $body,
    string $contentType,
    string $method = 'POST'
) {

    /*
     * Raw-body forwarding (block page logo upload,
     * custom HTML upload).
     */

    global $FASTAPI_URL;

    $context =
        stream_context_create([
            'http' => [
                'method'  => $method,
                'header'  => "Content-Type: $contentType\r\n",
                'content' => $body
            ]
        ]);

    echo @file_get_contents(
        $FASTAPI_URL
        . $path,
        false,
        $context
    );

}

$action =
    (string)(
        $_GET['action']
        ?? ''
    );

if (
    $_SERVER['REQUEST_METHOD']
    === 'POST'
) {

    $body =
        json_decode(
            file_get_contents(
                'php://input'
            ),
            true
        ) ?? [];

    switch ($action) {

        /* ---- Devices tab ---- */

        case 'block':
            netfortressRequire('NetFortress Devices');
            netfortressForward(
                '/api/netfortress/devices/block',
                [
                    'target_type' =>
                        (string)(
                            $body['target_type']
                            ?? ''
                        ),
                    'target_value' =>
                        (string)(
                            $body['target_value']
                            ?? ''
                        ),
                    'reason' =>
                        (string)(
                            $body['reason']
                            ?? ''
                        )
                ]
            );
            exit;

        case 'unblock':
            netfortressRequire('NetFortress Devices');
            netfortressForward(
                '/api/netfortress/devices/unblock',
                [
                    'policy_id' =>
                        (int)(
                            $body['policy_id']
                            ?? 0
                        )
                ]
            );
            exit;

        /* ---- Modules tab ---- */

        case 'toggle':
            netfortressRequire('NetFortress Modules');
            netfortressForward(
                '/api/netfortress/modules/toggle',
                [
                    'module_key' =>
                        (string)(
                            $body['module_key']
                            ?? ''
                        ),
                    'enabled' =>
                        (bool)(
                            $body['enabled']
                            ?? false
                        )
                ]
            );
            exit;

        case 'ids':
            netfortressRequire('NetFortress Modules');
            netfortressForward(
                '/api/netfortress/modules/ids',
                [
                    'action' =>
                        (string)(
                            $body['op']
                            ?? ''
                        )
                ]
            );
            exit;

        /* ---- Network page (interfaces + hostname) ---- */

        case 'label':
            netfortressRequire('Network');
            netfortressForward(
                '/api/netfortress/network/label',
                [
                    'interface' =>
                        (string)(
                            $body['interface']
                            ?? ''
                        ),
                    'label' =>
                        (string)(
                            $body['label']
                            ?? ''
                        )
                ]
            );
            exit;

        case 'hostname':
            netfortressRequire('Network');
            netfortressForward(
                '/api/netfortress/network/hostname',
                [
                    'hostname' =>
                        (string)(
                            $body['hostname']
                            ?? ''
                        )
                ]
            );
            exit;

        /* ---- Network page: DHCP / IP pools ---- */

        case 'dhcp-enabled':
            netfortressRequire('Network');
            netfortressForward(
                '/api/netfortress/dhcp/enabled',
                [
                    'enabled' =>
                        (bool)(
                            $body['enabled']
                            ?? false
                        )
                ]
            );
            exit;

        case 'pool-add':
            netfortressRequire('Network');
            netfortressForward(
                '/api/netfortress/dhcp/pool',
                [
                    'name' =>
                        (string)(
                            $body['name']
                            ?? ''
                        ),
                    'vlan_id' =>
                        (int)(
                            $body['vlan_id']
                            ?? 0
                        ),
                    'subnet' =>
                        (string)(
                            $body['subnet']
                            ?? ''
                        ),
                    'pool_start' =>
                        (string)(
                            $body['pool_start']
                            ?? ''
                        ),
                    'pool_end' =>
                        (string)(
                            $body['pool_end']
                            ?? ''
                        )
                ]
            );
            exit;

        case 'pool-delete':
            netfortressRequire('Network');
            netfortressForward(
                '/api/netfortress/dhcp/pool/delete',
                [
                    'item_id' =>
                        (int)(
                            $body['pool_id']
                            ?? 0
                        )
                ]
            );
            exit;

        case 'reservation-add':
            netfortressRequire('Network');
            netfortressForward(
                '/api/netfortress/dhcp/reservation',
                [
                    'mac_address' =>
                        (string)(
                            $body['mac_address']
                            ?? ''
                        ),
                    'ip_address' =>
                        (string)(
                            $body['ip_address']
                            ?? ''
                        ),
                    'hostname' =>
                        (string)(
                            $body['hostname']
                            ?? ''
                        )
                ]
            );
            exit;

        case 'reservation-delete':
            netfortressRequire('Network');
            netfortressForward(
                '/api/netfortress/dhcp/reservation/delete',
                [
                    'item_id' =>
                        (int)(
                            $body['reservation_id']
                            ?? 0
                        )
                ]
            );
            exit;

        /* ---- Network page: WireGuard ---- */

        case 'wg-enabled':
            netfortressRequire('Network');
            netfortressForward(
                '/api/netfortress/wireguard/enabled',
                [
                    'enabled' =>
                        (bool)(
                            $body['enabled']
                            ?? false
                        )
                ]
            );
            exit;

        case 'wg-peer-add':
            netfortressRequire('Network');
            netfortressForward(
                '/api/netfortress/wireguard/peer',
                [
                    'kind' =>
                        (string)(
                            $body['kind']
                            ?? 'client'
                        ),
                    'name' =>
                        (string)(
                            $body['name']
                            ?? ''
                        ),
                    'allowed_ips' =>
                        (string)(
                            $body['allowed_ips']
                            ?? 'auto'
                        ),
                    'public_key' =>
                        (string)(
                            $body['public_key']
                            ?? ''
                        ),
                    'endpoint_host' =>
                        (string)(
                            $body['endpoint_host']
                            ?? ''
                        ),
                    'endpoint_port' =>
                        (int)(
                            $body['endpoint_port']
                            ?? 0
                        )
                ]
            );
            exit;

        case 'wg-peer-delete':
            netfortressRequire('Network');
            netfortressForward(
                '/api/netfortress/wireguard/peer/delete',
                [
                    'item_id' =>
                        (int)(
                            $body['peer_id']
                            ?? 0
                        )
                ]
            );
            exit;

        /* ---- Block list tab ---- */

        case 'blocklist-add':
            netfortressRequire('NetFortress Block list');
            netfortressForward(
                '/api/netfortress/blocklists/add',
                [
                    'name' =>
                        (string)(
                            $body['name']
                            ?? ''
                        ),
                    'url' =>
                        (string)(
                            $body['url']
                            ?? ''
                        ),
                    'format' =>
                        (string)(
                            $body['format']
                            ?? 'hosts'
                        ),
                    'update_hours' =>
                        (int)(
                            $body['update_hours']
                            ?? 24
                        ),
                    'category' =>
                        (string)(
                            $body['category']
                            ?? ''
                        )
                ]
            );
            exit;

        case 'blocklist-stevenblack':
            netfortressRequire('NetFortress Block list');
            netfortressForward(
                '/api/netfortress/blocklists/stevenblack'
            );
            exit;

        case 'blocklist-feeds':
            netfortressRequire('NetFortress Block list');
            netfortressForward(
                '/api/netfortress/blocklists/category-feeds'
            );
            exit;

        case 'blocklist-delete':
            netfortressRequire('NetFortress Block list');
            netfortressForward(
                '/api/netfortress/blocklists/delete',
                [
                    'item_id' =>
                        (int)(
                            $body['source_id']
                            ?? 0
                        )
                ]
            );
            exit;

        case 'blocklist-update':
            netfortressRequire('NetFortress Block list');
            netfortressForward(
                '/api/netfortress/blocklists/update',
                [
                    'item_id' =>
                        (int)(
                            $body['source_id']
                            ?? 0
                        )
                ]
            );
            exit;

        case 'blocklists-due':
            netfortressRequire('NetFortress Block list');
            netfortressForward(
                '/api/netfortress/blocklists/update-due',
                [
                    'force' =>
                        (bool)(
                            $body['force']
                            ?? false
                        )
                ]
            );
            exit;

        /* ---- Application Blocking tab ---- */

        case 'application-set':
            netfortressRequire('NetFortress Application Blocking');
            netfortressForward(
                '/api/netfortress/applications/set',
                [
                    'application' =>
                        (string)(
                            $body['application']
                            ?? ''
                        ),
                    'enabled' =>
                        (bool)(
                            $body['enabled']
                            ?? false
                        ),
                    'block_quic' =>
                        (bool)(
                            $body['block_quic']
                            ?? false
                        )
                ]
            );
            exit;

        case 'category-set':
            netfortressRequire('NetFortress Application Blocking');
            netfortressForward(
                '/api/netfortress/categories/set',
                [
                    'category' =>
                        (string)(
                            $body['category']
                            ?? ''
                        ),
                    'enabled' =>
                        (bool)(
                            $body['enabled']
                            ?? false
                        ),
                    'block_quic' =>
                        (bool)(
                            $body['block_quic']
                            ?? false
                        )
                ]
            );
            exit;

        case 'service-add':
            netfortressRequire('NetFortress Application Blocking');
            netfortressForward(
                '/api/netfortress/services/add',
                [
                    'name' =>
                        (string)(
                            $body['name']
                            ?? ''
                        ),
                    'category' =>
                        (string)(
                            $body['category']
                            ?? ''
                        ),
                    'domains' =>
                        (array)(
                            $body['domains']
                            ?? []
                        )
                ]
            );
            exit;

        case 'service-delete':
            netfortressRequire('NetFortress Application Blocking');
            netfortressForward(
                '/api/netfortress/services/delete',
                [
                    'name' =>
                        (string)(
                            $body['name']
                            ?? ''
                        )
                ]
            );
            exit;

        case 'group-add':
            netfortressRequire('NetFortress Application Blocking');
            netfortressForward(
                '/api/netfortress/groups/add',
                [
                    'name' =>
                        (string)(
                            $body['name']
                            ?? ''
                        ),
                    'description' =>
                        (string)(
                            $body['description']
                            ?? ''
                        )
                ]
            );
            exit;

        case 'group-delete':
            netfortressRequire('NetFortress Application Blocking');
            netfortressForward(
                '/api/netfortress/groups/delete',
                [
                    'category' =>
                        (string)(
                            $body['category']
                            ?? ''
                        ),
                    'application' => ''
                ]
            );
            exit;

        case 'group-member-add':
            netfortressRequire('NetFortress Application Blocking');
            netfortressForward(
                '/api/netfortress/groups/member-add',
                [
                    'category' =>
                        (string)(
                            $body['category']
                            ?? ''
                        ),
                    'application' =>
                        (string)(
                            $body['application']
                            ?? ''
                        )
                ]
            );
            exit;

        case 'group-member-remove':
            netfortressRequire('NetFortress Application Blocking');
            netfortressForward(
                '/api/netfortress/groups/member-remove',
                [
                    'category' =>
                        (string)(
                            $body['category']
                            ?? ''
                        ),
                    'application' =>
                        (string)(
                            $body['application']
                            ?? ''
                        )
                ]
            );
            exit;

        /* ---- Web Proxy and Cache tab ---- */

        case 'proxy-set':
            netfortressRequire('NetFortress Web Proxy and Cache');
            netfortressForward(
                '/api/netfortress/proxy/set',
                $body
            );
            exit;

        case 'cache-purge':
            netfortressRequire('NetFortress Web Proxy and Cache');
            netfortressForward(
                '/api/netfortress/cache/purge',
                [
                    'url' =>
                        (string)(
                            $body['url']
                            ?? ''
                        )
                ]
            );
            exit;

        /* ---- Policy acceptance tab ---- */

        case 'policy-set':
            netfortressRequire('NetFortress Policy acceptance');
            netfortressForward(
                '/api/netfortress/policy/set',
                $body
            );
            exit;

        case 'policy-revoke':
            netfortressRequire('NetFortress Policy acceptance');
            netfortressForward(
                '/api/netfortress/policy/revoke',
                [
                    'item_id' =>
                        (int)(
                            $body['item_id']
                            ?? 0
                        )
                ]
            );
            exit;

        /* ---- Block Page tab ---- */

        case 'blockpage-set':
            netfortressRequire('NetFortress Block Page');
            netfortressForward(
                '/api/netfortress/blockpage/set',
                $body
            );
            exit;

        case 'blockpage-logo-upload':

            /*
             * Raw image body from the browser.
             */

            netfortressRequire('NetFortress Block Page');

            $raw =
                file_get_contents(
                    'php://input'
                ) ?: '';

            if (strlen($raw) > 262144) {
                http_response_code(422);
                echo json_encode([
                    'success' => false,
                    'message' => 'Logo must be under 256 KB.'
                ]);
                exit;
            }

            netfortressForwardRaw(
                '/api/netfortress/blockpage-logo',
                $raw,
                (string)(
                    $_SERVER['CONTENT_TYPE']
                    ?? 'application/octet-stream'
                )
            );
            exit;

        case 'blockpage-logo-delete':
            netfortressRequire('NetFortress Block Page');
            netfortressForward(
                '/api/netfortress/blockpage-logo/delete',
                []
            );
            exit;

        case 'blockpage-custom':

            /*
             * Raw HTML body from the browser.
             */

            netfortressRequire('NetFortress Block Page');

            netfortressForwardRaw(
                '/api/netfortress/blockpage-custom',
                (string)(
                    file_get_contents(
                        'php://input'
                    )
                ),
                'text/html; charset=utf-8'
            );
            exit;

        case 'blockpage-custom-delete':
            netfortressRequire('NetFortress Block Page');
            netfortressForward(
                '/api/netfortress/blockpage-custom/delete',
                []
            );
            exit;

        case 'admin-port-set':
            netfortressRequire('NetFortress Operations');
            netfortressForward(
                '/api/netfortress/admin-port',
                [
                    'port' =>
                        (int)(
                            $body['port']
                            ?? 0
                        )
                ]
            );
            exit;

        case 'acme-set':
            netfortressRequire('NetFortress Operations');
            netfortressForward(
                '/api/netfortress/acme',
                $body
            );
            exit;

        case 'acme-request':
            netfortressRequire('NetFortress Operations');
            netfortressForward(
                '/api/netfortress/acme/request',
                []
            );
            exit;

        case 'dns-hostname-set':
            netfortressRequire('NetFortress Block Page');
            netfortressForward(
                '/api/netfortress/dns-hostname',
                [
                    'hostname' =>
                        (string)(
                            $body['hostname']
                            ?? ''
                        )
                ]
            );
            exit;

    }

    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Unknown action.'
    ]);
    exit;
}

switch ($action) {

    case 'devices':
        netfortressRequire('NetFortress Devices');
        netfortressForward(
            '/api/netfortress/devices'
        );
        exit;

    case 'modules':
        netfortressRequire('NetFortress Modules');
        netfortressForward(
            '/api/netfortress/modules'
        );
        exit;

    case 'events':
        netfortressRequire('NetFortress Reports');
        netfortressForward(
            '/api/netfortress/events'
        );
        exit;

    case 'network':
        netfortressRequire('Network');
        netfortressForward(
            '/api/netfortress/network'
        );
        exit;

    case 'dhcp':
        netfortressRequire('Network');
        netfortressForward(
            '/api/netfortress/dhcp'
        );
        exit;

    case 'wireguard':
        netfortressRequire('Network');
        netfortressForward(
            '/api/netfortress/wireguard'
        );
        exit;

    case 'audit':
        netfortressRequire('NetFortress Audit Log');
        netfortressForward(
            '/api/netfortress/audit'
        );
        exit;

    case 'blocklists':
        netfortressRequire('NetFortress Block list');
        netfortressForward(
            '/api/netfortress/blocklists'
        );
        exit;

    case 'applications':
        netfortressRequire('NetFortress Application Blocking');
        netfortressForward(
            '/api/netfortress/applications'
        );
        exit;

    case 'proxy':
        netfortressRequire('NetFortress Web Proxy and Cache');
        netfortressForward(
            '/api/netfortress/proxy'
        );
        exit;

    case 'policy':
        netfortressRequire('NetFortress Policy acceptance');
        netfortressForward(
            '/api/netfortress/policy'
        );
        exit;

    case 'blockpage':
        netfortressRequire('NetFortress Block Page');
        netfortressForward(
            '/api/netfortress/blockpage'
        );
        exit;

    case 'blockpage-logo':

        /*
         * The logo image itself.
         */

        netfortressRequire('NetFortress Block Page');

        global $FASTAPI_URL;

        $logo = @file_get_contents(
            $FASTAPI_URL
            . '/api/netfortress/blockpage-logo'
        );

        if ($logo === false) {
            http_response_code(404);
            exit;
        }

        $info = @getimagesizefromstring($logo);

        header(
            'Content-Type: '
            . ($info['mime']
                ?? 'image/png')
        );

        echo $logo;
        exit;

    case 'blockpage-preview':

        /*
         * The rendered block page, exactly as a
         * blocked client sees it.
         */

        netfortressRequire('NetFortress Block Page');

        global $FASTAPI_URL;

        header('Content-Type: text/html; charset=utf-8');

        echo @file_get_contents(
            $FASTAPI_URL
            . '/api/netfortress/blockpage-preview'
        );
        exit;

    case 'operations':
        netfortressRequire('NetFortress Operations');
        netfortressForward(
            '/api/netfortress/operations'
        );
        exit;

    case 'license':
        netfortressRequire('NetFortress Operations');
        netfortressForward(
            '/api/netfortress/license'
        );
        exit;

    case 'admin-port':
        netfortressRequire('NetFortress Operations');
        netfortressForward(
            '/api/netfortress/admin-port'
        );
        exit;

    case 'acme':
        netfortressRequire('NetFortress Operations');
        netfortressForward(
            '/api/netfortress/acme'
        );
        exit;

    case 'dns-hostname':
        netfortressRequire('NetFortress Block Page');
        netfortressForward(
            '/api/netfortress/dns-hostname'
        );
        exit;

    case 'ca':

        /*
         * The appliance HTTPS block CA certificate
         * (for installing on client devices).
         */

        netfortressRequire('NetFortress Block Page');

        global $FASTAPI_URL;

        $cert = @file_get_contents(
            $FASTAPI_URL
            . '/api/netfortress/ca'
        );

        if (
            $cert === false
            || strlen($cert) < 50
            || strncmp(ltrim($cert), '{', 1) === 0
        ) {

            /*
             * JSON body means the appliance has not
             * generated a certificate yet - answer with
             * a friendly JSON error, never a broken
             * download.
             */

            header('Content-Type: application/json; charset=utf-8');
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'message' => 'The HTTPS block service has not generated a certificate yet.'
            ]);
            exit;
        }

        header(
            'Content-Type: application/x-x509-ca-cert'
        );
        header(
            'Content-Disposition: attachment; '
            . 'filename="firewall-appliance-ca.crt"'
        );

        echo $cert;
        exit;

    case 'docs':

        /*
         * Manual PDF download from the appliance.
         */

        netfortressRequire('NetFortress Operations');

        $file =
            (string)(
                $_GET['file']
                ?? ''
            );

        if (
            !preg_match(
                '/^[A-Za-z0-9._-]+\\.pdf$/',
                $file
            )
        ) {
            http_response_code(400);
            exit;
        }

        global $FASTAPI_URL;

        $pdf = @file_get_contents(
            $FASTAPI_URL
            . '/api/netfortress/docs/'
            . rawurlencode($file)
        );

        if (
            $pdf === false
            || strlen($pdf) < 100
        ) {
            http_response_code(404);
            exit;
        }

        header('Content-Type: application/pdf');
        header(
            'Content-Disposition: attachment; '
            . 'filename="' . $file . '"'
        );

        echo $pdf;
        exit;

    case 'backup':

        /*
         * Backup download: streams the appliance backup
         * archive as a gzip file, not JSON.
         */

        netfortressRequire('NetFortress Operations');

        global $FASTAPI_URL;

        header('Content-Type: application/gzip');
        header(
            'Content-Disposition: attachment; '
            . 'filename="firewall-appliance-backup.tar.gz"'
        );

        echo @file_get_contents(
            $FASTAPI_URL
            . '/api/netfortress/backup'
        );

        exit;

}

http_response_code(400);
echo json_encode([
    'success' => false,
    'message' => 'Unknown action.'
]);
