<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * NetFortress appliance console proxy. The Settings
 * -> Services -> NetFortress pages (Devices, Modules)
 * call this endpoint; it forwards to the portal API,
 * which drives the local Firewall Appliance through
 * the network services provider. The caller must hold
 * the NetFortress permission.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

/*
 * Each NetFortress tab owns its own permission child
 * (NetFortress Devices, NetFortress Modules, ...). The
 * proxy enforces the permission that matches the action
 * so a group with access to only one tab cannot drive
 * another tab's appliance features.
 */

function netfortressRequire(
    string $permission
) {

    if (
        !hasPermission(
            $permission
        )
    ) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Access denied.'
        ]);
        exit;
    }

}

function netfortressForward(
    string $path,
    array $payload = null
) {

    global $FASTAPI_URL;

    if (
        $payload === null
    ) {
        echo @file_get_contents(
            $FASTAPI_URL
            . $path
        );

        return;
    }

    $context =
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => json_encode(
                    $payload
                )
            ]
        ]);

    echo @file_get_contents(
        $FASTAPI_URL
        . $path,
        false,
        $context
    );
}

$action =
    (string)(
        $_GET['action']
        ?? ''
    );

if (
    $_SERVER['REQUEST_METHOD']
    === 'POST'
) {

    $body =
        json_decode(
            file_get_contents(
                'php://input'
            ),
            true
        ) ?? [];

    switch ($action) {

        case 'block':
            netfortressRequire('NetFortress Devices');
            netfortressForward(
                '/api/netfortress/devices/block',
                [
                    'target_type' =>
                        (string)(
                            $body['target_type']
                            ?? ''
                        ),
                    'target_value' =>
                        (string)(
                            $body['target_value']
                            ?? ''
                        ),
                    'reason' =>
                        (string)(
                            $body['reason']
                            ?? ''
                        )
                ]
            );
            exit;

        case 'unblock':
            netfortressRequire('NetFortress Devices');
            netfortressForward(
                '/api/netfortress/devices/unblock',
                [
                    'policy_id' =>
                        (int)(
                            $body['policy_id']
                            ?? 0
                        )
                ]
            );
            exit;

        case 'toggle':
            netfortressRequire('NetFortress Modules');
            netfortressForward(
                '/api/netfortress/modules/toggle',
                [
                    'module_key' =>
                        (string)(
                            $body['module_key']
                            ?? ''
                        ),
                    'enabled' =>
                        (bool)(
                            $body['enabled']
                            ?? false
                        )
                ]
            );
            exit;

        case 'ids':
            netfortressRequire('NetFortress Modules');
            netfortressForward(
                '/api/netfortress/modules/ids',
                [
                    'action' =>
                        (string)(
                            $body['op']
                            ?? ''
                        )
                ]
            );
            exit;

    }

    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Unknown action.'
    ]);
    exit;
}

switch ($action) {

    case 'devices':
        netfortressRequire('NetFortress Devices');
        netfortressForward(
            '/api/netfortress/devices'
        );
        exit;

    case 'modules':
        netfortressRequire('NetFortress Modules');
        netfortressForward(
            '/api/netfortress/modules'
        );
        exit;

    case 'events':
        netfortressRequire('NetFortress Reports');
        netfortressForward(
            '/api/netfortress/events'
        );
        exit;

}

http_response_code(400);
echo json_encode([
    'success' => false,
    'message' => 'Unknown action.'
]);
