<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (!hasPermission('Theme')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'appearance-theme';
$pageHeading = 'Customization';
$showSidebarPageHeading = true;


$portalSettings =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];


$currentTheme =
    strtolower(
        trim(
            (string)(
                $portalSettings['theme']
                ?? 'basic'
            )
        )
    );

if ($currentTheme === '') {
    $currentTheme = 'basic';
}


/*
 * UPDATE003 - Portal Theme Registry
 *
 * New themes can be registered here without changing
 * the Theme page layout.
 *
 * Only Basic is available in Update003.
 */

$availableThemes = [

    'basic' => [
        'name' => 'Basic',
        'description' =>
            'The standard Portal theme with the full-height sidebar, '
            . 'configurable banner and company branding.',
        'available' => true
    ],

    'firewall' => [
        'name' => 'Firewall',
        'description' =>
            'The network security look: deep navy panels on '
            . 'near-black with sky-blue accents, '
            . 'matching the firewall appliance interface.',
        'available' => true
    ]

];

?>
<!DOCTYPE html>
<html>
<head>

    <title>Appearance - Theme</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined"
        rel="stylesheet">

</head>

<body>

<?php include 'includes/banner.php'; ?>
<?php include 'includes/sidebar.php'; ?>


<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>

            <h1>Appearance</h1>

            <p>
                Select the visual theme used throughout the portal.
            </p>

        </div>

        <div class="appearance-theme-badge">
            Active: <?= htmlspecialchars(
                $availableThemes[$currentTheme]['name']
                ?? ucfirst($currentTheme)
            ) ?>
        </div>

    </div>


        <?php include __DIR__ . '/includes/page-tabs.php'; ?>


    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>

                <h2>Portal Theme</h2>

                <p>
                    Choose the base design used by the Portal interface.
                </p>

            </div>

        </div>


        <div class="appearance-theme-grid">

            <?php foreach($availableThemes as $themeKey => $theme): ?>

            <?php
                $isActive =
                    $currentTheme === $themeKey;
            ?>

            <article
                class="appearance-theme-card<?= $isActive ? ' active' : '' ?>">

                <div class="appearance-theme-preview appearance-theme-preview-basic appearance-theme-preview-<?= htmlspecialchars($themeKey) ?>">

                    <div class="theme-preview-sidebar">

                        <div class="theme-preview-logo"></div>

                        <div class="theme-preview-avatar"></div>

                        <div class="theme-preview-nav active"></div>
                        <div class="theme-preview-nav"></div>
                        <div class="theme-preview-nav short"></div>

                    </div>

                    <div class="theme-preview-main">

                        <div class="theme-preview-banner">

                            <div class="theme-preview-welcome"></div>
                            <div class="theme-preview-company"></div>

                        </div>

                        <div class="theme-preview-content">

                            <div class="theme-preview-panel wide"></div>

                            <div class="theme-preview-row">
                                <div class="theme-preview-panel"></div>
                                <div class="theme-preview-panel"></div>
                            </div>

                        </div>

                    </div>

                </div>


                <div class="appearance-theme-card-body">

                    <div class="appearance-theme-card-heading">

                        <div>

                            <h3>
                                <?= htmlspecialchars($theme['name']) ?>
                            </h3>

                            <?php if($isActive): ?>

                            <span class="appearance-theme-active">
                                <span class="material-symbols-outlined">
                                    check_circle
                                </span>
                                Active
                            </span>

                            <?php endif; ?>

                        </div>

                    </div>


                    <p>
                        <?= htmlspecialchars($theme['description']) ?>
                    </p>


                    <div class="appearance-theme-card-actions">

                        <?php if($isActive): ?>

                        <button
                            type="button"
                            class="table-btn appearance-theme-current"
                            disabled>
                            Current Theme
                        </button>

                        <?php if($themeKey === 'basic'): ?>

                        <a
                            href="appearance-theme-basic.php"
                            class="table-btn appearance-theme-customize">
                            Customize
                        </a>

                        <?php endif; ?>

                        <?php elseif(!empty($theme['available'])): ?>

                        <button
                            type="button"
                            class="table-btn appearance-theme-select"
                            data-theme="<?= htmlspecialchars($themeKey) ?>">
                            Use Theme
                        </button>

                        <?php else: ?>

                        <button
                            type="button"
                            class="table-btn"
                            disabled>
                            Not Available
                        </button>

                        <?php endif; ?>

                    </div>

                </div>

            </article>

            <?php endforeach; ?>

        </div>


        <p class="appearance-theme-note">
            Additional themes can be added later without changing
            the Basic theme configuration.
        </p>

    </div>

</div>


<div
    id="appearanceThemeMessage"
    class="appearance-theme-message"
    role="status"
    aria-live="polite">
</div>


<script>
(function () {

    const buttons =
        document.querySelectorAll(
            '.appearance-theme-select'
        );

    const message =
        document.getElementById(
            'appearanceThemeMessage'
        );


    function showMessage(text, success) {

        if (!message) {
            return;
        }

        message.textContent =
            (success ? '✓ ' : '') + text;

        message.classList.toggle(
            'success',
            success
        );

        message.classList.toggle(
            'error',
            !success
        );

        message.classList.add('show');


        window.setTimeout(
            function () {
                message.classList.remove('show');
            },
            3500
        );
    }


    buttons.forEach(
        function (button) {

            button.addEventListener(
                'click',
                async function () {

                    const theme =
                        button.dataset.theme || '';

                    if (!theme) {
                        return;
                    }


                    button.disabled = true;


                    try {

                        const response =
                            await fetch(
                                'appearance-api.php',
                                {
                                    method: 'POST',

                                    headers: {
                                        'Content-Type':
                                            'application/json'
                                    },

                                    body: JSON.stringify({
                                        action: 'save',
                                        settings: {
                                            theme: theme
                                        }
                                    })
                                }
                            );

                        const data =
                            await response.json();


                        if (
                            !response.ok
                            ||
                            !data.success
                        ) {

                            throw new Error(
                                data.message
                                || 'Unable to change theme.'
                            );
                        }


                        showMessage(
                            data.message
                            || 'Theme updated.',
                            true
                        );


                        window.setTimeout(
                            function () {
                                window.location.reload();
                            },
                            450
                        );

                    } catch (error) {

                        showMessage(
                            error.message
                            || 'Unable to change theme.',
                            false
                        );

                        button.disabled = false;
                    }
                }
            );
        }
    );

})();
</script>

</body>
</html>
