<?php

$FASTAPI_URL = "http://127.0.0.1:8000";
$TECHNITIUM_HOST = "127.0.0.1";

?>