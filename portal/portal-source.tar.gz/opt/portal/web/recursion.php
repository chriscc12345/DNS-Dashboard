<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';

if (
    !hasPermission(
        'Recursion'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'recursion';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

/*
 * Read the live recursion settings
 * from the Technitium DNS server API
 * for the initial render.
 */

function technitiumRecursionSettings() {

    global $TECHNITIUM_HOST, $TECHNITIUM_TOKEN;

    $ch = curl_init(
        'http://' . $TECHNITIUM_HOST
        . ':5380/api/settings/get'
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer '
            . $TECHNITIUM_TOKEN
        ],
        CURLOPT_TIMEOUT => 10
    ]);

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    $json = json_decode($body, true);

    if (
        !is_array($json)
        || ($json['status'] ?? '') !== 'ok'
    ) {
        return null;
    }

    return $json['response'] ?? [];
}

$recursionSettings =
    technitiumRecursionSettings();

$recursionPolicy =
    (string)(
        $recursionSettings['recursion']
        ?? 'Deny'
    );

$recursionNetworks =
    is_array(
        $recursionSettings[
            'recursionNetworkACL'
        ]
        ?? null
    )
        ? $recursionSettings[
            'recursionNetworkACL'
        ]
        : [];

$recursionNetworksText =
    implode("\n", $recursionNetworks);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Technitium - Recursion</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Technitium</h1>

            <p>
                Manage the Technitium DNS server.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="settings-saved" id="recursion_saved" hidden>
        Settings saved.
    </div>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Recursion</h2>

                <p>
                    Control which clients the DNS server resolves recursively for.
                </p>
            </div>

        </div>

        <div class="settings-form">

            <div class="settings-field">

                <label for="recursion_policy">
                    Recursion Policy
                </label>

                <select
                    id="recursion_policy"
                    class="table-control">

                    <option
                        value="Deny"
                        <?= $recursionPolicy === 'Deny'
                            ? 'selected'
                            : '' ?>>
                        Deny
                    </option>

                    <option
                        value="AllowOnlyForPrivateNetworks"
                        <?= $recursionPolicy === 'AllowOnlyForPrivateNetworks'
                            ? 'selected'
                            : '' ?>>
                        Allow Only For Private Networks
                    </option>

                    <option
                        value="UseSpecifiedNetworkACL"
                        <?= $recursionPolicy === 'UseSpecifiedNetworkACL'
                            ? 'selected'
                            : '' ?>>
                        Use Specified Network ACL
                    </option>

                    <option
                        value="Allow"
                        <?= $recursionPolicy === 'Allow'
                            ? 'selected'
                            : '' ?>>
                        Allow
                    </option>

                </select>

            </div>

            <div class="settings-field">

                <label for="recursion_networks">
                    Recursion Networks
                </label>

                <textarea
                    id="recursion_networks"
                    class="table-control"
                    rows="5"
                    spellcheck="false"
                    <?= $recursionPolicy !== 'UseSpecifiedNetworkACL'
                        ? 'disabled'
                        : '' ?>><?= htmlspecialchars(
                            $recursionNetworksText
                        ) ?></textarea>

                <p class="appearance-help">
                    One IP or network address per line.
                    Add ! at the start of an entry to
                    deny it. The list is processed in
                    order and is used only with the Use
                    Specified Network ACL policy.
                </p>

            </div>

            <p class="appearance-help">
                If no network matches the ACL, the
                default policy denies everything
                except loopback.
            </p>

            <button
                type="button"
                id="save_recursion"
                class="approve-btn">
                Save
            </button>

        </div>

    </div>

</div>

<script>
const recursionApi =
    'technitium-recursion-api.php';

const recursionPolicySelect =
    document.getElementById('recursion_policy');
const recursionNetworksBox =
    document.getElementById('recursion_networks');
const recursionSavedBox =
    document.getElementById('recursion_saved');

let recursionFlashTimer = null;

function syncRecursionNetworks() {

    recursionNetworksBox.disabled =
        recursionPolicySelect.value
            !== 'UseSpecifiedNetworkACL';
}

function showRecursionMessage(message) {

    recursionSavedBox.hidden = false;
    recursionSavedBox.textContent = message;

    if (recursionFlashTimer) {
        clearTimeout(recursionFlashTimer);
    }

    recursionFlashTimer = setTimeout(() => {
        recursionSavedBox.hidden = true;
    }, 4000);
}

function applyRecursionView(view) {

    if (!view || view.success !== true) {
        return;
    }

    recursionPolicySelect.value =
        view.recursion || 'Deny';

    recursionNetworksBox.value =
        (view.recursion_networks || [])
            .join('\n');

    syncRecursionNetworks();
}

async function refreshRecursion() {

    try {

        const response = await fetch(
            recursionApi + '?action=get'
        );

        applyRecursionView(
            await response.json()
        );

    } catch (error) {
        /* keep the server rendered values */
    }
}

recursionPolicySelect.addEventListener(
    'change',
    syncRecursionNetworks
);

document
    .getElementById('save_recursion')
    .addEventListener('click', async () => {

        const response = await fetch(
            recursionApi,
            {
                method: 'POST',
                body: new URLSearchParams({
                    action: 'set',
                    recursion:
                        recursionPolicySelect.value,
                    recursion_networks:
                        recursionNetworksBox.value
                })
            }
        );

        const json =
            await response.json();

        if (json.success !== true) {
            showRecursionMessage(
                json.message || 'Update failed.'
            );
            return;
        }

        applyRecursionView(json);
        showRecursionMessage(
            'Recursion settings saved.'
        );
    }
);

refreshRecursion();
</script>

</body>

</html>
