<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Modules')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-modules';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Modules</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-module-state {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
        }
        .nf-module-state-on {
            background: var(--theme-basic-success, #237a4b);
            color: #fff;
        }
        .nf-module-state-off {
            background: var(--theme-basic-button-secondary, #24313a);
            color: #fff;
        }
        .nf-ids-panel {
            margin-top: 18px;
            padding: 16px;
            border: 1px solid var(--theme-basic-card-border, #637681);
            border-radius: 8px;
            background: var(--theme-basic-card-background, #18232a);
            color: var(--theme-basic-card-text, #fff);
        }
        .nf-ids-panel h3 {
            margin: 0 0 6px 0;
        }
        .nf-ids-panel p {
            margin: 0 0 12px 0;
            font-size: 13px;
            color: var(--theme-basic-text-secondary, #aebbc3);
        }
        .nf-ids-actions button {
            margin-right: 8px;
        }
        #nfModulesMessage {
            margin-top: 10px;
            font-size: 13px;
            display: none;
        }
        #nfModulesMessage.nf-message-error {
            color: var(--theme-basic-error, #b83b3b);
            display: block;
        }
        #nfModulesMessage.nf-message-ok {
            color: var(--theme-basic-success, #237a4b);
            display: block;
        }
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Firewall modules - enabled modules are compiled into
                the appliance policy.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel um-table-panel">

        <table id="nfModulesTable">
            <thead>
            <tr>
                <th>Module</th>
                <th>Description</th>
                <th>State</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody id="nfModulesBody">
            <tr>
                <td colspan="4">Loading modules from the appliance...</td>
            </tr>
            </tbody>
        </table>

        <div id="nfModulesMessage"></div>

        <div id="nfIdsPanel" class="nf-ids-panel" style="display:none">
            <h3>IDS/IPS (Suricata)</h3>
            <p id="nfIdsStatus">Checking IDS/IPS status...</p>
            <div class="nf-ids-actions">
                <button type="button" class="approve-btn nf-ids-action" data-op="install">Install IDS/IPS</button>
                <button type="button" class="deny-btn nf-ids-action" data-op="uninstall">Uninstall</button>
                <button type="button" class="table-btn nf-ids-action" data-op="rules_update">Update Rules</button>
            </div>
        </div>

        <p style="margin-top:10px;font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3);">
            Module changes are enforced by the appliance on its next
            policy refresh. The list refreshes automatically every 15 seconds.
        </p>

    </div>

</div>

<script>
(function () {

    const body = document.getElementById('nfModulesBody');
    const message = document.getElementById('nfModulesMessage');
    const idsPanel = document.getElementById('nfIdsPanel');
    const idsStatus = document.getElementById('nfIdsStatus');

    let loading = false;
    let lastSignature = null;

    function showMessage(text, ok) {

        if (!text) {
            message.className = '';
            message.textContent = '';
            return;
        }

        message.className = ok
            ? 'nf-message-ok'
            : 'nf-message-error';
        message.textContent = text;

    }

    function escapeHtml(value) {

        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');

    }

    function renderRow(module) {

        const row = document.createElement('tr');

        const enabled = !!module.enabled;

        /* Modules that cannot work in the current deployment mode are
           locked: no toggle, greyed row, the reason underneath. */

        const notApplicable = module.applicable === false;

        if (notApplicable) {

            row.style.opacity = '0.5';

            row.innerHTML =
                '<td><strong>' + escapeHtml(module.name) + '</strong>' +
                '<br><small style="color:#888">' + escapeHtml(module.key) + '</small></td>' +
                '<td>' + escapeHtml(module.description || '') +
                '<br><small style="color:#888">' +
                escapeHtml(module.unavailable_reason || '') + '</small></td>' +
                '<td>' +
                '<span class="nf-module-state nf-module-state-off">Not applicable</span>' +
                '</td>' +
                '<td>&mdash;</td>';

            return row;

        }

        row.innerHTML =
            '<td><strong>' + escapeHtml(module.name) + '</strong>' +
            '<br><small style="color:#888">' + escapeHtml(module.key) + '</small></td>' +
            '<td>' + escapeHtml(module.description || '') +
            (
                module.requires && module.requires.length
                    ? '<br><small style="color:#888">Requires: ' +
                      escapeHtml(module.requires.join(', ')) + '</small>'
                    : ''
            ) +
            '</td>' +
            '<td>' +
            (
                enabled
                    ? '<span class="nf-module-state nf-module-state-on">Enabled</span>'
                    : '<span class="nf-module-state nf-module-state-off">Disabled</span>'
            ) +
            '</td>' +
            '<td>' +
            '<button type="button" class="' +
            (enabled ? 'deny-btn' : 'approve-btn') +
            ' nf-module-toggle" data-key="' + escapeHtml(module.key) + '" ' +
            'data-enabled="' + (enabled ? '0' : '1') + '" ' +
            'data-label="' + escapeHtml(module.name) + '">' +
            (enabled ? 'Disable' : 'Enable') +
            '</button>' +
            '</td>';

        return row;

    }

    function cleanHelperMessage(message) {

        /* The appliance helper reports raw sudo/system noise when the
           privileged helper is unavailable; show a clean sentence
           instead of the terminal output. */

        const text = String(message || '').trim();

        if (!text) {
            return '';
        }

        if (/sudo:|password is required|read-only file system/i.test(text)) {
            return 'The IDS/IPS helper is not available on this appliance.';
        }

        return text;

    }

    function renderIds(ids) {

        if (!ids) {
            idsPanel.style.display = 'none';
            return;
        }

        idsPanel.style.display = 'block';

        const installed = !!ids.installed;
        const running = !!ids.running;

        const parts = [installed ? 'Installed' : 'Not installed'];

        if (running) {
            parts.push('running');
        }

        const note = cleanHelperMessage(ids.message);

        if (note) {
            parts.push(note);
        }

        idsStatus.textContent = parts.join(' - ');

    }

    function loadModules() {

        if (loading) {
            return;
        }

        loading = true;

        fetch('netfortress-api.php?action=modules')
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {

                loading = false;

                if (!data.success) {
                    lastSignature = null;
                    body.innerHTML =
                        '<tr><td colspan="4">' +
                        escapeHtml(data.message || 'The appliance is not reachable.') +
                        '</td></tr>';
                    idsPanel.style.display = 'none';
                    return;
                }

                /* Only re-render when the data actually changed - a
                   rebuild on every poll causes a visible flash. */

                const signature = JSON.stringify(data);

                if (signature === lastSignature) {
                    return;
                }

                lastSignature = signature;

                body.innerHTML = '';

                (data.modules || []).forEach(function (module) {
                    body.appendChild(renderRow(module));
                });

                renderIds(data.ids_ips);

            })
            .catch(function () {

                loading = false;

                body.innerHTML =
                    '<tr><td colspan="4">' +
                    'The appliance API is not reachable.</td></tr>';

            });

    }

    function postAction(action, payload, label) {

        showMessage('Working: ' + label + '...', true);

        fetch('netfortress-api.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {

                if (data.success) {
                    showMessage(label + ' completed.', true);
                } else {
                    showMessage(
                        cleanHelperMessage(data.message) ||
                            'The appliance rejected the request.',
                        false
                    );
                }

                loadModules();

            })
            .catch(function () {
                showMessage('The appliance API is not reachable.', false);
                loadModules();
            });

    }

    document.addEventListener(
        'click',
        function (event) {

            const toggle = event.target.closest('.nf-module-toggle');

            if (toggle) {
                postAction(
                    'toggle',
                    {
                        module_key: toggle.dataset.key,
                        enabled: toggle.dataset.enabled === '1'
                    },
                    (toggle.dataset.enabled === '1' ? 'Enabling ' : 'Disabling ') + toggle.dataset.label
                );
                return;
            }

            const idsButton = event.target.closest('.nf-ids-action');

            if (idsButton) {
                const labels = {
                    install: 'Installing IDS/IPS',
                    uninstall: 'Uninstalling IDS/IPS',
                    rules_update: 'Updating IDS/IPS rules'
                };
                idsButton.disabled = true;
                postAction(
                    'ids',
                    { op: idsButton.dataset.op },
                    labels[idsButton.dataset.op] || 'IDS/IPS action'
                );
            }

        }
    );

    loadModules();
    setInterval(loadModules, 15000);

})();
</script>

</body>

</html>
