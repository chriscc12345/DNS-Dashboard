<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Local network interface proxy.
 * Serves the Local Interface tab on
 * the Network page. Forwards LAN
 * configuration reads and applies to
 * the portal API. The caller must
 * hold the Network permission.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

if (
    !hasPermission(
        'Network'
    )
) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

function fastapiNetworkJson(
    $path,
    $payload = null
) {

    global $FASTAPI_URL;

    $ch = curl_init(
        $FASTAPI_URL . $path
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 70
    ]);

    if ($payload !== null) {

        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: '
                . 'application/json'
            ],
            CURLOPT_POSTFIELDS =>
                json_encode($payload)
        ]);
    }

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    return json_decode($body, true);
}

function networkProxyResult($data) {

    if ($data === null) {
        return [
            'success' => false,
            'message' =>
                'The portal API did not '
                . 'respond.'
        ];
    }

    $data['success'] =
        ($data['status'] ?? '') === 'ok';

    unset($data['status']);

    return $data;
}

$action =
    $_GET['action']
    ?? ($_POST['action'] ?? '');

if ($action === 'get') {

    echo json_encode(
        networkProxyResult(
            fastapiNetworkJson(
                '/network/interface'
            )
        )
    );
    exit;
}

if ($action === 'apply') {

    $payload = [
        'interface' =>
            (string)(
                $_POST['interface'] ?? ''
            ),
        'method' =>
            (string)(
                $_POST['method'] ?? ''
            ),
        'address' =>
            (string)(
                $_POST['address'] ?? ''
            ),
        'netmask' =>
            (string)(
                $_POST['netmask'] ?? ''
            ),
        'gateway' =>
            (string)(
                $_POST['gateway'] ?? ''
            ),
        'dns' =>
            (string)(
                $_POST['dns'] ?? ''
            ),
        'dry_run' =>
            (string)(
                $_POST['dry_run'] ?? ''
            ) === '1'
    ];

    echo json_encode(
        networkProxyResult(
            fastapiNetworkJson(
                '/network/interface',
                $payload
            )
        )
    );
    exit;
}

echo json_encode([
    'success' => false,
    'message' => 'Unknown action.'
]);
