<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// User Management tab POST redirects
// work cleanly.
require_once __DIR__
    . '/includes/user-management-tabs-head.php';

$countryDialCodes = require __DIR__ . '/includes/countries.php';

$currentSection = 'settings';
$currentPage = 'users';
$pageHeading = 'Security';
$showSidebarPageHeading = true;

if(
    !hasPermission('Users')
){
    include 'includes/access-denied.php';
    exit;
}


if(isset($_POST['create_user'])){

    if(
        $_POST['password']
        !==
        $_POST['confirm_password']
    ){
        header(
            "Location: users.php?error=password_mismatch"
        );
        exit;
    }

    $data = json_encode([
        'display_name' => $_POST['display_name'],
        'username'     => $_POST['username'],
        'password'     => $_POST['password']
    ]);

    $response = file_get_contents(
        $FASTAPI_URL . "/users/create",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    $createResult = json_decode($response, true);

    if(
        !is_array($createResult)
        ||
        (
            isset($createResult['status'])
            &&
            strtolower((string)$createResult['status']) === 'error'
        )
    ){
        $message = 'Unable to create user';

        if(
            is_array($createResult)
            &&
            !empty($createResult['message'])
        ){
            $message = $createResult['message'];
        }

        header(
            "Location: users.php?error=" .
            urlencode($message)
        );
        exit;
    }

    /* Save User Profile */

    $profileData = json_encode([
        'username'      => $_POST['username'],
        'display_name'  => $_POST['display_name'],
        'surname'       => $_POST['surname'],
        'email_address' => $_POST['email_address'],
        'country_code'  => $_POST['country_code'],
        'mobile_number' => $_POST['mobile_number'],
        'department'    => $_POST['department'],
        'photo'         => $_POST['photo'] ?? '',
        'group_id'      => (int)$_POST['group_id']
    ]);

    $profileResponse = file_get_contents(
        $FASTAPI_URL . "/user-profiles/create",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $profileData
            ]
        ])
    );

    $profileResult = json_decode(
        $profileResponse,
        true
    );

    if(
        !is_array($profileResult)
        ||
        empty($profileResult['success'])
    ){
        $message = 'Unable to create user profile';

        if(
            is_array($profileResult)
            &&
            !empty($profileResult['message'])
        ){
            $message = $profileResult['message'];
        }

        header(
            "Location: users.php?error=" .
            urlencode($message)
        );
        exit;
    }

    /* Save Group */

    if(!empty($_POST['group_id'])){

        $groupData = json_encode([
            'username' => $_POST['username'],
            'group_id' => (int)$_POST['group_id']
        ]);

        file_get_contents(
            $FASTAPI_URL . "/users/group/save",
            false,
            stream_context_create([
                'http' => [
                    'method'  => 'POST',
                    'header'  =>
                        "Content-Type: application/json\r\n",
                    'content' => $groupData
                ]
            ])
        );
    }

    header("Location: users.php");
    exit;
}

if(isset($_POST['update_user'])){

    /*
     * Update003:
     * Edit User supports AJAX saves while retaining the
     * traditional redirect as a non-JavaScript fallback.
     */

    $isAjax =
        isset($_POST['ajax'])
        &&
        $_POST['ajax'] === '1';


    $sendEditUserResponse =
        function(
            bool $success,
            string $message,
            int $statusCode = 200,
            array $extra = []
        ) use ($isAjax) {

            if ($isAjax) {

                http_response_code($statusCode);

                header(
                    'Content-Type: application/json; charset=utf-8'
                );

                echo json_encode(
                    array_merge(
                        [
                            'success' => $success,
                            'message' => $message
                        ],
                        $extra
                    )
                );

                exit;
            }

            if (!$success) {

                http_response_code($statusCode);

                echo htmlspecialchars(
                    $message,
                    ENT_QUOTES,
                    'UTF-8'
                );

                exit;
            }

            header("Location: users.php");
            exit;
        };


    $editUserApiRequest =
        function(
            string $url,
            array $payload
        ): array {

            $context = stream_context_create([
                'http' => [
                    'method'        => 'POST',
                    'header'        =>
                        "Content-Type: application/json\r\n",
                    'content'       => json_encode($payload),
                    'ignore_errors' => true,
                    'timeout'       => 10
                ]
            ]);

            $response =
                @file_get_contents(
                    $url,
                    false,
                    $context
                );

            $statusCode = 0;

            if (
                isset($http_response_header)
                &&
                is_array($http_response_header)
                &&
                isset($http_response_header[0])
                &&
                preg_match(
                    '/\s(\d{3})\s/',
                    $http_response_header[0],
                    $matches
                )
            ) {
                $statusCode = (int)$matches[1];
            }

            $decoded =
                $response !== false
                    ? json_decode($response, true)
                    : null;

            $ok =
                $response !== false
                &&
                (
                    $statusCode === 0
                    ||
                    (
                        $statusCode >= 200
                        &&
                        $statusCode < 300
                    )
                );

            return [
                'ok'     => $ok,
                'status' => $statusCode,
                'data'   =>
                    is_array($decoded)
                        ? $decoded
                        : null
            ];
        };


    $username =
        trim(
            (string)(
                $_POST['username']
                ?? ''
            )
        );

    $displayName =
        trim(
            (string)(
                $_POST['display_name']
                ?? ''
            )
        );


    if ($username === '') {

        $sendEditUserResponse(
            false,
            'Username is required.',
            400
        );
    }


    if ($displayName === '') {

        $sendEditUserResponse(
            false,
            'Display Name is required.',
            400
        );
    }


    /*
     * 1. Update the Technitium-facing user record.
     */

    $userResult =
        $editUserApiRequest(
            $FASTAPI_URL . "/users/update",
            [
                'username'     => $username,
                'display_name' => $displayName
            ]
        );

    if (!$userResult['ok']) {

        $message =
            is_array($userResult['data'])
            &&
            !empty($userResult['data']['detail'])
                ? (string)$userResult['data']['detail']
                : 'Unable to update the user account.';

        $sendEditUserResponse(
            false,
            $message,
            502
        );
    }


    /*
     * 2. Update the Portal profile.
     */

    $groupId =
        isset($_POST['group_id'])
            ? (int)$_POST['group_id']
            : 0;

    $profileResult =
        $editUserApiRequest(
            $FASTAPI_URL . "/user-profiles/update",
            [
                'username'      => $username,
                'display_name'  => $displayName,
                'surname'       =>
                    trim(
                        (string)(
                            $_POST['surname']
                            ?? ''
                        )
                    ),
                'department'    =>
                    trim(
                        (string)(
                            $_POST['department']
                            ?? ''
                        )
                    ),
                'email_address' =>
                    trim(
                        (string)(
                            $_POST['email_address']
                            ?? ''
                        )
                    ),
                'country_code'  =>
                    trim(
                        (string)(
                            $_POST['country_code']
                            ?? ''
                        )
                    ),
                'mobile_number' =>
                    trim(
                        (string)(
                            $_POST['mobile_number']
                            ?? ''
                        )
                    ),
                'photo'         =>
                    trim(
                        (string)(
                            $_POST['photo']
                            ?? ''
                        )
                    ),
                'group_id'      => $groupId
            ]
        );

    if (!$profileResult['ok']) {

        $message =
            is_array($profileResult['data'])
            &&
            !empty($profileResult['data']['detail'])
                ? (string)$profileResult['data']['detail']
                : 'Unable to update the user profile.';

        $sendEditUserResponse(
            false,
            $message,
            502
        );
    }


    /*
     * 3. Save the authoritative Portal group assignment.
     */

    if ($groupId > 0) {

        $groupResult =
            $editUserApiRequest(
                $FASTAPI_URL . "/users/group/save",
                [
                    'username' => $username,
                    'group_id' => $groupId
                ]
            );

        if (!$groupResult['ok']) {

            $message =
                is_array($groupResult['data'])
                &&
                !empty($groupResult['data']['detail'])
                    ? (string)$groupResult['data']['detail']
                    : 'User profile was updated, but the group assignment could not be saved.';

            $sendEditUserResponse(
                false,
                $message,
                502
            );
        }
    }


    $sendEditUserResponse(
        true,
        'User profile saved successfully.',
        200,
        [
            'profile' => [
                'username'      => $username,
                'display_name'  => $displayName,
                'email_address' =>
                    trim(
                        (string)(
                            $_POST['email_address']
                            ?? ''
                        )
                    ),
                'group_id'      => $groupId
            ]
        ]
    );
}


if(isset($_POST['delete_user'])){

    if(
        $_POST['username'] === 'admin' ||
        $_POST['username'] === 'api'
    ){

        header("Location: users.php");
        exit;

    }

    $data = json_encode([
        'username' => $_POST['username']
    ]);

    file_get_contents(
        $FASTAPI_URL . "/users/delete",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );
    
    file_get_contents(
        $FASTAPI_URL . "/user-profiles/delete",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: users.php");
    exit;

}

if(isset($_POST['reset_password'])){

    if(empty(trim($_POST['password']))){
        header("Location: users.php?error=blank_password");
        exit;
    }

    if(
        $_POST['password'] !==
        $_POST['confirm_password']
    ){
        header("Location: users.php?error=password_mismatch");
        exit;
    }

    $data = json_encode([
        'username' => $_POST['username'],
        'password' => $_POST['password']
    ]);

    file_get_contents(
        $FASTAPI_URL . "/users/reset-password",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: users.php");
    exit;
}


/*
 * UPDATE - Portal 2FA admin reset.
 * Clears a locked-out user's two-factor enrolment;
 * they can sign in with just their password again.
 */

if(isset($_POST['reset_2fa'])){

    $data = json_encode([
        'username' => $_POST['username']
    ]);

    file_get_contents(
        $FASTAPI_URL . "/2fa/reset",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: users.php");
    exit;
}

if(isset($_POST['toggle_user'])){

    $endpoint =
        ($_POST['disabled'] === 'true')
        ? '/users/enable'
        : '/users/disable';

    $data = json_encode([
        'username' => $_POST['username']
    ]);

    file_get_contents(
        $FASTAPI_URL . $endpoint,
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: users.php");
    exit;
}

$json = file_get_contents(
    $FASTAPI_URL . "/users"
);

$data = json_decode($json, true);

$users = $data['response']['users'] ?? [];

$groups = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/groups"
    ),
    true
);

$userGroups = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/users/groups"
    ),
    true
);

$userGroupMap = [];

foreach (($userGroups ?? []) as $username => $groupName) {
    $userGroupMap[strtolower($username)] = $groupName;
}

$userProfiles = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/user-profiles"
    ),
    true
);

$portalSettings = json_decode(
    @file_get_contents(
        $FASTAPI_URL . "/portal-settings"
    ),
    true
);

$defaultCountryIso =
    strtoupper(
        trim(
            (string)(
                $portalSettings['default_country_iso']
                ?? 'ZA'
            )
        )
    );

if(
    !preg_match(
        '/^[A-Z]{2}$/',
        $defaultCountryIso
    )
){
    $defaultCountryIso = 'ZA';
}


/* UPDATE003 - Add User Disclaimer settings */

$userDisclaimerEnabled =
    strtolower(
        trim(
            (string)(
                $portalSettings['user_disclaimer_enabled']
                ?? 'true'
            )
        )
    ) === 'true';

$userDisclaimerTitle =
    trim(
        (string)(
            $portalSettings['user_disclaimer_title']
            ?? 'User Information'
        )
    );

$userDisclaimerText =
    trim(
        (string)(
            $portalSettings['user_disclaimer_text']
            ?? 'Create a new user account for the portal and assign the appropriate group and permissions.'
        )
    );

$userDisclaimerChecklist =
    (string)(
        $portalSettings['user_disclaimer_checklist']
        ?? "User will be created in the portal\nProfile details will be saved\nGroup permissions will apply\nUser will be able to log in once created"
    );

$userDisclaimerNote =
    trim(
        (string)(
            $portalSettings['user_disclaimer_note']
            ?? 'Make sure the information is correct before creating the user.'
        )
    );

$userDisclaimerItems =
    preg_split(
        '/\r\n|\r|\n/',
        $userDisclaimerChecklist
    );

$userDisclaimerItems =
    array_values(
        array_filter(
            array_map(
                'trim',
                $userDisclaimerItems
            ),
            static function ($item) {
                return $item !== '';
            }
        )
    );

$profileMap = [];

foreach ($userProfiles as $profile) {

    $profileMap[strtolower($profile['username'])] = $profile;

}

/*
 * Server-side user search and page size.
 */

$search =
    trim(
        (string)(
            $_GET['search'] ?? ''
        )
    );

$perPageParam =
    (string)(
        $_GET['per_page'] ?? '10'
    );

$perPage =
    in_array(
        $perPageParam,
        ['10', '25', '50', '100', 'all'],
        true
    )
        ? $perPageParam
        : '10';

if ($search !== '') {

    $users = array_values(
        array_filter(
            $users,
            static function ($user) use ($search, $profileMap, $userGroupMap) {

                $username =
                    strtolower(
                        (string)(
                            $user['username'] ?? ''
                        )
                    );

                $profile =
                    $profileMap[$username] ?? [];

                $haystack =
                    implode(
                        ' ',
                        [
                            (string)($user['displayName'] ?? ''),
                            (string)($user['username'] ?? ''),
                            (string)($profile['surname'] ?? ''),
                            (string)($profile['department'] ?? ''),
                            (string)($profile['email_address'] ?? ''),
                            (string)($profile['mobile_number'] ?? ''),
                            (string)($userGroupMap[$username] ?? ''),
                        ]
                    );

                return stripos(
                    $haystack,
                    $search
                ) !== false;
            }
        )
    );
}

if (
    $perPage !== 'all'
    &&
    count($users) > (int)$perPage
) {

    $users = array_slice(
        $users,
        0,
        (int)$perPage
    );
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>User Management - Users</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
<?php include __DIR__ . '/includes/favicon.php'; ?>

    
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />    
    
</head>

<body>

<?php include 'includes/sidebar.php'; ?>

<?php include 'includes/banner.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>User Management</h1>

            <p>
                Create and manage portal user accounts, profiles and permissions.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/user-management-tabs.php'; ?>

    
    
    <?php if(isset($_GET['error']) &&
              $_GET['error'] === 'password_mismatch'): ?>
    
        <div class="error-message">
            Passwords do not match.
        </div>
    
    <?php endif; ?>
      
      <div class="my-table-controls">
      
            <div class="my-table-controls-left">
            
            <button
                type="button"
                class="table-btn"
                onclick="openUserModal()">
            
                Add User
            
            </button>
            </div>
            
            <div class="my-table-controls-right">
        
                <form method="get">
        
                         
                    <input
                        type="text"
                        name="search"
                        placeholder="Search Here"
                        class="table-control"
                        value="<?= htmlspecialchars($search) ?>">
               
                        <select 
                            name="per_page"
                            class="table-control">
                        
                            <option value="10"
                                <?= $perPage == 10 ? 'selected' : '' ?>>
                                10
                            </option>
                        
                            <option value="25"
                                <?= $perPage == 25 ? 'selected' : '' ?>>
                                25
                            </option>
                        
                            <option value="50"
                                <?= $perPage == 50 ? 'selected' : '' ?>>
                                50
                            </option>
                        
                            <option value="100"
                                <?= $perPage == 100 ? 'selected' : '' ?>>
                                100
                            </option>
                        
                            <option value="all"
                                <?= $perPage == 'all' ? 'selected' : '' ?>>
                                All
                            </option>
                        
                        </select>
        
                    <button 
                        type="submit"
                        class="table-btn">
                        Search
                    </button>
                    
                    <a href="users.php" class="clear-btn">
                        Clear
                    </a>
        
                </form>
        
            </div>
      
      </div>

    <div class="appearance-panel um-table-panel">

    <table>

        <tr>
            <th>User ID</th>
            <th>Display Name</th>
            <th>Surname</th>
            <th>Username</th>
            <th>Department</th>
            <th>Email Address</th>
            <th>Mobile Number</th>
            <th>Group</th>
            <th>2FA Auth</th>
            <th>Status</th>
            <th>Last Login</th>
            <th>Source IP</th>
            <th>Actions</th>
        </tr>

        <?php foreach($users as $user): ?>

        <tr>
            <td>
                <?= htmlspecialchars(
                    $profileMap[strtolower($user['username'])]['id']
                    ?? ''
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    $profileMap[strtolower($user['username'])]['display_name']
                    ?? $user['displayName']
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    $profileMap[strtolower($user['username'])]['surname']
                    ?? ''
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    $profileMap[strtolower($user['username'])]['username']
                    ?? $user['username']
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    $profileMap[strtolower($user['username'])]['department']
                    ?? ''
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    $profileMap[strtolower($user['username'])]['email_address']
                    ?? ''
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    ($profileMap[strtolower($user['username'])]['country_code'] ?? '')
                    . ' ' .
                    ($profileMap[strtolower($user['username'])]['mobile_number'] ?? '')
                ) ?>
                
            </td>
            <td>
                <?= htmlspecialchars(
                    $userGroupMap[
                        strtolower($user['username'])
                    ] ?? 'Not Assigned'
                ) ?>
            </td>

            <td>
                <?= !empty($user['twoFactorEnabled'])
                    ? 'Enabled'
                    : 'Disabled' ?>
            </td>

            <td class="user-status-cell">

            <?php if($user['disabled']): ?>

                <span
                    class="user-status-dot is-disabled"
                    title="Disabled"
                    aria-label="Disabled">
                </span>

            <?php else: ?>

                <span
                    class="user-status-dot is-active"
                    title="Active"
                    aria-label="Active">
                </span>

            <?php endif; ?>

            </td>

            <td>
                <?php
                    $lastLogin =
                        trim(
                            (string)(
                                $user['recentSessionLoggedOn']
                                ?? ''
                            )
                        );

                    $neverLoggedIn =
                        $lastLogin === ''
                        ||
                        str_starts_with(
                            $lastLogin,
                            '0001-01-01'
                        )
                        ||
                        str_starts_with(
                            $lastLogin,
                            '01 Jan 0001'
                        );
                ?>

                <?= $neverLoggedIn
                    ? 'Never'
                    : htmlspecialchars(
                        date(
                            'd M Y H:i',
                            strtotime($lastLogin)
                        )
                    ) ?>
            </td>

            <td>
                <?php
                    $sourceIp =
                        trim(
                            (string)(
                                $user['recentSessionRemoteAddress']
                                ?? ''
                            )
                        );
                ?>

                <?= htmlspecialchars(
                    $sourceIp === ''
                    || $sourceIp === '0.0.0.0'
                        ? 'None'
                        : $sourceIp
                ) ?>
            </td>

            <td>

                <button
                    class="edit-btn"
                    onclick="openEditUserModal(
                        '<?= htmlspecialchars($user['displayName']) ?>',
                        '<?= htmlspecialchars($user['username']) ?>',
                        '<?= $user['disabled'] ? 'true' : 'false' ?>'
                    )">
            
                    Edit
            
                </button>

            <?php if(
                $user['disabled']
                && $user['username'] !== 'admin'
                && $user['username'] !== 'api'
            ): ?>

                <!-- Disabled users get a direct Delete button on the row -
                     the edit modal stays available for everything else. -->

                <form
                    method="post"
                    style="display:inline"
                    onsubmit="return confirm(
                        'Are you sure you want to delete this user? This cannot be undone.'
                    );">

                    <input
                        type="hidden"
                        name="username"
                        value="<?= htmlspecialchars($user['username']) ?>">

                    <button
                        type="submit"
                        name="delete_user"
                        value="1"
                        class="deny-btn">
                        Delete
                    </button>

                </form>

            <?php endif; ?>
            
            </td>

        </tr>

        <?php endforeach; ?>

    </table>

    </div>

    <div id="userModal" class="modal">

    <div class="user-modal-content add-user-modal">

        <div class="add-user-titlebar">

            <h3>Add User</h3>

            <button
                type="button"
                class="add-user-close"
                onclick="closeUserModal()"
                aria-label="Close">
                &times;
            </button>

        </div>

        <form method="post" id="addUserForm">

            <div class="add-user-layout">

                <div class="add-user-fields">

                    <div class="add-user-grid">

                        <div class="portal-field">
                            <label for="add_display_name">
                                Display Name
                            </label>
                            <input
                                type="text"
                                id="add_display_name"
                                name="display_name"
                                placeholder="e.g. John Smith"
                                required>
                        </div>

                        <div class="portal-field">
                            <label for="add_surname">
                                Surname
                            </label>
                            <input
                                type="text"
                                id="add_surname"
                                name="surname"
                                placeholder="e.g. Smith">
                        </div>

                        <div class="portal-field">
                            <label for="country_code">
                                Country
                            </label>

                            <select
                                id="country_code"
                                name="country_code"
                                required>

                                <?php foreach($countryDialCodes as $country): ?>

                                    <option
                                        value="<?= htmlspecialchars($country['dial_code']) ?>"
                                        data-country="<?= htmlspecialchars($country['code']) ?>"
                                        <?= $country['code'] === $defaultCountryIso ? 'selected' : '' ?>>
                                        <?= htmlspecialchars(
                                            $country['name'] .
                                            ' (' .
                                            $country['dial_code'] .
                                            ')'
                                        ) ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>
                        </div>

                        <div class="portal-field username-field">

                            <label for="username">
                                Username
                            </label>

                            <input
                                type="text"
                                id="username"
                                name="username"
                                placeholder="e.g. jsmith"
                                autocomplete="off"
                                required>

                            <div
                                id="usernameAvailability"
                                class="username-availability"
                                aria-live="polite">
                            </div>

                        </div>

                        <div class="portal-field">
                            <label for="add_department">
                                Department
                            </label>
                            <input
                                type="text"
                                id="add_department"
                                name="department"
                                placeholder="e.g. IT, Finance, Operations">
                        </div>

                        <div class="portal-field">
                            <label for="group_id">
                                User Group
                            </label>

                            <select
                                id="group_id"
                                name="group_id"
                                required>

                                <?php foreach($groups as $group): ?>

                                    <option
                                        value="<?= $group[0] ?>"
                                        data-unassigned="<?= strcasecmp($group[1], 'Unassigned') === 0 ? '1' : '0' ?>"
                                        <?= strcasecmp($group[1], 'Unassigned') === 0 ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($group[1]) ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>
                        </div>

                        <div class="portal-field">
                            <label for="password">
                                Password
                            </label>
                            <input
                                type="password"
                                id="password"
                                name="password"
                                placeholder="Enter password"
                                autocomplete="new-password"
                                required>
                        </div>

                        <div class="portal-field">
                            <label for="email_address">
                                Email Address
                            </label>
                            <input
                                type="email"
                                id="email_address"
                                name="email_address"
                                placeholder="e.g. john@company.co.za">
                        </div>

                        <div class="portal-field">
                            <label for="mobile_number">
                                Mobile Number
                            </label>
                            <input
                                type="text"
                                id="mobile_number"
                                name="mobile_number"
                                placeholder="e.g. 071 123 4567">
                        </div>

                        <div class="portal-field">
                            <label for="confirm_password">
                                Confirm Password
                            </label>
                            <input
                                type="password"
                                id="confirm_password"
                                name="confirm_password"
                                placeholder="Confirm password"
                                autocomplete="new-password"
                                required>
                        </div>

                    </div>

                </div>


                <?php if($userDisclaimerEnabled): ?>

                <aside class="add-user-disclaimer">

                    <?php if($userDisclaimerTitle !== ''): ?>

                    <div class="disclaimer-heading">

                        <span class="disclaimer-icon">i</span>

                        <h4>
                            <?= htmlspecialchars($userDisclaimerTitle) ?>
                        </h4>

                    </div>

                    <?php endif; ?>


                    <?php if($userDisclaimerText !== ''): ?>

                    <p>
                        <?= nl2br(
                            htmlspecialchars(
                                $userDisclaimerText
                            )
                        ) ?>
                    </p>

                    <?php endif; ?>


                    <?php if(!empty($userDisclaimerItems)): ?>

                    <div class="disclaimer-divider"></div>

                    <ul>

                        <?php foreach($userDisclaimerItems as $item): ?>

                        <li>
                            <?= htmlspecialchars($item) ?>
                        </li>

                        <?php endforeach; ?>

                    </ul>

                    <?php endif; ?>


                    <?php if($userDisclaimerNote !== ''): ?>

                    <div class="disclaimer-note">
                        <?= nl2br(
                            htmlspecialchars(
                                $userDisclaimerNote
                            )
                        ) ?>
                    </div>

                    <?php endif; ?>

                </aside>

                <?php endif; ?>

            </div>


            <div class="add-user-actions">

                <button
                    type="submit"
                    name="create_user"
                    id="createUserBtn"
                    class="approve-btn"
                    disabled>
                    Create
                </button>

                <button
                    type="button"
                    class="deny-btn"
                    onclick="closeUserModal()">
                    Cancel
                </button>

            </div>

        </form>

    </div>

</div>

<div id="editUserModal" class="modal">

        <div class="user-modal-content profile-editor-modal">

            <div class="profile-editor-titlebar">
                <h3>Edit User</h3>

                <button
                    type="button"
                    class="profile-editor-close"
                    onclick="closeEditUserModal()"
                    aria-label="Close">
                    &times;
                </button>
            </div>

            <form method="post" id="editUserForm">

                <input
                    type="hidden"
                    id="edit_username"
                    name="username">

                <input
                    type="hidden"
                    id="edit_disabled"
                    name="disabled">

                <input
                    type="hidden"
                    id="edit_photo"
                    name="photo">

                <section class="profile-editor-header">

                    <div class="profile-avatar-control">

                        <button
                            type="button"
                            class="profile-avatar-upload"
                            id="profileAvatarUpload"
                            aria-label="Add or change profile picture">

                            <img
                                id="profileAvatarPreview"
                                class="profile-avatar-preview"
                                src=""
                                alt=""
                                style="display:none;">

                            <span
                                class="profile-avatar-icon"
                                id="profileAvatarIcon">
                                &#128100;
                            </span>

                            <span class="profile-avatar-overlay">
                                <span class="profile-avatar-camera">
                                    &#128247;
                                </span>

                                <span
                                    class="profile-avatar-label"
                                    id="profileAvatarLabel">
                                    Add Picture
                                </span>
                            </span>

                        </button>

                        <input
                            type="file"
                            id="profileAvatarFile"
                            accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                            hidden>

                        <button
                            type="button"
                            id="profileAvatarRemove"
                            class="profile-avatar-remove"
                            style="display:none;">
                            Remove
                        </button>

                        <div
                            id="profileAvatarStatus"
                            class="profile-avatar-status"
                            role="status"
                            aria-live="polite">
                        </div>

                        <div
                            id="profileAvatarHint"
                            class="profile-avatar-hint"
                            style="display:none;">
                            Drag to reposition<br>
                            Scroll to zoom
                        </div>

                    </div>

                    <div class="profile-editor-identity">

                        <div
                            class="profile-editor-name"
                            id="profileEditorName">
                            User
                        </div>

                        <div
                            class="profile-editor-email"
                            id="profileEditorEmail">
                        </div>

                        <div class="profile-editor-meta">

                            <span id="profileEditorGroup">
                                Unassigned
                            </span>

                            <span id="profileEditorUserId">
                                User ID: —
                            </span>

                        </div>

                    </div>

                </section>

                <section class="profile-editor-section">

                    <div class="profile-section-heading">
                        <h4>User Details</h4>
                    </div>

                    <div class="portal-form-grid">

                        <div class="portal-field">
                            <label for="edit_display_name">
                                Display Name
                            </label>
                            <input
                                type="text"
                                id="edit_display_name"
                                name="display_name"
                                required>
                        </div>

                        <div class="portal-field">
                            <label for="edit_surname">
                                Surname
                            </label>
                            <input
                                type="text"
                                id="edit_surname"
                                name="surname">
                        </div>

                        <div class="portal-field">
                            <label for="edit_department">
                                Department
                            </label>
                            <input
                                type="text"
                                id="edit_department"
                                name="department">
                        </div>

                        <div class="portal-field">
                            <label for="edit_username_display">
                                Username
                            </label>
                            <input
                                type="text"
                                id="edit_username_display"
                                readonly>
                        </div>

                        <div class="portal-field">
                            <label for="edit_email_address">
                                Email Address
                            </label>
                            <input
                                type="email"
                                id="edit_email_address"
                                name="email_address">
                        </div>

                        <div class="portal-field">
                            <label for="edit_country_code">
                                Country
                            </label>

                            <select
                                id="edit_country_code"
                                name="country_code"
                                required>

                                <?php foreach($countryDialCodes as $country): ?>

                                    <option
                                        value="<?= htmlspecialchars($country['dial_code']) ?>"
                                        data-country="<?= htmlspecialchars($country['code']) ?>">
                                        <?= htmlspecialchars(
                                            $country['name'] .
                                            ' (' .
                                            $country['dial_code'] .
                                            ')'
                                        ) ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>
                        </div>

                        <div class="portal-field">
                            <label for="edit_mobile_number">
                                Mobile Number
                            </label>
                            <input
                                type="text"
                                id="edit_mobile_number"
                                name="mobile_number">
                        </div>

                        <div class="portal-field">
                            <label for="edit_group_id">
                                User Group
                            </label>

                            <select
                                id="edit_group_id"
                                name="group_id"
                                required>

                                <?php foreach($groups as $group): ?>

                                    <option
                                        value="<?= $group[0] ?>"
                                        data-unassigned="<?= strcasecmp($group[1], 'Unassigned') === 0 ? '1' : '0' ?>">
                                        <?= htmlspecialchars($group[1]) ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>
                        </div>

                    </div>

                </section>

                <section class="profile-editor-section custom-fields-section">

                    <div
                        id="customUserFields"
                        class="custom-user-sections">

                        <div class="custom-fields-empty">
                            Loading custom fields...
                        </div>

                    </div>

                    <?php if(hasPermission('Edit User Fields')): ?>

                        <div class="custom-section-add-wrap">

                            <button
                                type="button"
                                class="custom-section-add-btn"
                                id="addCustomSectionBtn">
                                ADD NEW
                            </button>

                        </div>

                    <?php endif; ?>

                </section>

                <div
                    id="editUserSaveStatus"
                    class="profile-editor-save-status"
                    role="status"
                    aria-live="polite"
                    style="display:none;">
                </div>

                <div class="profile-editor-actions">

                    <div class="profile-primary-actions">

                        <button
                            type="submit"
                            name="update_user"
                            id="editUserSaveBtn"
                            class="approve-btn">
                            Save
                        </button>

                        <button
                            type="button"
                            class="deny-btn"
                            onclick="closeEditUserModal()">
                            Cancel
                        </button>

                    </div>

                    <div class="profile-secondary-actions">

                        <button
                            type="button"
                            class="table-btn"
                            onclick="showPasswordReset()">
                            Reset Password
                        </button>

                        <button
                            type="submit"
                            name="reset_2fa"
                            class="table-btn"
                            onclick="return confirm(
                                'Clear two-factor authentication for this user?'
                            );">
                            Reset 2FA
                        </button>

                        <button
                            type="submit"
                            name="toggle_user"
                            id="disableEnableBtn"
                            class="table-btn">
                            Disable User
                        </button>

                        <button
                            id="deleteUserBtn"
                            type="submit"
                            name="delete_user"
                            class="deny-btn"
                            onclick="return confirm(
                                'Are you sure you want to delete this user?'
                            );">
                            Delete User
                        </button>

                    </div>

                </div>

<div
                    id="passwordResetSection"
                    style="display:none;">
                
                    <br><br>
                
                    <label>New Password</label>
                
                    <input
                        type="password"
                        id="edit_password"
                        name="password">

                
                    <br><br>
                
                    <label>Confirm Password</label>
                
                    <input
                        type="password"
                        id="edit_confirm_password"
                        name="confirm_password">

                
                    <br><br>
                
                    <button
                        type="submit"
                        name="reset_password"
                        class="table-btn">
                
                        Confirm Reset
                
                    </button>
                
                </div>
    
            

            </form>

        </div>

    </div>

</div>

<?php if(hasPermission('Edit User Fields')): ?>

<div
    id="customFieldManagerModal"
    class="modal custom-field-manager-overlay"
    style="display:none; z-index:12000;">

    <div
        class="user-modal-content profile-editor-modal custom-field-manager-modal">

        <div class="profile-editor-titlebar">

            <div>

                <h3 id="customFieldManagerTitle">
                    Add Custom Field
                </h3>

                <div class="custom-field-manager-subtitle">
                    Configure a reusable field for user profiles.
                </div>

            </div>

            <button
                type="button"
                class="profile-editor-close"
                id="customFieldManagerClose"
                aria-label="Close">
                &times;
            </button>

        </div>


        <form id="customFieldManagerForm">

            <input
                type="hidden"
                id="customFieldId"
                value="">


            <div class="portal-form-grid custom-field-manager-grid">

                <div class="form-group custom-field-section-setting">

                    <label for="customFieldSection">
                        Section
                    </label>

                    <select
                        id="customFieldSection"
                        required>
                    </select>

                </div>

                <div class="form-group custom-field-section-spacer">
                </div>

                <div class="form-group">

                    <label for="customFieldName">
                        Field Name
                    </label>

                    <input
                        type="text"
                        id="customFieldName"
                        maxlength="100"
                        autocomplete="off"
                        required>

                </div>


                <div class="form-group">

                    <label for="customFieldType">
                        Field Type
                    </label>

                    <select
                        id="customFieldType"
                        required>

                        <option value="text">
                            Text
                        </option>

                        <option value="textarea">
                            Text Area
                        </option>

                        <option value="email">
                            Email
                        </option>

                        <option value="number">
                            Number
                        </option>

                        <option value="date">
                            Date
                        </option>

                        <option value="checkbox">
                            Checkbox
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label for="customFieldSortOrder">
                        Sort Order
                    </label>

                    <input
                        type="number"
                        id="customFieldSortOrder"
                        value="0"
                        step="1">

                </div>


                <div class="form-group custom-field-required-setting">

                    <label>
                        Required
                    </label>

                    <label class="custom-field-required-option">

                        <input
                            type="checkbox"
                            id="customFieldRequired">

                        <span>
                            Required field
                        </span>

                    </label>

                </div>


                <div
                    class="form-group custom-field-key-setting"
                    id="customFieldKeyGroup"
                    style="display:none;">

                    <label for="customFieldKey">
                        Internal Key
                    </label>

                    <input
                        type="text"
                        id="customFieldKey"
                        readonly>

                    <div class="custom-field-key-help">
                        Permanent internal identifier.
                        It does not change when the field is renamed.
                    </div>

                </div>

                <div class="form-group custom-field-prepend-setting">

                    <label for="customFieldPrepend">
                        Prepend
                    </label>

                    <input
                        type="text"
                        id="customFieldPrepend"
                        maxlength="50"
                        autocomplete="off"
                        placeholder="Example: EMP-">

                    <div class="custom-field-key-help">
                        Optional text shown before the stored value.
                    </div>

                </div>

            </div>


            <div
                id="customFieldManagerStatus"
                class="profile-editor-save-status"
                role="status"
                aria-live="polite"
                style="display:none;">
            </div>


            <div class="profile-editor-actions">

                <div class="profile-primary-actions">

                    <button
                        type="submit"
                        id="customFieldManagerSave"
                        class="approve-btn">
                        Create Field
                    </button>

                    <button
                        type="button"
                        id="customFieldManagerCancel"
                        class="deny-btn">
                        Cancel
                    </button>

                </div>


                <div class="profile-secondary-actions">

                    <button
                        type="button"
                        id="customFieldManagerDelete"
                        class="deny-btn"
                        style="display:none;">
                        Delete Field
                    </button>

                </div>

            </div>

        </form>

    </div>

</div>


<div
    id="customSectionManagerModal"
    class="modal custom-field-manager-overlay"
    style="display:none; z-index:12010;">

    <div
        class="user-modal-content profile-editor-modal custom-field-manager-modal">

        <div class="profile-editor-titlebar">

            <div>

                <h3 id="customSectionManagerTitle">
                    Add Custom Section
                </h3>

                <div class="custom-field-manager-subtitle">
                    Create or configure a profile field section.
                </div>

            </div>

            <button
                type="button"
                class="profile-editor-close"
                id="customSectionManagerClose"
                aria-label="Close">
                &times;
            </button>

        </div>

        <form id="customSectionManagerForm">

            <input
                type="hidden"
                id="customSectionId"
                value="">

            <div class="portal-form-grid custom-field-manager-grid">

                <div class="form-group">

                    <label for="customSectionName">
                        Section Name
                    </label>

                    <input
                        type="text"
                        id="customSectionName"
                        maxlength="100"
                        autocomplete="off"
                        required>

                </div>

                <div class="form-group">

                    <label for="customSectionSortOrder">
                        Sort Order
                    </label>

                    <input
                        type="number"
                        id="customSectionSortOrder"
                        value="0"
                        step="1">

                </div>

            </div>

            <div
                id="customSectionManagerStatus"
                class="profile-editor-save-status"
                role="status"
                aria-live="polite"
                style="display:none;">
            </div>

            <div class="profile-editor-actions">

                <div class="profile-primary-actions">

                    <button
                        type="submit"
                        id="customSectionManagerSave"
                        class="approve-btn">
                        Create Section
                    </button>

                    <button
                        type="button"
                        id="customSectionManagerCancel"
                        class="deny-btn">
                        Cancel
                    </button>

                </div>

                <div class="profile-secondary-actions">

                    <button
                        type="button"
                        id="customSectionManagerDelete"
                        class="deny-btn"
                        style="display:none;">
                        Delete Section
                    </button>

                </div>

            </div>

        </form>

    </div>

</div>

<?php endif; ?>


<script>

/*
 * =========================================================
 * CUSTOM FIELD MANAGER
 * =========================================================
 */

let customFieldDefinitions = [];


let customFieldSections = [];


async function customFieldJsonRequest(
    url,
    options = {}
){

    const response =
        await fetch(
            url,
            options
        );

    const contentType =
        response.headers.get(
            'content-type'
        ) || '';

    if(
        !contentType
            .toLowerCase()
            .includes('application/json')
    ){
        throw new Error(
            'Custom field server returned an unexpected response.'
        );
    }

    const result =
        await response.json();

    if(
        !response.ok
        ||
        result.success !== true
    ){
        throw new Error(
            result.message ||
            'Custom field request failed.'
        );
    }

    return result;
}


async function loadCustomFieldSections(){

    const result =
        await customFieldJsonRequest(
            '/user-custom-fields-api.php?action=sections',
            {
                headers: {
                    'X-Requested-With':
                        'XMLHttpRequest'
                }
            }
        );

    customFieldSections =
        Array.isArray(result.sections)
            ? result.sections
            : [];

    return customFieldSections;
}


function populateCustomFieldSectionSelect(
    selectedSectionId = null
){

    const select =
        document.getElementById(
            'customFieldSection'
        );

    if(!select){
        return;
    }

    const selectedId =
        Number(selectedSectionId);

    select.innerHTML =
        customFieldSections
            .map(section => {

                const sectionId =
                    Number(section.id);

                if(
                    !Number.isInteger(sectionId)
                    ||
                    sectionId <= 0
                ){
                    return '';
                }

                const selected =
                    sectionId === selectedId
                        ? ' selected'
                        : '';

                return (
                    '<option value="' +
                    sectionId +
                    '"' +
                    selected +
                    '>' +
                    escapeCustomFieldHtml(
                        section.section_name || ''
                    ) +
                    '</option>'
                );
            })
            .join('');

    if(
        !Number.isInteger(selectedId)
        &&
        select.options.length > 0
    ){
        select.selectedIndex = 0;
    }
}


async function customSectionRequest(
    action,
    payload = null
){

    const options = {
        headers: {
            'X-Requested-With':
                'XMLHttpRequest'
        }
    };

    if(payload !== null){

        options.method = 'POST';

        options.headers[
            'Content-Type'
        ] = 'application/json';

        options.body =
            JSON.stringify(payload);
    }

    return await customFieldJsonRequest(
        '/user-custom-fields-api.php?action=' +
            encodeURIComponent(action),
        options
    );
}


const canEditUserFields =
    <?php echo hasPermission('Edit User Fields') ? 'true' : 'false'; ?>;


function setCustomFieldManagerStatus(
    message,
    isError = false
){

    const status =
        document.getElementById(
            'customFieldManagerStatus'
        );

    if(!status){
        return;
    }

    if(!message){

        status.style.display = 'none';
        status.textContent = '';
        status.style.color = '';

        return;
    }

    status.style.display = 'block';
    status.textContent = message;
    status.style.color =
        isError
            ? '#ef4444'
            : '#22c55e';
}


function resetCustomFieldManagerForm(
    preferredSectionId = null
){

    const form =
        document.getElementById(
            'customFieldManagerForm'
        );

    if(form){
        form.reset();
    }

    const fieldId =
        document.getElementById(
            'customFieldId'
        );

    const fieldKey =
        document.getElementById(
            'customFieldKey'
        );

    const keyGroup =
        document.getElementById(
            'customFieldKeyGroup'
        );

    const prepend =
        document.getElementById(
            'customFieldPrepend'
        );

    const title =
        document.getElementById(
            'customFieldManagerTitle'
        );

    const saveButton =
        document.getElementById(
            'customFieldManagerSave'
        );

    const deleteButton =
        document.getElementById(
            'customFieldManagerDelete'
        );

    const sortOrder =
        document.getElementById(
            'customFieldSortOrder'
        );

    if(fieldId){
        fieldId.value = '';
    }

    if(fieldKey){
        fieldKey.value = '';
    }

    if(keyGroup){
        keyGroup.style.display = 'none';
    }

    if(prepend){
        prepend.value = '';
    }

    if(title){
        title.textContent =
            'Add Custom Field';
    }

    if(saveButton){
        saveButton.textContent =
            'Create Field';
    }

    if(deleteButton){
        deleteButton.style.display =
            'none';
    }

    if(sortOrder){
        sortOrder.value = '0';
    }

    populateCustomFieldSectionSelect(
        preferredSectionId
    );

    setCustomFieldManagerStatus('');
}

async function loadCustomFieldDefinitions(){

    const response =
        await fetch(
            '/user-custom-fields-api.php' +
            '?action=definitions',
            {
                headers: {
                    'X-Requested-With':
                        'XMLHttpRequest'
                }
            }
        );


    const contentType =
        response.headers.get(
            'content-type'
        ) || '';


    if(
        !contentType
            .toLowerCase()
            .includes('application/json')
    ){
        throw new Error(
            'Custom field server returned an unexpected response.'
        );
    }


    const result =
        await response.json();


    if(
        !response.ok
        ||
        result.success !== true
    ){
        throw new Error(
            result.message ||
            'Unable to load custom field definitions.'
        );
    }


    customFieldDefinitions =
        Array.isArray(result.fields)
            ? result.fields
            : [];


    return customFieldDefinitions;
}


function populateCustomFieldManager(field){

    const fieldId =
        document.getElementById(
            'customFieldId'
        );

    const fieldName =
        document.getElementById(
            'customFieldName'
        );

    const fieldType =
        document.getElementById(
            'customFieldType'
        );

    const required =
        document.getElementById(
            'customFieldRequired'
        );

    const sortOrder =
        document.getElementById(
            'customFieldSortOrder'
        );

    const fieldKey =
        document.getElementById(
            'customFieldKey'
        );

    const keyGroup =
        document.getElementById(
            'customFieldKeyGroup'
        );

    const prepend =
        document.getElementById(
            'customFieldPrepend'
        );

    const title =
        document.getElementById(
            'customFieldManagerTitle'
        );

    const saveButton =
        document.getElementById(
            'customFieldManagerSave'
        );

    const deleteButton =
        document.getElementById(
            'customFieldManagerDelete'
        );

    fieldId.value =
        String(field.id);

    fieldName.value =
        field.field_name || '';

    fieldType.value =
        field.field_type || 'text';

    required.checked =
        field.required === true;

    sortOrder.value =
        String(
            field.sort_order ?? 0
        );

    fieldKey.value =
        field.field_key || '';

    keyGroup.style.display =
        'block';

    if(prepend){
        prepend.value =
            field.prepend || '';
    }

    populateCustomFieldSectionSelect(
        field.section_id
    );

    title.textContent =
        'Edit Custom Field';

    saveButton.textContent =
        'Save Field';

    deleteButton.style.display =
        'inline-flex';
}

async function customFieldDefinitionRequest(
    action,
    payload
){

    const response =
        await fetch(
            '/user-custom-fields-api.php?action=' +
            encodeURIComponent(action),
            {
                method: 'POST',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify(
                    payload || {}
                )
            }
        );


    let result;

    try {

        result = await response.json();

    } catch(error) {

        throw new Error(
            'Invalid response from custom field service.'
        );
    }


    if(
        !response.ok
        ||
        result.success !== true
    ){

        throw new Error(
            result.message ||
            'Custom field request failed.'
        );
    }


    return result;
}


async function openCustomFieldManager(
    fieldId = null,
    preferredSectionId = null
){

    const modal =
        document.getElementById(
            'customFieldManagerModal'
        );

    if(!modal){
        return;
    }

    modal.style.display = 'flex';

    try {

        setCustomFieldManagerStatus(
            'Loading field settings...'
        );

        const [
            sections,
            fields
        ] = await Promise.all([
            loadCustomFieldSections(),
            loadCustomFieldDefinitions()
        ]);

        if(sections.length === 0){
            throw new Error(
                'Create a custom section before adding fields.'
            );
        }

        resetCustomFieldManagerForm(
            preferredSectionId
        );

        if(fieldId !== null){

            const numericFieldId =
                Number(fieldId);

            const field =
                fields.find(
                    item =>
                        Number(item.id) ===
                        numericFieldId
                );

            if(!field){
                throw new Error(
                    'Custom field not found.'
                );
            }

            populateCustomFieldManager(
                field
            );
        }

        setCustomFieldManagerStatus('');

        const fieldName =
            document.getElementById(
                'customFieldName'
            );

        if(fieldName){
            fieldName.focus();
        }

    } catch(error) {

        console.error(
            'Custom Field Manager load failed:',
            error
        );

        setCustomFieldManagerStatus(
            error.message ||
            'Unable to load custom fields.',
            true
        );
    }
}

function closeCustomFieldManager(){

    const modal =
        document.getElementById(
            'customFieldManagerModal'
        );

    if(modal){
        modal.style.display = 'none';
    }

    resetCustomFieldManagerForm();
}


document.addEventListener(
    'DOMContentLoaded',
    () => {

        const closeButton =
            document.getElementById(
                'customFieldManagerClose'
            );

        const cancelButton =
            document.getElementById(
                'customFieldManagerCancel'
            );

        const form =
            document.getElementById(
                'customFieldManagerForm'
            );



        if(closeButton){

            closeButton.addEventListener(
                'click',
                closeCustomFieldManager
            );
        }


        if(cancelButton){

            cancelButton.addEventListener(
                'click',
                closeCustomFieldManager
            );
        }


        if(form){

            form.addEventListener(
                'submit',
                async event => {

                    event.preventDefault();


                    const fieldId =
                        Number(
                            document.getElementById(
                                'customFieldId'
                            )?.value || 0
                        );

                    const sectionId =
                        Number(
                            document.getElementById(
                                'customFieldSection'
                            )?.value || 0
                        );

                    const fieldName =
                        document.getElementById(
                            'customFieldName'
                        )?.value.trim() || '';

                    const fieldType =
                        document.getElementById(
                            'customFieldType'
                        )?.value || '';

                    const required =
                        document.getElementById(
                            'customFieldRequired'
                        )?.checked === true;

                    const sortOrderRaw =
                        document.getElementById(
                            'customFieldSortOrder'
                        )?.value ?? '0';

                    const sortOrder =
                        Number(sortOrderRaw);

                    const prepend =
                        document.getElementById(
                            'customFieldPrepend'
                        )?.value.trim() || '';

                    const saveButton =
                        document.getElementById(
                            'customFieldManagerSave'
                        );


                    if(
                        !Number.isInteger(sectionId)
                        ||
                        sectionId <= 0
                    ){

                        setCustomFieldManagerStatus(
                            'Section is required.',
                            true
                        );

                        return;
                    }

                    if(!fieldName){

                        setCustomFieldManagerStatus(
                            'Field Name is required.',
                            true
                        );

                        return;
                    }


                    if(
                        !Number.isInteger(sortOrder)
                    ){

                        setCustomFieldManagerStatus(
                            'Sort Order must be a whole number.',
                            true
                        );

                        return;
                    }

                    if(prepend.length > 50){

                        setCustomFieldManagerStatus(
                            'Prepend cannot exceed 50 characters.',
                            true
                        );

                        return;
                    }


                    const isEdit =
                        Number.isInteger(fieldId)
                        &&
                        fieldId > 0;


                    const payload = {
                        section_id: sectionId,
                        field_name: fieldName,
                        field_type: fieldType,
                        required: required,
                        sort_order: sortOrder,
                        prepend: prepend
                    };


                    if(isEdit){
                        payload.field_id = fieldId;
                    }


                    if(saveButton){
                        saveButton.disabled = true;
                    }


                    setCustomFieldManagerStatus(
                        isEdit
                            ? 'Saving field...'
                            : 'Creating field...'
                    );


                    try {

                        const result =
                            await customFieldDefinitionRequest(
                                isEdit
                                    ? 'update-definition'
                                    : 'create-definition',
                                payload
                            );


                        /*
                         * Refresh definitions first so the
                         * manager and Edit controls use the
                         * latest server state.
                         */
                        await loadCustomFieldDefinitions();


                        /*
                         * Refresh the currently open user's
                         * custom-field controls immediately.
                         */
                        const userIdText =
                            document.getElementById(
                                'profileEditorUserId'
                            )?.textContent || '';

                        const userIdMatch =
                            userIdText.match(
                                /User ID:\s*(\d+)/
                            );

                        const currentUserId =
                            userIdMatch
                                ? Number(userIdMatch[1])
                                : 0;


                        if(
                            Number.isInteger(currentUserId)
                            &&
                            currentUserId > 0
                        ){

                            await loadCustomUserFields(
                                currentUserId
                            );
                        }


                        setCustomFieldManagerStatus(
                            result.message ||
                            (
                                isEdit
                                    ? 'Custom field updated.'
                                    : 'Custom field created.'
                            )
                        );


                        setTimeout(
                            closeCustomFieldManager,
                            350
                        );

                    } catch(error) {

                        console.error(
                            'Custom field save failed:',
                            error
                        );

                        setCustomFieldManagerStatus(
                            error.message ||
                            'Unable to save custom field.',
                            true
                        );

                    } finally {

                        if(saveButton){
                            saveButton.disabled = false;
                        }
                    }
                }
            );
        }
    }
);


/*
 * =========================================================
 * CUSTOM FIELD DEFINITION DELETE
 * =========================================================
 *
 * Deleting the definition also removes its stored values
 * through the database foreign-key ON DELETE CASCADE.
 */

document.addEventListener(
    'DOMContentLoaded',
    () => {

        const deleteButton =
            document.getElementById(
                'customFieldManagerDelete'
            );

        if(!deleteButton){
            return;
        }


        deleteButton.addEventListener(
            'click',
            async () => {

                const fieldId =
                    Number(
                        document.getElementById(
                            'customFieldId'
                        )?.value || 0
                    );

                const fieldName =
                    document.getElementById(
                        'customFieldName'
                    )?.value.trim() ||
                    'this custom field';


                if(
                    !Number.isInteger(fieldId)
                    ||
                    fieldId <= 0
                ){

                    setCustomFieldManagerStatus(
                        'Invalid custom field ID.',
                        true
                    );

                    return;
                }


                const confirmed =
                    window.confirm(
                        'Delete "' +
                        fieldName +
                        '"?\n\n' +
                        'This permanently deletes this custom field ' +
                        'and all saved values for ALL users.\n\n' +
                        'This action cannot be undone.'
                    );


                if(!confirmed){
                    return;
                }


                deleteButton.disabled = true;

                setCustomFieldManagerStatus(
                    'Deleting field...'
                );


                try {

                    const result =
                        await customFieldDefinitionRequest(
                            'delete-definition',
                            {
                                field_id: fieldId
                            }
                        );


                    await loadCustomFieldDefinitions();


                    const userIdText =
                        document.getElementById(
                            'profileEditorUserId'
                        )?.textContent || '';

                    const userIdMatch =
                        userIdText.match(
                            /User ID:\s*(\d+)/
                        );

                    const currentUserId =
                        userIdMatch
                            ? Number(userIdMatch[1])
                            : 0;


                    if(
                        Number.isInteger(currentUserId)
                        &&
                        currentUserId > 0
                    ){

                        await loadCustomUserFields(
                            currentUserId
                        );
                    }


                    setCustomFieldManagerStatus(
                        result.message ||
                        'Custom field deleted.'
                    );


                    setTimeout(
                        closeCustomFieldManager,
                        350
                    );

                } catch(error) {

                    console.error(
                        'Custom field delete failed:',
                        error
                    );

                    setCustomFieldManagerStatus(
                        error.message ||
                        'Unable to delete custom field.',
                        true
                    );

                } finally {

                    deleteButton.disabled = false;
                }
            }
        );
    }
);



/*
 * =========================================================
 * UPDATE003 - CUSTOM FIELD SECTION MANAGER
 * =========================================================
 */

function setCustomSectionManagerStatus(
    message,
    isError = false
){

    const status =
        document.getElementById(
            'customSectionManagerStatus'
        );

    if(!status){
        return;
    }

    if(!message){
        status.style.display = 'none';
        status.textContent = '';
        status.style.color = '';
        return;
    }

    status.style.display = 'block';
    status.textContent = message;
    status.style.color =
        isError
            ? '#ef4444'
            : '#22c55e';
}


function resetCustomSectionManagerForm(){

    const form =
        document.getElementById(
            'customSectionManagerForm'
        );

    if(form){
        form.reset();
    }

    const sectionId =
        document.getElementById(
            'customSectionId'
        );

    const sortOrder =
        document.getElementById(
            'customSectionSortOrder'
        );

    const title =
        document.getElementById(
            'customSectionManagerTitle'
        );

    const saveButton =
        document.getElementById(
            'customSectionManagerSave'
        );

    const deleteButton =
        document.getElementById(
            'customSectionManagerDelete'
        );

    if(sectionId){
        sectionId.value = '';
    }

    if(sortOrder){
        sortOrder.value = '0';
    }

    if(title){
        title.textContent =
            'Add Custom Section';
    }

    if(saveButton){
        saveButton.textContent =
            'Create Section';
    }

    if(deleteButton){
        deleteButton.style.display =
            'none';
    }

    setCustomSectionManagerStatus('');
}


function populateCustomSectionManager(
    section
){

    const sectionId =
        document.getElementById(
            'customSectionId'
        );

    const sectionName =
        document.getElementById(
            'customSectionName'
        );

    const sortOrder =
        document.getElementById(
            'customSectionSortOrder'
        );

    const title =
        document.getElementById(
            'customSectionManagerTitle'
        );

    const saveButton =
        document.getElementById(
            'customSectionManagerSave'
        );

    const deleteButton =
        document.getElementById(
            'customSectionManagerDelete'
        );

    if(sectionId){
        sectionId.value =
            String(section.id);
    }

    if(sectionName){
        sectionName.value =
            section.section_name || '';
    }

    if(sortOrder){
        sortOrder.value =
            String(
                section.sort_order ?? 0
            );
    }

    if(title){
        title.textContent =
            'Edit Custom Section';
    }

    if(saveButton){
        saveButton.textContent =
            'Save Section';
    }

    if(deleteButton){
        deleteButton.style.display =
            'inline-flex';
    }
}


async function openCustomSectionManager(
    sectionId = null
){

    if(!canEditUserFields){
        return;
    }

    const modal =
        document.getElementById(
            'customSectionManagerModal'
        );

    if(!modal){
        return;
    }

    resetCustomSectionManagerForm();

    modal.style.display =
        'flex';

    try {

        setCustomSectionManagerStatus(
            'Loading sections...'
        );

        const sections =
            await loadCustomFieldSections();

        if(sectionId !== null){

            const numericSectionId =
                Number(sectionId);

            const section =
                sections.find(
                    item =>
                        Number(item.id) ===
                        numericSectionId
                );

            if(!section){
                throw new Error(
                    'Custom section not found.'
                );
            }

            populateCustomSectionManager(
                section
            );
        }

        setCustomSectionManagerStatus('');

        const sectionName =
            document.getElementById(
                'customSectionName'
            );

        if(sectionName){
            sectionName.focus();
        }

    } catch(error) {

        console.error(
            'Custom Section Manager load failed:',
            error
        );

        setCustomSectionManagerStatus(
            error.message ||
            'Unable to load custom sections.',
            true
        );
    }
}


function closeCustomSectionManager(){

    const modal =
        document.getElementById(
            'customSectionManagerModal'
        );

    if(modal){
        modal.style.display =
            'none';
    }

    resetCustomSectionManagerForm();
}


function getCurrentProfileEditorUserId(){

    const userIdText =
        document.getElementById(
            'profileEditorUserId'
        )?.textContent || '';

    const match =
        userIdText.match(
            /User ID:\s*(\d+)/
        );

    if(!match){
        return 0;
    }

    const userId =
        Number(match[1]);

    return (
        Number.isInteger(userId)
        &&
        userId > 0
    )
        ? userId
        : 0;
}


async function refreshCustomUserFieldEditor(){

    await Promise.all([
        loadCustomFieldSections(),
        loadCustomFieldDefinitions()
    ]);

    const userId =
        getCurrentProfileEditorUserId();

    if(userId > 0){
        await loadCustomUserFields(
            userId
        );
    }
}


document.addEventListener(
    'DOMContentLoaded',
    () => {

        const addSectionButton =
            document.getElementById(
                'addCustomSectionBtn'
            );

        const closeButton =
            document.getElementById(
                'customSectionManagerClose'
            );

        const cancelButton =
            document.getElementById(
                'customSectionManagerCancel'
            );

        const form =
            document.getElementById(
                'customSectionManagerForm'
            );

        const deleteButton =
            document.getElementById(
                'customSectionManagerDelete'
            );


        if(addSectionButton){

            addSectionButton.addEventListener(
                'click',
                () => {
                    openCustomSectionManager();
                }
            );
        }


        if(closeButton){

            closeButton.addEventListener(
                'click',
                closeCustomSectionManager
            );
        }


        if(cancelButton){

            cancelButton.addEventListener(
                'click',
                closeCustomSectionManager
            );
        }


        if(form){

            form.addEventListener(
                'submit',
                async event => {

                    event.preventDefault();

                    const sectionId =
                        Number(
                            document.getElementById(
                                'customSectionId'
                            )?.value || 0
                        );

                    const sectionName =
                        document.getElementById(
                            'customSectionName'
                        )?.value.trim() || '';

                    const sortOrder =
                        Number(
                            document.getElementById(
                                'customSectionSortOrder'
                            )?.value ?? '0'
                        );

                    const saveButton =
                        document.getElementById(
                            'customSectionManagerSave'
                        );

                    if(!sectionName){

                        setCustomSectionManagerStatus(
                            'Section Name is required.',
                            true
                        );

                        return;
                    }

                    if(
                        !Number.isInteger(sortOrder)
                    ){

                        setCustomSectionManagerStatus(
                            'Sort Order must be a whole number.',
                            true
                        );

                        return;
                    }

                    const isEdit =
                        Number.isInteger(sectionId)
                        &&
                        sectionId > 0;

                    const payload = {
                        section_name:
                            sectionName,

                        sort_order:
                            sortOrder
                    };

                    if(isEdit){
                        payload.section_id =
                            sectionId;
                    }

                    if(saveButton){
                        saveButton.disabled =
                            true;
                    }

                    setCustomSectionManagerStatus(
                        isEdit
                            ? 'Saving section...'
                            : 'Creating section...'
                    );

                    try {

                        const result =
                            await customSectionRequest(
                                isEdit
                                    ? 'update-section'
                                    : 'create-section',
                                payload
                            );

                        await refreshCustomUserFieldEditor();

                        setCustomSectionManagerStatus(
                            result.message ||
                            (
                                isEdit
                                    ? 'Custom section updated.'
                                    : 'Custom section created.'
                            )
                        );

                        setTimeout(
                            closeCustomSectionManager,
                            350
                        );

                    } catch(error) {

                        console.error(
                            'Custom section save failed:',
                            error
                        );

                        setCustomSectionManagerStatus(
                            error.message ||
                            'Unable to save custom section.',
                            true
                        );

                    } finally {

                        if(saveButton){
                            saveButton.disabled =
                                false;
                        }
                    }
                }
            );
        }


        if(deleteButton){

            deleteButton.addEventListener(
                'click',
                async () => {

                    const sectionId =
                        Number(
                            document.getElementById(
                                'customSectionId'
                            )?.value || 0
                        );

                    const sectionName =
                        document.getElementById(
                            'customSectionName'
                        )?.value.trim() ||
                        'this custom section';

                    if(
                        !Number.isInteger(sectionId)
                        ||
                        sectionId <= 0
                    ){

                        setCustomSectionManagerStatus(
                            'Invalid custom section ID.',
                            true
                        );

                        return;
                    }

                    const confirmed =
                        window.confirm(
                            'Delete "' +
                            sectionName +
                            '"?\n\n' +
                            'The section must be empty before it can be deleted.'
                        );

                    if(!confirmed){
                        return;
                    }

                    deleteButton.disabled =
                        true;

                    setCustomSectionManagerStatus(
                        'Deleting section...'
                    );

                    try {

                        const result =
                            await customSectionRequest(
                                'delete-section',
                                {
                                    section_id:
                                        sectionId
                                }
                            );

                        await refreshCustomUserFieldEditor();

                        setCustomSectionManagerStatus(
                            result.message ||
                            'Custom section deleted.'
                        );

                        setTimeout(
                            closeCustomSectionManager,
                            350
                        );

                    } catch(error) {

                        console.error(
                            'Custom section delete failed:',
                            error
                        );

                        setCustomSectionManagerStatus(
                            error.message ||
                            'Unable to delete custom section.',
                            true
                        );

                    } finally {

                        deleteButton.disabled =
                            false;
                    }
                }
            );
        }
    }
);


document.addEventListener(
    'click',
    event => {

        if(!canEditUserFields){
            return;
        }

        const editFieldButton =
            event.target.closest(
                '.custom-field-edit-btn'
            );

        if(editFieldButton){

            const fieldId =
                Number(
                    editFieldButton.dataset
                        .customFieldEditId
                );

            if(
                Number.isInteger(fieldId)
                &&
                fieldId > 0
            ){
                openCustomFieldManager(
                    fieldId
                );
            }

            return;
        }


        const addFieldButton =
            event.target.closest(
                '.custom-section-add-field-btn'
            );

        if(addFieldButton){

            const sectionId =
                Number(
                    addFieldButton.dataset
                        .customSectionId
                );

            if(
                Number.isInteger(sectionId)
                &&
                sectionId > 0
            ){
                openCustomFieldManager(
                    null,
                    sectionId
                );
            }

            return;
        }


        const editSectionButton =
            event.target.closest(
                '.custom-section-edit-btn'
            );

        if(editSectionButton){

            const sectionId =
                Number(
                    editSectionButton.dataset
                        .customSectionId
                );

            if(
                Number.isInteger(sectionId)
                &&
                sectionId > 0
            ){
                openCustomSectionManager(
                    sectionId
                );
            }
        }
    }
);


let usernameAvailabilityTimer = null;
let usernameAvailabilityConfirmed = false;
let usernameAvailabilityRequest = 0;

function resetUsernameAvailability(){

    const usernameInput =
        document.getElementById('username');

    const status =
        document.getElementById('usernameAvailability');

    const createButton =
        document.getElementById('createUserBtn');

    usernameAvailabilityConfirmed = false;
    usernameAvailabilityRequest++;

    if(usernameAvailabilityTimer){
        clearTimeout(usernameAvailabilityTimer);
        usernameAvailabilityTimer = null;
    }

    if(status){
        status.style.display = 'none';
        status.textContent = '';
        status.style.color = '';
    }

    if(createButton){
        createButton.disabled = true;
    }

    if(usernameInput && !usernameInput.value.trim()){
        return;
    }
}


function checkUsernameAvailability(){

    const usernameInput =
        document.getElementById('username');

    const status =
        document.getElementById('usernameAvailability');

    const createButton =
        document.getElementById('createUserBtn');

    if(!usernameInput || !status || !createButton){
        return;
    }

    const username = usernameInput.value.trim();
    const requestNumber = ++usernameAvailabilityRequest;

    usernameAvailabilityConfirmed = false;
    createButton.disabled = true;

    if(usernameAvailabilityTimer){
        clearTimeout(usernameAvailabilityTimer);
    }

    if(!username){
        status.style.display = 'none';
        status.textContent = '';
        return;
    }

    status.style.display = 'block';
    status.style.color = '';
    status.textContent = 'Checking username...';

    usernameAvailabilityTimer = setTimeout(() => {

        fetch(
            '/api/users/username-available/' +
            encodeURIComponent(username)
        )
        .then(response => {

            if(!response.ok){
                throw new Error(
                    'Availability lookup failed'
                );
            }

            return response.json();
        })
        .then(data => {

            if(
                requestNumber !==
                usernameAvailabilityRequest
            ){
                return;
            }

            if(
                usernameInput.value.trim()
                !== username
            ){
                return;
            }

            status.style.display = 'block';

            if(data.available === true){

                usernameAvailabilityConfirmed = true;

                status.textContent =
                    'Username is available';

                status.style.color = '#22c55e';

                createButton.disabled = false;

            } else {

                usernameAvailabilityConfirmed = false;

                status.textContent =
                    'Username is not available';

                status.style.color = '#ef4444';

                createButton.disabled = true;
            }
        })
        .catch(() => {

            if(
                requestNumber !==
                usernameAvailabilityRequest
            ){
                return;
            }

            usernameAvailabilityConfirmed = false;

            status.style.display = 'block';

            status.textContent =
                'Unable to check username';

            status.style.color = '#ef4444';

            createButton.disabled = true;
        });

    }, 400);
}


document.addEventListener(
    'DOMContentLoaded',
    function(){

        const usernameInput =
            document.getElementById('username');

        const addUserForm =
            document.getElementById('addUserForm');

        if(usernameInput){

            usernameInput.addEventListener(
                'input',
                checkUsernameAvailability
            );
        }

        if(addUserForm){

            addUserForm.addEventListener(
                'submit',
                function(event){

                    if(
                        !usernameAvailabilityConfirmed
                    ){
                        event.preventDefault();
                        checkUsernameAvailability();
                    }
                }
            );
        }
    }
);


function openUserModal() {

    resetUsernameAvailability();

    document.getElementById('userModal').style.display = 'flex';

}

function closeUserModal() {

    document.getElementById('userModal').style.display = 'none';

}



/* =========================================================
   Update003 - Edit User Profile Picture / Crop Editor
   ========================================================= */

/*
 * Crop state.
 *
 * x/y are rendered image offsets in avatar pixels.
 * scale is additional zoom above the minimum cover scale.
 */

const profileCropState = {
    token: '',
    tempUrl: '',
    sourceWidth: 0,
    sourceHeight: 0,
    scale: 1,
    x: 0,
    y: 0,
    dragging: false,
    pointerId: null,
    dragStartX: 0,
    dragStartY: 0,
    imageStartX: 0,
    imageStartY: 0,
    hasPendingCrop: false,
    finalCleanupToken: null
};


function getProfileAvatarElements(){

    return {
        button:
            document.getElementById(
                'profileAvatarUpload'
            ),

        preview:
            document.getElementById(
                'profileAvatarPreview'
            ),

        icon:
            document.getElementById(
                'profileAvatarIcon'
            ),

        label:
            document.getElementById(
                'profileAvatarLabel'
            ),

        remove:
            document.getElementById(
                'profileAvatarRemove'
            ),

        status:
            document.getElementById(
                'profileAvatarStatus'
            ),

        file:
            document.getElementById(
                'profileAvatarFile'
            ),

        photo:
            document.getElementById(
                'edit_photo'
            ),

        hint:
            document.getElementById(
                'profileAvatarHint'
            )
    };
}


function resetProfileCropState(){

    profileCropState.token = '';
    profileCropState.tempUrl = '';
    profileCropState.sourceWidth = 0;
    profileCropState.sourceHeight = 0;
    profileCropState.scale = 1;
    profileCropState.x = 0;
    profileCropState.y = 0;
    profileCropState.dragging = false;
    profileCropState.pointerId = null;
    profileCropState.dragStartX = 0;
    profileCropState.dragStartY = 0;
    profileCropState.imageStartX = 0;
    profileCropState.imageStartY = 0;
    profileCropState.hasPendingCrop = false;
    profileCropState.finalCleanupToken = null;
}


function resetProfileAvatarUI(){

    const el =
        getProfileAvatarElements();

    resetProfileCropState();

    if(el.preview){
        el.preview.src = '';
        el.preview.style.display = 'none';
        el.preview.style.width = '';
        el.preview.style.height = '';
        el.preview.style.left = '';
        el.preview.style.top = '';
        el.preview.style.transform = '';
    }

    if(el.icon){
        el.icon.style.display = '';
    }

    if(el.label){
        el.label.textContent = 'Add Picture';
    }

    if(el.remove){
        el.remove.style.display = 'none';
    }

    if(el.status){
        el.status.textContent = '';
        el.status.className =
            'profile-avatar-status';
    }

    if(el.hint){
        el.hint.style.display = 'none';
    }

    if(el.file){
        el.file.value = '';
    }
}


function setProfileAvatar(photo){

    const el =
        getProfileAvatarElements();

    if(
        !el.preview ||
        !el.icon ||
        !el.label ||
        !el.remove
    ){
        return;
    }


    const cleanPhoto =
        String(photo || '').trim();


    /*
     * Existing saved picture:
     * normal static cover preview.
     */

    if(cleanPhoto === ''){

        el.preview.src = '';
        el.preview.style.display = 'none';
        el.preview.style.width = '';
        el.preview.style.height = '';
        el.preview.style.left = '';
        el.preview.style.top = '';
        el.preview.style.transform = '';

        el.icon.style.display = '';

        el.label.textContent =
            'Add Picture';

        el.remove.style.display =
            'none';

        if(el.hint){
            el.hint.style.display =
                'none';
        }

        return;
    }


    let photoUrl =
        cleanPhoto;

    if(
        !/^https?:\/\//i.test(photoUrl)
        &&
        !photoUrl.startsWith('/')
    ){
        photoUrl =
            '/' + photoUrl;
    }


    el.preview.src =
        photoUrl;

    el.preview.style.display =
        'block';

    el.preview.style.width =
        '100%';

    el.preview.style.height =
        '100%';

    el.preview.style.left =
        '0';

    el.preview.style.top =
        '0';

    el.preview.style.transform =
        'none';

    el.icon.style.display =
        'none';

    el.label.textContent =
        'Change Picture';

    el.remove.style.display =
        'inline-block';

    if(el.hint){
        el.hint.style.display =
            'none';
    }
}


function profileCropMetrics(){

    const el =
        getProfileAvatarElements();

    if(
        !el.button ||
        profileCropState.sourceWidth <= 0 ||
        profileCropState.sourceHeight <= 0
    ){
        return null;
    }


    const avatarSize =
        el.button.clientWidth;


    /*
     * Minimum scale required to completely cover
     * the circular viewport.
     */

    const coverScale =
        Math.max(
            avatarSize /
                profileCropState.sourceWidth,

            avatarSize /
                profileCropState.sourceHeight
        );


    const renderScale =
        coverScale *
        profileCropState.scale;


    return {
        avatarSize,
        coverScale,
        renderScale,

        renderedWidth:
            profileCropState.sourceWidth *
            renderScale,

        renderedHeight:
            profileCropState.sourceHeight *
            renderScale
    };
}


function clampProfileCropPosition(){

    const metrics =
        profileCropMetrics();

    if(!metrics){
        return;
    }


    /*
     * The rendered image must always cover the entire
     * avatar square. No empty area can enter the crop.
     */

    const minX =
        metrics.avatarSize -
        metrics.renderedWidth;

    const minY =
        metrics.avatarSize -
        metrics.renderedHeight;


    profileCropState.x =
        Math.min(
            0,
            Math.max(
                minX,
                profileCropState.x
            )
        );


    profileCropState.y =
        Math.min(
            0,
            Math.max(
                minY,
                profileCropState.y
            )
        );
}


function renderProfileCrop(){

    const el =
        getProfileAvatarElements();

    const metrics =
        profileCropMetrics();

    if(
        !el.preview ||
        !metrics
    ){
        return;
    }


    clampProfileCropPosition();


    el.preview.style.display =
        'block';

    el.preview.style.width =
        metrics.renderedWidth +
        'px';

    el.preview.style.height =
        metrics.renderedHeight +
        'px';

    el.preview.style.left =
        profileCropState.x +
        'px';

    el.preview.style.top =
        profileCropState.y +
        'px';

    el.preview.style.transform =
        'none';
}


function centreProfileCrop(){

    const metrics =
        profileCropMetrics();

    if(!metrics){
        return;
    }


    profileCropState.x =
        (
            metrics.avatarSize -
            metrics.renderedWidth
        ) / 2;


    profileCropState.y =
        (
            metrics.avatarSize -
            metrics.renderedHeight
        ) / 2;


    renderProfileCrop();
}


async function discardPendingProfileCrop(){

    const token =
        profileCropState.token;

    if(!token){
        resetProfileCropState();
        return;
    }


    /*
     * Clear local state first so repeated close/change
     * actions cannot discard the same token twice.
     */

    resetProfileCropState();


    const data =
        new FormData();

    data.set(
        'action',
        'discard'
    );

    data.set(
        'token',
        token
    );


    try {

        await fetch(
            '/profile-image-upload.php',
            {
                method: 'POST',
                body: data
            }
        );

    } catch(error) {

        /*
         * Best effort cleanup.
         * Server-side stale-temp cleanup will be added
         * to Update003 packaging as a second safeguard.
         */
    }
}


document.addEventListener(
    'DOMContentLoaded',
    function(){

        const el =
            getProfileAvatarElements();


        if(
            !el.button ||
            !el.preview ||
            !el.file ||
            !el.remove ||
            !el.status ||
            !el.photo
        ){
            return;
        }


        /*
         * Add/change picture.
         *
         * While a crop is active, clicking the circle
         * should drag rather than reopening the picker.
         */

        el.button.addEventListener(
            'click',
            function(){

                if(
                    profileCropState.hasPendingCrop
                ){
                    return;
                }

                el.file.click();
            }
        );


        el.file.addEventListener(
            'change',
            async function(){

                const file =
                    el.file.files &&
                    el.file.files.length
                        ? el.file.files[0]
                        : null;


                if(!file){
                    return;
                }


                const allowedTypes = [
                    'image/jpeg',
                    'image/png',
                    'image/webp'
                ];


                if(
                    !allowedTypes.includes(
                        file.type
                    )
                ){

                    el.status.className =
                        'profile-avatar-status is-error';

                    el.status.textContent =
                        'Choose a JPG, PNG or WebP image.';

                    el.file.value = '';

                    return;
                }


                if(
                    file.size >
                    (5 * 1024 * 1024)
                ){

                    el.status.className =
                        'profile-avatar-status is-error';

                    el.status.textContent =
                        'Profile picture must be 5 MB or smaller.';

                    el.file.value = '';

                    return;
                }


                /*
                 * If another unsaved temporary source exists,
                 * discard it before replacing it.
                 */

                await discardPendingProfileCrop();


                el.status.className =
                    'profile-avatar-status is-working';

                el.status.textContent =
                    'Preparing picture...';

                el.button.disabled = true;
                el.remove.disabled = true;


                try {

                    const formData =
                        new FormData();

                    formData.set(
                        'action',
                        'upload'
                    );

                    formData.set(
                        'profile_image',
                        file
                    );


                    const response =
                        await fetch(
                            '/profile-image-upload.php',
                            {
                                method: 'POST',
                                body: formData
                            }
                        );


                    const data =
                        await response.json();


                    if(
                        !response.ok ||
                        data.success !== true ||
                        !data.token ||
                        !data.url ||
                        !data.width ||
                        !data.height
                    ){
                        throw new Error(
                            data.message ||
                            'Unable to prepare profile picture.'
                        );
                    }


                    profileCropState.token =
                        data.token;

                    profileCropState.tempUrl =
                        data.url;

                    profileCropState.sourceWidth =
                        Number(data.width);

                    profileCropState.sourceHeight =
                        Number(data.height);

                    profileCropState.scale = 1;

                    profileCropState.hasPendingCrop =
                        true;


                    el.preview.src =
                        data.url;

                    el.preview.style.display =
                        'block';

                    el.icon.style.display =
                        'none';

                    el.label.textContent =
                        'Drag Picture';

                    el.remove.style.display =
                        'inline-block';


                    if(el.hint){
                        el.hint.style.display =
                            'block';
                    }


                    /*
                     * Wait until the browser knows the image
                     * before calculating the initial crop.
                     */

                    if(el.preview.complete){

                        centreProfileCrop();

                    }else{

                        el.preview.onload =
                            function(){
                                centreProfileCrop();
                            };
                    }


                    el.status.className =
                        'profile-avatar-status is-success';

                    el.status.textContent =
                        'Position picture, then click Save.';


                } catch(error) {

                    el.status.className =
                        'profile-avatar-status is-error';

                    el.status.textContent =
                        error.message ||
                        'Unable to prepare profile picture.';

                } finally {

                    el.button.disabled = false;
                    el.remove.disabled = false;
                    el.file.value = '';
                }
            }
        );


        /*
         * Pointer drag.
         * Works with mouse, pen and touch.
         */

        el.button.addEventListener(
            'pointerdown',
            function(event){

                if(
                    !profileCropState.hasPendingCrop
                ){
                    return;
                }


                event.preventDefault();

                profileCropState.dragging =
                    true;

                profileCropState.pointerId =
                    event.pointerId;

                profileCropState.dragStartX =
                    event.clientX;

                profileCropState.dragStartY =
                    event.clientY;

                profileCropState.imageStartX =
                    profileCropState.x;

                profileCropState.imageStartY =
                    profileCropState.y;


                el.button.setPointerCapture(
                    event.pointerId
                );

                el.button.classList.add(
                    'is-cropping'
                );
            }
        );


        el.button.addEventListener(
            'pointermove',
            function(event){

                if(
                    !profileCropState.dragging
                    ||
                    event.pointerId !==
                        profileCropState.pointerId
                ){
                    return;
                }


                event.preventDefault();


                profileCropState.x =
                    profileCropState.imageStartX +
                    (
                        event.clientX -
                        profileCropState.dragStartX
                    );


                profileCropState.y =
                    profileCropState.imageStartY +
                    (
                        event.clientY -
                        profileCropState.dragStartY
                    );


                renderProfileCrop();
            }
        );


        function endProfileDrag(event){

            if(
                !profileCropState.dragging
            ){
                return;
            }


            if(
                event.pointerId !==
                profileCropState.pointerId
            ){
                return;
            }


            profileCropState.dragging =
                false;

            profileCropState.pointerId =
                null;

            el.button.classList.remove(
                'is-cropping'
            );


            try {

                el.button.releasePointerCapture(
                    event.pointerId
                );

            } catch(error) {
            }
        }


        el.button.addEventListener(
            'pointerup',
            endProfileDrag
        );

        el.button.addEventListener(
            'pointercancel',
            endProfileDrag
        );


        /*
         * Mouse-wheel zoom.
         *
         * Keep the point under the cursor visually anchored
         * while zoom changes.
         */

        el.button.addEventListener(
            'wheel',
            function(event){

                if(
                    !profileCropState.hasPendingCrop
                ){
                    return;
                }


                event.preventDefault();


                const before =
                    profileCropMetrics();

                if(!before){
                    return;
                }


                const rect =
                    el.button.getBoundingClientRect();

                const pointerX =
                    event.clientX -
                    rect.left;

                const pointerY =
                    event.clientY -
                    rect.top;


                const sourceX =
                    (
                        pointerX -
                        profileCropState.x
                    ) /
                    before.renderScale;

                const sourceY =
                    (
                        pointerY -
                        profileCropState.y
                    ) /
                    before.renderScale;


                const factor =
                    event.deltaY < 0
                        ? 1.08
                        : (1 / 1.08);


                profileCropState.scale =
                    Math.min(
                        5,
                        Math.max(
                            1,
                            profileCropState.scale *
                            factor
                        )
                    );


                const after =
                    profileCropMetrics();


                profileCropState.x =
                    pointerX -
                    (
                        sourceX *
                        after.renderScale
                    );

                profileCropState.y =
                    pointerY -
                    (
                        sourceY *
                        after.renderScale
                    );


                renderProfileCrop();

            },
            {
                passive: false
            }
        );


        /*
         * Remove.
         *
         * If editing a new temporary image, discard it.
         * The saved DB picture itself is only removed after
         * the normal Save operation succeeds.
         */

        el.remove.addEventListener(
            'click',
            async function(event){

                event.stopPropagation();


                if(
                    profileCropState.hasPendingCrop
                ){

                    await discardPendingProfileCrop();
                }


                el.photo.value = '';

                setProfileAvatar('');


                el.status.className =
                    'profile-avatar-status is-success';

                el.status.textContent =
                    'Picture removed. Click Save to apply.';
            }
        );
    }
);


/* =========================================================
   Update003 - Edit User AJAX Save
   Crop -> Profile Save
   ========================================================= */

async function createFinalProfileCrop(){

    if(
        !profileCropState.hasPendingCrop ||
        !profileCropState.token
    ){
        return null;
    }


    const metrics =
        profileCropMetrics();

    if(!metrics){
        throw new Error(
            'Unable to calculate the profile picture crop.'
        );
    }


    /*
     * Convert the visible avatar square back into
     * sanitized source-image pixels.
     */

    const sourceX =
        Math.max(
            0,
            -profileCropState.x /
            metrics.renderScale
        );

    const sourceY =
        Math.max(
            0,
            -profileCropState.y /
            metrics.renderScale
        );

    const sourceSize =
        metrics.avatarSize /
        metrics.renderScale;


    const data =
        new FormData();

    data.set(
        'action',
        'crop'
    );

    data.set(
        'token',
        profileCropState.token
    );

    data.set(
        'source_x',
        String(sourceX)
    );

    data.set(
        'source_y',
        String(sourceY)
    );

    data.set(
        'source_size',
        String(sourceSize)
    );


    const response =
        await fetch(
            '/profile-image-upload.php',
            {
                method: 'POST',
                body: data
            }
        );


    const contentType =
        response.headers.get(
            'content-type'
        ) || '';


    if(
        !contentType
            .toLowerCase()
            .includes('application/json')
    ){
        throw new Error(
            'Image server returned an unexpected response.'
        );
    }


    const result =
        await response.json();


    if(
        !response.ok ||
        result.success !== true ||
        !result.photo
    ){
        throw new Error(
            result.message ||
            'Unable to crop the profile picture.'
        );
    }


    /*
     * The crop endpoint removes the temporary source
     * after creating the final image.
     *
     * Preserve the opaque session-bound cleanup token
     * until the profile save has either succeeded or failed.
     */

    if(!result.cleanup_token){
        throw new Error(
            'Profile picture cleanup token was not returned.'
        );
    }


    const cleanupToken =
        result.cleanup_token;


    resetProfileCropState();

    profileCropState.finalCleanupToken =
        cleanupToken;


    return result;
}


async function resolvePendingFinalProfileImage(
    action
){

    const token =
        profileCropState.finalCleanupToken;


    if(!token){
        return true;
    }


    if(
        action !== 'commit-final'
        &&
        action !== 'discard-final'
    ){
        throw new Error(
            'Invalid profile picture lifecycle action.'
        );
    }


    const formData =
        new FormData();

    formData.set(
        'action',
        action
    );

    formData.set(
        'token',
        token
    );


    const response =
        await fetch(
            '/profile-image-upload.php',
            {
                method: 'POST',
                body: formData
            }
        );


    const contentType =
        response.headers.get(
            'content-type'
        ) || '';


    if(
        !contentType
            .toLowerCase()
            .includes('application/json')
    ){
        throw new Error(
            'Image lifecycle server returned an unexpected response.'
        );
    }


    const result =
        await response.json();


    if(
        !response.ok
        ||
        result.success !== true
    ){
        throw new Error(
            result.message ||
            'Unable to complete profile picture lifecycle.'
        );
    }


    profileCropState.finalCleanupToken =
        null;


    return true;
}


document.addEventListener(
    'DOMContentLoaded',
    function(){

        const editUserForm =
            document.getElementById(
                'editUserForm'
            );

        const saveButton =
            document.getElementById(
                'editUserSaveBtn'
            );

        const status =
            document.getElementById(
                'editUserSaveStatus'
            );

        const photoField =
            document.getElementById(
                'edit_photo'
            );

        const avatarStatus =
            document.getElementById(
                'profileAvatarStatus'
            );


        if(
            !editUserForm ||
            !saveButton ||
            !status ||
            !photoField
        ){
            return;
        }


        editUserForm.addEventListener(
            'submit',
            async function(event){

                /*
                 * Intercept ONLY Save.
                 *
                 * Disable/Enable/Delete keep their existing
                 * submit behaviour.
                 */

                if(
                    !event.submitter ||
                    event.submitter.name !==
                        'update_user'
                ){
                    return;
                }


                event.preventDefault();


                if(
                    !editUserForm.reportValidity()
                ){
                    return;
                }


                status.style.display =
                    'block';

                status.className =
                    'profile-editor-save-status is-working';

                status.textContent =
                    profileCropState.hasPendingCrop
                        ? 'Processing profile picture...'
                        : 'Saving user profile...';


                const originalText =
                    saveButton.textContent;

                saveButton.disabled =
                    true;

                saveButton.textContent =
                    'Saving...';


                /*
                 * Profile/image lifecycle boundary:
                 *
                 * false = the normal profile save has not succeeded yet,
                 *         so a newly-created final image is still disposable.
                 *
                 * true  = users.php has successfully saved the profile,
                 *         so its image may now be referenced by PostgreSQL
                 *         and must never be deleted by browser rollback.
                 */
                let profileSaveSucceeded = false;


                try {

                    /*
                     * If a new image is waiting, create the
                     * final 512x512 crop BEFORE constructing
                     * the profile FormData.
                     */

                    if(
                        profileCropState.hasPendingCrop
                    ){

                        const cropResult =
                            await createFinalProfileCrop();


                        if(
                            !cropResult ||
                            !cropResult.photo
                        ){
                            throw new Error(
                                'Unable to prepare the final profile picture.'
                            );
                        }


                        photoField.value =
                            cropResult.photo;


                        setProfileAvatar(
                            cropResult.photo
                        );


                        if(avatarStatus){

                            avatarStatus.className =
                                'profile-avatar-status is-success';

                            avatarStatus.textContent =
                                'Profile picture processed.';
                        }


                        status.textContent =
                            'Saving user profile...';
                    }


                    /*
                     * Build FormData only after the image
                     * path has been finalized.
                     */

                    const formData =
                        new FormData(
                            editUserForm
                        );


                    formData.set(
                        'update_user',
                        '1'
                    );

                    formData.set(
                        'ajax',
                        '1'
                    );


                    const response =
                        await fetch(
                            window.location.pathname,
                            {
                                method: 'POST',
                                body: formData,
                                headers: {
                                    'X-Requested-With':
                                        'XMLHttpRequest'
                                }
                            }
                        );


                    const contentType =
                        response.headers.get(
                            'content-type'
                        ) || '';


                    if(
                        !contentType
                            .toLowerCase()
                            .includes(
                                'application/json'
                            )
                    ){
                        throw new Error(
                            'Server returned an unexpected response.'
                        );
                    }


                    const data =
                        await response.json();


                    if(
                        !response.ok ||
                        data.success !== true
                    ){
                        throw new Error(
                            data.message ||
                            'Unable to save the user profile.'
                        );
                    }


                    /*
                     * users.php has confirmed the profile save.
                     *
                     * From this exact point onward a newly-created
                     * final image may already be referenced by the
                     * saved profile. It must never be discarded by
                     * a later custom-field error.
                     */
                    profileSaveSucceeded = true;


                    /*
                     * Commit the image lifecycle immediately after
                     * the successful profile save.
                     *
                     * commit-final only forgets the pending cleanup
                     * token. It does not delete the image.
                     */
                    if(
                        profileCropState.finalCleanupToken
                    ){
                        await resolvePendingFinalProfileImage(
                            'commit-final'
                        );
                    }


                    /*
                     * Custom-field values are a subsequent save.
                     * Failure here must report an error, but must
                     * never roll back an already-saved profile image.
                     */

                    const userIdText =
                        (
                            document.getElementById(
                                'profileEditorUserId'
                            ).textContent
                            || ''
                        );

                    const userIdMatch =
                        userIdText.match(
                            /User ID:\s*(\d+)/
                        );

                    const customFieldUserId =
                        userIdMatch
                            ? Number(userIdMatch[1])
                            : 0;


                    if(
                        !Number.isInteger(
                            customFieldUserId
                        )
                        ||
                        customFieldUserId <= 0
                    ){
                        throw new Error(
                            'Unable to determine the user ID for custom fields.'
                        );
                    }


                    status.textContent =
                        'Saving custom user fields...';


                    await saveCustomUserFields(
                        customFieldUserId
                    );


                    status.className =
                        'profile-editor-save-status is-success';

                    status.textContent =
                        data.message ||
                        'User profile saved successfully.';


                    const displayName =
                        document.getElementById(
                            'edit_display_name'
                        ).value.trim();

                    const email =
                        document.getElementById(
                            'edit_email_address'
                        ).value.trim();

                    const username =
                        document.getElementById(
                            'edit_username'
                        ).value.trim();

                    const groupSelect =
                        document.getElementById(
                            'edit_group_id'
                        );

                    const selectedGroup =
                        groupSelect &&
                        groupSelect.selectedIndex >= 0
                            ? groupSelect.options[
                                groupSelect.selectedIndex
                            ]
                            : null;


                    document.getElementById(
                        'profileEditorName'
                    ).textContent =
                        displayName ||
                        username;


                    document.getElementById(
                        'profileEditorEmail'
                    ).textContent =
                        email;


                    document.getElementById(
                        'profileEditorGroup'
                    ).textContent =
                        'Policy Group - ' +
                        (
                            selectedGroup
                                ? selectedGroup
                                    .textContent
                                    .trim()
                                : 'Unassigned'
                        );


                } catch(error) {

                    /*
                     * If crop creation succeeded but the profile
                     * save failed, remove that unused final image.
                     */

                    if(
                        !profileSaveSucceeded
                        &&
                        profileCropState.finalCleanupToken
                    ){
                        try {

                            await resolvePendingFinalProfileImage(
                                'discard-final'
                            );

                        } catch(cleanupError) {

                            console.error(
                                'Profile image cleanup failed:',
                                cleanupError
                            );
                        }
                    }


                    status.className =
                        'profile-editor-save-status is-error';

                    status.textContent =
                        error.message ||
                        'Unable to save the user profile.';


                } finally {

                    saveButton.disabled =
                        false;

                    saveButton.textContent =
                        originalText;
                }
            }
        );
    }
);


/* =========================================================
   Update003 - Custom User Fields
   Edit User renderer
   ========================================================= */

function escapeCustomFieldHtml(value){

    return String(
        value === null || value === undefined
            ? ''
            : value
    )
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}


function renderCustomUserFields(fields){

    const container =
        document.getElementById(
            'customUserFields'
        );

    if(!container){
        return;
    }

    const fieldList =
        Array.isArray(fields)
            ? fields
            : [];

    /*
     * Prefer the independently loaded section list so empty
     * sections are still visible. Fall back to section metadata
     * supplied with fields if necessary.
     */
    let sections =
        Array.isArray(customFieldSections)
            ? customFieldSections
                .map(section => ({
                    id:
                        Number(section.id),

                    section_name:
                        String(
                            section.section_name || ''
                        ),

                    sort_order:
                        Number(
                            section.sort_order ?? 0
                        )
                }))
                .filter(section =>
                    Number.isInteger(section.id)
                    &&
                    section.id > 0
                )
            : [];

    if(sections.length === 0){

        const discovered =
            new Map();

        fieldList.forEach(field => {

            const sectionId =
                Number(field.section_id);

            if(
                !Number.isInteger(sectionId)
                ||
                sectionId <= 0
                ||
                discovered.has(sectionId)
            ){
                return;
            }

            discovered.set(
                sectionId,
                {
                    id: sectionId,

                    section_name:
                        String(
                            field.section_name ||
                            'Custom User Fields'
                        ),

                    sort_order:
                        Number(
                            field.section_sort_order ?? 0
                        )
                }
            );
        });

        sections =
            Array.from(
                discovered.values()
            );
    }

    sections.sort(
        (a, b) => {

            const sortDifference =
                Number(a.sort_order || 0)
                -
                Number(b.sort_order || 0);

            if(sortDifference !== 0){
                return sortDifference;
            }

            return Number(a.id) - Number(b.id);
        }
    );

    if(sections.length === 0){

        container.innerHTML =
            '<div class="custom-fields-empty">' +
                (
                    canEditUserFields
                        ? 'No custom sections have been added.'
                        : 'No custom fields have been added.'
                ) +
            '</div>';

        return;
    }


    function renderField(field){

        const fieldId =
            Number(field.id);

        if(
            !Number.isInteger(fieldId)
            ||
            fieldId <= 0
        ){
            return '';
        }

        const fieldName =
            escapeCustomFieldHtml(
                field.field_name || ''
            );

        const fieldType =
            String(
                field.field_type || 'text'
            ).toLowerCase();

        const value =
            field.value === null ||
            field.value === undefined
                ? ''
                : String(field.value);

        const escapedValue =
            escapeCustomFieldHtml(
                value
            );

        const prepend =
            field.prepend === null ||
            field.prepend === undefined
                ? ''
                : String(field.prepend);

        const escapedPrepend =
            escapeCustomFieldHtml(
                prepend
            );

        const required =
            field.required === true;

        const requiredLabel =
            required
                ? ' <span class="custom-field-required">*</span>'
                : '';

        const requiredAttribute =
            required
                ? ' required'
                : '';

        const commonAttributes =
            ' data-custom-field-id="' +
            fieldId +
            '"' +
            ' data-custom-field-type="' +
            escapeCustomFieldHtml(
                fieldType
            ) +
            '"';

        let rawControl = '';

        switch(fieldType){

            case 'textarea':

                rawControl =
                    '<textarea' +
                    commonAttributes +
                    requiredAttribute +
                    ' rows="3">' +
                    escapedValue +
                    '</textarea>';

                break;


            case 'email':

                rawControl =
                    '<input type="email"' +
                    commonAttributes +
                    requiredAttribute +
                    ' value="' +
                    escapedValue +
                    '">';

                break;


            case 'number':

                rawControl =
                    '<input type="number"' +
                    commonAttributes +
                    requiredAttribute +
                    ' value="' +
                    escapedValue +
                    '">';

                break;


            case 'date':

                rawControl =
                    '<input type="date"' +
                    commonAttributes +
                    requiredAttribute +
                    ' value="' +
                    escapedValue +
                    '">';

                break;


            case 'checkbox':

                rawControl =
                    '<label class="custom-field-checkbox">' +
                        '<input type="checkbox"' +
                        commonAttributes +
                        (
                            value === '1'
                                ? ' checked'
                                : ''
                        ) +
                        requiredAttribute +
                        '>' +
                        '<span>Yes</span>' +
                    '</label>';

                break;


            case 'text':
            default:

                rawControl =
                    '<input type="text"' +
                    commonAttributes +
                    requiredAttribute +
                    ' value="' +
                    escapedValue +
                    '">';

                break;
        }


        let control =
            rawControl;

        /*
         * Prepend is definition metadata.
         * It is deliberately NOT inserted into the input value.
         * The collector therefore continues to submit only the
         * user's raw value.
         */
        if(
            prepend !== ''
            &&
            fieldType !== 'checkbox'
        ){

            control =
                '<div class="custom-field-input-with-prepend">' +

                    '<span class="custom-field-prepend">' +
                        escapedPrepend +
                    '</span>' +

                    '<div class="custom-field-prepend-control">' +
                        rawControl +
                    '</div>' +

                '</div>';
        }


        const managementControl =
            canEditUserFields
                ? (
                    '<button ' +
                        'type="button" ' +
                        'class="custom-field-edit-btn" ' +
                        'data-custom-field-edit-id="' +
                        fieldId +
                        '" ' +
                        'title="Edit custom field" ' +
                        'aria-label="Edit custom field">' +
                        'Edit' +
                    '</button>'
                )
                : '';


        return (
            '<div class="form-group custom-field-item">' +

                '<div class="custom-field-label-row">' +

                    '<label>' +
                        fieldName +
                        requiredLabel +
                    '</label>' +

                    managementControl +

                '</div>' +

                control +

            '</div>'
        );
    }


    container.innerHTML =
        sections.map(section => {

            const sectionId =
                Number(section.id);

            const sectionName =
                escapeCustomFieldHtml(
                    section.section_name ||
                    'Custom User Fields'
                );

            const sectionFields =
                fieldList
                    .filter(field =>
                        Number(field.section_id)
                        === sectionId
                    )
                    .sort(
                        (a, b) => {

                            const sortDifference =
                                Number(a.sort_order ?? 0)
                                -
                                Number(b.sort_order ?? 0);

                            if(sortDifference !== 0){
                                return sortDifference;
                            }

                            return (
                                Number(a.id)
                                -
                                Number(b.id)
                            );
                        }
                    );

            const sectionEditControl =
                canEditUserFields
                    ? (
                        '<button ' +
                            'type="button" ' +
                            'class="custom-section-edit-btn" ' +
                            'data-custom-section-id="' +
                            sectionId +
                            '" ' +
                            'title="Edit custom section">' +
                            'Edit' +
                        '</button>'
                    )
                    : '';

            const sectionAddFieldControl =
                canEditUserFields
                    ? (
                        '<button ' +
                            'type="button" ' +
                            'class="profile-add-field-btn custom-section-add-field-btn" ' +
                            'data-custom-section-id="' +
                            sectionId +
                            '" ' +
                            'title="Add field to this section">' +
                            '+ Add Field' +
                        '</button>'
                    )
                    : '';

            const fieldsHtml =
                sectionFields.length > 0
                    ? (
                        '<div class="portal-form-grid custom-section-fields">' +
                            sectionFields
                                .map(renderField)
                                .join('') +
                        '</div>'
                    )
                    : (
                        '<div class="custom-fields-empty custom-section-empty">' +
                            (
                                canEditUserFields
                                    ? 'No fields in this section yet.'
                                    : 'No fields available in this section.'
                            ) +
                        '</div>'
                    );

            return (
                '<section class="custom-user-field-section" ' +
                    'data-custom-section-id="' +
                    sectionId +
                    '">' +

                    '<div class="custom-section-heading">' +

                        '<div class="custom-section-title-group">' +

                            '<h4>' +
                                sectionName +
                            '</h4>' +

                            sectionEditControl +

                        '</div>' +

                        '<div class="custom-section-actions">' +
                            sectionAddFieldControl +
                        '</div>' +

                    '</div>' +

                    fieldsHtml +

                '</section>'
            );

        }).join('');
}


function collectCustomUserFieldValues(){

    const controls =
        document.querySelectorAll(
            '#customUserFields [data-custom-field-id]'
        );

    const values = [];


    controls.forEach(control => {

        const fieldId =
            Number(
                control.dataset.customFieldId
            );

        if(
            !Number.isInteger(fieldId)
            ||
            fieldId <= 0
        ){
            return;
        }


        const fieldType =
            String(
                control.dataset.customFieldType
                || 'text'
            ).toLowerCase();


        let value = '';


        if(fieldType === 'checkbox'){

            value =
                control.checked
                    ? '1'
                    : '0';

        } else {

            value =
                control.value !== undefined
                    ? String(control.value)
                    : '';
        }


        values.push({
            field_id: fieldId,
            value: value
        });
    });


    return values;
}


async function saveCustomUserFields(userId){

    const response =
        await fetch(
            '/user-custom-fields-api.php?action=save',
            {
                method: 'POST',

                headers: {
                    'Content-Type':
                        'application/json',

                    'X-Requested-With':
                        'XMLHttpRequest'
                },

                body: JSON.stringify({
                    user_id: userId,
                    values:
                        collectCustomUserFieldValues()
                })
            }
        );


    const contentType =
        response.headers.get(
            'content-type'
        ) || '';


    if(
        !contentType
            .toLowerCase()
            .includes('application/json')
    ){
        throw new Error(
            'Custom field server returned an unexpected response.'
        );
    }


    const result =
        await response.json();


    if(
        !response.ok
        ||
        result.success !== true
    ){
        throw new Error(
            result.message ||
            'Unable to save custom user fields.'
        );
    }


    return result;
}


async function loadCustomUserFields(userId){

    const container =
        document.getElementById(
            'customUserFields'
        );

    if(!container){
        return;
    }


    container.innerHTML =
        '<div class="custom-fields-empty">' +
        'Loading custom fields...' +
        '</div>';


    try {

        const response =
            await fetch(
                '/user-custom-fields-api.php' +
                '?action=load' +
                '&user_id=' +
                encodeURIComponent(userId),
                {
                    headers: {
                        'X-Requested-With':
                            'XMLHttpRequest'
                    }
                }
            );


        const contentType =
            response.headers.get(
                'content-type'
            ) || '';


        if(
            !contentType
                .toLowerCase()
                .includes('application/json')
        ){
            throw new Error(
                'Custom field server returned an unexpected response.'
            );
        }


        const result =
            await response.json();


        if(
            !response.ok
            ||
            result.success !== true
        ){
            throw new Error(
                result.message ||
                'Unable to load custom user fields.'
            );
        }


        renderCustomUserFields(
            result.fields || []
        );


    } catch(error) {

        console.error(
            'Custom field load failed:',
            error
        );

        container.innerHTML =
            '<div class="custom-fields-empty custom-fields-error">' +
            escapeCustomFieldHtml(
                error.message ||
                'Unable to load custom fields.'
            ) +
            '</div>';
    }
}


function openEditUserModal(
    displayName,
    username,
    disabled
){

    /*
     * Always start Edit User with a clean save status.
     */
    const editUserSaveStatus =
        document.getElementById('editUserSaveStatus');

    if(editUserSaveStatus){
        editUserSaveStatus.style.display = 'none';
        editUserSaveStatus.className =
            'profile-editor-save-status';
        editUserSaveStatus.textContent = '';
    }

    resetProfileAvatarUI();

    document.getElementById(
        'edit_display_name'
    ).value = displayName;

    document.getElementById(
        'edit_username'
    ).value = username;

    document.getElementById(
        'edit_username_display'
    ).value = username;

    document.getElementById(
        'edit_disabled'
    ).value = disabled;


    document.getElementById(
        'profileEditorName'
    ).textContent = displayName || username;

    document.getElementById(
        'profileEditorEmail'
    ).textContent = '';

    document.getElementById(
        'profileEditorGroup'
    ).textContent = 'Policy Group - Unassigned';

    document.getElementById(
        'profileEditorUserId'
    ).textContent = 'User ID: —';
    
    fetch(
        '/api/user-profiles/' + username
    )
    .then(response => response.json())
    .then(profile => {
    
        document.getElementById(
            'edit_surname'
        ).value = profile.surname || '';
    
        document.getElementById(
            'edit_department'
        ).value = profile.department || '';
    
        document.getElementById(
            'edit_email_address'
        ).value = profile.email_address || '';
    
        const editCountryCode =
            document.getElementById('edit_country_code');

        if(profile.country_code){
            editCountryCode.value = profile.country_code;
        }
    
        document.getElementById(
            'edit_mobile_number'
        ).value = profile.mobile_number || '';

        document.getElementById(
            'edit_photo'
        ).value = profile.photo || '';


        setProfileAvatar(
            profile.photo || ''
        );


        document.getElementById(
            'profileEditorName'
        ).textContent =
            profile.display_name ||
            displayName ||
            username;

        document.getElementById(
            'profileEditorEmail'
        ).textContent =
            profile.email_address || '';

        document.getElementById(
            'profileEditorUserId'
        ).textContent =
            'User ID: ' +
            (
                profile.id !== undefined &&
                profile.id !== null
                    ? profile.id
                    : '—'
            );


        if(
            profile.id !== undefined &&
            profile.id !== null
        ){
            loadCustomUserFields(
                profile.id
            );
        } else {
            renderCustomUserFields([]);
        }
    
    });

    const btn =
        document.getElementById(
            'disableEnableBtn'
        );
    
    const deleteBtn =
        document.getElementById(
            'deleteUserBtn'
        );
    
    if(
        username === 'admin' ||
        username === 'api'
    ){
    
        deleteBtn.style.display = 'none';
        btn.style.display = 'none';
    
    } else {
    
        deleteBtn.style.display = 'inline-block';
        btn.style.display = 'inline-block';
    
    }

    if(disabled === 'true'){

        btn.innerText = 'Enable User';

    } else {

        btn.innerText = 'Disable User';

    }
    
    document.getElementById(
        'passwordResetSection'
    ).style.display = 'none';
    
    fetch(
        '/api/users/' +
        username +
        '/group'
    )
    .then(response => response.json())
    .then(data => {
    
        const groupSelect = document.getElementById(
            'edit_group_id'
        );

        if (data.group_id) {
            groupSelect.value = data.group_id;
        } else {
            const unassignedOption = groupSelect.querySelector(
                'option[data-unassigned="1"]'
            );

            if (unassignedOption) {
                groupSelect.value = unassignedOption.value;
            }
        }


        const selectedGroup =
            groupSelect.options[groupSelect.selectedIndex];

        document.getElementById(
            'profileEditorGroup'
        ).textContent =
            'Policy Group - ' +
            (
                selectedGroup
                    ? selectedGroup.textContent.trim()
                    : 'Unassigned'
            );
    
    });
    
        document.getElementById(
            'editUserModal'
        ).style.display = 'flex';
    
    }
    
const requestedProfileUsername =
    <?= json_encode(
        isset($_GET['profile'])
            ? trim((string)$_GET['profile'])
            : ''
    ) ?>;

if(requestedProfileUsername){
    window.addEventListener(
        'DOMContentLoaded',
        function(){
            openEditUserModal(
                requestedProfileUsername,
                requestedProfileUsername,
                false
            );
        }
    );
}


async function closeEditUserModal(){

    /*
     * Closing Edit User must never leave an unfinished
     * profile-picture upload behind.
     *
     * Stage 1:
     *   tmp_<token>.webp -> discardPendingProfileCrop()
     *
     * Stage 2:
     *   profile_<token>.webp created by crop but not yet
     *   committed -> discard-final using the session token.
     */

    const pendingFinalToken =
        profileCropState.finalCleanupToken;


    if(pendingFinalToken){

        try {

            await resolvePendingFinalProfileImage(
                'discard-final'
            );

        } catch(error) {

            console.error(
                'Pending final profile image cleanup failed:',
                error
            );
        }

    }


    /*
     * discardPendingProfileCrop() is safe when there is
     * no temporary crop token, so always run it.
     */

    await discardPendingProfileCrop();


    document.getElementById(
        'editUserModal'
    ).style.display = 'none';

}

function showPasswordReset(){

    document.getElementById(
        'passwordResetSection'
    ).style.display = 'block';
    
    document.getElementById(
        'edit_password'
    ).required = true;
    
    document.getElementById(
        'edit_confirm_password'
    ).required = true;

}

</script>
</body>
</html>