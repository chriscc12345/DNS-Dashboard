<?php

require_once 'auth.php';
require_once 'config.php';

if(
    !hasPermission('Users')
){
    include 'includes/access-denied.php';
    exit;
}


if(isset($_POST['create_user'])){

    if(
        $_POST['password']
        !==
        $_POST['confirm_password']
    ){
        header(
            "Location: users.php?error=password_mismatch"
        );
        exit;
    }
    $data = json_encode([
        'display_name' => $_POST['display_name'],
        'username'     => $_POST['username'],
        'password'     => $_POST['password']
    ]);

    $response = file_get_contents(
        $FASTAPI_URL . "/users/create",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );
    
    /* Save User Profile */
    
    $profileData = json_encode([
        'username'      => $_POST['username'],
        'display_name'  => $_POST['display_name'],
        'surname'       => $_POST['surname'],
        'email_address' => $_POST['email_address'],
        'country_code'  => $_POST['country_code'],
        'mobile_number' => $_POST['mobile_number'],
        'department'    => $_POST['department'],
        'photo'         => $_POST['photo'] ?? '',
        'group_id'      => (int)$_POST['group_id']
    ]);

    
    file_get_contents(
        $FASTAPI_URL . "/user-profiles/create",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $profileData
            ]
        ])
    );
    
    /* Save Group */
    
    if(!empty($_POST['group_id'])){
    
        $groupData = json_encode([
            'username' => $_POST['username'],
            'group_id' => (int)$_POST['group_id']
        ]);
    
        file_get_contents(
            $FASTAPI_URL . "/users/group/save",
            false,
            stream_context_create([
                'http' => [
                    'method'  => 'POST',
                    'header'  =>
                        "Content-Type: application/json\r\n",
                    'content' => $groupData
                ]
            ])
        );
    }

    header("Location: users.php");
    exit;
}

if(isset($_POST['update_user'])){

    $data = json_encode([
        'username'     => $_POST['username'],
        'display_name' => $_POST['display_name']
    ]);

    file_get_contents(
        $FASTAPI_URL . "/users/update",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );
    $profileData = json_encode([
        'username'      => $_POST['username'],
        'display_name'  => $_POST['display_name'],
        'surname'       => $_POST['surname'],
        'department'    => $_POST['department'],
        'email_address' => $_POST['email_address'],
        'country_code'  => $_POST['country_code'],
        'mobile_number' => $_POST['mobile_number'],
        'group_id'      => (int)$_POST['group_id']
    ]);
    
    file_get_contents(
        $FASTAPI_URL . "/user-profiles/update",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $profileData
            ]
        ])
    );
    
    if(!empty($_POST['group_id'])){
    
        $groupData = json_encode([
            'username' => $_POST['username'],
            'group_id' => (int)$_POST['group_id']
        ]);
    
        file_get_contents(
            $FASTAPI_URL . "/users/group/save",
            false,
            stream_context_create([
                'http' => [
                    'method'  => 'POST',
                    'header'  => "Content-Type: application/json\r\n",
                    'content' => $groupData
                ]
            ])
        );
    
    }

    header("Location: users.php");
    exit;
}

if(isset($_POST['delete_user'])){

    if(
        $_POST['username'] === 'admin' ||
        $_POST['username'] === 'api'
    ){

        header("Location: users.php");
        exit;

    }

    $data = json_encode([
        'username' => $_POST['username']
    ]);

    file_get_contents(
        $FASTAPI_URL . "/users/delete",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );
    
    file_get_contents(
        $FASTAPI_URL . "/user-profiles/delete",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: users.php");
    exit;

}

if(isset($_POST['reset_password'])){

    if(empty(trim($_POST['password']))){
        header("Location: users.php?error=blank_password");
        exit;
    }

    if(
        $_POST['password'] !==
        $_POST['confirm_password']
    ){
        header("Location: users.php?error=password_mismatch");
        exit;
    }

    $data = json_encode([
        'username' => $_POST['username'],
        'password' => $_POST['password']
    ]);

    file_get_contents(
        $FASTAPI_URL . "/users/reset-password",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: users.php");
    exit;
}


if(isset($_POST['toggle_user'])){

    $endpoint =
        ($_POST['disabled'] === 'true')
        ? '/users/enable'
        : '/users/disable';

    $data = json_encode([
        'username' => $_POST['username']
    ]);

    file_get_contents(
        $FASTAPI_URL . $endpoint,
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: users.php");
    exit;
}

$json = file_get_contents(
    $FASTAPI_URL . "/users"
);

$data = json_decode($json, true);

$users = $data['response']['users'] ?? [];

$groups = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/groups"
    ),
    true
);

$userGroups = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/users/groups"
    ),
    true
);

$userProfiles = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/user-profiles"
    ),
    true
);

$profileMap = [];

foreach ($userProfiles as $profile) {

    $profileMap[$profile['username']] = $profile;

}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Users</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
    <link
        rel="icon"
        type="image/png"
        href="images/favicon.png">
    
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />    
    
</head>

<body>

<?php include 'includes/sidebar.php'; ?>

<div class="banner">
  <img src="images/banner.jpg">
</div>

<div class="content">

    <h1>Users</h1>
    
    <?php if(isset($_GET['error']) &&
              $_GET['error'] === 'password_mismatch'): ?>
    
        <div class="error-message">
            Passwords do not match.
        </div>
    
    <?php endif; ?>
      
      <div class="my-table-controls">
      
            <div class="my-table-controls-left">
            
            <button
                type="button"
                class="table-btn"
                onclick="openUserModal()">
            
                Add User
            
            </button>
            </div>
            
            <div class="my-table-controls-right">
        
                <form method="get">
        
                         
                    <input
                        type="text"
                        name="search"
                        placeholder="Search Here"
                        class="table-control"
                        value="<?= htmlspecialchars($search) ?>">
               
                        <select 
                            name="per_page"
                            class="table-control">
                        
                            <option value="10"
                                <?= $perPage == 10 ? 'selected' : '' ?>>
                                10
                            </option>
                        
                            <option value="25"
                                <?= $perPage == 25 ? 'selected' : '' ?>>
                                25
                            </option>
                        
                            <option value="50"
                                <?= $perPage == 50 ? 'selected' : '' ?>>
                                50
                            </option>
                        
                            <option value="100"
                                <?= $perPage == 100 ? 'selected' : '' ?>>
                                100
                            </option>
                        
                            <option value="all"
                                <?= $perPage == 'all' ? 'selected' : '' ?>>
                                All
                            </option>
                        
                        </select>
        
                    <button 
                        type="submit"
                        class="table-btn">
                        Search
                    </button>
                    
                    <a href="admin.php" class="clear-btn">
                        Clear
                    </a>
        
                </form>
        
            </div>
      
      </div>

    <table>

        <tr>
            <th>Photo</th>
            <th>Display Name</th>
            <th>Surname</th>
            <th>Username</th>
            <th>Department</th>
            <th>Email Address</th>
            <th>Mobile Number</th>
            <th>Group</th>
            <th>2FA Auth</th>
            <th>Status</th>
            <th>Last Login</th>
            <th>Source IP</th>
            <th>Actions</th>
        </tr>

        <?php foreach($users as $user): ?>

        <tr>
            <td>
                <?= htmlspecialchars(
                    $profileMap[$user['username']]['photo']
                    ?? ''
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    $profileMap[$user['username']]['display_name']
                    ?? $user['displayName']
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    $profileMap[$user['username']]['surname']
                    ?? ''
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    $profileMap[$user['username']]['username']
                    ?? $user['username']
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    $profileMap[$user['username']]['department']
                    ?? ''
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    $profileMap[$user['username']]['email_address']
                    ?? ''
                ) ?>
            </td>
            <td>
                <?= htmlspecialchars(
                    ($profileMap[$user['username']]['country_code'] ?? '')
                    . ' ' .
                    ($profileMap[$user['username']]['mobile_number'] ?? '')
                ) ?>
                
            </td>
            <td>
                <?= htmlspecialchars(
                    $userGroups[
                        $user['username']
                    ] ?? 'Not Assigned'
                ) ?>
            </td>

            <td>
                <?= $user['totpEnabled']
                    ? 'Enabled'
                    : 'Disabled' ?>
            </td>

            <td>

            <?php if($user['disabled']): ?>
            
                <span class="badge-disabled">
                    Disabled
                </span>
            
            <?php else: ?>
            
                <span class="badge-active">
                    Active
                </span>
            
            <?php endif; ?>
            
            </td>

            <td>
                <?= date(
                    'd M Y H:i',
                    strtotime(
                        $user['recentSessionLoggedOn']
                    )
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $user['recentSessionRemoteAddress']
                ) ?>
            </td>
            
            <td>

                <button
                    class="edit-btn"
                    onclick="openEditUserModal(
                        '<?= htmlspecialchars($user['displayName']) ?>',
                        '<?= htmlspecialchars($user['username']) ?>',
                        '<?= $user['disabled'] ? 'true' : 'false' ?>'
                    )">
            
                    Edit
            
                </button>
            
            </td>

        </tr>

        <?php endforeach; ?>

    </table>
    <div id="userModal" class="modal">

        <div class="user-modal-content">
    
            <h3>Add User</h3>
    
            <form method="post">
    
                <label>Display Name</label>
                <input 
                    type="text"
                    name="display_name" 
                    required>
                
                <label>Surname</label>
                <input
                    type="text"
                    name="surname">
                
                <label>Department</label>
                <input
                    type="text"
                     name="department">
                
                <label>Username</label>
                <input 
                    type="text" 
                    name="username" required>
                
                <label>Password</label>
                <input type="password" name="password" required>
                <label>Confirm Password</label>
                <input
                    type="password"
                    name="confirm_password"
                    required>
                
                <br><br>
                
                <label>Email Address</label>
                <input
                    type="email"
                    name="email_address">
                
                <br><br>
                
                <label>Country Code</label>
                
                <select name="country_code">
                
                    <option value="+27">+27</option>
                
                    <option value="+1">+1</option>
                
                    <option value="+44">+44</option>
                
                    <option value="+61">+61</option>
                
                </select>
                
                <br><br>
                
                <label>Mobile Number</label>
                
                <input
                    type="text"
                    name="mobile_number">
                
                <br><br>
                
                <label>User Group</label>
                <select name="group_id" required>
                
                    <?php foreach($groups as $group): ?>
                
                        <option value="<?= $group[0] ?>">
                            <?= htmlspecialchars($group[1]) ?>
                        </option>
                
                    <?php endforeach; ?>
                
                </select>
    
                <br><br>
    
                <button
                    type="submit"
                    name="create_user"
                    class="approve-btn">
    
                    Create
    
                </button>
    
                <button
                    type="button"
                    class="deny-btn"
                    onclick="closeUserModal()">
    
                    Cancel
    
                </button>
    
            </form>
    
        </div>
    
    </div>
    <div id="editUserModal" class="modal">

        <div class="user-modal-content">
    
            <h3>Edit User</h3>
    
            <form method="post">
    
                <input
                    type="hidden"
                    id="edit_username"
                    name="username">
                <input
                    type="hidden"
                    id="edit_disabled"
                    name="disabled">
    
                <label>Display Name</label>
                <input 
                    type="text" 
                    id="edit_display_name"
                    name="display_name" 
                    required>

                
                <label>Surname</label>
                <input
                    type="text"
                    id="edit_surname"
                    name="surname">
                
                <label>Department</label>
                <input
                    type="text"
                    id="edit_department"
                    name="department">
                
                <label>Username</label>
                <input 
                    type="text" 
                    id="edit_username_display"
                    readonly>
                                              
                <label>Email Address</label>
                <input
                    type="email"
                    id="edit_email_address"
                    name="email_address">
                
                <br><br>
                
                <label>Country Code</label>
                
                <select 
                    id="edit_country_code"
                    name="country_code">
                
                      <option value="+27">+27</option>
                  
                      <option value="+1">+1</option>
                  
                      <option value="+44">+44</option>
                  
                      <option value="+61">+61</option>
                
                </select>
                
                <br><br>
                
                <label>Mobile Number</label>
                
                <input
                    type="text"
                    id="edit_mobile_number"
                    name="mobile_number">
                
                <br><br>
                
                <label>User Group</label>
                <select 
                    id="edit_group_id"
                    name="group_id" 
                    required>
                
                    <?php foreach($groups as $group): ?>
                
                        <option value="<?= $group[0] ?>">
                            <?= htmlspecialchars($group[1]) ?>
                        </option>
                
                    <?php endforeach; ?>
                
                </select>
    
                <br><br>
    
                <hr>
                
                <div class="user-action-bar">
                
                    <button
                        type="submit"
                        name="update_user"
                        class="approve-btn">
                
                        Save
                
                    </button>
                
                    <button
                        type="button"
                        class="table-btn"
                        onclick="closeEditUserModal()">
                
                        Cancel
                
                    </button>
                
                    <button
                        type="button"
                        class="table-btn"
                        onclick="showPasswordReset()">
                
                        Reset Password
                
                    </button>
                
                    <button
                        type="submit"
                        name="toggle_user"
                        id="disableEnableBtn"
                        class="table-btn">
                
                        Disable User
                
                    </button>
                
                    <button
                        id="deleteUserBtn"
                        type="submit"
                        name="delete_user"
                        class="deny-btn"
                        onclick="return confirm(
                            'Are you sure you want to delete this user?'
                        );">
                
                        Delete User
                
                    </button>
                
                </div>
                
                <div
                    id="passwordResetSection"
                    style="display:none;">
                
                    <br><br>
                
                    <label>New Password</label>
                
                    <input
                        type="password"
                        id="edit_password"
                        name="password">

                
                    <br><br>
                
                    <label>Confirm Password</label>
                
                    <input
                        type="password"
                        id="edit_confirm_password"
                        name="confirm_password">

                
                    <br><br>
                
                    <button
                        type="submit"
                        name="reset_password"
                        class="table-btn">
                
                        Confirm Reset
                
                    </button>
                
                </div>
    
            </form>
    
        </div>
    
    </div>

</div>
<script>

function openUserModal() {

    document.getElementById('userModal').style.display = 'flex';

}

function closeUserModal() {

    document.getElementById('userModal').style.display = 'none';

}

function openEditUserModal(
    displayName,
    username,
    disabled
){

    document.getElementById(
        'edit_display_name'
    ).value = displayName;

    document.getElementById(
        'edit_username'
    ).value = username;

    document.getElementById(
        'edit_username_display'
    ).value = username;

    document.getElementById(
        'edit_disabled'
    ).value = disabled;
    
    fetch(
        '/api/user-profiles/' + username
    )
    .then(response => response.json())
    .then(profile => {
    
        document.getElementById(
            'edit_surname'
        ).value = profile.surname || '';
    
        document.getElementById(
            'edit_department'
        ).value = profile.department || '';
    
        document.getElementById(
            'edit_email_address'
        ).value = profile.email_address || '';
    
        document.getElementById(
            'edit_country_code'
        ).value = profile.country_code || '+27';
    
        document.getElementById(
            'edit_mobile_number'
        ).value = profile.mobile_number || '';
    
    });

    const btn =
        document.getElementById(
            'disableEnableBtn'
        );
    
    const deleteBtn =
        document.getElementById(
            'deleteUserBtn'
        );
    
    if(
        username === 'admin' ||
        username === 'api'
    ){
    
        deleteBtn.style.display = 'none';
        btn.style.display = 'none';
    
    } else {
    
        deleteBtn.style.display = 'inline-block';
        btn.style.display = 'inline-block';
    
    }

    if(disabled === 'true'){

        btn.innerText = 'Enable User';

    } else {

        btn.innerText = 'Disable User';

    }
    
    document.getElementById(
        'passwordResetSection'
    ).style.display = 'none';
    
    fetch(
        '/api/users/' +
        username +
        '/group'
    )
    .then(response => response.json())
    .then(data => {
    
        document.getElementById(
            'edit_group_id'
        ).value = data.group_id || '';
    
    });
    
        document.getElementById(
            'editUserModal'
        ).style.display = 'flex';
    
    }
    
function closeEditUserModal(){

    document.getElementById(
        'editUserModal'
    ).style.display = 'none';

}

function showPasswordReset(){

    document.getElementById(
        'passwordResetSection'
    ).style.display = 'block';
    
    document.getElementById(
        'edit_password'
    ).required = true;
    
    document.getElementById(
        'edit_confirm_password'
    ).required = true;

}

</script>
</body>
</html>