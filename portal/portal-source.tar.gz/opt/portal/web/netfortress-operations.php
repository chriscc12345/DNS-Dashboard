<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Operations')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-operations';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Operations</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;white-space:nowrap}
        .nf-ok{background:var(--theme-basic-success,#237a4b);color:#fff}
        .nf-warn{background:var(--theme-basic-warning,#c79a00);color:#111827}
        .nf-off{background:var(--theme-basic-button-secondary,#24313a);color:#fff}
        .nf-panel{margin-top:18px;padding:16px;border:1px solid var(--theme-basic-card-border,#637681);border-radius:8px;background:var(--theme-basic-card-background,#18232a);color:var(--theme-basic-card-text,#fff)}
        .nf-panel h3{margin:0 0 6px 0}
        .nf-panel p{margin:0 0 12px 0;font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3)}
        .nf-btnrow{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
        .nf-stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}
        .nf-stat{padding:12px;border:1px solid var(--theme-basic-card-border,#637681);border-radius:8px;background:var(--theme-basic-card-background-alt,#202c34)}
        .nf-stat-label{font-size:12px;color:var(--theme-basic-text-secondary,#aebbc3)}
        .nf-stat-value{font-size:20px;font-weight:600;margin-top:4px}
        .nf-input{width:200px;padding:6px 10px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:4px;background:var(--theme-basic-input-background,#202c34);color:var(--theme-basic-input-text,#fff);font-size:13px}
        .nf-input-wide{width:420px}
        .nf-btnrow{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
        .nf-form-grid{display:grid;grid-template-columns:220px 1fr;gap:10px 12px;align-items:start;font-size:14px}
        #nfMsg{margin-top:10px;font-size:13px;display:none}
        #nfMsg.ok{color:var(--theme-basic-success,#237a4b);display:block}
        #nfMsg.err{color:var(--theme-basic-error,#b83b3b);display:block}
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Operations - appliance health, services and backup.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel">

        <div class="nf-btnrow" style="justify-content:space-between">
            <h3 style="margin:0">Appliance overview</h3>
            <button type="button" class="table-btn" id="nfRefresh">Refresh</button>
        </div>

        <div class="nf-stat-grid" id="nfStats">
            <div class="nf-stat"><div class="nf-stat-label">Loading appliance status...</div></div>
        </div>

        <div id="nfMsg"></div>

    </div>

    <div class="appearance-panel um-table-panel">

        <h3 style="margin-top:0">Appliance services</h3>

        <table id="nfTable">
            <thead>
            <tr>
                <th>Service</th>
                <th>Installed</th>
            </tr>
            </thead>
            <tbody id="nfBody">
            <tr>
                <td colspan="2">Loading services...</td>
            </tr>
            </tbody>
        </table>

    </div>

    <div class="nf-panel">
        <h3>License</h3>
        <div id="nfLicense" style="font-size:14px"></div>
        <details id="nfLicenseFeatures" style="margin-top:10px;font-size:13px">
            <summary style="cursor:pointer">Licensed features</summary>
            <div id="nfLicenseFeatureList" style="margin-top:8px"></div>
        </details>
    </div>

    <div class="nf-panel">
        <h3>Admin page port</h3>
        <p id="nfAdminPortInfo">
            The TCP port the appliance admin dashboard answers on.
        </p>
        <div class="nf-btnrow">
            <input type="number" class="nf-input" id="nfAdminPort" min="1" max="65535" placeholder="port">
            <button type="button" class="approve-btn" id="nfAdminPortSave">Change port</button>
        </div>
        <p style="font-size:12px;color:var(--theme-basic-text-secondary,#aebbc3)">
            Reserved (cannot be used): <span id="nfReservedPorts"></span>
        </p>
    </div>

    <div class="nf-panel">
        <h3>Fleet updates</h3>
        <p id="nfUpdateModeInfo">
            Whether this appliance applies new builds automatically or waits
            for an administrator.
        </p>
        <div class="nf-btnrow">
            <button type="button" class="approve-btn" id="nfUpdateAuto">Automatic</button>
            <button type="button" class="deny-btn" id="nfUpdateManual">Manual</button>
        </div>
        <p style="font-size:12px;color:var(--theme-basic-text-secondary,#aebbc3)">
            Automatic: new builds are applied on the 15-minute check. Manual:
            the appliance console Operations page shows a banner and you
            stage and apply the update yourself.
        </p>
    </div>

    <div class="nf-panel">
        <div class="nf-btnrow" style="justify-content:space-between">
            <div>
                <h3 style="margin:0">Public TLS certificate</h3>
                <p style="margin:4px 0 0 0;font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3)">
                    Real Let's Encrypt certificates via Cloudflare DNS-01 —
                    padlocked HTTPS for the dashboard and block page with no
                    client-side installs.
                </p>
            </div>
            <span class="nf-badge nf-off" id="nfAcmeState">not issued</span>
        </div>
        <div class="nf-form-grid" style="max-width:680px;margin-top:14px">
            <label for="nfAcmeEnabled">Enable public certificates</label>
            <input type="checkbox" id="nfAcmeEnabled">

            <label for="nfAcmeEmail">Contact e-mail</label>
            <input type="email" class="nf-input nf-input-wide" id="nfAcmeEmail" placeholder="admin@example.com" required>

            <label for="nfAcmeZone">Cloudflare zone</label>
            <input type="text" class="nf-input nf-input-wide" id="nfAcmeZone" placeholder="example.com" required>

            <label for="nfAcmeFqdn">Appliance hostname</label>
            <input type="text" class="nf-input nf-input-wide" id="nfAcmeFqdn" placeholder="firewall.example.com" required>

            <label for="nfAcmeBlockFqdn">Block page hostname</label>
            <input type="text" class="nf-input nf-input-wide" id="nfAcmeBlockFqdn" placeholder="blocked.example.com" required>

            <label for="nfAcmeToken">
                Cloudflare API token
                <small>
                    Create it in Cloudflare under My Profile → API Tokens.
                    Stored once — leave blank to keep the saved token.
                </small>
            </label>
            <input type="password" class="nf-input nf-input-wide" id="nfAcmeToken" placeholder="Zone / DNS / Edit permission">
        </div>
        <div class="nf-btnrow" style="margin-top:12px">
            <button type="button" class="approve-btn" id="nfAcmeSave">Save settings</button>
            <button type="button" class="table-btn" id="nfAcmeRequest">Request / renew certificate</button>
        </div>
        <div id="nfAcmeMessage" style="font-size:13px"></div>
    </div>

    <div class="nf-panel">
        <h3>Documents</h3>
        <p>
            Downloadable manuals from the appliance.
        </p>
        <div class="nf-btnrow">
            <a href="netfortress-api.php?action=docs&file=firewall-appliance-dashboard-manual.pdf" class="table-btn" style="text-decoration:none">Dashboard manual (PDF)</a>
            <a href="netfortress-api.php?action=docs&file=firewall-appliance-api-integration-reference.pdf" class="table-btn" style="text-decoration:none">API integration reference (PDF)</a>
        </div>
    </div>

    <div class="nf-panel">
        <h3>Backup</h3>
        <p>
            Download a backup archive of the appliance configuration
            (secrets are not included).
        </p>
        <div class="nf-btnrow">
            <a href="netfortress-api.php?action=backup" class="table-btn"
               style="text-decoration:none">Download backup</a>
        </div>
    </div>

</div>

<script>
(function () {

    const stats = document.getElementById('nfStats');
    const body = document.getElementById('nfBody');
    const message = document.getElementById('nfMsg');

    let lastOperationsSignature = null;

    function esc(v) {
        return String(v ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');
    }

    function formatBytes(value) {

        const bytes = Number(value) || 0;

        if (bytes <= 0) { return '0'; }

        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        let index = 0;
        let size = bytes;

        while (size >= 1024 && index < units.length - 1) {
            size /= 1024;
            index += 1;
        }

        return size.toFixed(index ? 1 : 0) + ' ' + units[index];

    }

    function formatUptime(seconds) {

        seconds = Number(seconds) || 0;

        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);

        const parts = [];
        if (days) { parts.push(days + 'd'); }
        if (hours) { parts.push(hours + 'h'); }
        parts.push(minutes + 'm');

        return parts.join(' ');

    }

    function stat(label, value) {
        return '<div class="nf-stat"><div class="nf-stat-label">' + esc(label) +
            '</div><div class="nf-stat-value">' + value + '</div></div>';
    }

    function load() {

        fetch('netfortress-api.php?action=operations')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    stats.innerHTML = '<div class="nf-stat"><div class="nf-stat-label">' +
                        esc(data.message || 'The appliance is not reachable.') +
                        '</div></div>';
                    body.innerHTML = '<tr><td colspan="2"></td></tr>';
                    return;
                }

                const overview = data.overview || {};
                const memory = overview.memory || {};

                /* Uptime and load change on every poll - re-rendering the
                   whole grid each time causes a visible flash. Render the
                   grid only when the stable fields change, and update the
                   volatile cards in place. */

                const stable = JSON.stringify([overview.hostname, overview.kernel, overview.cpu_cores, memory, data.services]);

                const uptimeText = esc(formatUptime(overview.uptime_seconds));
                const loadText = esc((overview.load_average || []).join(' ') || '-');

                const uptimeCard = document.getElementById('nfStatUptime');
                const loadCard = document.getElementById('nfStatLoad');

                if (stable === lastOperationsSignature && uptimeCard && loadCard) {
                    uptimeCard.textContent = uptimeText;
                    loadCard.textContent = loadText;
                    return;
                }

                lastOperationsSignature = stable;

                stats.innerHTML =
                    stat('Hostname', esc(overview.hostname || '-')) +
                    stat('Kernel', esc(overview.kernel || '-')) +
                    '<div class="nf-stat"><div class="nf-stat-label">Uptime</div><div class="nf-stat-value" id="nfStatUptime">' + uptimeText + '</div></div>' +
                    stat('CPU cores', esc(overview.cpu_cores ?? '-')) +
                    '<div class="nf-stat"><div class="nf-stat-label">Load average</div><div class="nf-stat-value" id="nfStatLoad">' + loadText + '</div></div>' +
                    stat('Memory used',
                        esc(memory.used_percent ?? '-') + '%' +
                        ' <small style="color:var(--theme-basic-text-secondary,#aebbc3)">of ' +
                        esc(formatBytes(memory.total_bytes)) + '</small>');

                body.innerHTML = '';

                const services = data.services || [];

                if (services.length === 0) {
                    body.innerHTML = '<tr><td colspan="2">No service information.</td></tr>';
                } else {
                    services.forEach(function (service) {
                        const tr = document.createElement('tr');
                        tr.innerHTML =
                            '<td><strong>' + esc(service.name) + '</strong></td>' +
                            '<td>' + (service.installed
                                ? '<span class="nf-badge nf-ok">installed</span>'
                                : '<span class="nf-badge nf-off">not installed</span>') + '</td>';
                        body.appendChild(tr);
                    });
                }

            })
            .catch(function () {
                stats.innerHTML = '<div class="nf-stat"><div class="nf-stat-label">' +
                    'The appliance API is not reachable.</div></div>';
            });

    }

    /* ---- license ---- */

    function loadLicense() {

        fetch('netfortress-api.php?action=license')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                const box = document.getElementById('nfLicense');
                const list = document.getElementById('nfLicenseFeatureList');

                if (!data.success) {
                    box.textContent = data.message || 'License information is not available.';
                    return;
                }

                const license = data.license || {};

                const expiry = license.expires_at
                    ? new Date(license.expires_at).toLocaleDateString()
                    : 'perpetual';

                box.innerHTML =
                    badge(license.state || 'unknown',
                        license.state === 'active' ? 'nf-ok' : 'nf-warn') +
                    ' <strong>' + esc(license.edition_label || license.edition || '-') + '</strong>' +
                    (license.license_type ? ' (' + esc(license.license_type) + ')' : '') +
                    ' - expires ' + esc(expiry) +
                    '<br>Devices: <strong>' + esc(license.device_count ?? '-') + '</strong>' +
                    ' of ' + esc(license.device_limit > 0 ? license.device_limit : 'unlimited') +
                    ' - Accounts: <strong>' + esc(license.account_count ?? '-') + '</strong>' +
                    ' of ' + esc(license.account_limit > 0 ? license.account_limit : 'unlimited') +
                    (license.grace_until
                        ? '<br>Grace period until ' + esc(new Date(license.grace_until).toLocaleDateString())
                        : '') +
                    '<br><small style="color:var(--theme-basic-text-secondary,#aebbc3)">Installation ' +
                    esc(license.installation_id || '-') + '</small>';

                const features = license.features || [];
                const restricted = license.restricted_features || [];

                list.innerHTML =
                    features.map(function (feature) {
                        return badge(feature, 'nf-ok');
                    }).join(' ') +
                    (restricted.length
                        ? '<br><br>Not in this edition: ' +
                          restricted.map(function (feature) {
                              return badge(feature, 'nf-off');
                          }).join(' ')
                        : '');

            })
            .catch(function () {
                document.getElementById('nfLicense').textContent =
                    'The appliance API is not reachable.';
            });

    }

    /* ---- admin port ---- */

    function loadAdminPort() {

        fetch('netfortress-api.php?action=admin-port')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    document.getElementById('nfAdminPortInfo').textContent =
                        data.message || 'Admin port information is not available.';
                    return;
                }

                document.getElementById('nfAdminPortInfo').innerHTML =
                    'The appliance admin dashboard answers on port <strong>' +
                    esc(data.port) + '</strong>.';

                document.getElementById('nfReservedPorts').textContent =
                    (data.reserved || []).join(', ');

            })
            .catch(function () {
                document.getElementById('nfAdminPortInfo').textContent =
                    'The appliance API is not reachable.';
            });

    }

    document.getElementById('nfAdminPortSave').addEventListener('click', function () {

        const port = parseInt(document.getElementById('nfAdminPort').value, 10);

        if (!port) {
            msg('Enter a port number.', false);
            return;
        }

        post('admin-port-set', { port: port }, 'Changing admin port');

    });

    /* ---- ACME TLS ---- */

    function loadAcme() {

        fetch('netfortress-api.php?action=acme')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                const state = document.getElementById('nfAcmeState');

                if (!data.success) {
                    state.textContent = data.message || 'not available';
                    state.className = 'nf-badge nf-warn';
                    return;
                }

                const acme = data.acme || {};

                document.getElementById('nfAcmeEnabled').checked = !!acme.enabled;
                document.getElementById('nfAcmeEmail').value = acme.email || '';
                document.getElementById('nfAcmeZone').value = acme.zone || '';
                document.getElementById('nfAcmeFqdn').value = acme.appliance_fqdn || '';
                document.getElementById('nfAcmeBlockFqdn').value = acme.block_fqdn || '';
                document.getElementById('nfAcmeToken').value = '';
                document.getElementById('nfAcmeToken').placeholder =
                    acme.api_token === 'set'
                        ? 'stored — leave blank to keep'
                        : 'Zone / DNS / Edit permission';

                if (acme.issued) {
                    state.textContent = acme.expires_at
                        ? 'issued — expires ' + new Date(acme.expires_at).toLocaleDateString()
                        : 'issued';
                    state.className = 'nf-badge nf-ok';
                } else {
                    state.textContent = 'not issued';
                    state.className = 'nf-badge nf-off';
                }

            })
            .catch(function () {
                const state = document.getElementById('nfAcmeState');
                state.textContent = 'unreachable';
                state.className = 'nf-badge nf-warn';
            });

    }

    document.getElementById('nfAcmeSave').addEventListener('click', function () {

        post('acme-set', {
            enabled: document.getElementById('nfAcmeEnabled').checked,
            email: document.getElementById('nfAcmeEmail').value.trim(),
            zone: document.getElementById('nfAcmeZone').value.trim(),
            appliance_fqdn: document.getElementById('nfAcmeFqdn').value.trim(),
            block_fqdn: document.getElementById('nfAcmeBlockFqdn').value.trim(),
            api_token: document.getElementById('nfAcmeToken').value.trim()
        }, 'Saving settings').then(function (data) {
            if (data && data.success) {
                document.getElementById('nfAcmeMessage').textContent =
                    'Settings saved. Request the certificate when ready.';
                loadAcme();
            }
        });

    });

    document.getElementById('nfAcmeRequest').addEventListener('click', function () {

        const box = document.getElementById('nfAcmeMessage');
        box.textContent = 'Requesting the certificate from Let\u2019s Encrypt via Cloudflare DNS — this can take about a minute…';

        post('acme-request', {}, 'Requesting certificate').then(function (data) {

            if (data && data.success) {
                const names = (data.result && data.result.names) || [];
                box.textContent = names.length
                    ? 'Certificate issued for ' + names.join(', ') + '.'
                    : 'Certificate issued.';
                loadAcme();
            } else if (data) {
                box.textContent = data.message ||
                    'The appliance rejected the request.';
            }

        });

    });

    /* ---- fleet update mode ---- */

    function renderUpdateMode(mode) {

        const auto = document.getElementById('nfUpdateAuto');
        const manual = document.getElementById('nfUpdateManual');

        const isAuto = mode !== 'manual';

        auto.style.opacity = isAuto ? '1' : '0.5';
        manual.style.opacity = isAuto ? '0.5' : '1';

        document.getElementById('nfUpdateModeInfo').innerHTML =
            isAuto
                ? 'This appliance applies new builds <strong>automatically</strong> ' +
                  'on its 15-minute check.'
                : 'Updates are <strong>manual</strong>: the banner on the appliance ' +
                  'console Operations page shows when a new build is published.';

    }

    function loadUpdateMode() {

        fetch('netfortress-api.php?action=update-mode')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    document.getElementById('nfUpdateModeInfo').textContent =
                        data.message || 'The update mode is not available.';
                    return;
                }

                renderUpdateMode(data.mode);

            })
            .catch(function () {
                document.getElementById('nfUpdateModeInfo').textContent =
                    'The appliance API is not reachable.';
            });

    }

    document.getElementById('nfUpdateAuto').addEventListener('click', function () {
        post('update-mode-set', { mode: 'auto' }, 'Switching to automatic updates');
        loadUpdateMode();
    });

    document.getElementById('nfUpdateManual').addEventListener('click', function () {
        post('update-mode-set', { mode: 'manual' }, 'Switching to manual updates');
        loadUpdateMode();
    });

    document.getElementById('nfRefresh').addEventListener('click', function () {
        load();
        loadLicense();
        loadAdminPort();
        loadAcme();
        loadUpdateMode();
    });

    load();
    loadLicense();
    loadAdminPort();
    loadAcme();
    loadUpdateMode();
    setInterval(load, 30000);

})();
</script>

</body>

</html>
