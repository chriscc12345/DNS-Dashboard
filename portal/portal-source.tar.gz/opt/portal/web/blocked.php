<?php
$enrollLink = '';
$applianceHealth = @file_get_contents('http://127.0.0.1:8080/api/v1/health', false, stream_context_create(array('http' => array('timeout' => 2))));
if ($applianceHealth !== false && strpos($applianceHealth, '"status":"ok"') !== false) {
    $enrollLink = '<a href="/enroll" style="display:block;margin:16px 0 0;font-size:14px;text-decoration:underline;opacity:.9">Install the network certificate</a><p style="margin:6px 0 0;font-size:12px;opacity:.6">so this page also displays correctly on secure (https) sites</p>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <title>Access Denied | Network Security</title>
    <style>
        :root {
            --bg-color: #050810;
            --card-bg: rgba(10, 14, 24, 0.92);
            --text-main: #f3f4f6;
            --text-muted: #64748b;
            --accent-blue: #3b82f6;
            --grid-bg: rgba(255, 255, 255, 0.02);
            --border-color: rgba(255, 255, 255, 0.08);
            --btn-bg: linear-gradient(180deg, #2563eb 0%, #1d4ed8 100%);
        }

        body {
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-main);
            padding: 24px;
            text-align: center;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 94vh;
            overflow: hidden;
            position: relative;
        }

        #blockBackgroundAnimation {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            pointer-events: none;
        }

        @keyframes gatewayEntrance {
            0% { opacity: 0; transform: translateY(20px) scale(0.99); }
            100% { opacity: 1; transform: translateY(0) scale(1); }
        }

        .container {
            max-width: 500px;
            width: 100%;
            background: var(--card-bg);
            backdrop-filter: blur(28px);
            -webkit-backdrop-filter: blur(28px);
            border-radius: 16px;
            padding: 44px 40px;
            box-shadow: 0 40px 80px -15px rgba(0, 0, 0, 0.95);
            border: 1px solid var(--border-color);
            position: relative;
            z-index: 5;
            animation: gatewayEntrance 0.5s cubic-bezier(0.25, 1, 0.5, 1) forwards;
        }

        .status-accent-bar {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: var(--accent-blue);
            box-shadow: 0 2px 12px rgba(59, 130, 246, 0.35);
            border-top-left-radius: 16px;
            border-top-right-radius: 16px;
        }

        .header-visual {
            width: 100%;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 24px;
        }

        .icon-security-svg {
            width: 44px;
            height: 44px;
            fill: #60a5fa;
            filter: drop-shadow(0 0 10px rgba(59, 130, 246, 0.35));
        }

        h1 {
            font-size: 22px;
            font-weight: 600;
            margin-top: 0;
            margin-bottom: 12px;
            letter-spacing: -0.02em;
            color: #ffffff;
        }

        p {
            color: #94a3b8;
            font-size: 13.5px;
            line-height: 1.6;
            margin-bottom: 36px;
            padding: 0 12px;
        }

        .info-grid {
            text-align: left;
            background: var(--grid-bg);
            padding: 20px 24px;
            border-radius: 10px;
            font-family: 'SFMono-Regular', Menlo, Monaco, Consolas, monospace;
            font-size: 13px;
            border: 1px solid rgba(255, 255, 255, 0.04);
            margin-bottom: 32px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            padding-bottom: 12px;
        }

        .info-row:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .label {
            font-weight: 500;
            color: var(--text-muted);
            width: 140px;
            flex-shrink: 0;
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.05em;
        }

        .value {
            color: #cbd5e1;
            word-break: break-all;
            text-align: right;
            flex-grow: 1;
            font-weight: 500;
        }

        .whitelist-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: var(--btn-bg);
            color: #ffffff;
            text-decoration: none;
            padding: 14px 24px;
            border-radius: 8px;
            font-size: 13.5px;
            font-weight: 500;
            letter-spacing: -0.01em;
            transition: all 0.2s ease-out;
            width: 100%;
            box-sizing: border-box;
            border: 1px solid rgba(0, 0, 0, 0.4);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.15), 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .whitelist-btn:hover {
            transform: translateY(-1px);
            filter: brightness(1.1);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 6px 16px rgba(37, 99, 235, 0.25);
        }
    </style>
</head>
<body>

<canvas id="blockBackgroundAnimation"></canvas>

<div class="container">
    <div class="status-accent-bar"></div>

    <div class="header-visual">
        <svg class="icon-security-svg" viewBox="0 0 24 24">
            <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
        </svg>
    </div>

    <h1>Access Restricted by Network Policy</h1>
    <p>The host connection request was dropped in compliance with local threat intelligence lists.</p>

    <div class="info-grid">
        <div class="info-row"><span class="label">Local IP</span><span class="value" id="client-ip"><!--#echo var="REMOTE_ADDR" --></span></div>
        <div class="info-row"><span class="label">Dst Domain</span><span class="value" id="blocked-domain">Unknown</span></div>
        <div class="info-row"><span class="label">Policy Map</span><span class="value">Block List Zone</span></div>
    </div>

    <a href="#" id="whitelist-link" class="whitelist-btn">Request Access</a>
    <?php echo $enrollLink; ?>
</div>

<script src="js/portal-animation.js"></script>
<script>
(function () {
    const canvas = document.getElementById('blockBackgroundAnimation');
    if (!canvas || !window.PortalAnimation) {
        return;
    }
    window.blockPortalAnimation = new window.PortalAnimation({
        canvas: canvas,
        container: document.body,
        enabled: true,
        style: 'cyber',
        intensity: 'low'
    });
})();
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // 1. Context Information Loading
    // The DNS backend redirects blocked sites here with ?host=<blocked
    // site>; the browser hostname alone would just be the portal's.
    const requestParams = new URLSearchParams(window.location.search);
    const currentHost = requestParams.get("host") || window.location.hostname || "Unknown Host";
    document.getElementById('blocked-domain').innerText = currentHost;

    const whitelistLink = document.getElementById('whitelist-link');

    setInterval(() => {

        fetch(`/api/status/${currentHost}`)
            .then(response => response.json())
            .then(data => {

                if (data.status === "Pending") {

                    whitelistLink.style.background =
                        'linear-gradient(180deg, #f59e0b 0%, #d97706 100%)';

                    whitelistLink.style.borderColor = '#b45309';

                    whitelistLink.innerText =
                        'Requested - Pending Approval';

                    whitelistLink.style.pointerEvents = 'none';
                }
                if (data.status === "Approved") {

                    whitelistLink.style.background =
                        'linear-gradient(180deg, #22c55e 0%, #15803d 100%)';

                    whitelistLink.innerText =
                        'Request Approved - Redirecting...';

                    whitelistLink.style.pointerEvents = 'none';

                    setTimeout(() => {
                        window.location.href =
                            "https://" + currentHost;
                    }, 2000);
                }

                if (data.status === "Denied") {

                    whitelistLink.style.background =
                        'linear-gradient(180deg, #ef4444 0%, #991b1b 100%)';

                    whitelistLink.innerText =
                        'Request Denied';

                    whitelistLink.style.pointerEvents = 'none';
                }

            })
            .catch(err => console.error(err));

    }, 5000);

	whitelistLink.addEventListener('click', function(e) {
		e.preventDefault();

		whitelistLink.innerText = 'Processing...';
		whitelistLink.style.pointerEvents = 'none';

    fetch("/api/request", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            domain: currentHost,
            client_ip: document.getElementById('client-ip').innerText.trim(),
            reason: "Block List Zone"
        })
    })
		.then(response => {
			if (!response.ok) {
				throw new Error('Server returned error status: ' + response.status);
			}
			return response.json();
		})
    .then(data => {

        if (data.success === false) {

            whitelistLink.style.background =
                'linear-gradient(180deg, #f59e0b 0%, #d97706 100%)';

            whitelistLink.innerText =
                'Request Already Pending Approval';

            whitelistLink.style.pointerEvents = 'none';

            return;
        }

        whitelistLink.style.background =
            'linear-gradient(180deg, #22c55e 0%, #15803d 100%)';

        whitelistLink.innerText =
            'Request Submitted - Awaiting Approval';

        whitelistLink.style.pointerEvents = 'none';
    })

		.catch(err => {
			console.error(err);

			whitelistLink.innerText = 'Request Access';
			whitelistLink.style.pointerEvents = 'auto';

			alert('Could not submit request. Please contact your network administrator.');
		});
	});
});
</script>

</body>
</html>
