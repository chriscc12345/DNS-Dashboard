<?php

require_once 'auth.php';
require_once 'config.php';

header('Content-Type: application/json');


function bannerResponse(
    bool $success,
    string $message,
    array $extra = []
): void {

    echo json_encode(
        array_merge(
            [
                'success' => $success,
                'message' => $message
            ],
            $extra
        )
    );

    exit;
}


if (!hasPermission('Banner')) {

    http_response_code(403);

    bannerResponse(
        false,
        'You do not have permission to manage the banner.'
    );
}


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    bannerResponse(
        false,
        'POST required.'
    );
}


$action =
    trim(
        (string)(
            $_POST['action']
            ?? ''
        )
    );


$uploadDirectory =
    '/opt/portal/web/uploads/appearance';

$relativeDirectory =
    'uploads/appearance';

$defaultBanner =
    'images/banner.jpg';


function getCurrentBannerImage(
    string $fastApiUrl,
    string $defaultBanner
): string {

    $settings =
        @file_get_contents(
            $fastApiUrl . '/portal-settings'
        );

    if ($settings === false) {
        return $defaultBanner;
    }

    $decoded =
        json_decode(
            $settings,
            true
        );

    if (!is_array($decoded)) {
        return $defaultBanner;
    }

    $value =
        trim(
            (string)(
                $decoded['banner_image']
                ?? $defaultBanner
            )
        );

    return
        $value !== ''
            ? $value
            : $defaultBanner;
}


function saveBannerSetting(
    string $fastApiUrl,
    string $bannerPath,
    bool $resetFraming = false
): bool {

    $settings = [
        'banner_image' => $bannerPath
    ];

    if ($resetFraming) {

        $settings['banner_fit_mode'] =
            'fit';

        $settings['banner_position_x'] =
            '50';

        $settings['banner_position_y'] =
            '50';

        $settings['banner_zoom'] =
            '60';
    }

    $payload =
        json_encode(
            [
                'settings' => $settings
            ]
        );

    $context =
        stream_context_create(
            [
                'http' => [
                    'method' => 'POST',
                    'header' =>
                        "Content-Type: application/json\r\n",
                    'content' => $payload,
                    'ignore_errors' => true,
                    'timeout' => 10
                ]
            ]
        );

    $response =
        @file_get_contents(
            $fastApiUrl . '/portal-settings/appearance',
            false,
            $context
        );

    if ($response === false) {
        return false;
    }

    $decoded =
        json_decode(
            $response,
            true
        );

    return
        is_array($decoded)
        && (
            ($decoded['success'] ?? false) === true
            || ($decoded['settings']['banner_image'] ?? null)
                === $bannerPath
        );
}


function deleteManagedBanner(
    string $relativePath,
    string $uploadDirectory
): void {

    if (
        !preg_match(
            '#^uploads/appearance/banner_[a-f0-9]{32}\.(?:webp|webm)$#',
            $relativePath
        )
    ) {
        return;
    }

    $filename =
        basename(
            $relativePath
        );

    $absolutePath =
        $uploadDirectory
        . '/'
        . $filename;

    if (is_file($absolutePath)) {
        @unlink($absolutePath);
    }
}


/*
 * Restore the immutable Basic factory banner.
 */

if ($action === 'restore') {

    $oldBanner =
        getCurrentBannerImage(
            $FASTAPI_URL,
            $defaultBanner
        );

    if (
        !saveBannerSetting(
            $FASTAPI_URL,
            $defaultBanner
        )
    ) {

        http_response_code(502);

        bannerResponse(
            false,
            'Unable to restore the default banner setting.'
        );
    }

    if ($oldBanner !== $defaultBanner) {

        deleteManagedBanner(
            $oldBanner,
            $uploadDirectory
        );
    }

    bannerResponse(
        true,
        'Default banner restored.',
        [
            'banner_image' => $defaultBanner
        ]
    );
}


if ($action !== 'upload') {

    http_response_code(400);

    bannerResponse(
        false,
        'Invalid action.'
    );
}


if (
    !isset($_FILES['banner'])
    || !is_array($_FILES['banner'])
) {

    http_response_code(400);

    bannerResponse(
        false,
        'No banner file was supplied.'
    );
}


$file =
    $_FILES['banner'];


if (
    ($file['error'] ?? UPLOAD_ERR_NO_FILE)
    !== UPLOAD_ERR_OK
) {

    http_response_code(400);

    bannerResponse(
        false,
        'Banner upload failed.'
    );
}


$fileSize =
    (int)(
        $file['size']
        ?? 0
    );


$tempFile =
    (string)(
        $file['tmp_name']
        ?? ''
    );


if (
    $tempFile === ''
    || !is_uploaded_file($tempFile)
) {

    http_response_code(400);

    bannerResponse(
        false,
        'Invalid uploaded file.'
    );
}


$finfo =
    new finfo(
        FILEINFO_MIME_TYPE
    );

$mimeType =
    $finfo->file(
        $tempFile
    );


$allowedImageMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/webp'
];

$isWebm =
    $mimeType === 'video/webm';

$isImage =
    in_array(
        $mimeType,
        $allowedImageMimeTypes,
        true
    );


if (
    !$isImage
    && !$isWebm
) {

    http_response_code(400);

    bannerResponse(
        false,
        'Only JPG, PNG, WebP and WebM banners are allowed.'
    );
}


$maximumFileSize =
    $isWebm
        ? (20 * 1024 * 1024)
        : (5 * 1024 * 1024);

if (
    $fileSize <= 0
    || $fileSize > $maximumFileSize
) {

    http_response_code(400);

    bannerResponse(
        false,
        $isWebm
            ? 'WebM banner must be 20 MB or smaller.'
            : 'Image banner must be 5 MB or smaller.'
    );
}


/*
 * WebM banners are validated by MIME type and retained
 * as WebM. No FFmpeg/transcoding dependency is required.
 */
if ($isWebm) {

    $filename =
        'banner_'
        . bin2hex(
            random_bytes(16)
        )
        . '.webm';

    $absolutePath =
        $uploadDirectory
        . '/'
        . $filename;

    $relativePath =
        $relativeDirectory
        . '/'
        . $filename;


    if (
        !move_uploaded_file(
            $tempFile,
            $absolutePath
        )
        || !is_file($absolutePath)
    ) {

        http_response_code(500);

        bannerResponse(
            false,
            'Unable to save the WebM banner.'
        );
    }


    @chmod(
        $absolutePath,
        0644
    );


    $oldBanner =
        getCurrentBannerImage(
            $FASTAPI_URL,
            $defaultBanner
        );


    if (
        !saveBannerSetting(
            $FASTAPI_URL,
            $relativePath,
            true
        )
    ) {

        @unlink(
            $absolutePath
        );

        http_response_code(502);

        bannerResponse(
            false,
            'Unable to save the banner setting.'
        );
    }


    if (
        $oldBanner !== $defaultBanner
        && $oldBanner !== $relativePath
    ) {

        deleteManagedBanner(
            $oldBanner,
            $uploadDirectory
        );
    }


    bannerResponse(
        true,
        'Animated WebM banner uploaded.',
        [
            'banner_image' => $relativePath,
            'banner_type' => 'video'
        ]
    );
}


/*
 * Static image banners continue through the existing
 * GD resize/WebP conversion pipeline below.
 */

switch ($mimeType) {

    case 'image/jpeg':

        $source =
            @imagecreatefromjpeg(
                $tempFile
            );

        break;


    case 'image/png':

        $source =
            @imagecreatefrompng(
                $tempFile
            );

        break;


    case 'image/webp':

        $source =
            @imagecreatefromwebp(
                $tempFile
            );

        break;


    default:

        $source = false;
}


if ($source === false) {

    http_response_code(400);

    bannerResponse(
        false,
        'The uploaded image could not be processed.'
    );
}


$sourceWidth =
    imagesx(
        $source
    );

$sourceHeight =
    imagesy(
        $source
    );


if (
    $sourceWidth < 1
    || $sourceHeight < 1
) {

    imagedestroy(
        $source
    );

    http_response_code(400);

    bannerResponse(
        false,
        'Invalid image dimensions.'
    );
}


/*
 * Banner sources may be large.
 *
 * Preserve aspect ratio while limiting unnecessary source
 * dimensions. The Basic theme itself remains responsible
 * for cropping the image with object-fit: cover.
 */

$maximumWidth = 3840;
$maximumHeight = 2160;

$scale =
    min(
        1,
        $maximumWidth / $sourceWidth,
        $maximumHeight / $sourceHeight
    );

$targetWidth =
    max(
        1,
        (int)round(
            $sourceWidth * $scale
        )
    );

$targetHeight =
    max(
        1,
        (int)round(
            $sourceHeight * $scale
        )
    );


$destination =
    imagecreatetruecolor(
        $targetWidth,
        $targetHeight
    );


imagealphablending(
    $destination,
    false
);

imagesavealpha(
    $destination,
    true
);

$transparent =
    imagecolorallocatealpha(
        $destination,
        0,
        0,
        0,
        127
    );

imagefilledrectangle(
    $destination,
    0,
    0,
    $targetWidth,
    $targetHeight,
    $transparent
);


imagecopyresampled(
    $destination,
    $source,
    0,
    0,
    0,
    0,
    $targetWidth,
    $targetHeight,
    $sourceWidth,
    $sourceHeight
);


$filename =
    'banner_'
    . bin2hex(
        random_bytes(16)
    )
    . '.webp';

$absolutePath =
    $uploadDirectory
    . '/'
    . $filename;

$relativePath =
    $relativeDirectory
    . '/'
    . $filename;


$written =
    imagewebp(
        $destination,
        $absolutePath,
        88
    );


imagedestroy(
    $source
);

imagedestroy(
    $destination
);


if (
    !$written
    || !is_file($absolutePath)
) {

    http_response_code(500);

    bannerResponse(
        false,
        'Unable to save the processed banner.'
    );
}


@chmod(
    $absolutePath,
    0644
);


$oldBanner =
    getCurrentBannerImage(
        $FASTAPI_URL,
        $defaultBanner
    );


if (
    !saveBannerSetting(
        $FASTAPI_URL,
        $relativePath,
        true
    )
) {

    @unlink(
        $absolutePath
    );

    http_response_code(502);

    bannerResponse(
        false,
        'Unable to save the banner setting.'
    );
}


if (
    $oldBanner !== $defaultBanner
    && $oldBanner !== $relativePath
) {

    deleteManagedBanner(
        $oldBanner,
        $uploadDirectory
    );
}


bannerResponse(
    true,
    'Banner uploaded.',
    [
        'banner_image' => $relativePath
    ]
);
