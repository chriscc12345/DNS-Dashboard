<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// section tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';

if (
    !hasPermission(
        'Email Notifications'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'monitor-email';
$pageHeading = 'Communications';
$showSidebarPageHeading = true;

/*
 * The channel rules UI (Add New button,
 * rules table and the Add User styled
 * cascade popup).
 */

$monitorChannelName = 'Email';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Monitor Alerts - Email</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Monitor Alerts</h1>

            <p>
                Manage Email.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel">

        <?php include __DIR__
            . '/includes/monitor-channel-rules.php'; ?>

    </div>

</div>

</body>

</html>
