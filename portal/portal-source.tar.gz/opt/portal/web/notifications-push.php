<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (
    !hasPermission(
        'Push Notifications'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'notifications-push';
$pageHeading = 'Communications';
$showSidebarPageHeading = true;

$portalSettings =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];

function savePortalSettings($settings) {

    global $FASTAPI_URL;

    $payload =
        json_encode(
            ['settings' => $settings]
        );

    return file_get_contents(
        $FASTAPI_URL . '/portal-settings/appearance',
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $payload
            ]
        ])
    );
}

if (isset($_POST['save_notifications'])) {

    savePortalSettings([
        'notify_push_subject' =>
            trim((string)$_POST['notify_push_subject']),
        'notify_push_public_key' =>
            trim((string)$_POST['notify_push_public_key']),
        'notify_push_private_key' =>
            (string)$_POST['notify_push_private_key']
    ]);

    header('Location: notifications-push.php?saved=1');
    exit;
}

$savedMessage = '';

if (($_GET['saved'] ?? '') === '1') {
    $savedMessage = 'Notification settings saved.';
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Notification Channels - Push</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Notification Channels</h1>

            <p>
                Configure how the portal communicates with users.
            </p>
        </div>

    </div>

    <?php if($savedMessage !== ''): ?>

    <div class="settings-saved">
        <?= htmlspecialchars($savedMessage) ?>
    </div>

    <?php endif; ?>

        <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Push Notifications</h2>

                <p>
                    Web push credentials used for browser notifications.
                </p>
            </div>

        </div>

        <form method="post" class="settings-form">

            <div class="settings-field-row">

            <div class="settings-field">

                <label for="notify_push_subject">
                    Web Push Subject
                </label>

                <input
                    type="text"
                    id="notify_push_subject"
                    name="notify_push_subject"
                    value="<?= htmlspecialchars((string)($portalSettings['notify_push_subject'] ?? '')) ?>"
                    class="table-control">

            </div>

            </div>

            <div class="settings-field-row">

            <div class="settings-field">

                <label for="notify_push_public_key">
                    VAPID Public Key
                </label>

                <input
                    type="text"
                    id="notify_push_public_key"
                    name="notify_push_public_key"
                    value="<?= htmlspecialchars((string)($portalSettings['notify_push_public_key'] ?? '')) ?>"
                    class="table-control">

            </div>

            </div>

            <div class="settings-field-row">

            <div class="settings-field">

                <label for="notify_push_private_key">
                    VAPID Private Key
                </label>

                <input
                    type="password"
                    id="notify_push_private_key"
                    name="notify_push_private_key"
                    value="<?= htmlspecialchars((string)($portalSettings['notify_push_private_key'] ?? '')) ?>"
                    class="table-control">

            </div>

            </div>

            <p class="appearance-help">
                VAPID credentials for web push notifications. The subject is usually a mailto: address that identifies the sender.
            </p>

            <button
                type="submit"
                name="save_notifications"
                value="1"
                class="approve-btn">
                Save
            </button>

                    <button
                type="button"
                class="table-btn"
                style="margin-left:10px;"
                onclick="sendTestNotification()">
                Send Test Notification
            </button>

</form>

            <div
                id="testResult"
                style="display:none;
                       margin-top:12px;">
            </div>

            <script>

            function sendTestNotification(){

                var to = '';


                fetch(
                    'notifications-test-api.php',
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type':
                                'application/json'
                        },
                        body: JSON.stringify({
                            channel: 'push',
                            to: to
                        })
                    }
                )
                .then(function(response){
                    return response.json();
                })
                .then(function(data){

                    var box = document
                        .getElementById(
                            'testResult'
                        );

                    box.style.display =
                        'block';

                    box.className =
                        data.success
                            ? 'settings-saved'
                            : 'error-message';

                    box.textContent =
                        data.message
                        || 'No response.';

                })
                .catch(function(){
                    var box = document
                        .getElementById(
                            'testResult'
                        );

                    box.style.display =
                        'block';

                    box.className =
                        'error-message';

                    box.textContent =
                        'The test request failed.';
                });

            }

            </script>


    </div>

</div>
</body>
</html>
