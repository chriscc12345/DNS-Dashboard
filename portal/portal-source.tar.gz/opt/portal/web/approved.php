<?php

require_once 'auth.php';
require_once 'config.php';

if(
    !hasPermission(
        'Approve Requests'
    )
){
    include 'includes/access-denied.php';
    exit;
}

$currentPage = 'approved';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_POST['reblock'])) {

    $id = intval($_POST['id']);

    $url = $FASTAPI_URL . "/reblock/" . $id;

    $result = file_get_contents(
        $url,
        false,
        stream_context_create([
            'http' => [
                'method' => 'POST'
            ]
        ])
    );
    header("Location: approved.php");
    exit;

}

if (isset($_POST['approve'])) {

    $id = intval($_POST['id']);

    $url = $FASTAPI_URL . "/approve/" . $id;

    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $result = curl_exec($ch);

    curl_close($ch);
    header("Location: approved.php");
    exit;
}

$json = file_get_contents(
    $FASTAPI_URL . "/approved"
);

$requests = json_decode($json, true);

$search = isset($_GET['search'])
    ? strtolower(trim($_GET['search']))
    : '';

if($search !== ''){

    $requests = array_filter(
        $requests,
        function($row) use ($search){

            return strpos(
                strtolower(
                    implode(' ', $row)
                ),
                $search
            ) !== false;

        }
    );

}

$totalRecords = count($requests);

$perPage = isset($_GET['per_page'])
    ? $_GET['per_page']
    : 10;

if($perPage !== 'all'){

    $requests = array_slice(
        $requests,
        0,
        intval($perPage)
    );

}

$showingRecords = count($requests);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Approved Requests</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
    <link
        rel="icon"
        type="image/png"
        href="images/favicon.png">
        
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
    
</head>


<body>

<div class="banner">
  <img src="images/banner.jpg">
</div>

<?php include 'includes/sidebar.php'; ?>



<div class="content">

        <h1>Approved Requests</h1>
                
        <div class="table-controls">
        
            <div class="table-controls-right">
        
                <form method="get">
              
                    <input
                        type="text"
                        placeholder="Search Here"
                        class="table-control"
                        name="search"
                        value="<?= htmlspecialchars($search) ?>">
        
        
                        <select 
                            name="per_page"
                            class="table-control">
                        
                            <option value="10"
                                <?= $perPage == 10 ? 'selected' : '' ?>>
                                10
                            </option>
                        
                            <option value="25"
                                <?= $perPage == 25 ? 'selected' : '' ?>>
                                25
                            </option>
                        
                            <option value="50"
                                <?= $perPage == 50 ? 'selected' : '' ?>>
                                50
                            </option>
                        
                            <option value="100"
                                <?= $perPage == 100 ? 'selected' : '' ?>>
                                100
                            </option>
                        
                            <option value="all"
                                <?= $perPage == 'all' ? 'selected' : '' ?>>
                                All
                            </option>
                        
                        </select>
        
                        <button 
                            type="submit"
                            class="table-btn">
                            Search
                        </button>
                        
                        <a href="approved.php" class="clear-btn">
                            Clear
                        </a>
                </form>
               
            </div>
        
        </div>
        
        <table>
        
        <tr>
            <th>ID</th>
            <th>Domain</th>
            <th>Client IP</th>
            <th>Blocked Reason</th>
            <th>Blocked Time</th>
            <th>Blocked Until</th>
            <th>Action</th>
        
            
        </tr>
        
        <?php foreach($requests as $row): ?>
        
        
        <tr>
        
            <td><?= htmlspecialchars($row[0]) ?></td>
            <td><?= htmlspecialchars($row[1]) ?></td>
            <td><?= htmlspecialchars($row[2]) ?></td>
            <td><?= htmlspecialchars($row[3]) ?></td>
            <td>
            <?php
            if (!empty($row[5])) {
                echo date('d M Y H:i', strtotime($row[5]));
            } else {
                echo "-";
            }
            ?>
            </td>
            <td>
            <?php
            if (!empty($row[6])) {
            
                echo date(
                    'd M Y H:i',
                    strtotime($row[6])
                );
            
            } else {
            
                echo "Permanent";
            
            }
            ?>
            </td>
            <td>
                
                <form method="post">
            
                    <input
                        type="hidden"
                        name="id"
                        value="<?= $row[0] ?>">
            
                    <button
                        type:="submit"
                        class="deny-btn"
                        name="reblock">
            
                        Block Now
            
                    </button>
            
                </form>
            
            </td>
        
            
        
        </tr>
        
        <?php endforeach; ?>
        
        </table>
                
        <div class="table-summary">
        
            Showing
            <strong><?= $showingRecords ?></strong>
            of
            <strong><?= $totalRecords ?></strong>
        
        </div>
        
        <script>
        
        const ws = new WebSocket(
                                class="deny-btn"
                        onclick="closeAllowModal()">
        
                        Cancel
        
                    </button>
        
                </form>
        
            </div>
        
        </div>
        
        <script>
        
        const ws = new WebSocket(
            `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`
        );
        
        ws.onmessage = function(event){
        
            if(event.data === "refresh"){
        
                location.reload();
        
            }
        
        };
        
        </script>
        <script>

        function openAllowModal(id){
        
            document
                .getElementById('allowRequestId')
                .value = id;
        
            document
        );
        
        ws.onmessage = function(event){
        
            if(event.data === "refresh"){
        
                location.reload();
        
            }
        
        };
        
        </script>
</div>
</body>
</html>