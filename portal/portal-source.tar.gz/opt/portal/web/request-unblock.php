<?php
// 1. Allow the frontend block page to securely communicate here
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

// 2. Your Technitium DNS Configurations
define('TECHNITIUM_IP', '127.0.0.1:5380'); 
define('API_TOKEN', 'b7a29636a3afecc1d0f7558a0a26dcfa44b0850d67ffa18a76d17c8aa65ad2d1'); 

// 3. Read the domain passed from the webpage button
$domain = filter_input(INPUT_GET, 'domain', FILTER_SANITIZE_URL);
$domain = trim(strtolower($domain)); 

if (!$domain) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "No domain provided."]);
    exit;
}

// 4. Clean API Endpoint URL (No token in the URL string to follow modern security specs)
$apiUrl = "http://" . TECHNITIUM_IP . "/api/allowed/add?domain=" . urlencode($domain);

// 5. Build standard HTTP context with Bearer Token (Works without cURL installed!)
$options = [
    'http' => [
        'method' => 'GET',
        'header' => [
            "Authorization: Bearer " . API_TOKEN,
            "Accept: application/json"
        ],
        'ignore_errors' => true,
        'timeout' => 5
    ]
];

$context = stream_context_create($options);
$response = @file_get_contents($apiUrl, false, $context);

// 6. Respond back to the frontend page button
if ($response !== false) {
    $resObj = json_decode($response, true);
    // If Technitium returned an error envelope, relay it as a bad request
    if (isset($resObj['status']) && $resObj['status'] === 'error') {
        http_response_code(400);
    } else {
        http_response_code(200);
    }
    echo $response;
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Web server failed to connect to Technitium DNS locally."]);
}
?>
