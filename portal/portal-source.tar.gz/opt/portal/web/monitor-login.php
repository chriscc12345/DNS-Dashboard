<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';

if (
    !hasPermission(
        'Notification Channel'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'monitor-login';
$pageHeading = 'Communications';
$showSidebarPageHeading = true;

/*
 * The hub itself is not one of the channel
 * tabs, so landing on it leaves every tab
 * inactive. Open the first channel tab the
 * visitor may see - the same way HTTPS/SSL
 * opens on its Portal Certificate tab. The
 * overview below stays as the fallback for
 * when no tab is viewable.
 */

if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $hubFirstTab = null;

    foreach (
        $pageTabsList
        as $hubTab
    ) {

        $hubHref = trim(
            (string)(
                $hubTab['tab_href']
                ?? ''
            )
        );

        $hubPermission = trim(
            (string)(
                $hubTab['tab_permission']
                ?? ''
            )
        );

        if (
            $hubHref === ''
            || $hubHref === 'monitor-login.php'
            || (
                $hubPermission !== ''
                && !hasPermission(
                    $hubPermission
                )
            )
        ) {
            continue;
        }

        $hubSort = (int)(
            $hubTab['sort_order']
            ?? 0
        );

        $hubId = (int)(
            $hubTab['id']
            ?? 0
        );

        $hubBestSort = $hubFirstTab
            ? (int)(
                $hubFirstTab[
                    'sort_order'
                ]
                ?? 0
            )
            : null;

        $hubBestId = $hubFirstTab
            ? (int)(
                $hubFirstTab['id']
                ?? 0
            )
            : null;

        if (
            $hubFirstTab === null
            || $hubSort < $hubBestSort
            || (
                $hubSort === $hubBestSort
                && $hubId < $hubBestId
            )
        ) {
            $hubFirstTab = $hubTab;
        }
    }

    if ($hubFirstTab !== null) {

        header(
            'Location: '
            . trim(
                (string)(
                    $hubFirstTab[
                        'tab_href'
                    ]
                )
            )
        );
        exit;
    }
}

/*
 * The Monitor Alerts hub shows a read only
 * overview of every configured notification
 * rule across all channels. Rules are
 * created and edited on each channel tab
 * (the generated monitor-<channel>.php
 * pages), which keeps a single place to
 * manage them.
 */

$loginNotifications =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL
            . '/monitor/login-notifications'
        ),
        true
    ) ?? [];

$loginNotifications =
    is_array($loginNotifications)
        ? $loginNotifications
        : [];

function monitorTargetLabel($target) {

    return strcasecmp(
        (string)$target,
        'All'
    ) === 0
        ? 'All Users'
        : (string)$target;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Monitor Alerts - Notification Channel</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Monitor Alerts</h1>

            <p>
                Configure what the portal monitors and who gets told about it.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>All Notification Rules</h2>

                <p>
                    Every rule across all channels. Open a channel tab to
                    create, edit or test its notifications.
                </p>
            </div>

        </div>

        <table class="ssl-table">

            <tr>
                <th>Notification Channel</th>
                <th>Function</th>
                <th>Type of Notification</th>
                <th>User</th>
                <th>Login Message</th>
                <th>Failed Message</th>
                <th>Logout Message</th>
                <th>Status</th>
            </tr>

            <?php foreach (
                $loginNotifications
                as $lnRule
            ): ?>

            <tr>
                <td>
                    <?= htmlspecialchars(
                        (string)(
                            $lnRule['notification_channel']
                            ?? ''
                        )
                    ) ?>
                </td>
                <td><?= htmlspecialchars(
                    (string)(
                        $lnRule[
                            'rule_function'
                        ]
                        ?? 'Login Notification'
                    )
                ) ?></td>
                <td>
                    <?= htmlspecialchars(
                        (string)(
                            $lnRule['notification_type']
                            ?? ''
                        )
                    ) ?>
                </td>
                <td>
                    <?= htmlspecialchars(
                        monitorTargetLabel(
                            $lnRule['target_username']
                            ?? ''
                        )
                    ) ?>
                </td>
                <td>
                    <?= htmlspecialchars(
                        (string)(
                            $lnRule['login_custom_message']
                            ?? ''
                        )
                    ) ?>
                </td>
                <td>
                    <?= htmlspecialchars(
                        (string)(
                            $lnRule['failed_custom_message']
                            ?? ''
                        )
                    ) ?>
                </td>
                <td>
                    <?= htmlspecialchars(
                        (string)(
                            $lnRule['logout_custom_message']
                            ?? ''
                        )
                    ) ?>
                </td>
                <td>
                    <span class="<?= !empty($lnRule['enabled'])
                        ? 'badge-active'
                        : 'badge-disabled' ?>">
                        <?= !empty($lnRule['enabled'])
                            ? 'Enabled'
                            : 'Disabled' ?>
                    </span>
                </td>
            </tr>

            <?php endforeach; ?>

            <?php if(
                count($loginNotifications) === 0
            ): ?>

            <tr>
                <td colspan="8">
                    <span class="settings-coming-soon">
                        No notification rules yet - open a channel tab and
                        click Add New to create one.
                    </span>
                </td>
            </tr>

            <?php endif; ?>

        </table>

    </div>

</div>

</body>

</html>
