<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (
    !hasPermission(
        'Pushbullet'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'notifications-pushbullet';
$pageHeading = 'Communications';
$showSidebarPageHeading = true;

$portalSettings =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];

function savePortalSettings($settings) {

    global $FASTAPI_URL;

    $payload =
        json_encode(
            ['settings' => $settings]
        );

    return file_get_contents(
        $FASTAPI_URL . '/portal-settings/appearance',
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $payload
            ]
        ])
    );
}

if (isset($_POST['save_notifications'])) {

    savePortalSettings([
        'notify_pushbullet_token' =>
            (string)$_POST['notify_pushbullet_token'],
        'notify_pushbullet_channel' =>
            trim((string)$_POST['notify_pushbullet_channel'])
    ]);

    header('Location: notifications-pushbullet.php?saved=1');
    exit;
}

$savedMessage = '';

if (($_GET['saved'] ?? '') === '1') {
    $savedMessage = 'Notification settings saved.';
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Notification Channels - Pushbullet</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Notification Channels</h1>

            <p>
                Configure how the portal communicates with users.
            </p>
        </div>

    </div>

    <?php if($savedMessage !== ''): ?>

    <div class="settings-saved">
        <?= htmlspecialchars($savedMessage) ?>
    </div>

    <?php endif; ?>

        <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Pushbullet</h2>

                <p>
                    Pushbullet API credentials used for sending notifications.
                </p>
            </div>

        </div>

        <form method="post" class="settings-form">

            <div class="settings-field-row">

            <div class="settings-field">

                <label for="notify_pushbullet_token">
                    Access Token
                </label>

                <input
                    type="password"
                    id="notify_pushbullet_token"
                    name="notify_pushbullet_token"
                    value="<?= htmlspecialchars((string)($portalSettings['notify_pushbullet_token'] ?? '')) ?>"
                    class="table-control">

            </div>

            </div>

            <div class="settings-field-row">

            <div class="settings-field">

                <label for="notify_pushbullet_channel">
                    Channel Tag
                </label>

                <input
                    type="text"
                    id="notify_pushbullet_channel"
                    name="notify_pushbullet_channel"
                    value="<?= htmlspecialchars((string)($portalSettings['notify_pushbullet_channel'] ?? '')) ?>"
                    class="table-control">

            </div>

            </div>

            <p class="appearance-help">
                Pushbullet API credentials. Create an access token in your Pushbullet account settings. Optionally enter a channel tag to post to a Pushbullet channel instead of your devices.
            </p>

            <button
                type="submit"
                name="save_notifications"
                value="1"
                class="approve-btn">
                Save
            </button>

                    <button
                type="button"
                class="table-btn"
                style="margin-left:10px;"
                onclick="sendTestNotification()">
                Send Test Notification
            </button>

</form>

            <div
                id="testResult"
                style="display:none;
                       margin-top:12px;">
            </div>

            <script>

            function sendTestNotification(){

                var to = '';


                fetch(
                    'notifications-test-api.php',
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type':
                                'application/json'
                        },
                        body: JSON.stringify({
                            channel: 'pushbullet',
                            to: to
                        })
                    }
                )
                .then(function(response){
                    return response.json();
                })
                .then(function(data){

                    var box = document
                        .getElementById(
                            'testResult'
                        );

                    box.style.display =
                        'block';

                    box.className =
                        data.success
                            ? 'settings-saved'
                            : 'error-message';

                    box.textContent =
                        data.message
                        || 'No response.';

                })
                .catch(function(){
                    var box = document
                        .getElementById(
                            'testResult'
                        );

                    box.style.display =
                        'block';

                    box.className =
                        'error-message';

                    box.textContent =
                        'The test request failed.';
                });

            }

            </script>


    </div>

</div>
</body>
</html>
