<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// section tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';

if (
    !hasPermission(
        'Session Timeout'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'timeout';
$pageHeading = 'Security';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>Session Timeout</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Session Timeout</h1>

            <p>
                Manage Session Timeout.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Session Timeout</h2>

                <p>
                    This page has no content yet.
                </p>
            </div>

        </div>

    </div>

</div>

</body>

</html>
