<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (!hasPermission('Login')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'appearance-login';
$pageHeading = 'Customization';
$showSidebarPageHeading = true;

$portalSettings =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];

$loginTitle =
    trim(
        (string)(
            $portalSettings['login_title']
            ?? 'DNS Security Dashboard'
        )
    );

$loginSubtitle =
    trim(
        (string)(
            $portalSettings['login_subtitle']
            ?? ''
        )
    );

$loginLogoSize =
    (int)(
        $portalSettings['login_logo_size']
        ?? 180
    );

if (
    $loginLogoSize < 60
    || $loginLogoSize > 300
) {
    $loginLogoSize = 180;
}


$loginBackground =
    trim(
        (string)(
            $portalSettings['login_background_image']
            ?? ''
        )
    );

$loginOverlay =
    (int)(
        $portalSettings['login_background_overlay']
        ?? 0
    );

if ($loginOverlay < 0 || $loginOverlay > 100) {
    $loginOverlay = 0;
}

$loginCardPosition =
    strtolower(
        trim(
            (string)(
                $portalSettings['login_card_position']
                ?? 'center'
            )
        )
    );

if (
    !in_array(
        $loginCardPosition,
        ['left', 'center', 'right'],
        true
    )
) {
    $loginCardPosition = 'center';
}

$showLogoLogin =
    strtolower(
        (string)(
            $portalSettings['show_logo_login']
            ?? 'true'
        )
    ) === 'true';

$showLoginFooter =
    strtolower(
        (string)(
            $portalSettings['show_login_footer']
            ?? 'false'
        )
    ) === 'true';

$loginFooterText =
    trim(
        (string)(
            $portalSettings['login_footer_text']
            ?? ''
        )
    );

$loginAnimationEnabled =
    strtolower(
        (string)(
            $portalSettings['login_animation_enabled']
            ?? 'false'
        )
    ) === 'true';

$loginAnimationStyle =
    strtolower(
        trim(
            (string)(
                $portalSettings['login_animation_style']
                ?? 'cyber'
            )
        )
    );

$loginAnimationStyles = [
    'cyber' => 'Cyber Security',
    'digital_rain' => 'Digital Rain',
    'network_grid' => 'Network Grid',
    'security_scanner' => 'Security Scanner',
];

if (!isset($loginAnimationStyles[$loginAnimationStyle])) {
    $loginAnimationStyle = 'cyber';
}

$loginAnimationIntensity =
    strtolower(
        trim(
            (string)(
                $portalSettings['login_animation_intensity']
                ?? 'medium'
            )
        )
    );

if (
    !in_array(
        $loginAnimationIntensity,
        ['low', 'medium', 'high', 'ultra'],
        true
    )
) {
    $loginAnimationIntensity = 'medium';
}


$companyLogo =
    trim(
        (string)(
            $portalSettings['company_logo']
            ?? ''
        )
    );

?>
<!DOCTYPE html>
<html>
<head>

    <title>Appearance - Login Page</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined"
        rel="stylesheet">

</head>

<body>

<?php include 'includes/sidebar.php'; ?>
<?php include 'includes/banner.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

            <div>
                <h1>Appearance</h1>

                <p>
                    Configure the appearance of the Portal sign-in screen.
                </p>
            </div>

        </div>


            <?php include __DIR__ . '/includes/page-tabs.php'; ?>


        <div class="appearance-panel">

            <div class="appearance-panel-heading">

                <div>
                    <h2>Login Page Design</h2>

                    <p>
                        Preview and configure the sign-in screen shown
                        before a user enters the Portal.
                    </p>
                </div>

            </div>


            <div class="appearance-login-layout">

                <div class="appearance-login-preview-column">

                    <div
                        class="appearance-login-preview"
                        id="appearanceLoginPreview"
                        data-position="<?= htmlspecialchars($loginCardPosition) ?>">

                        <div
                            class="appearance-login-preview-background"
                            id="appearanceLoginPreviewBackground"
                            <?php if($loginBackground !== ''): ?>
                            style="background-image:url('<?= htmlspecialchars($loginBackground) ?>');"
                            <?php endif; ?>>
                        </div>

                        <canvas
                            class="appearance-login-preview-animation"
                            id="appearanceLoginPreviewAnimation"
                            aria-hidden="true">
                        </canvas>

                        <div
                            class="appearance-login-preview-overlay"
                            id="appearanceLoginPreviewOverlay"
                            style="opacity:<?= htmlspecialchars((string)($loginOverlay / 100)) ?>;">
                        </div>

                        <div
                            class="appearance-login-preview-card"
                            id="appearanceLoginPreviewCard">

                            <div
                                class="appearance-login-preview-logo"
                                id="appearanceLoginPreviewLogo"
                                <?= $showLogoLogin ? '' : 'hidden' ?>>

                                <?php if($companyLogo !== ''): ?>

                                <img
                                    src="<?= htmlspecialchars($companyLogo) ?>"
                                    alt="Company logo"
                                    id="appearanceLoginPreviewLogoImage"
                                    style="width:<?= $loginLogoSize ?>px;">

                                <?php else: ?>

                                <span class="material-symbols-outlined">
                                    shield_lock
                                </span>

                                <?php endif; ?>

                            </div>

                            <h3 id="appearanceLoginPreviewTitle">
                                <?= htmlspecialchars($loginTitle) ?>
                            </h3>

                            <p
                                class="appearance-login-preview-subtitle"
                                id="appearanceLoginPreviewSubtitle"
                                <?= $loginSubtitle !== '' ? '' : 'hidden' ?>>
                                <?= htmlspecialchars($loginSubtitle) ?>
                            </p>

                            <div class="appearance-login-preview-input">
                                Username
                            </div>

                            <div class="appearance-login-preview-input">
                                Password
                            </div>

                            <div class="appearance-login-preview-button">
                                Sign In
                            </div>

                            <div
                                class="appearance-login-preview-footer"
                                id="appearanceLoginPreviewFooter"
                                <?= $showLoginFooter ? '' : 'hidden' ?>>
                                <?= htmlspecialchars($loginFooterText) ?>
                            </div>

                        </div>

                    </div>


                    <div class="appearance-logo-actions">

                        <button
                            type="button"
                            class="table-btn"
                            id="appearanceChooseLoginBackground">
                            Upload Background
                        </button>

                        <?php if($loginBackground !== ''): ?>

                        <button
                            type="button"
                            class="table-btn appearance-secondary-btn"
                            id="appearanceRemoveLoginBackground">
                            Remove Background
                        </button>

                        <?php endif; ?>

                    </div>

                    <input
                        type="file"
                        id="appearanceLoginBackgroundFile"
                        accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                        hidden>

                    <p class="appearance-help">
                        JPG, PNG or WebP. Maximum file size 5 MB.
                        Large images are automatically resized.
                    </p>


                    <div class="appearance-login-animation-section appearance-login-animation-left">

                        <div class="appearance-login-animation-heading">
                            <div>
                                <strong>Login Animation</strong>
                                <small>
                                    Add a subtle animated cyber-security
                                    layer to the Login Page background.
                                </small>
                            </div>
                        </div>

                        <label class="appearance-option">

                            <span>
                                <strong>Enable Login Animation</strong>

                                <small>
                                    Display the animation behind the Login
                                    card without changing the background image.
                                </small>
                            </span>

                            <input
                                type="checkbox"
                                id="appearanceLoginAnimationEnabled"
                                <?= $loginAnimationEnabled ? 'checked' : '' ?>>

                        </label>


                        <div
                            class="appearance-login-animation-settings"
                            id="appearanceLoginAnimationSettings">

                            <div class="appearance-login-field">

                                <label for="appearanceLoginAnimationStyle">
                                    Animation Style
                                </label>

                                <div
                                    class="appearance-custom-select"
                                    data-select-id="appearanceLoginAnimationStyle">

                                    <button
                                        type="button"
                                        class="appearance-custom-select-button"
                                        aria-haspopup="listbox"
                                        aria-expanded="false">

                                        <span class="appearance-custom-select-text">
                                            <?= htmlspecialchars(
                                                $loginAnimationStyles[
                                                    $loginAnimationStyle
                                                ]
                                            ) ?>
                                        </span>

                                        <span
                                            class="login-position-chevron"
                                            aria-hidden="true">
                                        </span>

                                    </button>

                                    <div
                                        class="appearance-custom-select-menu"
                                        role="listbox"
                                        hidden>

                                        <?php foreach(
                                            $loginAnimationStyles
                                            as $animationStyleValue
                                            => $animationStyleLabel
                                        ): ?>

                                        <button
                                            type="button"
                                            data-value="<?= htmlspecialchars(
                                                $animationStyleValue
                                            ) ?>"
                                            role="option">
                                            <?= htmlspecialchars(
                                                $animationStyleLabel
                                            ) ?>
                                        </button>

                                        <?php endforeach; ?>

                                    </div>

                                </div>

                                <select
                                    id="appearanceLoginAnimationStyle"
                                    class="appearance-custom-native-select">

                                    <?php foreach(
                                        $loginAnimationStyles
                                        as $animationStyleValue
                                        => $animationStyleLabel
                                    ): ?>

                                    <option
                                        value="<?= htmlspecialchars(
                                            $animationStyleValue
                                        ) ?>"
                                        <?= $loginAnimationStyle
                                            === $animationStyleValue
                                                ? 'selected'
                                                : '' ?>>
                                        <?= htmlspecialchars(
                                            $animationStyleLabel
                                        ) ?>
                                    </option>

                                    <?php endforeach; ?>

                                </select>

                            </div>


                            <div class="appearance-login-field">

                                <label for="appearanceLoginAnimationIntensity">
                                    Animation Intensity
                                </label>

                                <div
                                    class="appearance-custom-select"
                                    data-select-id="appearanceLoginAnimationIntensity">

                                    <button
                                        type="button"
                                        class="appearance-custom-select-button"
                                        aria-haspopup="listbox"
                                        aria-expanded="false">

                                        <span class="appearance-custom-select-text">
                                            <?= htmlspecialchars(
                                                $loginAnimationIntensity === 'ultra'
                                                    ? 'Ultra High'
                                                    : ucfirst($loginAnimationIntensity)
                                            ) ?>
                                        </span>

                                        <span
                                            class="login-position-chevron"
                                            aria-hidden="true">
                                        </span>

                                    </button>

                                    <div
                                        class="appearance-custom-select-menu"
                                        role="listbox"
                                        hidden>

                                        <button type="button" data-value="low" role="option">
                                            Low
                                        </button>

                                        <button type="button" data-value="medium" role="option">
                                            Medium
                                        </button>

                                        <button type="button" data-value="high" role="option">
                                            High
                                        </button>

                                        <button type="button" data-value="ultra" role="option">
                                            Ultra High
                                        </button>

                                    </div>

                                </div>

                                <select
                                    id="appearanceLoginAnimationIntensity"
                                    class="appearance-custom-native-select">

                                    <option
                                        value="low"
                                        <?= $loginAnimationIntensity === 'low'
                                            ? 'selected'
                                            : '' ?>>
                                        Low
                                    </option>

                                    <option
                                        value="medium"
                                        <?= $loginAnimationIntensity === 'medium'
                                            ? 'selected'
                                            : '' ?>>
                                        Medium
                                    </option>

                                    <option
                                        value="high"
                                        <?= $loginAnimationIntensity === 'high'
                                            ? 'selected'
                                            : '' ?>>
                                        High
                                    </option>

                                    <option
                                        value="ultra"
                                        <?= $loginAnimationIntensity === 'ultra'
                                            ? 'selected'
                                            : '' ?>>
                                        Ultra High
                                    </option>

                                </select>

                            </div>

                        </div>

                    </div>
                </div>


                <div class="appearance-login-options appearance-login-options-compact">

                    <div class="appearance-login-field">

                        <label for="appearanceLoginTitle">
                            Login Title
                        </label>

                        <input
                            type="text"
                            id="appearanceLoginTitle"
                            maxlength="120"
                            value="<?= htmlspecialchars($loginTitle) ?>">

                    </div>


                    <div class="appearance-login-field">

                        <label for="appearanceLoginSubtitle">
                            Subtitle
                        </label>

                        <input
                            type="text"
                            id="appearanceLoginSubtitle"
                            maxlength="250"
                            value="<?= htmlspecialchars($loginSubtitle) ?>"
                            placeholder="Optional welcome message">

                    </div>


                    <label class="appearance-option">

                        <span>
                            <strong>Show Company Logo</strong>

                            <small>
                                Display the company logo above the
                                Login Page title.
                            </small>
                        </span>

                        <input
                            type="checkbox"
                            id="appearanceShowLogoLogin"
                            <?= $showLogoLogin ? 'checked' : '' ?>>

                    </label>


                    <div class="appearance-login-field">

                        <div class="appearance-login-range-heading">

                            <label for="appearanceLoginLogoSize">
                                Company Logo Size
                            </label>

                            <strong id="appearanceLoginLogoSizeValue">
                                <?= $loginLogoSize ?> px
                            </strong>

                        </div>

                        <input
                            type="range"
                            id="appearanceLoginLogoSize"
                            min="60"
                            max="300"
                            step="1"
                            value="<?= $loginLogoSize ?>">

                        <small>
                            Adjust the company logo width on the
                            Login Page.
                        </small>

                    </div>


                    <div class="appearance-login-field">

                        <label for="appearanceLoginPosition">
                            Login Card Position
                        </label>

                        
<div class="login-position-select" id="loginPositionCustom">

    <button
        type="button"
        class="login-position-select-button"
        id="loginPositionButton"
        aria-haspopup="listbox"
        aria-expanded="false">

        <span id="loginPositionButtonText">
            <?= htmlspecialchars(ucfirst($loginCardPosition)) ?>
        </span>

        <span
            class="login-position-chevron"
            aria-hidden="true">
        </span>

    </button>

    <div
        class="login-position-select-menu"
        id="loginPositionMenu"
        role="listbox"
        hidden>

        <button type="button" data-value="left" role="option">
            Left
        </button>

        <button type="button" data-value="center" role="option">
            Center
        </button>

        <button type="button" data-value="right" role="option">
            Right
        </button>

    </div>

</div>

<select class="login-position-native-select"
                            id="appearanceLoginPosition"
                            class="appearance-select">

                            <option
                                value="left"
                                <?= $loginCardPosition === 'left' ? 'selected' : '' ?>>
                                Left
                            </option>

                            <option
                                value="center"
                                <?= $loginCardPosition === 'center' ? 'selected' : '' ?>>
                                Center
                            </option>

                            <option
                                value="right"
                                <?= $loginCardPosition === 'right' ? 'selected' : '' ?>>
                                Right
                            </option>

                        </select>

                    </div>


                    <div class="appearance-login-field">

                        <div class="appearance-login-range-heading">

                            <label for="appearanceLoginOverlay">
                                Background Overlay
                            </label>

                            <strong id="appearanceLoginOverlayValue">
                                <?= $loginOverlay ?>%
                            </strong>

                        </div>

                        <input
                            type="range"
                            id="appearanceLoginOverlay"
                            min="0"
                            max="100"
                            step="1"
                            value="<?= $loginOverlay ?>">

                        <small>
                            Darken the background to improve Login
                            card visibility.
                        </small>

                    </div>


                    <label class="appearance-option">

                        <span>
                            <strong>Show Footer Text</strong>

                            <small>
                                Display optional information beneath
                                the Sign In button.
                            </small>
                        </span>

                        <input
                            type="checkbox"
                            id="appearanceShowLoginFooter"
                            <?= $showLoginFooter ? 'checked' : '' ?>>

                    </label>


                    <div
                        class="appearance-login-field"
                        id="appearanceLoginFooterField"
                        <?= $showLoginFooter ? '' : 'hidden' ?>>

                        <label for="appearanceLoginFooterText">
                            Footer Text
                        </label>

                        <textarea
                            id="appearanceLoginFooterText"
                            maxlength="300"
                            rows="3"
                            placeholder="Optional footer text"><?= htmlspecialchars($loginFooterText) ?></textarea>

                    </div>





                </div>

            </div>

        </div>

</div>


<div
    class="appearance-login-toast"
    id="appearanceLoginToast"
    hidden>
</div>


<script src="js/portal-animation.js"></script>

<script>
(function () {

    const title =
        document.getElementById('appearanceLoginTitle');

    const subtitle =
        document.getElementById('appearanceLoginSubtitle');

    const showLogo =
        document.getElementById('appearanceShowLogoLogin');

    const logoSize =
        document.getElementById('appearanceLoginLogoSize');

    const logoSizeValue =
        document.getElementById('appearanceLoginLogoSizeValue');

    const previewLogoImage =
        document.getElementById('appearanceLoginPreviewLogoImage');


    const position =
        document.getElementById('appearanceLoginPosition');

    const overlay =
        document.getElementById('appearanceLoginOverlay');

    const overlayValue =
        document.getElementById('appearanceLoginOverlayValue');

    const showFooter =
        document.getElementById('appearanceShowLoginFooter');

    const footerText =
        document.getElementById('appearanceLoginFooterText');

    const footerField =
        document.getElementById('appearanceLoginFooterField');

    const animationEnabled =
        document.getElementById('appearanceLoginAnimationEnabled');

    const animationStyle =
        document.getElementById('appearanceLoginAnimationStyle');

    const animationIntensity =
        document.getElementById('appearanceLoginAnimationIntensity');

    const animationSettings =
        document.getElementById('appearanceLoginAnimationSettings');


    const chooseBackground =
        document.getElementById('appearanceChooseLoginBackground');

    const removeBackground =
        document.getElementById('appearanceRemoveLoginBackground');

    const backgroundFile =
        document.getElementById('appearanceLoginBackgroundFile');

    const preview =
        document.getElementById('appearanceLoginPreview');

    const previewOverlay =
        document.getElementById('appearanceLoginPreviewOverlay');

    const previewTitle =
        document.getElementById('appearanceLoginPreviewTitle');

    const previewSubtitle =
        document.getElementById('appearanceLoginPreviewSubtitle');

    const previewLogo =
        document.getElementById('appearanceLoginPreviewLogo');

    const previewFooter =
        document.getElementById('appearanceLoginPreviewFooter');

    const toast =
        document.getElementById('appearanceLoginToast');


    let toastTimer = null;


    function showMessage(message, success) {

        if (!toast) {
            return;
        }

        toast.textContent = message;

        toast.classList.toggle(
            'success',
            success === true
        );

        toast.classList.toggle(
            'error',
            success !== true
        );

        toast.hidden = false;

        if (toastTimer) {
            window.clearTimeout(toastTimer);
        }

        toastTimer =
            window.setTimeout(
                function () {
                    toast.hidden = true;
                },
                3200
            );
    }


    function updatePreview() {

        previewTitle.textContent =
            title.value.trim() || 'DNS Security Dashboard';

        const subtitleValue =
            subtitle.value.trim();

        previewSubtitle.textContent =
            subtitleValue;

        previewSubtitle.hidden =
            subtitleValue === '';

        previewLogo.hidden =
            !showLogo.checked;

        logoSizeValue.textContent =
            logoSize.value + ' px';

        if (previewLogoImage) {

            previewLogoImage.style.width =
                logoSize.value + 'px';

        }

        preview.dataset.position =
            position.value;

        overlayValue.textContent =
            overlay.value + '%';

        previewOverlay.style.opacity =
            String(
                Number(overlay.value) / 100
            );

        footerField.hidden =
            !showFooter.checked;

        previewFooter.hidden =
            !showFooter.checked;

        previewFooter.textContent =
            footerText.value.trim();

        const animationIsEnabled =
            animationEnabled.checked;

        animationSettings.classList.toggle(
            'disabled',
            !animationIsEnabled
        );

        animationStyle.disabled =
            !animationIsEnabled;

        animationIntensity.disabled =
            !animationIsEnabled;
    }


    let loginSaveTimer = null;
    let loginSaveSequence = 0;


    function getLoginSettingsPayload() {

        return {
            login_title:
                title.value.trim(),

            login_subtitle:
                subtitle.value.trim(),

            login_logo_size:
                logoSize.value,

            login_background_overlay:
                overlay.value,

            login_card_position:
                position.value,

            show_logo_login:
                showLogo.checked
                    ? 'true'
                    : 'false',

            show_login_footer:
                showFooter.checked
                    ? 'true'
                    : 'false',

            login_footer_text:
                footerText.value.trim(),

            login_animation_enabled:
                animationEnabled.checked
                    ? 'true'
                    : 'false',

            login_animation_style:
                animationStyle.value,

            login_animation_intensity:
                animationIntensity.value
        };
    }


    async function saveLoginSettings(
        successMessage
    ) {

        const sequence =
            ++loginSaveSequence;

        try {

            const response =
                await fetch(
                    'appearance-api.php',
                    {
                        method: 'POST',

                        headers: {
                            'Content-Type':
                                'application/json'
                        },

                        body: JSON.stringify({
                            action: 'save',
                            settings:
                                getLoginSettingsPayload()
                        })
                    }
                );

            const data =
                await response.json();

            if (
                !response.ok
                || !data.success
            ) {
                throw new Error(
                    data.message
                    || 'Unable to save Login Page settings.'
                );
            }

            /*
             * Ignore the toast from an older request if a
             * newer save has already started.
             */
            if (sequence !== loginSaveSequence) {
                return;
            }

            showMessage(
                successMessage
                || 'Login Page settings saved.',
                true
            );

        } catch (error) {

            if (sequence !== loginSaveSequence) {
                return;
            }

            showMessage(
                error.message
                || 'Unable to save Login Page settings.',
                false
            );
        }
    }


    function queueLoginSave(
        successMessage,
        delay
    ) {

        if (loginSaveTimer) {
            window.clearTimeout(
                loginSaveTimer
            );
        }

        loginSaveTimer =
            window.setTimeout(
                function () {

                    loginSaveTimer = null;

                    saveLoginSettings(
                        successMessage
                    );
                },
                delay ?? 450
            );
    }


    function refreshLoginAppearancePreview() {

        updatePreview();
        refreshAnimationPreview();
    }


    /*
     * Text controls:
     * live preview immediately, save after a short pause.
     */
    [
        title,
        subtitle,
        footerText
    ].forEach(
        function (control) {

            control.addEventListener(
                'input',
                function () {

                    refreshLoginAppearancePreview();

                    queueLoginSave(
                        'Login Page settings saved.',
                        550
                    );
                }
            );

            control.addEventListener(
                'change',
                function () {

                    refreshLoginAppearancePreview();

                    queueLoginSave(
                        'Login Page settings saved.',
                        100
                    );
                }
            );
        }
    );


    /*
     * Sliders:
     * preview while moving; persist shortly after movement.
     */
    [
        logoSize,
        overlay
    ].forEach(
        function (control) {

            control.addEventListener(
                'input',
                function () {

                    refreshLoginAppearancePreview();

                    queueLoginSave(
                        'Login Page settings saved.',
                        300
                    );
                }
            );

            control.addEventListener(
                'change',
                function () {

                    refreshLoginAppearancePreview();

                    queueLoginSave(
                        'Login Page settings saved.',
                        50
                    );
                }
            );
        }
    );


    /*
     * Toggles and selects:
     * update and save immediately.
     */
    [
        showLogo,
        position,
        showFooter,
        animationEnabled,
        animationStyle,
        animationIntensity
    ].forEach(
        function (control) {

            control.addEventListener(
                'change',
                function () {

                    refreshLoginAppearancePreview();

                    queueLoginSave(
                        'Login Page settings saved.',
                        0
                    );
                }
            );
        }
    );


    chooseBackground.addEventListener(
        'click',
        function () {

            backgroundFile.value = '';
            backgroundFile.click();

        }
    );


    backgroundFile.addEventListener(
        'change',
        async function () {

            const file =
                backgroundFile.files[0];

            if (!file) {
                return;
            }

            const allowedTypes = [
                'image/jpeg',
                'image/png',
                'image/webp'
            ];

            if (!allowedTypes.includes(file.type)) {

                showMessage(
                    'Please select a JPG, PNG or WebP image.',
                    false
                );

                return;
            }

            if (
                file.size >
                (5 * 1024 * 1024)
            ) {

                showMessage(
                    'Background image must be 5 MB or smaller.',
                    false
                );

                return;
            }

            const formData =
                new FormData();

            formData.append(
                'action',
                'upload'
            );

            formData.append(
                'background',
                file
            );

            chooseBackground.disabled = true;

            try {

                const response =
                    await fetch(
                        'appearance-login-upload.php',
                        {
                            method: 'POST',
                            body: formData
                        }
                    );

                const data =
                    await response.json();

                if (
                    !response.ok
                    ||
                    !data.success
                ) {
                    throw new Error(
                        data.message
                        || 'Background upload failed.'
                    );
                }

                showMessage(
                    data.message
                    || 'Login background uploaded.',
                    true
                );

                window.setTimeout(
                    function () {
                        window.location.reload();
                    },
                    450
                );

            } catch (error) {

                showMessage(
                    error.message
                    || 'Background upload failed.',
                    false
                );

                chooseBackground.disabled = false;
            }

        }
    );


    if (removeBackground) {

        removeBackground.addEventListener(
            'click',
            async function () {

                if (
                    !window.confirm(
                        'Remove the Login background image?'
                    )
                ) {
                    return;
                }

                const formData =
                    new FormData();

                formData.append(
                    'action',
                    'remove'
                );

                removeBackground.disabled = true;

                try {

                    const response =
                        await fetch(
                            'appearance-login-upload.php',
                            {
                                method: 'POST',
                                body: formData
                            }
                        );

                    const data =
                        await response.json();

                    if (
                        !response.ok
                        ||
                        !data.success
                    ) {
                        throw new Error(
                            data.message
                            || 'Unable to remove the background.'
                        );
                    }

                    showMessage(
                        data.message
                        || 'Login background removed.',
                        true
                    );

                    window.setTimeout(
                        function () {
                            window.location.reload();
                        },
                        350
                    );

                } catch (error) {

                    showMessage(
                        error.message
                        || 'Unable to remove the background.',
                        false
                    );

                    removeBackground.disabled = false;
                }

            }
        );
    }



    const animationCanvas =
        document.getElementById(
            'appearanceLoginPreviewAnimation'
        );

    let loginAnimation = null;


    /*
     * Login animation preview.
     *
     * Rendering is shared with Banner through
     * /js/portal-animation.js.
     */
    function refreshAnimationPreview() {

        if (
            !animationCanvas
            || !preview
            || !window.PortalAnimation
            || !animationEnabled
            || !animationStyle
            || !animationIntensity
        ) {
            return;
        }

        const options = {
            canvas:
                animationCanvas,

            container:
                preview,

            enabled:
                animationEnabled.checked,

            style:
                animationStyle.value,

            intensity:
                animationIntensity.value
        };

        if (!loginAnimation) {

            loginAnimation =
                new window.PortalAnimation(
                    options
                );

            return;
        }

        loginAnimation.setOptions(
            options
        );
    }


    function initialiseAppearanceCustomSelect(customSelect) {

        const selectId =
            customSelect.dataset.selectId;

        const nativeSelect =
            document.getElementById(selectId);

        const button =
            customSelect.querySelector(
                '.appearance-custom-select-button'
            );

        const buttonText =
            customSelect.querySelector(
                '.appearance-custom-select-text'
            );

        const menu =
            customSelect.querySelector(
                '.appearance-custom-select-menu'
            );

        if (
            !nativeSelect
            || !button
            || !buttonText
            || !menu
        ) {
            return;
        }


        function closeMenu() {

            menu.hidden = true;

            button.setAttribute(
                'aria-expanded',
                'false'
            );
        }


        function syncControl() {

            const selected =
                nativeSelect.options[
                    nativeSelect.selectedIndex
                ];

            buttonText.textContent =
                selected
                    ? selected.textContent.trim()
                    : '';

            button.disabled =
                nativeSelect.disabled;

            menu
                .querySelectorAll('[data-value]')
                .forEach(option => {

                    const active =
                        option.dataset.value
                        === nativeSelect.value;

                    option.classList.toggle(
                        'is-selected',
                        active
                    );

                    option.setAttribute(
                        'aria-selected',
                        active ? 'true' : 'false'
                    );

                });
        }


        button.addEventListener(
            'click',
            function () {

                if (button.disabled) {
                    return;
                }

                const opening =
                    menu.hidden;

                document
                    .querySelectorAll(
                        '.appearance-custom-select-menu'
                    )
                    .forEach(otherMenu => {

                        if (otherMenu !== menu) {
                            otherMenu.hidden = true;

                            const otherButton =
                                otherMenu
                                    .closest(
                                        '.appearance-custom-select'
                                    )
                                    ?.querySelector(
                                        '.appearance-custom-select-button'
                                    );

                            if (otherButton) {
                                otherButton.setAttribute(
                                    'aria-expanded',
                                    'false'
                                );
                            }
                        }

                    });

                menu.hidden =
                    !opening;

                button.setAttribute(
                    'aria-expanded',
                    opening ? 'true' : 'false'
                );
            }
        );


        menu
            .querySelectorAll('[data-value]')
            .forEach(option => {

                option.addEventListener(
                    'click',
                    function () {

                        nativeSelect.value =
                            this.dataset.value;

                        nativeSelect.dispatchEvent(
                            new Event(
                                'change',
                                { bubbles: true }
                            )
                        );

                        syncControl();
                        closeMenu();
                    }
                );

            });


        nativeSelect.addEventListener(
            'change',
            syncControl
        );


        const observer =
            new MutationObserver(
                syncControl
            );

        observer.observe(
            nativeSelect,
            {
                attributes: true,
                attributeFilter: ['disabled']
            }
        );


        document.addEventListener(
            'click',
            function (event) {

                if (
                    !customSelect.contains(
                        event.target
                    )
                ) {
                    closeMenu();
                }
            }
        );


        button.addEventListener(
            'keydown',
            function (event) {

                if (event.key === 'Escape') {
                    closeMenu();
                }
            }
        );


        syncControl();
    }


    document
        .querySelectorAll(
            '.appearance-custom-select'
        )
        .forEach(
            initialiseAppearanceCustomSelect
        );


    const loginPositionCustom =
        document.getElementById('loginPositionCustom');

    const loginPositionButton =
        document.getElementById('loginPositionButton');

    const loginPositionButtonText =
        document.getElementById('loginPositionButtonText');

    const loginPositionMenu =
        document.getElementById('loginPositionMenu');


    function closeLoginPositionMenu() {

        loginPositionMenu.hidden = true;

        loginPositionButton.setAttribute(
            'aria-expanded',
            'false'
        );

    }


    function syncLoginPositionControl() {

        const selected =
            position.options[position.selectedIndex];

        loginPositionButtonText.textContent =
            selected
                ? selected.textContent
                : 'Center';

        loginPositionMenu
            .querySelectorAll('[data-value]')
            .forEach(option => {

                const active =
                    option.dataset.value === position.value;

                option.classList.toggle(
                    'is-selected',
                    active
                );

                option.setAttribute(
                    'aria-selected',
                    active ? 'true' : 'false'
                );

            });

    }


    loginPositionButton.addEventListener(
        'click',
        function () {

            const opening = loginPositionMenu.hidden;

            loginPositionMenu.hidden = !opening;

            loginPositionButton.setAttribute(
                'aria-expanded',
                opening ? 'true' : 'false'
            );

        }
    );


    loginPositionMenu
        .querySelectorAll('[data-value]')
        .forEach(option => {

            option.addEventListener(
                'click',
                function () {

                    position.value =
                        this.dataset.value;

                    position.dispatchEvent(
                        new Event(
                            'change',
                            { bubbles: true }
                        )
                    );

                    syncLoginPositionControl();
                    closeLoginPositionMenu();

                }
            );

        });


    document.addEventListener(
        'click',
        function (event) {

            if (
                !loginPositionCustom.contains(
                    event.target
                )
            ) {
                closeLoginPositionMenu();
            }

        }
    );


    loginPositionButton.addEventListener(
        'keydown',
        function (event) {

            if (event.key === 'Escape') {
                closeLoginPositionMenu();
            }

        }
    );


    syncLoginPositionControl();

    updatePreview();
    refreshAnimationPreview();

})();
</script>

</body>
</html>
