<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Application Blocking')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-applications';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Application Blocking</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;white-space:nowrap}
        .nf-ok{background:var(--theme-basic-success,#237a4b);color:#fff}
        .nf-err{background:var(--theme-basic-error,#b83b3b);color:#fff}
        .nf-warn{background:var(--theme-basic-warning,#c79a00);color:#111827}
        .nf-off{background:var(--theme-basic-button-secondary,#24313a);color:#fff}
        .nf-panel{margin-top:18px;padding:16px;border:1px solid var(--theme-basic-card-border,#637681);border-radius:8px;background:var(--theme-basic-card-background,#18232a);color:var(--theme-basic-card-text,#fff)}
        .nf-panel h3{margin:0 0 6px 0}
        .nf-panel p{margin:0 0 12px 0;font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3)}
        .nf-input{width:200px;padding:6px 10px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:4px;background:var(--theme-basic-input-background,#202c34);color:var(--theme-basic-input-text,#fff);font-size:13px}
        .nf-input-wide{width:420px}
        .nf-btnrow{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
        #nfMsg{margin-top:10px;font-size:13px;display:none}
        #nfMsg.ok{color:var(--theme-basic-success,#237a4b);display:block}
        #nfMsg.err{color:var(--theme-basic-error,#b83b3b);display:block}
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Application Blocking - category and per-application
                enforcement on the appliance.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel um-table-panel">

        <h3 style="margin-top:0">Categories</h3>

        <table id="nfCatTable">
            <thead>
            <tr>
                <th>Category</th>
                <th>Applications</th>
                <th>State</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody id="nfCatBody">
            <tr>
                <td colspan="4">Loading categories from the appliance...</td>
            </tr>
            </tbody>
        </table>

        <div id="nfMsg"></div>

    </div>

    <div class="appearance-panel um-table-panel">

        <h3 style="margin-top:0">Applications</h3>

        <input type="text" class="nf-input nf-input-wide" id="nfAppSearch"
               placeholder="filter applications..." style="margin-bottom:10px">

        <table id="nfAppTable">
            <thead>
            <tr>
                <th>Application</th>
                <th>Category</th>
                <th>Domains</th>
                <th>QUIC</th>
                <th>State</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody id="nfAppBody">
            <tr>
                <td colspan="6">Loading applications from the appliance...</td>
            </tr>
            </tbody>
        </table>

    </div>

    <div class="nf-panel">
        <h3>Custom service</h3>
        <p>
            Your own service (name + the domains it lives on). It appears
            with the curated applications and can join custom groups.
        </p>
        <div class="nf-btnrow">
            <input type="text" class="nf-input" id="nfSvcName" placeholder="service name (lowercase)">
            <input type="text" class="nf-input" id="nfSvcCat" placeholder="category">
            <input type="text" class="nf-input nf-input-wide" id="nfSvcDomains" placeholder="domains, comma separated">
            <button type="button" class="approve-btn" id="nfSvcAdd">Create service</button>
        </div>
        <div id="nfSvcList" style="font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3)"></div>
    </div>

    <div class="nf-panel">
        <h3>Custom group</h3>
        <p>
            A group card that blocks several applications at once.
        </p>
        <div class="nf-btnrow">
            <input type="text" class="nf-input" id="nfGrpName" placeholder="group name">
            <input type="text" class="nf-input nf-input-wide" id="nfGrpDesc" placeholder="description">
            <button type="button" class="approve-btn" id="nfGrpAdd">Create group</button>
        </div>
        <table id="nfGrpTable" style="margin-top:8px">
            <thead>
            <tr>
                <th>Group</th>
                <th>Members</th>
                <th>Add member</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody id="nfGrpBody"></tbody>
        </table>
    </div>

</div>

<script>
(function () {

    const catBody = document.getElementById('nfCatBody');
    const appBody = document.getElementById('nfAppBody');
    const grpBody = document.getElementById('nfGrpBody');
    const svcList = document.getElementById('nfSvcList');
    const message = document.getElementById('nfMsg');
    const search = document.getElementById('nfAppSearch');

    let apps = [];

    function esc(v) {
        return String(v ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');
    }

    function msg(text, ok) {
        if (!text) { message.className = ''; message.textContent = ''; return; }
        message.className = ok ? 'ok' : 'err';
        message.textContent = text;
    }

    function stateBadge(enabled) {
        return enabled
            ? '<span class="nf-badge nf-ok">Blocking</span>'
            : '<span class="nf-badge nf-off">Off</span>';
    }

    function load() {

        fetch('netfortress-api.php?action=applications')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    catBody.innerHTML = '<tr><td colspan="4">' +
                        esc(data.message || 'The appliance is not reachable.') + '</td></tr>';
                    appBody.innerHTML = '<tr><td colspan="6"></td></tr>';
                    return;
                }

                /* --- categories --- */

                const categories = (data.categories || []).slice().sort(function (a, b) {
                    return String(a.name).localeCompare(String(b.name));
                });

                catBody.innerHTML = '';

                categories.forEach(function (cat) {

                    const tr = document.createElement('tr');

                    const state = String(cat.state || (cat.enabled ? 'blocking' : 'off'));
                    const stateClass =
                        state === 'blocking' ? 'nf-ok'
                        : state === 'partial' ? 'nf-warn'
                        : 'nf-off';

                    tr.innerHTML =
                        '<td><strong>' + esc(cat.label || cat.name) + '</strong></td>' +
                        '<td>' + esc((cat.applications || []).join(', ') || 'feed only') + '</td>' +
                        '<td><span class="nf-badge ' + stateClass + '">' + esc(state) + '</span></td>' +
                        '<td>' +
                        '<button type="button" class="' + (cat.enabled ? 'deny-btn' : 'approve-btn') +
                        ' nf-cat-toggle" data-name="' + esc(cat.name) + '" data-enabled="' +
                        (cat.enabled ? '0' : '1') + '">' +
                        (cat.enabled ? 'Turn off' : 'Block') +
                        '</button>' +
                        '</td>';

                    catBody.appendChild(tr);

                });

                /* --- applications --- */

                apps = (data.applications || []).slice().sort(function (a, b) {
                    return String(a.name).localeCompare(String(b.name));
                });

                renderApps();

                /* --- custom groups + services --- */

                const groups = categories.filter(function (cat) {
                    return (cat.applications || []).length > 0 &&
                        String(cat.name).indexOf(' ') < 0 &&
                        cat.feed_source_id === null && !cat.feed;
                });

                renderGroups(categories);
                renderServices();

            })
            .catch(function () {
                catBody.innerHTML = '<tr><td colspan="4">The appliance API is not reachable.</td></tr>';
            });

    }

    function renderApps() {

        const filter = search.value.trim().toLowerCase();

        const visible = apps.filter(function (app) {
            return !filter ||
                String(app.name).toLowerCase().indexOf(filter) >= 0 ||
                String(app.category || '').toLowerCase().indexOf(filter) >= 0;
        });

        appBody.innerHTML = '';

        if (visible.length === 0) {
            appBody.innerHTML = '<tr><td colspan="6">No applications match.</td></tr>';
            return;
        }

        visible.forEach(function (app) {

            const tr = document.createElement('tr');

            tr.innerHTML =
                '<td><strong>' + esc(app.name) + '</strong>' +
                (app.custom ? ' <span class="nf-badge nf-warn">custom</span>' : '') + '</td>' +
                '<td>' + esc(app.category || '-') + '</td>' +
                '<td>' + esc((app.domains || []).length) + '</td>' +
                '<td>' + (app.block_quic
                    ? '<span class="nf-badge nf-ok">QUIC blocked</span>'
                    : '<span class="nf-badge nf-off">QUIC open</span>') + '</td>' +
                '<td>' + stateBadge(app.enabled) + '</td>' +
                '<td>' +
                '<button type="button" class="' + (app.enabled ? 'deny-btn' : 'approve-btn') +
                ' nf-app-toggle" data-name="' + esc(app.name) + '" data-quic="' +
                (app.block_quic ? '1' : '0') + '" data-enabled="' +
                (app.enabled ? '0' : '1') + '">' +
                (app.enabled ? 'Allow' : 'Block') +
                (app.custom ? '</button> <button type="button" class="deny-btn nf-svc-del" data-name="' +
                    esc(app.name) + '">Delete</button>' : '') +
                '</td>';

            appBody.appendChild(tr);

        });

    }

    function renderGroups(categories) {

        grpBody.innerHTML = '';

        /* Curated categories carry a feed; custom groups do not. Only
           the custom groups are manageable here. */

        const candidates = (categories || []).filter(function (cat) {
            return cat.feed_source_id === null && !cat.feed;
        });

        candidates.forEach(function (cat) {

            const tr = document.createElement('tr');
            tr.innerHTML =
                '<td><strong>' + esc(cat.label || cat.name) + '</strong></td>' +
                '<td>' + esc((cat.applications || []).join(', ') || '-') + '</td>' +
                '<td>' +
                '<input type="text" class="nf-input nf-grp-member-input" data-group="' +
                esc(cat.name) + '" placeholder="application name" style="width:160px"> ' +
                '<button type="button" class="table-btn nf-grp-member-add" data-group="' +
                esc(cat.name) + '">Add</button>' +
                '</td>' +
                '<td><button type="button" class="deny-btn nf-grp-del" data-group="' +
                esc(cat.name) + '">Delete</button></td>';

            grpBody.appendChild(tr);

        });

        if (candidates.length === 0) {
            grpBody.innerHTML = '<tr><td colspan="4">No custom groups yet.</td></tr>';
        }

    }

    function renderServices() {

        const customs = apps.filter(function (app) { return app.custom; });

        svcList.textContent = customs.length
            ? 'Custom services: ' + customs.map(function (app) { return app.name; }).join(', ')
            : 'No custom services yet.';

    }

    function post(action, payload, label, silent) {

        if (!silent) { msg('Working: ' + label + '...', true); }

        return fetch('netfortress-api.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    if (!silent) { msg(label + ' completed.', true); }
                } else {
                    msg(data.message || 'The appliance rejected the request.', false);
                }
                load();
                return data;
            })
            .catch(function () {
                msg('The appliance API is not reachable.', false);
                load();
            });

    }

    document.addEventListener('click', function (event) {

        const catToggle = event.target.closest('.nf-cat-toggle');
        if (catToggle) {
            post('category-set', {
                category: catToggle.dataset.name,
                enabled: catToggle.dataset.enabled === '1',
                block_quic: true
            }, (catToggle.dataset.enabled === '1' ? 'Blocking ' : 'Allowing ') + catToggle.dataset.name);
            return;
        }

        const appToggle = event.target.closest('.nf-app-toggle');
        if (appToggle) {
            post('application-set', {
                application: appToggle.dataset.name,
                enabled: appToggle.dataset.enabled === '1',
                block_quic: appToggle.dataset.quic === '1'
            }, (appToggle.dataset.enabled === '1' ? 'Blocking ' : 'Allowing ') + appToggle.dataset.name);
            return;
        }

        const svcDel = event.target.closest('.nf-svc-del');
        if (svcDel) {
            post('service-delete', { name: svcDel.dataset.name }, 'Deleting ' + svcDel.dataset.name);
            return;
        }

        const grpDel = event.target.closest('.nf-grp-del');
        if (grpDel) {
            post('group-delete', { category: grpDel.dataset.group }, 'Deleting group');
            return;
        }

        const grpAdd = event.target.closest('.nf-grp-member-add');
        if (grpAdd) {
            const input = document.querySelector(
                '.nf-grp-member-input[data-group="' + grpAdd.dataset.group + '"]'
            );
            if (input && input.value.trim()) {
                post('group-member-add', {
                    category: grpAdd.dataset.group,
                    application: input.value.trim()
                }, 'Adding member');
            }
            return;
        }

    });

    document.getElementById('nfSvcAdd').addEventListener('click', function () {

        const name = document.getElementById('nfSvcName').value.trim();
        const category = document.getElementById('nfSvcCat').value.trim();
        const domains = document.getElementById('nfSvcDomains').value
            .split(',')
            .map(function (item) { return item.trim(); })
            .filter(Boolean);

        if (!name || !category || domains.length === 0) {
            msg('Service name, category and at least one domain are required.', false);
            return;
        }

        post('service-add', { name: name, category: category, domains: domains }, 'Creating service');

    });

    document.getElementById('nfGrpAdd').addEventListener('click', function () {

        const name = document.getElementById('nfGrpName').value.trim();
        if (!name) {
            msg('Enter a group name.', false);
            return;
        }

        post('group-add', {
            name: name,
            description: document.getElementById('nfGrpDesc').value.trim()
        }, 'Creating group');

    });

    search.addEventListener('input', renderApps);

    load();

})();
</script>

</body>

</html>
