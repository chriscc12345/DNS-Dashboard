<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Block list')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-blocklist';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Block list</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;white-space:nowrap}
        .nf-ok{background:var(--theme-basic-success,#237a4b);color:#fff}
        .nf-err{background:var(--theme-basic-error,#b83b3b);color:#fff}
        .nf-warn{background:var(--theme-basic-warning,#c79a00);color:#111827}
        .nf-off{background:var(--theme-basic-button-secondary,#24313a);color:#fff}
        .nf-panel{margin-top:18px;padding:16px;border:1px solid var(--theme-basic-card-border,#637681);border-radius:8px;background:var(--theme-basic-card-background,#18232a);color:var(--theme-basic-card-text,#fff)}
        .nf-panel h3{margin:0 0 6px 0}
        .nf-panel p{margin:0 0 12px 0;font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3)}
        .nf-input{width:220px;padding:6px 10px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:4px;background:var(--theme-basic-input-background,#202c34);color:var(--theme-basic-input-text,#fff);font-size:13px}
        .nf-input-wide{width:420px}
        .nf-btnrow{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px}
        #nfMsg{margin-top:10px;font-size:13px;display:none}
        #nfMsg.ok{color:var(--theme-basic-success,#237a4b);display:block}
        #nfMsg.err{color:var(--theme-basic-error,#b83b3b);display:block}
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Block list - the blocklist feeds the appliance enforces.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel um-table-panel">

        <div class="nf-btnrow">
            <button type="button" class="table-btn nf-action" data-op="blocklist-stevenblack">Add StevenBlack feed</button>
            <button type="button" class="table-btn nf-action" data-op="blocklist-feeds">Register curated category feeds</button>
            <button type="button" class="approve-btn nf-action" data-op="blocklists-due" data-force="1">Update all feeds now</button>
        </div>

        <table id="nfTable">
            <thead>
            <tr>
                <th>Feed</th>
                <th>Category</th>
                <th>Format</th>
                <th>Every</th>
                <th>Status</th>
                <th>Domains</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody id="nfBody">
            <tr>
                <td colspan="7">Loading blocklist feeds from the appliance...</td>
            </tr>
            </tbody>
        </table>

        <div id="nfMsg"></div>

    </div>

    <div class="nf-panel">
        <h3>Add a custom feed</h3>
        <p>
            A hosts- or domains-format list fetched from a URL and
            refreshed on the schedule you set.
        </p>
        <div class="nf-btnrow">
            <input type="text" class="nf-input" id="nfName" placeholder="feed name">
            <input type="text" class="nf-input nf-input-wide" id="nfUrl" placeholder="https://example.com/hosts">
            <select class="nf-input" id="nfFormat">
                <option value="hosts">hosts</option>
                <option value="domains">domains</option>
            </select>
            <input type="number" class="nf-input" id="nfHours" placeholder="hours" min="1" max="720" value="24">
            <button type="button" class="approve-btn" id="nfAddBtn">Add feed</button>
        </div>
    </div>

</div>

<script>
(function () {

    const body = document.getElementById('nfBody');
    const message = document.getElementById('nfMsg');

    function esc(v) {
        return String(v ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');
    }

    function msg(text, ok) {
        if (!text) { message.className = ''; message.textContent = ''; return; }
        message.className = ok ? 'ok' : 'err';
        message.textContent = text;
    }

    function load() {

        fetch('netfortress-api.php?action=blocklists')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                if (!data.success) {
                    body.innerHTML = '<tr><td colspan="7">' +
                        esc(data.message || 'The appliance is not reachable.') +
                        '</td></tr>';
                    return;
                }

                body.innerHTML = '';

                const rows = data.blocklists || [];

                if (rows.length === 0) {
                    body.innerHTML = '<tr><td colspan="7">' +
                        'No feeds registered yet. Use the buttons above to add ' +
                        'the curated feeds.</td></tr>';
                    return;
                }

                rows.forEach(function (row) {

                    const status = String(row.status || 'unknown');
                    const statusClass =
                        status === 'healthy' ? 'nf-ok'
                        : status === 'failed' ? 'nf-err'
                        : 'nf-warn';

                    const tr = document.createElement('tr');
                    tr.innerHTML =
                        '<td><strong>' + esc(row.name) + '</strong>' +
                        '<br><small style="color:var(--theme-basic-text-secondary,#aebbc3)">' +
                        esc(row.url) + '</small></td>' +
                        '<td>' + esc(row.category || '-') + '</td>' +
                        '<td>' + esc(row.format || '-') + '</td>' +
                        '<td>' + esc(row.update_hours || '-') + ' h</td>' +
                        '<td><span class="nf-badge ' + statusClass + '">' + esc(status) + '</span></td>' +
                        '<td>' + esc(row.domain_count ?? '-') + '</td>' +
                        '<td>' +
                        '<button type="button" class="table-btn nf-update" data-id="' + row.id + '">Update now</button> ' +
                        '<button type="button" class="deny-btn nf-delete" data-id="' + row.id + '">Remove</button>' +
                        '</td>';

                    body.appendChild(tr);

                });

            })
            .catch(function () {
                body.innerHTML = '<tr><td colspan="7">The appliance API is not reachable.</td></tr>';
            });

    }

    function post(action, payload, label, done) {

        msg('Working: ' + label + '...', true);

        fetch('netfortress-api.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    msg(label + ' completed.', true);
                } else {
                    msg(data.message || 'The appliance rejected the request.', false);
                }
                if (done) { done(); } else { load(); }
            })
            .catch(function () {
                msg('The appliance API is not reachable.', false);
                load();
            });

    }

    document.addEventListener('click', function (event) {

        const update = event.target.closest('.nf-update');
        if (update) {
            update.disabled = true;
            post('blocklist-update', { source_id: parseInt(update.dataset.id, 10) }, 'Updating feed');
            return;
        }

        const del = event.target.closest('.nf-delete');
        if (del) {
            post('blocklist-delete', { source_id: parseInt(del.dataset.id, 10) }, 'Removing feed');
            return;
        }

        const action = event.target.closest('.nf-action');
        if (action) {
            action.disabled = true;
            post(action.dataset.op, { force: action.dataset.force === '1' },
                action.dataset.op === 'blocklists-due' ? 'Updating all feeds' : 'Registering feeds',
                function () { action.disabled = false; load(); });
        }

    });

    document.getElementById('nfAddBtn').addEventListener('click', function () {

        const name = document.getElementById('nfName').value.trim();
        const url = document.getElementById('nfUrl').value.trim();

        if (!name || !url) {
            msg('Enter a feed name and URL.', false);
            return;
        }

        post('blocklist-add', {
            name: name,
            url: url,
            format: document.getElementById('nfFormat').value,
            update_hours: parseInt(document.getElementById('nfHours').value, 10) || 24
        }, 'Adding feed');

    });

    load();

})();
</script>

</body>

</html>
