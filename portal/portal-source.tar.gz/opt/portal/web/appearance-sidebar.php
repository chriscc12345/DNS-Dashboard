<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (!hasPermission('Sidebar')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'appearance-sidebar';
$pageHeading = 'Customization';
$showSidebarPageHeading = true;

$portalSettings =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];


$sidebarWidth =
    (int)(
        $portalSettings['sidebar_width']
        ?? 260
    );

if ($sidebarWidth < 220 || $sidebarWidth > 340) {
    $sidebarWidth = 260;
}


$sidebarAvatarSize =
    (int)(
        $portalSettings['sidebar_avatar_size']
        ?? 64
    );

if (
    $sidebarAvatarSize < 36
    ||
    $sidebarAvatarSize > 90
) {
    $sidebarAvatarSize = 64;
}


$sidebarNavTextSize =
    (int)(
        $portalSettings['sidebar_nav_text_size']
        ?? 15
    );

if (
    $sidebarNavTextSize < 13
    ||
    $sidebarNavTextSize > 20
) {
    $sidebarNavTextSize = 15;
}


$sidebarLogoSize =
    (int)(
        $portalSettings['sidebar_logo_size']
        ?? 104
    );

if (
    $sidebarLogoSize < 40
    ||
    $sidebarLogoSize > 180
) {
    $sidebarLogoSize = 104;
}


$sidebarCollapseButtonSize =
    (int)(
        $portalSettings['sidebar_collapse_button_size']
        ?? 46
    );

if (
    $sidebarCollapseButtonSize < 36
    ||
    $sidebarCollapseButtonSize > 64
) {
    $sidebarCollapseButtonSize = 46;
}


$canEditSidebarLogo =
    hasPermission('Logo');


/*
 * UPDATE003 - Sidebar editor preview branding.
 */
$previewCompanyLogo =
    trim(
        (string)(
            $portalSettings['company_logo']
            ?? ''
        )
    );

if (
    $previewCompanyLogo !== ''
    &&
    !preg_match(
        '#^uploads/appearance/logo_[a-f0-9]{32}\\.webp$#',
        $previewCompanyLogo
    )
) {
    $previewCompanyLogo = '';
}


$previewProfilePhoto = '';

$previewUsername =
    isset($_SESSION['username'])
        ? trim((string)$_SESSION['username'])
        : '';

if ($previewUsername !== '') {

    $previewProfileResponse =
        @file_get_contents(
            $FASTAPI_URL
            . '/user-profiles/'
            . rawurlencode($previewUsername)
        );

    if ($previewProfileResponse !== false) {

        $previewProfile =
            json_decode(
                $previewProfileResponse,
                true
            );

        if (is_array($previewProfile)) {

            $candidatePhoto =
                trim(
                    (string)(
                        $previewProfile['photo']
                        ?? ''
                    )
                );

            if (
                preg_match(
                    '#^uploads/profiles/profile_[a-f0-9]{32}\\.webp$#',
                    $candidatePhoto
                )
            ) {
                $previewProfilePhoto =
                    $candidatePhoto;
            }
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>

    <title>Appearance - Sidebar</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined"
        rel="stylesheet">

</head>

<body>

<?php include 'includes/banner.php'; ?>
<?php include 'includes/sidebar.php'; ?>


<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Appearance</h1>

            <p>
                Configure the layout and sizing of the Basic theme sidebar.
            </p>
        </div>

    </div>


        <?php include __DIR__ . '/includes/page-tabs.php'; ?>


    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Sidebar Layout</h2>

                <p>
                    Adjust the expanded sidebar while keeping the compact
                    collapsed layout unchanged.
                </p>
            </div>

        </div>


        <div class="appearance-sidebar-layout">

            <div class="appearance-sidebar-preview-wrap">

                <div
                    class="appearance-sidebar-preview"
                    id="sidebarPreview">

                    <div class="appearance-sidebar-preview-logo">

                        <?php if($previewCompanyLogo !== ''): ?>

                        <img
                            src="<?= htmlspecialchars($previewCompanyLogo) ?>"
                            alt="Company logo"
                            class="appearance-sidebar-preview-logo-image">

                        <?php else: ?>

                        <span class="material-symbols-outlined">
                            business
                        </span>

                        <span>Company Logo</span>

                        <?php endif; ?>

                    </div>


                    <div class="appearance-sidebar-preview-nav">

                        <div class="active">
                            <span class="material-symbols-outlined">
                                home
                            </span>

                            <span class="preview-nav-text">
                                Dashboard
                            </span>
                        </div>

                        <div>
                            <span class="material-symbols-outlined">
                                pending_actions
                            </span>

                            <span class="preview-nav-text">
                                Pending
                            </span>
                        </div>

                        <div>
                            <span class="material-symbols-outlined">
                                group
                            </span>

                            <span class="preview-nav-text">
                                Users
                            </span>
                        </div>

                        <div>
                            <span class="material-symbols-outlined">
                                settings
                            </span>

                            <span class="preview-nav-text">
                                Settings
                            </span>
                        </div>

                    </div>


                    <div class="appearance-sidebar-preview-bottom">

                        <div class="appearance-sidebar-preview-bottom-action">

                            <span class="material-symbols-outlined">
                                keyboard_double_arrow_left
                            </span>

                            <span class="preview-nav-text">
                                Collapse
                            </span>

                        </div>


                        <div class="appearance-sidebar-preview-bottom-action">

                            <span class="material-symbols-outlined">
                                logout
                            </span>

                            <span class="preview-nav-text">
                                Logout
                            </span>

                        </div>


                        <div class="appearance-sidebar-preview-user">

                            <div
                                class="appearance-sidebar-preview-avatar"
                                id="sidebarPreviewAvatar">

                                <?php if($previewProfilePhoto !== ''): ?>

                                <img
                                    src="<?= htmlspecialchars($previewProfilePhoto) ?>"
                                    alt=""
                                    class="appearance-sidebar-preview-profile-photo">

                                <?php else: ?>

                                <span class="material-symbols-outlined">
                                    person
                                </span>

                                <?php endif; ?>

                            </div>

                            <div class="appearance-sidebar-preview-user-text">
                                <small>Logged in as:</small>
                                <strong>Portal User</strong>
                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <div class="appearance-sidebar-options">

                <div class="appearance-sidebar-control">

                    <div class="appearance-sidebar-control-heading">
                        <div>
                            <strong>Sidebar Width</strong>

                            <small>
                                Width of the expanded desktop sidebar.
                            </small>
                        </div>

                        <span id="sidebarWidthValue">
                            <?= $sidebarWidth ?> px
                        </span>
                    </div>

                    <input
                        type="range"
                        id="sidebarWidth"
                        min="220"
                        max="340"
                        step="1"
                        value="<?= $sidebarWidth ?>">

                </div>


                <?php if($canEditSidebarLogo): ?>

                <div class="appearance-sidebar-control">

                    <div class="appearance-sidebar-control-heading">
                        <div>
                            <strong>Company Logo Size</strong>

                            <small>
                                Size of the company logo in the expanded sidebar.
                            </small>
                        </div>

                        <span id="sidebarLogoSizeValue">
                            <?= $sidebarLogoSize ?> px
                        </span>
                    </div>

                    <input
                        type="range"
                        id="sidebarLogoSize"
                        min="40"
                        max="180"
                        step="1"
                        value="<?= $sidebarLogoSize ?>">

                </div>

                <?php endif; ?>


                <div class="appearance-sidebar-control">

                    <div class="appearance-sidebar-control-heading">
                        <div>
                            <strong>Profile Picture Size</strong>

                            <small>
                                Size of the signed-in user's picture when
                                the sidebar is expanded.
                            </small>
                        </div>

                        <span id="sidebarAvatarSizeValue">
                            <?= $sidebarAvatarSize ?> px
                        </span>
                    </div>

                    <input
                        type="range"
                        id="sidebarAvatarSize"
                        min="36"
                        max="90"
                        step="1"
                        value="<?= $sidebarAvatarSize ?>">

                </div>


                <div class="appearance-sidebar-control">

                    <div class="appearance-sidebar-control-heading">
                        <div>
                            <strong>Navigation Text Size</strong>

                            <small>
                                Font size used by expanded sidebar
                                navigation labels.
                            </small>
                        </div>

                        <span id="sidebarNavTextSizeValue">
                            <?= $sidebarNavTextSize ?> px
                        </span>
                    </div>

                    <input
                        type="range"
                        id="sidebarNavTextSize"
                        min="13"
                        max="20"
                        step="1"
                        value="<?= $sidebarNavTextSize ?>">

                </div>


                <div class="appearance-sidebar-control">

                    <div class="appearance-sidebar-control-heading">
                        <div>
                            <strong>Collapse Button Size</strong>

                            <small>
                                Size of the collapse button while the sidebar
                                is expanded.
                            </small>
                        </div>

                        <span id="sidebarCollapseButtonSizeValue">
                            <?= $sidebarCollapseButtonSize ?> px
                        </span>
                    </div>

                    <input
                        type="range"
                        id="sidebarCollapseButtonSize"
                        min="36"
                        max="64"
                        step="1"
                        value="<?= $sidebarCollapseButtonSize ?>">

                </div>


                <div class="appearance-sidebar-note">

                    <span class="material-symbols-outlined">
                        info
                    </span>

                    <div>
                        <strong>Collapsed sidebar remains compact</strong>

                        <p>
                            These settings affect the expanded sidebar.
                            The icon-only collapsed layout keeps its fixed
                            compact sizing.
                        </p>
                    </div>

                </div>


                <div class="appearance-sidebar-actions">

                    <button
                        type="button"
                        class="table-btn"
                        id="sidebarSave">
                        Save Sidebar Settings
                    </button>

                    <button
                        type="button"
                        class="table-btn appearance-secondary-btn"
                        id="sidebarReset">
                        Basic Defaults
                    </button>

                </div>

            </div>

        </div>

    </div>

</div>


<div
    id="appearanceSidebarMessage"
    class="appearance-theme-message"
    role="status"
    aria-live="polite">
</div>


<script>
(function () {

    const width =
        document.getElementById('sidebarWidth');

    const avatar =
        document.getElementById('sidebarAvatarSize');

    const navText =
        document.getElementById('sidebarNavTextSize');


    const logoSize =
        document.getElementById('sidebarLogoSize');

    const collapseSize =
        document.getElementById('sidebarCollapseButtonSize');

    const widthValue =
        document.getElementById('sidebarWidthValue');

    const avatarValue =
        document.getElementById('sidebarAvatarSizeValue');

    const navTextValue =
        document.getElementById('sidebarNavTextSizeValue');


    const logoSizeValue =
        document.getElementById('sidebarLogoSizeValue');

    const collapseSizeValue =
        document.getElementById(
            'sidebarCollapseButtonSizeValue'
        );

    const preview =
        document.getElementById('sidebarPreview');

    const previewAvatar =
        document.getElementById('sidebarPreviewAvatar');


    const previewLogo =
        document.querySelector(
            '.appearance-sidebar-preview-logo img'
        );

    const previewCollapse =
        document.querySelector(
            '.appearance-sidebar-preview-bottom-action'
        );

    const previewNavText =
        document.querySelectorAll(
            '.appearance-sidebar-preview .preview-nav-text'
        );

    const saveButton =
        document.getElementById('sidebarSave');

    const resetButton =
        document.getElementById('sidebarReset');

    const message =
        document.getElementById('appearanceSidebarMessage');


    function showMessage(text, success) {

        if (!message) {
            return;
        }

        message.textContent =
            (success ? '✓ ' : '') + text;

        message.classList.toggle(
            'success',
            success
        );

        message.classList.toggle(
            'error',
            !success
        );

        message.classList.add('show');

        window.setTimeout(
            function () {
                message.classList.remove('show');
            },
            3500
        );
    }


    function updatePreview() {

        widthValue.textContent =
            width.value + ' px';

        avatarValue.textContent =
            avatar.value + ' px';

        navTextValue.textContent =
            navText.value + ' px';


        if (logoSize && logoSizeValue) {
            logoSizeValue.textContent =
                logoSize.value + ' px';
        }

        if (collapseSize && collapseSizeValue) {
            collapseSizeValue.textContent =
                collapseSize.value + ' px';
        }


        /*
         * Preview is scaled so the full supported sidebar width
         * remains usable inside the editor.
         */
        const previewWidth =
            Math.round(
                210
                +
                (
                    (Number(width.value) - 220)
                    /
                    120
                )
                * 90
            );

        preview.style.width =
            previewWidth + 'px';


        const previewAvatarSize =
            Math.round(
                38
                +
                (
                    (Number(avatar.value) - 36)
                    /
                    54
                )
                * 34
            );

        previewAvatar.style.width =
            previewAvatarSize + 'px';

        previewAvatar.style.height =
            previewAvatarSize + 'px';

        previewAvatar.style.minWidth =
            previewAvatarSize + 'px';


        if (logoSize && previewLogo) {

            const previewLogoSize =
                Math.round(
                    28
                    +
                    (
                        (Number(logoSize.value) - 40)
                        /
                        140
                    )
                    * 62
                );

            previewLogo.style.maxWidth =
                previewLogoSize + 'px';

            previewLogo.style.maxHeight =
                previewLogoSize + 'px';
        }


        if (collapseSize && previewCollapse) {

            const previewCollapseSize =
                Math.round(
                    32
                    +
                    (
                        (Number(collapseSize.value) - 36)
                        /
                        28
                    )
                    * 18
                );

            previewCollapse.style.width =
                previewCollapseSize + 'px';

            previewCollapse.style.height =
                previewCollapseSize + 'px';

            previewCollapse.style.minWidth =
                previewCollapseSize + 'px';

            previewCollapse.style.minHeight =
                previewCollapseSize + 'px';
        }


        const previewFontSize =
            Math.max(
                12,
                Number(navText.value) - 2
            );

        previewNavText.forEach(
            function (item) {
                item.style.fontSize =
                    previewFontSize + 'px';
            }
        );
    }


    [
        width,
        avatar,
        navText,
        logoSize,
        collapseSize
    ].forEach(
        function (control) {

            if (!control) {
                return;
            }

            control.addEventListener(
                'input',
                updatePreview
            );
        }
    );


    resetButton.addEventListener(
        'click',
        function () {

            width.value = '260';
            avatar.value = '64';
            navText.value = '15';

            if (logoSize) {
                logoSize.value = '104';
            }

            if (collapseSize) {
                collapseSize.value = '46';
            }

            updatePreview();
        }
    );


    saveButton.addEventListener(
        'click',
        async function () {

            saveButton.disabled = true;

            try {

                const response =
                    await fetch(
                        'appearance-api.php',
                        {
                            method: 'POST',

                            headers: {
                                'Content-Type':
                                    'application/json'
                            },

                            body: JSON.stringify({
                                action: 'save',

                                settings: Object.assign(
                                    {
                                        sidebar_width:
                                            width.value,

                                        sidebar_avatar_size:
                                            avatar.value,

                                        sidebar_nav_text_size:
                                            navText.value,

                                        sidebar_collapse_button_size:
                                            collapseSize.value
                                    },

                                    logoSize
                                        ? {
                                            sidebar_logo_size:
                                                logoSize.value
                                        }
                                        : {}
                                )
                            })
                        }
                    );

                const data =
                    await response.json();

                if (
                    !response.ok
                    ||
                    !data.success
                ) {
                    throw new Error(
                        data.message
                        || 'Unable to save Sidebar settings.'
                    );
                }

                showMessage(
                    'Sidebar settings saved.',
                    true
                );

            } catch (error) {

                showMessage(
                    error.message
                    || 'Unable to save Sidebar settings.',
                    false
                );

            } finally {

                saveButton.disabled = false;
            }
        }
    );


    updatePreview();

})();
</script>

</body>
</html>
