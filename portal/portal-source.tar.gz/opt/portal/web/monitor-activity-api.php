<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Monitor board activity proxy. Serves the
 * Unblock Queue, Login Feed and Live Activity
 * widgets: the caller's portal permissions
 * decide both access and what the ticker
 * contains. The data comes from the portal
 * API which owns the monitoring and request
 * databases.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

function monitorActivityDenied() {

    http_response_code(403);

    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);

    exit;
}

$action =
    $_GET['action']
    ?? '';

if ($action === 'unblocks') {

    if (
        !hasPermission(
            'Pending Requests'
        )
    ) {
        monitorActivityDenied();
    }

    echo @file_get_contents(
        $FASTAPI_URL . '/unblocks'
    );

    exit;
}

if ($action === 'logins') {

    if (
        !hasPermission(
            'User Management'
        )
    ) {
        monitorActivityDenied();
    }

    echo @file_get_contents(
        $FASTAPI_URL
        . '/api/monitoring/logins'
    );

    exit;
}

if ($action === 'events') {

    $canUsers =
        hasPermission(
            'User Management'
        );

    $canPending =
        hasPermission(
            'Pending Requests'
        );

    if (
        !$canUsers
        && !$canPending
    ) {
        monitorActivityDenied();
    }

    $url =
        $FASTAPI_URL
        . '/api/monitoring/events'
        . '?include_logins='
        . ($canUsers ? '1' : '0')
        . '&include_requests='
        . ($canPending ? '1' : '0');

    echo @file_get_contents($url);

    exit;
}

http_response_code(404);

echo json_encode([
    'success' => false,
    'message' => 'Unknown action.'
]);
