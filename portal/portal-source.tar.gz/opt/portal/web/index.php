<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <title>Access Denied | Network Security Gateway</title>
    <style>
        :root {
            --bg-color: #020204;
            --card-bg: rgba(10, 11, 18, 0.9);
            --text-main: #f3f4f6;
            --text-muted: #4b5563;
            --accent-red: #ef4444;
            --grid-bg: #010102;
            --border-color: rgba(255, 255, 255, 0.06);
            --btn-bg: linear-gradient(180deg, #ef4444 0%, #991b1b 100%);
        }

        body { 
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
            background-color: var(--bg-color); 
            color: var(--text-main); 
            padding: 24px; 
            text-align: center;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 94vh;
            overflow: hidden;
            position: relative;
        }

        /* Increased Matrix Rain Visibility from 0.08 up to a crisp 0.35 */
        #matrix-canvas {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            pointer-events: none;
            opacity: 0.35;
        }

        @keyframes gatewayEntrance {
            0% { opacity: 0; transform: translateY(20px) scale(0.99); }
            100% { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes scanLines {
            0% { transform: translateY(-100%); }
            100% { transform: translateY(100%); }
        }

        .container { 
            max-width: 500px; 
            width: 100%;
            background: var(--card-bg); 
            backdrop-filter: blur(28px);
            -webkit-backdrop-filter: blur(28px);
            border-radius: 16px; 
            padding: 44px 40px; 
            box-shadow: 0 40px 80px -15px rgba(0, 0, 0, 0.95);
            border: 1px solid var(--border-color);
            position: relative;
            z-index: 5;
            animation: gatewayEntrance 0.5s cubic-bezier(0.25, 1, 0.5, 1) forwards;
        }

        .status-accent-bar {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: #ef4444;
            box-shadow: 0 2px 12px rgba(239, 68, 68, 0.6);
            border-top-left-radius: 16px;
            border-top-right-radius: 16px;
        }

        .header-visual {
            width: 100%;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 24px;
        }

        .icon-security-svg { 
            width: 44px;
            height: 44px;
            fill: var(--accent-red);
            filter: drop-shadow(0 0 12px rgba(239, 68, 68, 0.6));
        }
        
        h1 { 
            font-size: 22px; 
            font-weight: 600; 
            margin-top: 0; 
            margin-bottom: 12px;
            letter-spacing: -0.02em;
            color: #ffffff;
        }
        
        p { 
            color: #9ca3af; 
            font-size: 13.5px; 
            line-height: 1.6; 
            margin-bottom: 36px;
            padding: 0 12px;
        }

        .info-grid { 
            text-align: left; 
            background: var(--grid-bg); 
            padding: 20px 24px; 
            border-radius: 10px; 
            font-family: 'SFMono-Regular', Menlo, Monaco, Consolas, monospace; 
            font-size: 13px; 
            border: 1px solid rgba(255, 255, 255, 0.03);
            margin-bottom: 32px;
            position: relative;
            overflow: hidden;
        }

        .info-grid::after {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(rgba(239, 68, 68, 0.04) 0%, transparent 12%, transparent 100%);
            animation: scanLines 6s linear infinite;
            pointer-events: none;
        }

        .info-row { 
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px; 
            border-bottom: 1px solid rgba(255, 255, 255, 0.03); 
            padding-bottom: 12px; 
        }

        .info-row:last-child { 
            border-bottom: none; 
            margin-bottom: 0; 
            padding-bottom: 0; 
        }

        .label { 
            font-weight: 500; 
            color: var(--text-muted); 
            width: 140px; 
            flex-shrink: 0; 
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.05em;
        }

        .value { 
            color: #cbd5e1; 
            word-break: break-all; 
            text-align: right;
            flex-grow: 1;
            font-weight: 500;
        }

        .whitelist-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: var(--btn-bg);
            color: #ffffff;
            text-decoration: none;
            padding: 14px 24px;
            border-radius: 8px;
            font-size: 13.5px;
            font-weight: 500;
            letter-spacing: -0.01em;
            transition: all 0.2s ease-out;
            width: 100%;
            box-sizing: border-box;
            border: 1px solid rgba(0, 0, 0, 0.4);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.15), 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .whitelist-btn:hover {
            transform: translateY(-1px);
            filter: brightness(1.1);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 6px 16px rgba(239, 68, 68, 0.25);
        }
    </style>
</head>
<body>

<canvas id="matrix-canvas"></canvas>

<div class="container">
    <div class="status-accent-bar"></div>
    
    <div class="header-visual">
        <svg class="icon-security-svg" viewBox="0 0 24 24">
            <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
        </svg>
    </div>
    
    <h1>Access Restricted by Local DNS</h1>
    <p>The host connection request was dropped in compliance with local threat intelligence lists.</p>
    
    <div class="info-grid">
        <div class="info-row"><span class="label">Local IP</span><span class="value" id="client-ip"><!--#echo var="REMOTE_ADDR" --></span></div>
        <div class="info-row"><span class="label">Dst Domain</span><span class="value" id="blocked-domain">Unknown</span></div>
        <div class="info-row"><span class="label">Policy Map</span><span class="value">Block List Zone</span></div>
    </div>

    <a href="#" id="whitelist-link" class="whitelist-btn">Request Access</a>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // 1. Context Information Loading
    const currentHost = window.location.hostname || "Unknown Host";
    document.getElementById('blocked-domain').innerText = currentHost;

    const whitelistLink = document.getElementById('whitelist-link');
    
    setInterval(() => {
    
        fetch(`/api/status/${currentHost}`)
            .then(response => response.json())
            .then(data => {
    
                if (data.status === "Pending") {

                    whitelistLink.style.background =
                        'linear-gradient(180deg, #f59e0b 0%, #d97706 100%)';
                
                    whitelistLink.style.borderColor = '#b45309';
                
                    whitelistLink.innerText =
                        'Requested - Pending Approval';
                
                    whitelistLink.style.pointerEvents = 'none';
                }
                if (data.status === "Approved") {
    
                    whitelistLink.style.background =
                        'linear-gradient(180deg, #22c55e 0%, #15803d 100%)';
    
                    whitelistLink.innerText =
                        'Request Approved - Redirecting...';
    
                    whitelistLink.style.pointerEvents = 'none';
    
                    setTimeout(() => {
                        window.location.href =
                            "https://" + currentHost;
                    }, 2000);
                }
    
                if (data.status === "Denied") {
    
                    whitelistLink.style.background =
                        'linear-gradient(180deg, #ef4444 0%, #991b1b 100%)';
    
                    whitelistLink.innerText =
                        'Request Denied';
    
                    whitelistLink.style.pointerEvents = 'none';
                }
    
            })
            .catch(err => console.error(err));
    
    }, 5000);

	whitelistLink.addEventListener('click', function(e) {
		e.preventDefault();

		whitelistLink.innerText = 'Processing...';
		whitelistLink.style.pointerEvents = 'none';


    fetch("/api/request", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            domain: currentHost,
            client_ip: document.getElementById('client-ip').innerText.trim(),
            reason: "Block List Zone"
        })
    })
		.then(response => {
			if (!response.ok) {
				throw new Error('Server returned error status: ' + response.status);
			}
			return response.json();
		})
    .then(data => {

        if (data.success === false) {

            whitelistLink.style.background =
                'linear-gradient(180deg, #f59e0b 0%, #d97706 100%)';

            whitelistLink.innerText =
                'Request Already Pending Approval';

            whitelistLink.style.pointerEvents = 'none';

            return;
        }

        whitelistLink.style.background =
            'linear-gradient(180deg, #22c55e 0%, #15803d 100%)';

        whitelistLink.innerText =
            'Request Submitted - Awaiting Approval';

        whitelistLink.style.pointerEvents = 'none';
    })

		.catch(err => {
			console.error(err);

			whitelistLink.innerText = 'Request Access / Whitelist';
			whitelistLink.style.pointerEvents = 'auto';

			alert('Could not submit request. Please contact your network administrator.');
		});
	});

    // 2. High-Visibility Matrix Rain Engine
    const canvas = document.getElementById('matrix-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const fontSize = 14;
    let drops = [];
    const matrixChars = "0101011001101001011101".split("");

    function initMatrix() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        const columns = Math.floor(canvas.width / fontSize) + 1;
        drops = [];
        for (let x = 0; x < columns; x++) {
            drops[x] = Math.floor(Math.random() * -35); // Better stagger spread
        }
    }
    
    initMatrix();
    window.addEventListener('resize', initMatrix);

    function drawMatrix() {
        // Toned background clear trailing opacity down from 0.05 to 0.04 to make streams stay brighter longer
        ctx.fillStyle = 'rgba(2, 2, 4, 0.04)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold ' + fontSize + 'px monospace'; // Set font to bold for maximum brightness

        for (let i = 0; i < drops.length; i++) {
            const text = matrixChars[Math.floor(Math.random() * matrixChars.length)];
            const x = i * fontSize;
            const y = drops[i] * fontSize;

            if (y > 0) {
                ctx.fillText(text, x, y);
            }

            if (y > canvas.height && Math.random() > 0.98) {
                drops[i] = 0;
            }
            drops[i]++;
        }
    }

    setInterval(drawMatrix, 35);
});
</script>

</body>
</html>
