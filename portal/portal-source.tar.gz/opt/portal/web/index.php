<?php

/*
 * Portal front door. login.php forwards
 * already-authenticated visitors to the dashboard,
 * so the portal root always lands on the right page.
 *
 * The Access Denied page for blocked-domain arrivals
 * lives at blocked.php (how the active backend presents
 * it is configured with the backend integration).
 */

header('Location: login.php');
exit;
