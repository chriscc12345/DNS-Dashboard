<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

$netfortressSection = 'firewall';

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Firewall</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Firewall - managed on the local Firewall Appliance.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <?php include __DIR__ . '/includes/netfortress-frame.php'; ?>

</div>

</body>

</html>
