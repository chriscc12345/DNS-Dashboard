<?php
require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// User Management tab POST redirects
// work cleanly.
require_once __DIR__
    . '/includes/user-management-tabs-head.php';

if(
    !hasPermission(
        'User Groups'
    )
){
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'groups';
$pageHeading = 'Security';
$showSidebarPageHeading = true;

if(isset($_POST['create_group'])){

    $data = json_encode([
        'group_name'  => $_POST['group_name'],
        'description' => $_POST['description']
    ]);

    $response = json_decode(
        file_get_contents(
            $FASTAPI_URL . "/groups/create",
            false,
            stream_context_create([
                'http' => [
                    'method'  => 'POST',
                    'header'  => "Content-Type: application/json\r\n",
                    'content' => $data
                ]
            ])
        ),
        true
    );

    $groupId = $response['group_id'];

    $permissionsData = json_encode([
        'group_id'    => $groupId,
        'permissions' => $_POST['permissions'] ?? []
    ]);

    file_get_contents(
        $FASTAPI_URL . "/groups/permissions/save",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $permissionsData
            ]
        ])
    );

    header("Location: groups.php");
    exit;
}

if(isset($_POST['update_group'])){

    $data = json_encode([
        'id'          => (int)$_POST['group_id'],
        'group_name'  => $_POST['group_name'],
        'description' => $_POST['description']
    ]);

    file_get_contents(
        $FASTAPI_URL . "/groups/update",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );
    
    $permissionsData = json_encode([
        'group_id' => (int)$_POST['group_id'],
        'permissions' => $_POST['permissions'] ?? []
    ]);
    
    file_get_contents(
        $FASTAPI_URL . "/groups/permissions/save",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $permissionsData
            ]
        ])
    );

    header("Location: groups.php");
    exit;
}

if(isset($_POST['delete_group'])){

    $data = json_encode([
        'id' => (int)$_POST['group_id']
    ]);

    file_get_contents(
        $FASTAPI_URL . "/groups/delete",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: groups.php");
    exit;
}

$json = file_get_contents(
    $FASTAPI_URL . "/groups"
);

$permissionTree = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/permissions/tree"
    ),
    true
);

function renderPermissions($permissions){

    echo "<ul>";

    foreach($permissions as $permission){

        echo "<li>";

        echo "<label>";

        echo "<input
                type='checkbox'
                class='permission-checkbox'
                name='permissions[]'
                value='" . $permission['id'] . "'>";

        echo htmlspecialchars(
            $permission['name']
        );

        echo "</label>";

        if(!empty($permission['children'])){

            renderPermissions(
                $permission['children']
            );

        }

        echo "</li>";
    }

    echo "</ul>";
}

$groups = json_decode($json, true);

/*
 * Server-side group search and page size.
 */

$search =
    trim(
        (string)(
            $_GET['search'] ?? ''
        )
    );

$perPageParam =
    (string)(
        $_GET['per_page'] ?? '10'
    );

$perPage =
    in_array(
        $perPageParam,
        ['10', '25', '50', '100', 'all'],
        true
    )
        ? $perPageParam
        : '10';

if ($search !== '') {

    $groups = array_values(
        array_filter(
            $groups,
            static function ($group) use ($search) {

                $haystack =
                    implode(
                        ' ',
                        [
                            (string)($group[1] ?? ''),
                            (string)($group[2] ?? ''),
                        ]
                    );

                return stripos(
                    $haystack,
                    $search
                ) !== false;
            }
        )
    );
}

if (
    $perPage !== 'all'
    &&
    count($groups) > (int)$perPage
) {

    $groups = array_slice(
        $groups,
        0,
        (int)$perPage
    );
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>User Management - User Groups</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
<?php include __DIR__ . '/includes/favicon.php'; ?>

    
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />    
    
</head>

<body>

<?php include 'includes/sidebar.php'; ?>

<?php include 'includes/banner.php'; ?>


<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>User Management</h1>

            <p>
                Create and manage user groups and their permissions.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/user-management-tabs.php'; ?>

      <div class="table-controls">

          <div class="table-controls-left">

              <button
                  type="button"
                  class="table-btn"
                  onclick="openGroupModal()">

                  Add Group

              </button>

          </div>

          <div class="table-controls-right">

              <form method="get">

                  <input
                      type="text"
                      name="search"
                      placeholder="Search Here"
                      class="table-control"
                      value="<?= htmlspecialchars($search) ?>">

                  <select
                      name="per_page"
                      class="table-control">

                      <option value="10"
                          <?= $perPage == 10 ? 'selected' : '' ?>>
                          10
                      </option>

                      <option value="25"
                          <?= $perPage == 25 ? 'selected' : '' ?>>
                          25
                      </option>

                      <option value="50"
                          <?= $perPage == 50 ? 'selected' : '' ?>>
                          50
                      </option>

                      <option value="100"
                          <?= $perPage == 100 ? 'selected' : '' ?>>
                          100
                      </option>

                      <option value="all"
                          <?= $perPage == 'all' ? 'selected' : '' ?>>
                          All
                      </option>

                  </select>

                  <button
                      type="submit"
                      class="table-btn">
                      Search
                  </button>

                  <a href="groups.php" class="clear-btn">
                      Clear
                  </a>

              </form>

          </div>

      </div>

      <div class="appearance-panel um-table-panel">

      <table>
      
          <tr>
              <th>ID</th>
              <th>Group Name</th>
              <th>Description</th>
              <th>Created</th>
              <th>Actions</th>
          </tr>
      
          <?php foreach($groups as $group): ?>
      
            <tr>
                <td><?= htmlspecialchars($group[0]) ?></td>
                
                <td><?= htmlspecialchars($group[1]) ?></td>
            
                <td><?= htmlspecialchars($group[2]) ?></td>
            
                <td>
                    <?= date(
                        'd M Y H:i',
                        strtotime($group[3])
                    ) ?>
                </td>
            
                <td>
            
                    <button
                        type="button"
                        class="edit-btn"
                        onclick="openEditGroupModal(
                            '<?= $group[0] ?>',
                            '<?= htmlspecialchars($group[1]) ?>',
                            '<?= htmlspecialchars($group[2]) ?>'
                        )">
                    
                        Edit
                    
                    </button>
                    
                    <form
                          method="post"
                          style="display:inline;">
                      
                          <input
                              type="hidden"
                              name="group_id"
                              value="<?= $group[0] ?>">
                      
                          <button
                              type="submit"
                              name="delete_group"
                              class="deny-btn"
                              onclick="return confirm(
                                  'Are you sure you want to delete group: <?= htmlspecialchars($group[1]) ?>?'
                              );">
                      
                              Delete
                      
                          </button>
                      
                      </form>

                    
           
                </td>
            
            </tr>
      
          <?php endforeach; ?>
      
      </table>

      </div>

      <!--
          Both group popups reuse the Add
          User modal classes; .ln-modal
          gives them the shared popup
          styling, widened for the
          permissions tree.
      -->

      <div id="groupModal"
           class="modal ln-modal">

          <div class="user-modal-content
                    add-user-modal">

              <div class="add-user-titlebar">

                  <h3>Add Group</h3>

                  <button
                      type="button"
                      class="add-user-close"
                      onclick="closeGroupModal()"
                      aria-label="Close">
                      &times;
                  </button>

              </div>

              <form method="post">

                  <div class="add-user-layout">

                      <div class="add-user-fields">

                          <div class="add-user-grid">

                              <div class="portal-field">

                                  <label for="add_group_name">
                                      Group Name
                                  </label>

                                  <input
                                      type="text"
                                      name="group_name"
                                      id="add_group_name"
                                      required>

                              </div>

                              <div class="portal-field">

                                  <label for="add_description">
                                      Description
                                  </label>

                                  <input
                                      type="text"
                                      name="description"
                                      id="add_description">

                              </div>

                              <div class="ln-permissions"
                                   style="grid-column:1 / -1;">

                                  <label>Permissions</label>

                                  <div id="addPermissionsContainer">

                                      <?php renderPermissions($permissionTree); ?>

                                  </div>

                              </div>

                          </div>

                      </div>

                  </div>

                  <div class="ln-actions">

                      <button
                          type="submit"
                          name="create_group"
                          class="approve-btn">
                          Create
                      </button>

                      <button
                          type="button"
                          class="deny-btn"
                          onclick="closeGroupModal()">
                          Cancel
                      </button>

                  </div>

              </form>

          </div>

      </div>

      <div
          id="editGroupModal"
          class="modal ln-modal">

          <div class="user-modal-content
                    add-user-modal">

              <div class="add-user-titlebar">

                  <h3>Edit Group Permissions</h3>

                  <button
                      type="button"
                      class="add-user-close"
                      onclick="closeEditGroupModal()"
                      aria-label="Close">
                      &times;
                  </button>

              </div>

              <form method="post">

                  <input
                      type="hidden"
                      id="edit_group_id"
                      name="group_id">

                  <div class="add-user-layout">

                      <div class="add-user-fields">

                          <div class="add-user-grid">

                              <div class="portal-field">

                                  <label for="edit_group_name">
                                      Group Name
                                  </label>

                                  <input
                                      type="text"
                                      id="edit_group_name"
                                      name="group_name"
                                      required>

                              </div>

                              <div class="portal-field">

                                  <label for="edit_description">
                                      Description
                                  </label>

                                  <input
                                      type="text"
                                      id="edit_description"
                                      name="description">

                              </div>

                              <div class="ln-permissions"
                                   style="grid-column:1 / -1;">

                                  <label>Permissions</label>

                                  <div id="editPermissionsContainer">

                                      <?php renderPermissions($permissionTree); ?>

                                  </div>

                              </div>

                          </div>

                      </div>

                  </div>

                  <div class="ln-actions">

                      <button
                          type="submit"
                          name="update_group"
                          class="approve-btn">
                          Save
                      </button>

                      <button
                          type="button"
                          class="deny-btn"
                          onclick="closeEditGroupModal()">
                          Cancel
                      </button>

                  </div>

              </form>

          </div>

      </div>

</div>

<script>

function openGroupModal(){

    document.getElementById(
        'groupModal'
    ).style.display = 'flex';

}

function closeGroupModal(){

    document.getElementById(
        'groupModal'
    ).style.display = 'none';

}

function openEditGroupModal(
    id,
    groupName,
    description
){

    document.getElementById(
        'edit_group_id'
    ).value = id;

    document.getElementById(
        'edit_group_name'
    ).value = groupName;

    document.getElementById(
        'edit_description'
    ).value = description;
    
    document
      .querySelectorAll(
          '#editGroupModal .permission-checkbox'
      )
      .forEach(cb => cb.checked = false);
      
    fetch(
        '/api/groups/' + id + '/permissions'
    )
    .then(response => response.json())
    .then(data => {
    
        data.forEach(permissionId => {
    
        let checkbox =
            document.querySelector(
                '#editGroupModal .permission-checkbox[value="' +
                permissionId +
                '"]'
            );
    
            if(checkbox){
                checkbox.checked = true;
            }
    
        });
        document.getElementById(
            'editGroupModal'
        ).style.display = 'flex';
    });


}

function closeEditGroupModal(){

    document.getElementById(
        'editGroupModal'
    ).style.display = 'none';

}
document
    .querySelectorAll(
        '#addPermissionsContainer .permission-checkbox, ' +
        '#editPermissionsContainer .permission-checkbox'
    )
    .forEach(checkbox => {

        checkbox.addEventListener(
            'change',
            function(){

                let li = this.closest('li');

                let children =
                    li.querySelectorAll(
                        'ul .permission-checkbox'
                    );

                children.forEach(child => {

                    child.checked =
                        this.checked;

                });

                let parentLi =
                    li.parentElement.closest('li');

                while(parentLi){

                    let parentCheckbox =
                        parentLi.querySelector(
                            ':scope > label > .permission-checkbox'
                        );

                    let childCheckboxes =
                        parentLi.querySelectorAll(
                            ':scope > ul .permission-checkbox'
                        );

                    let allChecked = true;

                    childCheckboxes.forEach(cb => {

                        if(!cb.checked){
                            allChecked = false;
                        }

                    });

                    parentCheckbox.checked =
                        allChecked;

                    parentLi =
                        parentLi.parentElement.closest('li');

                }

            }
        );

    });


/* =========================================================
   UPDATE003 - COLLAPSIBLE PERMISSION BRANCHES

   Checkbox = change permission
   Parent row/text = expand/collapse children
   ========================================================= */

document
    .querySelectorAll(
        '#addPermissionsContainer li, ' +
        '#editPermissionsContainer li'
    )
    .forEach(li => {

        const childList =
            li.querySelector(':scope > ul');

        if(!childList){
            return;
        }

        const label =
            li.querySelector(':scope > label');

        if(!label){
            return;
        }

        label.classList.add(
            'permission-branch-label'
        );

        label.setAttribute(
            'title',
            'Click to collapse or expand'
        );

        label.addEventListener(
            'click',
            function(event){

                /*
                 * Checkbox remains completely independent.
                 * It must never trigger collapse/expand.
                 */
                if(
                    event.target.classList.contains(
                        'permission-checkbox'
                    )
                ){
                    return;
                }

                event.preventDefault();

                const collapsed =
                    li.classList.toggle(
                        'permission-branch-collapsed'
                    );

                label.setAttribute(
                    'aria-expanded',
                    collapsed ? 'false' : 'true'
                );

            }
        );

        label.setAttribute(
            'aria-expanded',
            'true'
        );

    });

</script>

</body>
</html>