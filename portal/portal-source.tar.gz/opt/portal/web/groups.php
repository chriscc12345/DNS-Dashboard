<?php
require_once 'auth.php';
require_once 'config.php';

if(
    !hasPermission(
        'User Groups'
    )
){
    include 'includes/access-denied.php';
    exit;
}

$currentPage = 'groups';

if(isset($_POST['create_group'])){

    $data = json_encode([
        'group_name'  => $_POST['group_name'],
        'description' => $_POST['description']
    ]);

    $response = json_decode(
        file_get_contents(
            $FASTAPI_URL . "/groups/create",
            false,
            stream_context_create([
                'http' => [
                    'method'  => 'POST',
                    'header'  => "Content-Type: application/json\r\n",
                    'content' => $data
                ]
            ])
        ),
        true
    );

    $groupId = $response['group_id'];

    $permissionsData = json_encode([
        'group_id'    => $groupId,
        'permissions' => $_POST['permissions'] ?? []
    ]);

    file_get_contents(
        $FASTAPI_URL . "/groups/permissions/save",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $permissionsData
            ]
        ])
    );

    header("Location: groups.php");
    exit;
}

if(isset($_POST['update_group'])){

    $data = json_encode([
        'id'          => (int)$_POST['group_id'],
        'group_name'  => $_POST['group_name'],
        'description' => $_POST['description']
    ]);

    file_get_contents(
        $FASTAPI_URL . "/groups/update",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );
    
    $permissionsData = json_encode([
        'group_id' => (int)$_POST['group_id'],
        'permissions' => $_POST['permissions'] ?? []
    ]);
    
    file_get_contents(
        $FASTAPI_URL . "/groups/permissions/save",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $permissionsData
            ]
        ])
    );

    header("Location: groups.php");
    exit;
}

if(isset($_POST['delete_group'])){

    $data = json_encode([
        'id' => (int)$_POST['group_id']
    ]);

    file_get_contents(
        $FASTAPI_URL . "/groups/delete",
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: groups.php");
    exit;
}

$json = file_get_contents(
    $FASTAPI_URL . "/groups"
);

$permissionTree = json_decode(
    file_get_contents(
        $FASTAPI_URL . "/permissions/tree"
    ),
    true
);

function renderPermissions($permissions){

    echo "<ul>";

    foreach($permissions as $permission){

        echo "<li>";

        echo "<label>";

        echo "<input
                type='checkbox'
                class='permission-checkbox'
                name='permissions[]'
                value='" . $permission['id'] . "'>";

        echo htmlspecialchars(
            $permission['name']
        );

        echo "</label>";

        if(!empty($permission['children'])){

            renderPermissions(
                $permission['children']
            );

        }

        echo "</li>";
    }

    echo "</ul>";
}

$groups = json_decode($json, true);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Groups</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
    <link
        rel="icon"
        type="image/png"
        href="images/favicon.png">
    
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />    
    
</head>

<body>

<?php include 'includes/sidebar.php'; ?>

<div class="banner">
  <img src="images/banner.jpg">
</div>


<div class="content">

    <h1>Groups</h1>

      <button
          type="button"
          class="table-btn"
          onclick="openGroupModal()">
      
          Add Group
      
      </button>
      
      <br><br>
      
      <table>
      
          <tr>
              <th>ID</th>
              <th>Group Name</th>
              <th>Description</th>
              <th>Created</th>
              <th>Actions</th>
          </tr>
      
          <?php foreach($groups as $group): ?>
      
            <tr>
                <td><?= htmlspecialchars($group[0]) ?></td>
                
                <td><?= htmlspecialchars($group[1]) ?></td>
            
                <td><?= htmlspecialchars($group[2]) ?></td>
            
                <td>
                    <?= date(
                        'd M Y H:i',
                        strtotime($group[3])
                    ) ?>
                </td>
            
                <td>
            
                    <button
                        type="button"
                        class="edit-btn"
                        onclick="openEditGroupModal(
                            '<?= $group[0] ?>',
                            '<?= htmlspecialchars($group[1]) ?>',
                            '<?= htmlspecialchars($group[2]) ?>'
                        )">
                    
                        Edit
                    
                    </button>
                    
                    <form
                          method="post"
                          style="display:inline;">
                      
                          <input
                              type="hidden"
                              name="group_id"
                              value="<?= $group[0] ?>">
                      
                          <button
                              type="submit"
                              name="delete_group"
                              class="deny-btn"
                              onclick="return confirm(
                                  'Are you sure you want to delete group: <?= htmlspecialchars($group[1]) ?>?'
                              );">
                      
                              Delete
                      
                          </button>
                      
                      </form>

                    
           
                </td>
            
            </tr>
      
          <?php endforeach; ?>
      
      </table>

      <div id="groupModal" class="modal">
      
          <div class="modal-content">
      
              <h2>Add Group</h2>
      
              <form method="post">
      
                  <label>Group Name</label>
      
                  <input
                      type="text"
                      name="group_name"
                      required>
      
                  <br><br>
      
                  <label>Description</label>
      
                  <input
                      type="text"
                      name="description">
      
                  <hr>

                  <h2>Permissions</h2>
                  
                  <div id="addPermissionsContainer">
                  
                      <?php renderPermissions($permissionTree); ?>
                  
                  </div>
      
                  <button
                      type="submit"
                      name="create_group"
                      class="approve-btn">
      
                      Create
      
                  </button>
      
                  <button
                      type="button"
                      class="deny-btn"
                      onclick="closeGroupModal()">
      
                      Cancel
      
                  </button>
      
              </form>
      
          </div>
      
      </div>
      <div id="editGroupModal" class="modal">

          <div class="modal-content">
      
              <h2>Edit Group Permissions</h2>
      
              <form method="post">
      
                  <input
                      type="hidden"
                      id="edit_group_id"
                      name="group_id">
      
                  <label>Group Name</label>
      
                  <input
                      type="text"
                      id="edit_group_name"
                      name="group_name"
                      required>
      
                  <br><br>
      
                  <label>Description</label>
      
                  <input
                      type="text"
                      id="edit_description"
                      name="description">
                      
                  <hr>
                  <h2>Permissions</h2>
                  
                  <div id="editPermissionsContainer">
                  
                      <?php renderPermissions($permissionTree); ?>
                  
                  </div>
              
                   
                  <button
                      type="submit"
                      name="update_group"
                      class="approve-btn">
      
                      Save
      
                  </button>
      
                  <button
                      type="button"
                      class="deny-btn"
                      onclick="closeEditGroupModal()">
      
                      Cancel
      
                  </button>
      
              </form>
      
          </div>
      
      </div>

</div>

<script>

function openGroupModal(){

    document.getElementById(
        'groupModal'
    ).style.display = 'flex';

}

function closeGroupModal(){

    document.getElementById(
        'groupModal'
    ).style.display = 'none';

}

function openEditGroupModal(
    id,
    groupName,
    description
){

    document.getElementById(
        'edit_group_id'
    ).value = id;

    document.getElementById(
        'edit_group_name'
    ).value = groupName;

    document.getElementById(
        'edit_description'
    ).value = description;
    
    document
      .querySelectorAll(
          '#editGroupModal .permission-checkbox'
      )
      .forEach(cb => cb.checked = false);
      
    fetch(
        '/api/groups/' + id + '/permissions'
    )
    .then(response => response.json())
    .then(data => {
    
        data.forEach(permissionId => {
    
        let checkbox =
            document.querySelector(
                '#editGroupModal .permission-checkbox[value="' +
                permissionId +
                '"]'
            );
    
            if(checkbox){
                checkbox.checked = true;
            }
    
        });
        document.getElementById(
            'editGroupModal'
        ).style.display = 'flex';
    });


}

function closeEditGroupModal(){

    document.getElementById(
        'editGroupModal'
    ).style.display = 'none';

}
document
    .querySelectorAll(
        '#addPermissionsContainer .permission-checkbox, ' +
        '#editPermissionsContainer .permission-checkbox'
    )
    .forEach(checkbox => {

        checkbox.addEventListener(
            'change',
            function(){

                let li = this.closest('li');

                let children =
                    li.querySelectorAll(
                        'ul .permission-checkbox'
                    );

                children.forEach(child => {

                    child.checked =
                        this.checked;

                });

                let parentLi =
                    li.parentElement.closest('li');

                while(parentLi){

                    let parentCheckbox =
                        parentLi.querySelector(
                            ':scope > label > .permission-checkbox'
                        );

                    let childCheckboxes =
                        parentLi.querySelectorAll(
                            ':scope > ul .permission-checkbox'
                        );

                    let allChecked = true;

                    childCheckboxes.forEach(cb => {

                        if(!cb.checked){
                            allChecked = false;
                        }

                    });

                    parentCheckbox.checked =
                        allChecked;

                    parentLi =
                        parentLi.parentElement.closest('li');

                }

            }
        );

    });

</script>

</body>
</html>