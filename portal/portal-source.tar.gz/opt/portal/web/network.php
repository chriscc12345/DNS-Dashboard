<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';

if (
    !hasPermission(
        'Network'
    )
) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'network';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

/*
 * Read the live LAN configuration
 * from the portal API for the initial
 * render.
 */

function portalNetworkState() {

    global $FASTAPI_URL;

    $ch = curl_init(
        $FASTAPI_URL . '/network/interface'
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20
    ]);

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    $json = json_decode($body, true);

    if (
        !is_array($json)
        || ($json['status'] ?? '') !== 'ok'
    ) {
        return null;
    }

    return $json;
}

$networkState = portalNetworkState();

$networkInterface =
    (string)(
        $networkState['interface']
        ?? ''
    );

$networkMethod =
    (string)(
        $networkState['method']
        ?? 'dhcp'
    );

$networkAddress =
    (string)(
        $networkState['address']
        ?? ''
    );

$networkNetmask =
    (string)(
        $networkState['netmask']
        ?? ''
    );

$networkGateway =
    (string)(
        $networkState['gateway']
        ?? ''
    );

$networkDns =
    is_array(
        $networkState['dns'] ?? null
    )
        ? $networkState['dns']
        : [];

$networkDnsText =
    implode("\n", $networkDns);

$networkLive =
    is_array(
        $networkState['live'] ?? null
    )
        ? $networkState['live']
        : [];

$liveAddresses =
    is_array(
        $networkLive['addresses']
        ?? null
    )
        ? implode(
            ', ',
            $networkLive['addresses']
        )
        : 'Unknown';

$liveGateway =
    (string)(
        $networkLive['gateway']
        ?? 'Unknown'
    );

$liveDns =
    is_array(
        $networkLive['dns'] ?? null
    )
        ? implode(
            ', ',
            $networkLive['dns']
        )
        : 'Unknown';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Network - Local Interface</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>Network</h1>

            <p>
                Configure the local network of this server.
            </p>
        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="settings-saved" id="network_saved" hidden>
        Settings saved.
    </div>

    <div class="appearance-panel">

        <div class="appearance-panel-heading">

            <div>
                <h2>Local Interface</h2>

                <p>
                    Current LAN configuration of the primary interface.
                </p>
            </div>

        </div>

        <table class="ssl-table">

            <tr>
                <th>Interface</th>
                <td><?= htmlspecialchars(
                    $networkInterface !== ''
                        ? $networkInterface
                        : 'Unknown'
                ) ?></td>
            </tr>

            <tr>
                <th>Addresses</th>
                <td><?= htmlspecialchars(
                    $liveAddresses
                ) ?></td>
            </tr>

            <tr>
                <th>Gateway</th>
                <td><?= htmlspecialchars(
                    $liveGateway
                ) ?></td>
            </tr>

            <tr>
                <th>DNS Servers</th>
                <td><?= htmlspecialchars(
                    $liveDns
                ) ?></td>
            </tr>

        </table>

        <div class="settings-form network-interface-form">

            <div class="settings-field">

                <label for="net_method">
                    Method
                </label>

                <select
                    id="net_method"
                    class="table-control">

                    <option
                        value="dhcp"
                        <?= $networkMethod === 'dhcp'
                            ? 'selected'
                            : '' ?>>
                        DHCP
                    </option>

                    <option
                        value="static"
                        <?= $networkMethod === 'static'
                            ? 'selected'
                            : '' ?>>
                        Static
                    </option>

                </select>

            </div>

            <div class="settings-field-row">

                <div class="settings-field">

                    <label for="net_address">
                        IP Address
                    </label>

                    <input
                        type="text"
                        id="net_address"
                        value="<?= htmlspecialchars(
                            $networkAddress
                        ) ?>"
                        placeholder="192.168.172.12"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label for="net_netmask">
                        Subnet Mask
                    </label>

                    <input
                        type="text"
                        id="net_netmask"
                        value="<?= htmlspecialchars(
                            $networkNetmask
                        ) ?>"
                        placeholder="255.255.255.0"
                        class="table-control">

                </div>

                <div class="settings-field">

                    <label for="net_gateway">
                        Gateway
                    </label>

                    <input
                        type="text"
                        id="net_gateway"
                        value="<?= htmlspecialchars(
                            $networkGateway
                        ) ?>"
                        placeholder="192.168.172.1"
                        class="table-control">

                </div>

            </div>

            <div class="settings-field">

                <label for="net_dns">
                    DNS Servers
                </label>

                <textarea
                    id="net_dns"
                    class="table-control"
                    rows="3"
                    spellcheck="false"><?= htmlspecialchars(
                        $networkDnsText
                    ) ?></textarea>

                <p class="appearance-help">
                    One DNS server IP per line.
                    Applied with static configuration;
                    DHCP manages DNS automatically.
                </p>

            </div>

            <p class="appearance-help">
                Saving writes the configuration and
                restarts the network service. Changing
                the IP address will disconnect your
                session until you reconnect to the new
                address.
            </p>

            <button
                type="button"
                id="save_network"
                class="approve-btn">
                Save
            </button>

        </div>

    </div>

</div>

<script>
const networkApi =
    'network-api.php';

const networkInterface =
    <?= json_encode(
        $networkInterface
    ) ?>;

const netMethodSelect =
    document.getElementById('net_method');
const netAddressInput =
    document.getElementById('net_address');
const netNetmaskInput =
    document.getElementById('net_netmask');
const netGatewayInput =
    document.getElementById('net_gateway');
const netDnsBox =
    document.getElementById('net_dns');
const networkSavedBox =
    document.getElementById('network_saved');

let networkFlashTimer = null;

function showNetworkMessage(message) {

    networkSavedBox.hidden = false;
    networkSavedBox.textContent = message;

    if (networkFlashTimer) {
        clearTimeout(networkFlashTimer);
    }

    networkFlashTimer = setTimeout(() => {
        networkSavedBox.hidden = true;
    }, 5000);
}

function syncStaticFields() {

    const isStatic =
        netMethodSelect.value === 'static';

    netAddressInput.disabled = !isStatic;
    netNetmaskInput.disabled = !isStatic;
    netGatewayInput.disabled = !isStatic;
}

function applyNetworkView(view) {

    if (
        !view
        || view.success !== true
    ) {
        return;
    }

    netMethodSelect.value =
        view.method || 'dhcp';

    netAddressInput.value =
        view.address || '';

    netNetmaskInput.value =
        view.netmask || '';

    netGatewayInput.value =
        view.gateway || '';

    netDnsBox.value =
        (view.dns || []).join('\n');

    syncStaticFields();
}

netMethodSelect.addEventListener(
    'change',
    syncStaticFields
);

document
    .getElementById('save_network')
    .addEventListener('click', async () => {

        if (
            !confirm(
                'Apply the LAN configuration? '
                + 'The network service will '
                + 'restart.'
            )
        ) {
            return;
        }

        const response = await fetch(
            networkApi,
            {
                method: 'POST',
                body: new URLSearchParams({
                    action: 'apply',
                    interface: networkInterface,
                    method: netMethodSelect.value,
                    address: netAddressInput.value,
                    netmask: netNetmaskInput.value,
                    gateway: netGatewayInput.value,
                    dns: netDnsBox.value
                })
            }
        );

        const json =
            await response.json();

        if (json.success !== true) {
            showNetworkMessage(
                json.message
                    || 'Update failed.'
            );
            return;
        }

        applyNetworkView(json);
        showNetworkMessage(
            'Network configuration applied.'
        );

        setTimeout(() => {
            location.reload();
        }, 1500);
    }
);

syncStaticFields();
</script>

</body>

</html>
