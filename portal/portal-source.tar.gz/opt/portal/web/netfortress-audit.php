<?php

require_once 'auth.php';
require_once 'config.php';

require_once __DIR__
    . '/includes/page-tabs-head.php';

if (!hasPermission('NetFortress Audit Log')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'netfortress-audit';
$pageHeading = 'Services';
$showSidebarPageHeading = true;

?>
<!DOCTYPE html>
<html>
<head>
    <title>NetFortress - Audit Log</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>

    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <style>
        .nf-badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;white-space:nowrap}
        .nf-ok{background:var(--theme-basic-success,#237a4b);color:#fff}
        .nf-err{background:var(--theme-basic-error,#b83b3b);color:#fff}
        .nf-warn{background:var(--theme-basic-warning,#c79a00);color:#111827}
        .nf-btnrow{display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;align-items:center}
        .nf-wbtn{padding:6px 14px;border:1px solid var(--theme-basic-input-border,#637681);border-radius:6px;background:var(--theme-basic-input-background,#202c34);color:var(--theme-basic-input-text,#fff);cursor:pointer;font-size:13px}
        .nf-wbtn.nf-sel{background:var(--theme-basic-button-primary,#c79a00);color:var(--theme-basic-button-primary-text,#111827);border-color:var(--theme-basic-button-primary,#c79a00)}
        #nfMsg{margin-top:10px;font-size:13px;display:none}
        #nfMsg.ok{color:var(--theme-basic-success,#237a4b);display:block}
        #nfMsg.err{color:var(--theme-basic-error,#b83b3b);display:block}
        .nf-details pre{margin:4px 0 0 0;font-size:11px;white-space:pre-wrap;word-break:break-all;max-width:340px}
    </style>

</head>

<body>

<?php include 'includes/banner.php'; ?>

<?php include 'includes/sidebar.php'; ?>

<div class="content appearance-page">

    <div class="appearance-page-header">

        <div>
            <h1>NetFortress</h1>

            <p>
                Audit log - recent administrative actions on the
                local Firewall Appliance.
            </p>

        </div>

    </div>

    <?php include __DIR__ . '/includes/page-tabs.php'; ?>

    <div class="appearance-panel um-table-panel">

        <div class="nf-btnrow">
            <strong style="font-size:13px;margin-right:4px;">Show:</strong>
            <button type="button" class="nf-wbtn" data-hours="1">Last hour</button>
            <button type="button" class="nf-wbtn nf-sel" data-hours="24">Last 24 hours</button>
            <button type="button" class="nf-wbtn" data-hours="168">Last 7 days</button>
            <button type="button" class="nf-wbtn" data-hours="0">Most recent 100</button>
        </div>

        <table id="nfTable">
            <thead>
            <tr>
                <th>Time</th>
                <th>Actor</th>
                <th>Action</th>
                <th>Resource</th>
                <th>Outcome</th>
                <th>Source IP</th>
                <th>Details</th>
            </tr>
            </thead>
            <tbody id="nfBody">
            <tr>
                <td colspan="7">Loading audit entries from the appliance...</td>
            </tr>
            </tbody>
        </table>

        <div id="nfMsg"></div>

        <p style="margin-top:10px;font-size:13px;color:var(--theme-basic-text-secondary,#aebbc3);">
            Only recent audit entries are shown. Older history stays on the
            appliance. The list refreshes automatically every 15 seconds.
        </p>

    </div>

</div>

<script>
(function () {

    const body = document.getElementById('nfBody');
    const message = document.getElementById('nfMsg');

    let windowHours = 24;
    let events = [];
    let loading = false;
    let lastSignature = null;

    function esc(v) {
        return String(v ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;');
    }

    function load() {

        if (loading) { return; }
        loading = true;

        fetch('netfortress-api.php?action=audit')
            .then(function (r) { return r.json(); })
            .then(function (data) {

                loading = false;

                if (!data.success) {
                    lastSignature = null;
                    body.innerHTML = '<tr><td colspan="7">' +
                        esc(data.message || 'The appliance is not reachable.') +
                        '</td></tr>';
                    return;
                }

                /* Only re-render when the data actually changed - a
                   rebuild on every poll causes a visible flash. */

                const signature = JSON.stringify(data);

                if (signature === lastSignature) {
                    return;
                }

                lastSignature = signature;

                events = data.events || [];
                render();

            })
            .catch(function () {
                loading = false;
                body.innerHTML = '<tr><td colspan="7">The appliance API is not reachable.</td></tr>';
            });

    }

    function render() {

        const now = Date.now();

        let visible = events;

        if (windowHours > 0) {
            visible = events.filter(function (e) {
                const t = new Date(e.occurred_at).getTime();
                return !isNaN(t) && (now - t) <= windowHours * 3600000;
            });
        } else {
            visible = events.slice(0, 100);
        }

        body.innerHTML = '';

        if (visible.length === 0) {
            body.innerHTML = '<tr><td colspan="7">No audit entries in this period.</td></tr>';
            return;
        }

        visible.forEach(function (e) {

            const row = document.createElement('tr');

            const outcome = String(e.outcome || '');
            const outcomeClass = outcome === 'failure' ? 'nf-err' : (outcome === 'warning' ? 'nf-warn' : 'nf-ok');

            let details = '';
            if (e.details && typeof e.details === 'object' && Object.keys(e.details).length > 0) {
                details = '<details class="nf-details"><summary>view</summary><pre>' +
                    esc(JSON.stringify(e.details, null, 1)) + '</pre></details>';
            }

            const actor = [e.actor_type, e.actor_id].filter(Boolean).join(' ');

            row.innerHTML =
                '<td>' + esc(new Date(e.occurred_at).toLocaleString()) + '</td>' +
                '<td>' + esc(actor || '-') + '</td>' +
                '<td>' + esc(e.action || '-') + '</td>' +
                '<td>' + esc([e.resource_type, e.resource_id].filter(Boolean).join(' ') || '-') + '</td>' +
                '<td><span class="nf-badge ' + outcomeClass + '">' +
                esc(outcome || 'success') + '</span></td>' +
                '<td>' + esc(e.source_ip || '-') + '</td>' +
                '<td>' + details + '</td>';

            body.appendChild(row);

        });

    }

    document.querySelectorAll('.nf-wbtn').forEach(function (button) {

        button.addEventListener('click', function () {

            document.querySelectorAll('.nf-wbtn').forEach(function (b) {
                b.classList.remove('nf-sel');
            });

            button.classList.add('nf-sel');
            windowHours = parseInt(button.dataset.hours, 10);
            render();

        });

    });

    load();
    setInterval(load, 15000);

})();
</script>

</body>

</html>
