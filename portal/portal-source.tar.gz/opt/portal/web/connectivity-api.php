<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Connectivity status proxy. The browser
 * polls this endpoint to refresh the
 * connectivity table on the Settings page;
 * it forwards the request to the portal
 * API which reads the monitoring servers.
 * The caller must hold the Connectivity
 * Status permission.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

if (
    !hasPermission(
        'Connectivity Status'
    )
) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

echo @file_get_contents(
    $FASTAPI_URL
    . '/api/monitoring/servers'
);
