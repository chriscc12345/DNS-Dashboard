<?php
require_once 'auth.php';
$currentPage = 'admin';

require_once 'config.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_POST['deny'])) {

    $id = intval($_POST['id']);

    $url = $FASTAPI_URL . "/deny/" . $id;

    $result = file_get_contents(
        $url,
        false,
        stream_context_create([
            'http' => [
                'method' => 'POST'
            ]
        ])
    );

    header("Location: admin.php");
    exit;
}

if (isset($_POST['allow'])) {

    $id = intval($_POST['id']);
    $type = $_POST['allow_type'];
    $duration = intval($_POST['duration']);

    $data = json_encode([
        'allow_type' => $type,
        'duration' => $duration
    ]);

    $url = $FASTAPI_URL . "/allow/" . $id;

    $result = file_get_contents(
        $url,
        false,
        stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $data
            ]
        ])
    );

    header("Location: denied.php");
    exit;

}

$json = file_get_contents(
    $FASTAPI_URL . "/pending"
);

$requests = json_decode($json, true);

$search = isset($_GET['search'])
    ? strtolower(trim($_GET['search']))
    : '';

if($search !== ''){

    $requests = array_filter(
        $requests,
        function($row) use ($search){

            return strpos(
                strtolower(
                    implode(' ', $row)
                ),
                $search
            ) !== false;

        }
    );

}

$totalRecords = count($requests);

$perPage = isset($_GET['per_page'])
    ? $_GET['per_page']
    : 10;

if($perPage !== 'all'){

    $requests = array_slice(
        $requests,
        0,
        intval($perPage)
    );

}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Pending Requests</title>

    <link
        rel="stylesheet"
        href="css/style.css">
    
    <link
        rel="icon"
        type="image/png"
        href="images/favicon.png">
        
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
</head>

<body>

<?php include 'includes/sidebar.php'; ?>

<div class="banner">
  <img src="images/banner.jpg">
</div>

<div class="content">

  <h1>Pending Requests</h1>
      <div class="table-controls">
      
            <div class="table-controls-right">
        
                <form method="get">
        
                         
                    <input
                        type="text"
                        name="search"
                        placeholder="Search Here"
                        class="table-control"
                        value="<?= htmlspecialchars($search) ?>">
               
                        <select 
                            name="per_page"
                            class="table-control">
                        
                            <option value="10"
                                <?= $perPage == 10 ? 'selected' : '' ?>>
                                10
                            </option>
                        
                            <option value="25"
                                <?= $perPage == 25 ? 'selected' : '' ?>>
                                25
                            </option>
                        
                            <option value="50"
                                <?= $perPage == 50 ? 'selected' : '' ?>>
                                50
                            </option>
                        
                            <option value="100"
                                <?= $perPage == 100 ? 'selected' : '' ?>>
                                100
                            </option>
                        
                            <option value="all"
                                <?= $perPage == 'all' ? 'selected' : '' ?>>
                                All
                            </option>
                        
                        </select>
        
                    <button 
                        type="submit"
                        class="table-btn">
                        Search
                    </button>
                    
                    <a href="admin.php" class="clear-btn">
                        Clear
                    </a>
        
                </form>
        
            </div>
      
      </div>
      
      <table>
      
      <tr>
          <th>ID</th>
          <th>Domain</th>
          <th>Client IP</th>
          <th>Reason</th>
          <th>Status</th>
          <th>Requested</th>
          <th>Action</th>
      </tr>
      
      <?php foreach($requests as $row): ?>
      
      <tr>
      
          <td><?= htmlspecialchars($row[0]) ?></td>
          <td><?= htmlspecialchars($row[1]) ?></td>
          <td><?= htmlspecialchars($row[2]) ?></td>
          <td><?= htmlspecialchars($row[3]) ?></td>
          <td><?= htmlspecialchars($row[4]) ?></td>
          <td><?= date('d M Y H:i', strtotime($row[5])) ?></td>
      
          <td>
      
              <form method="post">
      
                  <input
                      type="hidden"
                      name="id"
                      value="<?= $row[0] ?>">
      
                  <button
                      type="button"
                      class="approve-btn"
                      onclick="openAllowModal(<?= $row[0] ?>)">
                  
                      Allow
                  
                  </button>
      
                  <button
                      class="deny-btn"
                      name="deny">
                      Deny
                  </button>
      
              </form>
      
          </td>
      
      </tr>
      
      <?php endforeach; ?>
      
      </table>
                
        <div class="table-summary">
             Total Records:
             <strong><?= $totalRecords ?></strong>
        </div>
        <div id="allowModal" class="modal">

            <div class="modal-content">
        
                <h3>Allow Access</h3>
        
                <form method="post">
        
                    <input
                        type="hidden"
                        id="allowRequestId"
                        name="id">
        
                    <label>
        
                        <input
                            type="radio"
                            name="allow_type"
                            value="permanent"
                            checked
                            onchange="toggleDuration()">
                        
                        Permanent
        
                    </label>
        
                    <br><br>
        
                    <label>
        
                        <input
                            type="radio"
                            name="allow_type"
                            value="timed"
                            onchange="toggleDuration()">
                            
                        Timed
        
                    </label>
        
                    <br><br>
        
                    <div id="durationContainer">
                    
                        <select
                            name="duration"
                            id="durationSelect">
                    
                            <option value="15">15 Minutes</option>
                            <option value="30">30 Minutes</option>
                            <option value="60">1 Hour</option>
                            <option value="240">4 Hours</option>
                            <option value="1440">24 Hours</option>
                    
                        </select>
                    
                    </div>
        
                    <br><br>
        
                    <button
                        type="submit"
                        name="allow"
                        class="approve-btn">
        
                        Confirm
        
                    </button>
        
                    <button
                        type="button"
                        class="deny-btn"
                        onclick="closeAllowModal()">
        
                        Cancel
        
                    </button>
        
                </form>
        
            </div>
        
        </div>
        
        <script>
        
        const ws = new WebSocket(
            `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`
        );
        
        ws.onmessage = function(event){
        
            if(event.data === "refresh"){
        
                location.reload();
        
            }
        
        };
        
        </script>
        <script>

        function openAllowModal(id){
        
            document
                .getElementById('allowRequestId')
                .value = id;
        
            document
                .getElementById('allowModal')
                .style.display = 'flex';
        
        }
        
        function closeAllowModal(){
        
            document
                .getElementById('allowModal')
                .style.display = 'none';
        
        }
        
        function toggleDuration(){

                const timed =
                    document.querySelector(
                        'input[value="timed"]'
                    ).checked;
            
                document
                    .getElementById('durationContainer')
                    .style.display =
                        timed ? 'block' : 'none';
            
            }
            
            document
                .querySelectorAll(
                    'input[name="allow_type"]'
                )
                .forEach(radio => {
            
                    radio.addEventListener(
                        'change',
                        toggleDuration
                    );
            
                });
            
            toggleDuration();
        
        </script>
</div>
</body>
</html>