<?php

require_once 'auth.php';
require_once 'config.php';

/*
 * Technitium DHCP proxy. Serves the
 * DHCP tab on the Technitium hub page:
 * scopes and leases management. The
 * caller must hold the DHCP permission.
 */

header(
    'Content-Type: application/json; '
    . 'charset=utf-8'
);

if (
    !hasPermission(
        'DHCP'
    )
) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Access denied.'
    ]);
    exit;
}

function technitiumDhcpCall(
    $path,
    $params = null
) {

    global $TECHNITIUM_HOST, $TECHNITIUM_TOKEN;

    $ch = curl_init(
        'http://' . $TECHNITIUM_HOST
        . ':5380' . $path
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer '
            . $TECHNITIUM_TOKEN
        ],
        CURLOPT_TIMEOUT => 10
    ]);

    if ($params !== null) {
        curl_setopt(
            $ch,
            CURLOPT_POSTFIELDS,
            http_build_query($params)
        );
    }

    $body = curl_exec($ch);
    $code = curl_getinfo(
        $ch,
        CURLINFO_HTTP_CODE
    );

    curl_close($ch);

    if (
        $body === false
        || $code !== 200
    ) {
        return null;
    }

    return json_decode($body, true);
}

function dhcpState() {

    $scopes = technitiumDhcpCall(
        '/api/dhcp/scopes/list'
    );

    $leases = technitiumDhcpCall(
        '/api/dhcp/leases/list'
    );

    if (
        $scopes === null
        || ($scopes['status'] ?? '') !== 'ok'
    ) {
        return null;
    }

    return [
        'success' => true,
        'scopes' =>
            array_values(
                ($scopes['response']
                    ?? [])['scopes']
                    ?? []
            ),
        'leases' =>
            $leases !== null
            && ($leases['status'] ?? '') === 'ok'
                ? array_values(
                    ($leases['response']
                        ?? [])['leases']
                        ?? []
                )
                : []
    ];
}

$action =
    $_GET['action']
    ?? ($_POST['action'] ?? '');

if ($action === 'get') {

    $state = dhcpState();

    if ($state === null) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Failed to read the Technitium '
                . 'DHCP server state.'
        ]);
        exit;
    }

    echo json_encode($state);
    exit;
}

if ($action === 'scope_add') {

    $name = trim(
        (string)($_POST['name'] ?? '')
    );

    $startingAddress = trim(
        (string)(
            $_POST['starting_address'] ?? ''
        )
    );

    $endingAddress = trim(
        (string)(
            $_POST['ending_address'] ?? ''
        )
    );

    $subnetMask = trim(
        (string)(
            $_POST['subnet_mask'] ?? ''
        )
    );

    $leaseDays = (int)(
        $_POST['lease_days'] ?? 7
    );

    $leaseHours = (int)(
        $_POST['lease_hours'] ?? 0
    );

    $leaseMinutes = (int)(
        $_POST['lease_minutes'] ?? 0
    );

    if (
        $name === ''
        || !filter_var(
            $startingAddress,
            FILTER_VALIDATE_IP
        )
        || !filter_var(
            $endingAddress,
            FILTER_VALIDATE_IP
        )
        || !filter_var(
            $subnetMask,
            FILTER_VALIDATE_IP
        )
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Scope name, valid starting '
                . 'and ending addresses and a '
                . 'valid subnet mask are '
                . 'required.'
        ]);
        exit;
    }

    if (
        $leaseDays < 0
        || $leaseDays > 365
        || $leaseHours < 0
        || $leaseHours > 23
        || $leaseMinutes < 0
        || $leaseMinutes > 59
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Lease duration values are out '
                . 'of range.'
        ]);
        exit;
    }

    $result = technitiumDhcpCall(
        '/api/dhcp/scopes/set',
        [
            'name' => $name,
            'startingAddress' => $startingAddress,
            'endingAddress' => $endingAddress,
            'subnetMask' => $subnetMask,
            'leaseTimeDays' => (string)$leaseDays,
            'leaseTimeHours' => (string)$leaseHours,
            'leaseTimeMinutes' => (string)$leaseMinutes
        ]
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'The Technitium DHCP server '
                . 'rejected the new scope.'
        ]);
        exit;
    }

    $state = dhcpState();

    if ($state === null) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Scope created but the state '
                . 'could not be re-read.'
        ]);
        exit;
    }

    $state['message'] = 'Scope created.';
    echo json_encode($state);
    exit;
}

if (
    $action === 'scope_enable'
    || $action === 'scope_disable'
    || $action === 'scope_delete'
) {

    $name = trim(
        (string)($_POST['name'] ?? '')
    );

    if ($name === '') {
        echo json_encode([
            'success' => false,
            'message' => 'Scope name is required.'
        ]);
        exit;
    }

    $path =
        $action === 'scope_enable'
            ? '/api/dhcp/scopes/enable'
            : (
                $action === 'scope_disable'
                    ? '/api/dhcp/scopes/disable'
                    : '/api/dhcp/scopes/delete'
            );

    $result = technitiumDhcpCall(
        $path,
        ['name' => $name]
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'The Technitium DHCP server '
                . 'rejected the request.'
        ]);
        exit;
    }

    $state = dhcpState();

    if ($state === null) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Request done but the state '
                . 'could not be re-read.'
        ]);
        exit;
    }

    $state['message'] =
        $action === 'scope_enable'
            ? 'Scope enabled.'
            : (
                $action === 'scope_disable'
                    ? 'Scope disabled.'
                    : 'Scope deleted.'
            );

    echo json_encode($state);
    exit;
}

if ($action === 'lease_remove') {

    $name = trim(
        (string)($_POST['name'] ?? '')
    );

    $hardwareAddress = trim(
        (string)(
            $_POST['hardware_address'] ?? ''
        )
    );

    if (
        $name === ''
        || $hardwareAddress === ''
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Scope name and hardware '
                . 'address are required.'
        ]);
        exit;
    }

    $result = technitiumDhcpCall(
        '/api/dhcp/leases/remove',
        [
            'name' => $name,
            'hardwareAddress' => $hardwareAddress
        ]
    );

    if (
        $result === null
        || ($result['status'] ?? '') !== 'ok'
    ) {
        echo json_encode([
            'success' => false,
            'message' =>
                'The Technitium DHCP server '
                . 'rejected the request.'
        ]);
        exit;
    }

    $state = dhcpState();

    if ($state === null) {
        echo json_encode([
            'success' => false,
            'message' =>
                'Lease removed but the state '
                . 'could not be re-read.'
        ]);
        exit;
    }

    $state['message'] = 'Lease removed.';
    echo json_encode($state);
    exit;
}

echo json_encode([
    'success' => false,
    'message' => 'Unknown action.'
]);
