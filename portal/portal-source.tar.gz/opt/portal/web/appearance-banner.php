<?php

require_once 'auth.php';
require_once 'config.php';

// Must run before any output so the
// page tabs POST redirects work
// cleanly.
require_once __DIR__
    . '/includes/page-tabs-head.php';


if (!hasPermission('Banner')) {
    include 'includes/access-denied.php';
    exit;
}

$currentSection = 'settings';
$currentPage = 'appearance-banner';
$pageHeading = 'Customization';
$showSidebarPageHeading = true;

$portalSettings =
    json_decode(
        @file_get_contents(
            $FASTAPI_URL . '/portal-settings'
        ),
        true
    );

$portalSettings =
    is_array($portalSettings)
        ? $portalSettings
        : [];

$bannerImage =
    trim(
        (string)(
            $portalSettings['banner_image']
            ?? 'images/banner.jpg'
        )
    );

if ($bannerImage === '') {
    $bannerImage = 'images/banner.jpg';
}

$isDefaultBanner =
    $bannerImage === 'images/banner.jpg';


$bannerZoom =
    (int)(
        $portalSettings['banner_zoom']
        ?? 100
    );

if (
    $bannerZoom < 60
    ||
    $bannerZoom > 500
) {
    $bannerZoom = 100;
}


$bannerPositionX =
    (int)(
        $portalSettings['banner_position_x']
        ?? 50
    );

$bannerPositionY =
    (int)(
        $portalSettings['banner_position_y']
        ?? 50
    );

if (
    $bannerPositionX < 0
    ||
    $bannerPositionX > 100
) {
    $bannerPositionX = 50;
}

if (
    $bannerPositionY < 0
    ||
    $bannerPositionY > 100
) {
    $bannerPositionY = 50;
}


$bannerFitMode =
    strtolower(
        trim(
            (string)(
                $portalSettings['banner_fit_mode']
                ?? 'fit'
            )
        )
    );

if (
    $bannerFitMode !== 'fit'
    &&
    $bannerFitMode !== 'cover'
) {
    $bannerFitMode = 'fit';
}

$bannerIsWebm =
    (bool)preg_match(
        '/\.webm$/i',
        $bannerImage
    );


$bannerAnimationEnabled =
    strtolower(
        trim(
            (string)(
                $portalSettings['banner_animation_enabled']
                ?? 'false'
            )
        )
    ) === 'true';


$bannerAnimationStyle =
    strtolower(
        trim(
            (string)(
                $portalSettings['banner_animation_style']
                ?? 'cyber'
            )
        )
    );


$bannerAnimationStyles = [
    'cyber' => 'Cyber Security',
    'digital_rain' => 'Digital Rain',
    'network_grid' => 'Network Grid',
    'security_scanner' => 'Security Scanner',
];

if (!isset($bannerAnimationStyles[$bannerAnimationStyle])) {
    $bannerAnimationStyle = 'cyber';
}


$bannerAnimationIntensity =
    strtolower(
        trim(
            (string)(
                $portalSettings['banner_animation_intensity']
                ?? 'low'
            )
        )
    );

if (
    $bannerAnimationIntensity !== 'low'
    &&
    $bannerAnimationIntensity !== 'medium'
    &&
    $bannerAnimationIntensity !== 'high'
    &&
    $bannerAnimationIntensity !== 'ultra'
) {
    $bannerAnimationIntensity = 'low';
}

?>
<!DOCTYPE html>
<html>
<head>

    <title>Appearance - Banner</title>

    <link
        rel="stylesheet"
        href="css/style.css">

<?php include __DIR__ . '/includes/favicon.php'; ?>


    <link
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined"
        rel="stylesheet">

</head>

<body>

<?php include 'includes/sidebar.php'; ?>
<?php include 'includes/banner.php'; ?>


<div class="content appearance-page">

    <div class="appearance-page-header">

            <div>
                <h1>Appearance</h1>

                <p>
                    Configure the banner image used by the Basic theme.
                </p>
            </div>
</div>


            <?php include __DIR__ . '/includes/page-tabs.php'; ?>


        <div class="appearance-panel">

            <div class="appearance-panel-heading">

                <div>
                    <h2>Banner Image</h2>

                    <p>
                        Upload the background image displayed
                        across the Basic banner.
                    </p>
                </div>

            </div>


            <div class="appearance-banner-layout">

                <div class="appearance-banner-preview">

                    <div
                        class="appearance-banner-preview-box appearance-banner-editor"
                        id="appearanceBannerEditor"
                        data-zoom="<?= $bannerZoom ?>"
                        data-position-x="<?= $bannerPositionX ?>"
                        data-position-y="<?= $bannerPositionY ?>"
                        data-fit-mode="<?= htmlspecialchars($bannerFitMode) ?>">

                        <?php if($bannerIsWebm): ?>

                        <video
                            id="appearanceBannerPreviewMedia"
                            class="appearance-banner-preview-media"
                            autoplay
                            muted
                            loop
                            playsinline
                            preload="metadata"
                            draggable="false">

                            <source
                                src="<?= htmlspecialchars($bannerImage) ?>"
                                type="video/webm">

                        </video>

                        <?php else: ?>

                        <img
                            id="appearanceBannerPreviewMedia"
                            class="appearance-banner-preview-media"
                            src="<?= htmlspecialchars($bannerImage) ?>"
                            alt="Current banner"
                            draggable="false">

                        <?php endif; ?>

                        <canvas
                            class="appearance-banner-preview-animation"
                            id="appearanceBannerPreviewAnimation"
                            aria-hidden="true">
                        </canvas>

                        <div class="appearance-banner-editor-hint">
                            Drag to reposition · Mouse wheel to zoom
                        </div>

                    </div>

                    <div class="appearance-banner-editor-state">
                        <span id="appearanceBannerPositionValue">
                            X <?= $bannerPositionX ?>% ·
                            Y <?= $bannerPositionY ?>% ·
                            Zoom <?= $bannerZoom ?>%
                        </span>

                        <button
                            type="button"
                            class="table-btn appearance-secondary-btn"
                            id="appearanceCenterBanner">
                            Center Banner
                        </button>
                    </div>


                    <div class="appearance-logo-actions">

                        <button
                            type="button"
                            class="table-btn"
                            id="appearanceChooseBanner">
                            Upload Banner
                        </button>

                        <?php if(!$isDefaultBanner): ?>

                        <button
                            type="button"
                            class="table-btn appearance-secondary-btn"
                            id="appearanceRestoreBanner">
                            Restore Default
                        </button>

                        <?php endif; ?>

                    </div>


                    <p class="appearance-help">
                        JPG, PNG or WebP up to 5 MB, or animated WebM
                        up to 20 MB. Wide landscape media is recommended.
                    </p>

                </div>


                <div class="appearance-logo-options appearance-banner-options">

                    <div class="appearance-option">

                        <span>
                            <strong>Current Banner</strong>

                            <small>
                                <?= $isDefaultBanner
                                    ? 'Basic default banner'
                                    : 'Custom uploaded banner' ?>
                            </small>
                        </span>

                        <span class="appearance-banner-status">
                            <?= $isDefaultBanner
                                ? 'DEFAULT'
                                : 'CUSTOM' ?>
                        </span>

                    </div>


                    <div class="appearance-option">

                        <span>
                            <strong>Display Mode</strong>

                            <small>
                                Fit shows the complete banner. Cover fills
                                the frame and may crop the edges.
                            </small>
                        </span>

                        <select
                            id="appearanceBannerFitMode"
                            class="appearance-select">
                            <option
                                value="fit"
                                <?= $bannerFitMode === 'fit' ? 'selected' : '' ?>>
                                Fit
                            </option>
                            <option
                                value="cover"
                                <?= $bannerFitMode === 'cover' ? 'selected' : '' ?>>
                                Cover
                            </option>
                        </select>

                    </div>


                    <div class="appearance-option">

                        <span>
                            <strong>Banner Geometry</strong>

                            <small>
                                The Basic theme keeps the approved
                                banner height and layout. Changing the
                                image will not resize the banner.
                            </small>
                        </span>

                        <span class="appearance-banner-status">
                            BASIC
                        </span>

                    </div>



                    <div class="appearance-login-animation-section">

                        <div class="appearance-login-animation-heading">
                            <div>
                                <strong>Banner Animation</strong>
                                <small>
                                    Add an animated security layer over the
                                    Banner image without changing its framing.
                                </small>
                            </div>
                        </div>

                        <label class="appearance-option">

                            <span>
                                <strong>Enable Banner Animation</strong>
                                <small>
                                    Display the selected animation behind
                                    Banner content and company logo.
                                </small>
                            </span>

                            <input
                                type="checkbox"
                                id="appearanceBannerAnimationEnabled"
                                <?= $bannerAnimationEnabled ? 'checked' : '' ?>>

                        </label>


                        <div
                            class="appearance-login-animation-settings"
                            id="appearanceBannerAnimationSettings">

                            <div class="appearance-login-field">

                                <label for="appearanceBannerAnimationStyle">
                                    Animation Style
                                </label>

                                <div
                                    class="appearance-custom-select"
                                    data-select-id="appearanceBannerAnimationStyle">

                                    <button
                                        type="button"
                                        class="appearance-custom-select-button"
                                        aria-haspopup="listbox"
                                        aria-expanded="false">

                                        <span class="appearance-custom-select-text">
                                            <?= htmlspecialchars(
                                                $bannerAnimationStyles[
                                                    $bannerAnimationStyle
                                                ]
                                            ) ?>
                                        </span>

                                        <span
                                            class="login-position-chevron"
                                            aria-hidden="true">
                                        </span>

                                    </button>

                                    <div
                                        class="appearance-custom-select-menu"
                                        role="listbox"
                                        hidden>

                                        <?php foreach(
                                            $bannerAnimationStyles
                                            as $animationStyleValue
                                            => $animationStyleLabel
                                        ): ?>

                                        <button
                                            type="button"
                                            data-value="<?= htmlspecialchars(
                                                $animationStyleValue
                                            ) ?>"
                                            role="option">
                                            <?= htmlspecialchars(
                                                $animationStyleLabel
                                            ) ?>
                                        </button>

                                        <?php endforeach; ?>

                                    </div>

                                </div>

                                <select
                                    id="appearanceBannerAnimationStyle"
                                    class="appearance-custom-native-select">

                                    <?php foreach(
                                        $bannerAnimationStyles
                                        as $animationStyleValue
                                        => $animationStyleLabel
                                    ): ?>

                                    <option
                                        value="<?= htmlspecialchars(
                                            $animationStyleValue
                                        ) ?>"
                                        <?= $bannerAnimationStyle
                                            === $animationStyleValue
                                                ? 'selected'
                                                : '' ?>>
                                        <?= htmlspecialchars(
                                            $animationStyleLabel
                                        ) ?>
                                    </option>

                                    <?php endforeach; ?>

                                </select>

                            </div>


                            <div class="appearance-login-field">

                                <label for="appearanceBannerAnimationIntensity">
                                    Animation Intensity
                                </label>

                                <div
                                    class="appearance-custom-select"
                                    data-select-id="appearanceBannerAnimationIntensity">

                                    <button
                                        type="button"
                                        class="appearance-custom-select-button"
                                        aria-haspopup="listbox"
                                        aria-expanded="false">

                                        <span class="appearance-custom-select-text">
                                            <?= htmlspecialchars(
                                                $bannerAnimationIntensity === 'ultra'
                                                    ? 'Ultra High'
                                                    : ucfirst(
                                                        $bannerAnimationIntensity
                                                    )
                                            ) ?>
                                        </span>

                                        <span
                                            class="login-position-chevron"
                                            aria-hidden="true">
                                        </span>

                                    </button>

                                    <div
                                        class="appearance-custom-select-menu"
                                        role="listbox"
                                        hidden>

                                        <button type="button" data-value="low" role="option">
                                            Low
                                        </button>

                                        <button type="button" data-value="medium" role="option">
                                            Medium
                                        </button>

                                        <button type="button" data-value="high" role="option">
                                            High
                                        </button>

                                        <button type="button" data-value="ultra" role="option">
                                            Ultra High
                                        </button>

                                    </div>

                                </div>

                                <select
                                    id="appearanceBannerAnimationIntensity"
                                    class="appearance-custom-native-select">

                                    <option
                                        value="low"
                                        <?= $bannerAnimationIntensity === 'low'
                                            ? 'selected'
                                            : '' ?>>
                                        Low
                                    </option>

                                    <option
                                        value="medium"
                                        <?= $bannerAnimationIntensity === 'medium'
                                            ? 'selected'
                                            : '' ?>>
                                        Medium
                                    </option>

                                    <option
                                        value="high"
                                        <?= $bannerAnimationIntensity === 'high'
                                            ? 'selected'
                                            : '' ?>>
                                        High
                                    </option>

                                    <option
                                        value="ultra"
                                        <?= $bannerAnimationIntensity === 'ultra'
                                            ? 'selected'
                                            : '' ?>>
                                        Ultra High
                                    </option>

                                </select>

                            </div>

                        </div>

                    </div>
                </div>

            </div>

        </div>

</div>


<input
    type="file"
    id="appearanceBannerFile"
    accept="image/jpeg,image/png,image/webp,video/webm"
    hidden>


<div
    id="appearanceBannerMessage"
    class="appearance-message"
    hidden>
</div>


<script src="js/portal-animation.js"></script>

<script>
(function () {

    const chooseButton =
        document.getElementById(
            'appearanceChooseBanner'
        );

    const restoreButton =
        document.getElementById(
            'appearanceRestoreBanner'
        );

    const fileInput =
        document.getElementById(
            'appearanceBannerFile'
        );

    const message =
        document.getElementById(
            'appearanceBannerMessage'
        );

    const editor =
        document.getElementById(
            'appearanceBannerEditor'
        );

    const previewMedia =
        document.getElementById(
            'appearanceBannerPreviewMedia'
        );

    const positionValue =
        document.getElementById(
            'appearanceBannerPositionValue'
        );

    const centerButton =
        document.getElementById(
            'appearanceCenterBanner'
        );

    const fitModeSelect =
        document.getElementById(
            'appearanceBannerFitMode'
        );

    const animationEnabled =
        document.getElementById(
            'appearanceBannerAnimationEnabled'
        );

    const animationStyle =
        document.getElementById(
            'appearanceBannerAnimationStyle'
        );

    const animationIntensity =
        document.getElementById(
            'appearanceBannerAnimationIntensity'
        );

    const animationSettings =
        document.getElementById(
            'appearanceBannerAnimationSettings'
        );

    const animationCanvas =
        document.getElementById(
            'appearanceBannerPreviewAnimation'
        );

    let bannerAnimation = null;


    /*
     * Banner crop state.
     *
     * x/y are actual rendered-media pixel offsets.
     * zoom remains the saved 60..500 UI value.
     *
     * The UI zoom range maps to a multiplier ABOVE the
     * minimum cover scale:
     *
     *   60  = 1.00x minimum cover
     *   200 = 3.00x minimum cover\n     *   500 = 7.29x minimum cover
     */
    const bannerCropState = {

        sourceWidth: 0,
        sourceHeight: 0,

        zoom:
            Number(
                editor?.dataset.zoom
                || 100
            ),

        x: 0,
        y: 0,

        positionX:
            Number(
                editor?.dataset.positionX
                || 50
            ),

        positionY:
            Number(
                editor?.dataset.positionY
                || 50
            ),

        fitMode:
            (
                editor?.dataset.fitMode === 'cover'
                    ? 'cover'
                    : 'fit'
            ),

        dragging: false,
        pointerId: null,

        dragStartX: 0,
        dragStartY: 0,

        mediaStartX: 0,
        mediaStartY: 0
    };


    let wheelSaveTimer = null;


    function clamp(value, minimum, maximum) {

        return Math.min(
            maximum,
            Math.max(
                minimum,
                value
            )
        );
    }


    function bannerZoomMultiplier() {

        const value =
            clamp(
                Number(
                    bannerCropState.zoom
                ) || 60,
                60,
                500
            );

        /*
         * 60  -> 1.00x cover
         * 130 -> 2.00x cover
         * 200 -> 3.00x cover\n         * 500 -> 7.29x cover
         */
        return (
            1
            +
            (
                (value - 60)
                / 70
            )
        );
    }


    function bannerCropMetrics() {

        if (
            !editor
            ||
            bannerCropState.sourceWidth <= 0
            ||
            bannerCropState.sourceHeight <= 0
        ) {
            return null;
        }

        const frameWidth =
            editor.clientWidth;

        const frameHeight =
            editor.clientHeight;

        if (
            frameWidth <= 0
            ||
            frameHeight <= 0
        ) {
            return null;
        }

        const widthScale =
            frameWidth
            / bannerCropState.sourceWidth;

        const heightScale =
            frameHeight
            / bannerCropState.sourceHeight;

        /*
         * Fit:
         *   Entire media is visible at minimum zoom.
         *
         * Cover:
         *   Entire frame is filled at minimum zoom.
         */
        const baseScale =
            bannerCropState.fitMode === 'cover'
                ? Math.max(
                    widthScale,
                    heightScale
                )
                : Math.min(
                    widthScale,
                    heightScale
                );

        const renderScale =
            baseScale
            * bannerZoomMultiplier();

        return {
            frameWidth,
            frameHeight,
            baseScale,
            renderScale,

            renderedWidth:
                bannerCropState.sourceWidth
                * renderScale,

            renderedHeight:
                bannerCropState.sourceHeight
                * renderScale
        };
    }


    function bannerAxisBounds(
        frameSize,
        renderedSize
    ) {

        if (renderedSize >= frameSize) {
            return {
                minimum:
                    frameSize
                    - renderedSize,
                maximum: 0
            };
        }

        return {
            minimum: 0,
            maximum:
                frameSize
                - renderedSize
        };
    }


    function clampBannerCropPosition() {

        const metrics =
            bannerCropMetrics();

        if (!metrics) {
            return;
        }

        const xBounds =
            bannerAxisBounds(
                metrics.frameWidth,
                metrics.renderedWidth
            );

        const yBounds =
            bannerAxisBounds(
                metrics.frameHeight,
                metrics.renderedHeight
            );

        bannerCropState.x =
            clamp(
                bannerCropState.x,
                xBounds.minimum,
                xBounds.maximum
            );

        bannerCropState.y =
            clamp(
                bannerCropState.y,
                yBounds.minimum,
                yBounds.maximum
            );
    }


    function savedPositionToPixels() {

        const metrics =
            bannerCropMetrics();

        if (!metrics) {
            return;
        }

        const xBounds =
            bannerAxisBounds(
                metrics.frameWidth,
                metrics.renderedWidth
            );

        const yBounds =
            bannerAxisBounds(
                metrics.frameHeight,
                metrics.renderedHeight
            );

        bannerCropState.x =
            xBounds.maximum
            - (
                (
                    xBounds.maximum
                    - xBounds.minimum
                )
                * (
                    clamp(
                        bannerCropState.positionX,
                        0,
                        100
                    ) / 100
                )
            );

        bannerCropState.y =
            yBounds.maximum
            - (
                (
                    yBounds.maximum
                    - yBounds.minimum
                )
                * (
                    clamp(
                        bannerCropState.positionY,
                        0,
                        100
                    ) / 100
                )
            );

        clampBannerCropPosition();
    }


    function pixelsToSavedPosition() {

        const metrics =
            bannerCropMetrics();

        if (!metrics) {
            return;
        }

        const xBounds =
            bannerAxisBounds(
                metrics.frameWidth,
                metrics.renderedWidth
            );

        const yBounds =
            bannerAxisBounds(
                metrics.frameHeight,
                metrics.renderedHeight
            );

        const xRange =
            xBounds.maximum
            - xBounds.minimum;

        const yRange =
            yBounds.maximum
            - yBounds.minimum;

        bannerCropState.positionX =
            xRange > 0
                ? clamp(
                    (
                        (
                            xBounds.maximum
                            - bannerCropState.x
                        )
                        / xRange
                    ) * 100,
                    0,
                    100
                )
                : 50;

        bannerCropState.positionY =
            yRange > 0
                ? clamp(
                    (
                        (
                            yBounds.maximum
                            - bannerCropState.y
                        )
                        / yRange
                    ) * 100,
                    0,
                    100
                )
                : 50;
    }


    function updateStateText() {

        if (positionValue) {

            positionValue.textContent =
                'X '
                + Math.round(
                    bannerCropState.positionX
                )
                + '% · Y '
                + Math.round(
                    bannerCropState.positionY
                )
                + '% · Zoom '
                + Math.round(
                    bannerCropState.zoom
                )
                + '% · '
                + (
                    bannerCropState.fitMode === 'cover'
                        ? 'Cover'
                        : 'Fit'
                );
        }


    }


    function renderBannerCrop() {

        const metrics =
            bannerCropMetrics();

        if (
            !previewMedia
            ||
            !metrics
        ) {
            return;
        }


        clampBannerCropPosition();
        pixelsToSavedPosition();


        previewMedia.style.display =
            'block';

        previewMedia.style.width =
            metrics.renderedWidth
            + 'px';

        previewMedia.style.height =
            metrics.renderedHeight
            + 'px';

        previewMedia.style.left =
            bannerCropState.x
            + 'px';

        previewMedia.style.top =
            bannerCropState.y
            + 'px';

        previewMedia.style.transform =
            'none';


        updateStateText();
    }


    function centreBannerCrop() {

        const metrics =
            bannerCropMetrics();

        if (!metrics) {
            return;
        }


        bannerCropState.x =
            (
                metrics.frameWidth
                - metrics.renderedWidth
            ) / 2;

        bannerCropState.y =
            (
                metrics.frameHeight
                - metrics.renderedHeight
            ) / 2;


        renderBannerCrop();
    }


    function initialiseBannerCrop() {

        if (
            !previewMedia
            ||
            !editor
        ) {
            return;
        }


        const isVideo =
            previewMedia.tagName
                .toLowerCase()
            === 'video';


        if (isVideo) {

            bannerCropState.sourceWidth =
                Number(
                    previewMedia.videoWidth
                );

            bannerCropState.sourceHeight =
                Number(
                    previewMedia.videoHeight
                );

        } else {

            bannerCropState.sourceWidth =
                Number(
                    previewMedia.naturalWidth
                );

            bannerCropState.sourceHeight =
                Number(
                    previewMedia.naturalHeight
                );
        }


        if (
            bannerCropState.sourceWidth <= 0
            ||
            bannerCropState.sourceHeight <= 0
        ) {
            return;
        }


        savedPositionToPixels();
        renderBannerCrop();
    }


    let bannerMessageTimer = null;


    function showMessage(text, success) {

        if (!message) {
            return;
        }


        window.clearTimeout(
            bannerMessageTimer
        );


        message.textContent =
            (success ? '✓ ' : '')
            + text;


        message.classList.toggle(
            'success',
            success
        );

        message.classList.toggle(
            'error',
            !success
        );


        message.hidden = false;


        requestAnimationFrame(
            function () {

                message.classList.add(
                    'appearance-banner-toast-visible'
                );
            }
        );


        bannerMessageTimer =
            window.setTimeout(
                function () {

                    message.classList.remove(
                        'appearance-banner-toast-visible'
                    );


                    window.setTimeout(
                        function () {

                            message.hidden = true;

                        },
                        200
                    );
                },

                success
                    ? 1800
                    : 4200
            );
    }


    function setBusy(busy) {

        if (chooseButton) {
            chooseButton.disabled = busy;
        }

        if (restoreButton) {
            restoreButton.disabled = busy;
        }

        if (centerButton) {
            centerButton.disabled = busy;
        }

    }


    async function saveBannerSettings(settings) {

        const response =
            await fetch(
                'appearance-api.php',
                {
                    method: 'POST',

                    headers: {
                        'Content-Type':
                            'application/json'
                    },

                    body: JSON.stringify({
                        action: 'save',
                        settings: settings
                    })
                }
            );

        const data =
            await response.json();

        if (
            !response.ok
            ||
            !data.success
        ) {

            throw new Error(
                data.message
                || 'Unable to save banner settings.'
            );
        }

        return data;
    }


    async function persistFraming(
        includeZoom = true,
        successMessage = ''
    ) {

        pixelsToSavedPosition();


        const settings = {

            banner_position_x:
                Math.round(
                    bannerCropState.positionX
                ),

            banner_position_y:
                Math.round(
                    bannerCropState.positionY
                )
        };


        if (includeZoom) {

            settings.banner_zoom =
                Math.round(
                    bannerCropState.zoom
                );
        }


        setBusy(true);

        try {

            await saveBannerSettings(
                settings
            );

            if (successMessage) {

                showMessage(
                    successMessage,
                    true
                );
            }

        } catch (error) {

            showMessage(
                error.message
                || 'Unable to save banner framing.',
                false
            );

        } finally {

            setBusy(false);
        }
    }


    /*
     * Drag directly on the preview.
     *
     * Position is stored as a normalized focal point
     * from 0..100 rather than raw pixels.
     */
    if (editor) {

        editor.addEventListener(
            'pointerdown',
            function (event) {

                if (event.button !== 0) {
                    return;
                }

                bannerCropState.dragging = true;

                bannerCropState.pointerId =
                    event.pointerId;

                bannerCropState.dragStartX =
                    event.clientX;

                bannerCropState.dragStartY =
                    event.clientY;

                bannerCropState.mediaStartX =
                    bannerCropState.x;

                bannerCropState.mediaStartY =
                    bannerCropState.y;

                editor.setPointerCapture(
                    event.pointerId
                );

                editor.classList.add(
                    'dragging'
                );

                event.preventDefault();
            }
        );


        editor.addEventListener(
            'pointermove',
            function (event) {

                if (
                    !bannerCropState.dragging
                    ||
                    event.pointerId !==
                        bannerCropState.pointerId
                ) {
                    return;
                }

                event.preventDefault();

                bannerCropState.x =
                    bannerCropState.mediaStartX
                    + (
                        event.clientX
                        - bannerCropState.dragStartX
                    );

                bannerCropState.y =
                    bannerCropState.mediaStartY
                    + (
                        event.clientY
                        - bannerCropState.dragStartY
                    );

                renderBannerCrop();
            }
        );


        async function finishDrag(event) {

            if (
                !bannerCropState.dragging
                ||
                event.pointerId !==
                    bannerCropState.pointerId
            ) {
                return;
            }

            bannerCropState.dragging = false;

            editor.classList.remove(
                'dragging'
            );

            try {

                editor.releasePointerCapture(
                    event.pointerId
                );

            } catch (error) {
                // Pointer capture may already be released.
            }

            bannerCropState.pointerId = null;

            await persistFraming(
                false,
                'Banner position saved.'
            );
        }


        editor.addEventListener(
            'pointerup',
            finishDrag
        );

        editor.addEventListener(
            'pointercancel',
            finishDrag
        );


        /*
         * Mouse wheel zoom.
         * Save only after the wheel has stopped briefly.
         */
        editor.addEventListener(
            'wheel',
            function (event) {

                event.preventDefault();

                const before =
                    bannerCropMetrics();

                if (!before) {
                    return;
                }


                const rect =
                    editor.getBoundingClientRect();

                const pointerX =
                    event.clientX
                    - rect.left;

                const pointerY =
                    event.clientY
                    - rect.top;


                const sourceX =
                    (
                        pointerX
                        - bannerCropState.x
                    )
                    / before.renderScale;

                const sourceY =
                    (
                        pointerY
                        - bannerCropState.y
                    )
                    / before.renderScale;


                bannerCropState.zoom =
                    clamp(
                        bannerCropState.zoom
                        + (
                            event.deltaY < 0
                                ? 2
                                : -2
                        ),
                        60,
                        500
                    );


                const after =
                    bannerCropMetrics();

                if (!after) {
                    return;
                }


                bannerCropState.x =
                    pointerX
                    - (
                        sourceX
                        * after.renderScale
                    );

                bannerCropState.y =
                    pointerY
                    - (
                        sourceY
                        * after.renderScale
                    );


                renderBannerCrop();


                window.clearTimeout(
                    wheelSaveTimer
                );

                wheelSaveTimer =
                    window.setTimeout(
                        async function () {

                            await persistFraming(
                                true,
                                'Banner zoom saved.'
                            );

                        },
                        350
                    );

            },
            {
                passive: false
            }
        );
    }


    /*
     * Shared Appearance custom select behaviour.
     */
    function initialiseAppearanceCustomSelect(customSelect) {

        const selectId =
            customSelect.dataset.selectId;

        const nativeSelect =
            document.getElementById(selectId);

        const button =
            customSelect.querySelector(
                '.appearance-custom-select-button'
            );

        const buttonText =
            customSelect.querySelector(
                '.appearance-custom-select-text'
            );

        const menu =
            customSelect.querySelector(
                '.appearance-custom-select-menu'
            );

        if (
            !nativeSelect
            || !button
            || !buttonText
            || !menu
        ) {
            return;
        }


        function closeMenu() {

            menu.hidden = true;

            customSelect.classList.remove(
                'open-up'
            );

            button.setAttribute(
                'aria-expanded',
                'false'
            );
        }


        function syncControl() {

            const selected =
                nativeSelect.options[
                    nativeSelect.selectedIndex
                ];

            buttonText.textContent =
                selected
                    ? selected.textContent.trim()
                    : '';

            button.disabled =
                nativeSelect.disabled;

            menu
                .querySelectorAll('[data-value]')
                .forEach(option => {

                    const active =
                        option.dataset.value
                        === nativeSelect.value;

                    option.classList.toggle(
                        'is-selected',
                        active
                    );

                    option.setAttribute(
                        'aria-selected',
                        active ? 'true' : 'false'
                    );
                });
        }


        button.addEventListener(
            'click',
            function () {

                if (button.disabled) {
                    return;
                }

                const opening =
                    menu.hidden;

                document
                    .querySelectorAll(
                        '.appearance-custom-select-menu'
                    )
                    .forEach(otherMenu => {

                        if (otherMenu !== menu) {

                            otherMenu.hidden = true;

                            const otherButton =
                                otherMenu
                                    .closest(
                                        '.appearance-custom-select'
                                    )
                                    ?.querySelector(
                                        '.appearance-custom-select-button'
                                    );

                            if (otherButton) {
                                otherButton.setAttribute(
                                    'aria-expanded',
                                    'false'
                                );
                            }
                        }
                    });

                if (opening) {

                    /*
                     * Open upward when there is not enough
                     * viewport space below the control.
                     */
                    menu.hidden = false;

                    customSelect.classList.remove(
                        'open-up'
                    );

                    const buttonRect =
                        button.getBoundingClientRect();

                    const menuHeight =
                        menu.scrollHeight;

                    const spaceBelow =
                        window.innerHeight
                        - buttonRect.bottom;

                    const spaceAbove =
                        buttonRect.top;

                    if (
                        spaceBelow < menuHeight + 12
                        && spaceAbove > spaceBelow
                    ) {
                        customSelect.classList.add(
                            'open-up'
                        );
                    }

                } else {

                    menu.hidden = true;
                }

                button.setAttribute(
                    'aria-expanded',
                    opening ? 'true' : 'false'
                );
            }
        );


        menu
            .querySelectorAll('[data-value]')
            .forEach(option => {

                option.addEventListener(
                    'click',
                    function () {

                        nativeSelect.value =
                            this.dataset.value;

                        nativeSelect.dispatchEvent(
                            new Event(
                                'change',
                                {
                                    bubbles: true
                                }
                            )
                        );

                        syncControl();
                        closeMenu();
                    }
                );
            });


        nativeSelect.addEventListener(
            'change',
            syncControl
        );


        const observer =
            new MutationObserver(
                syncControl
            );

        observer.observe(
            nativeSelect,
            {
                attributes: true,
                attributeFilter: [
                    'disabled'
                ]
            }
        );

        syncControl();
    }


    document
        .querySelectorAll(
            '.appearance-custom-select'
        )
        .forEach(
            initialiseAppearanceCustomSelect
        );


    document.addEventListener(
        'click',
        function (event) {

            if (
                event.target.closest(
                    '.appearance-custom-select'
                )
            ) {
                return;
            }

            document
                .querySelectorAll(
                    '.appearance-custom-select-menu'
                )
                .forEach(menu => {

                    menu.hidden = true;

                    const button =
                        menu
                            .closest(
                                '.appearance-custom-select'
                            )
                            ?.querySelector(
                                '.appearance-custom-select-button'
                            );

                    if (button) {
                        button.setAttribute(
                            'aria-expanded',
                            'false'
                        );
                    }
                });
        }
    );


    document.addEventListener(
        'keydown',
        function (event) {

            if (event.key !== 'Escape') {
                return;
            }

            document
                .querySelectorAll(
                    '.appearance-custom-select-menu'
                )
                .forEach(menu => {

                    menu.hidden = true;

                    const button =
                        menu
                            .closest(
                                '.appearance-custom-select'
                            )
                            ?.querySelector(
                                '.appearance-custom-select-button'
                            );

                    if (button) {
                        button.setAttribute(
                            'aria-expanded',
                            'false'
                        );
                    }
                });
        }
    );


    /*
     * Banner animation controls.
     *
     * Banner follows its existing immediate-save behaviour.
     */
    function refreshBannerAnimationPreview() {

        if (
            !animationCanvas
            || !editor
            || !window.PortalAnimation
            || !animationEnabled
            || !animationStyle
            || !animationIntensity
        ) {
            return;
        }

        const options = {
            canvas:
                animationCanvas,

            container:
                editor,

            enabled:
                animationEnabled.checked,

            style:
                animationStyle.value,

            intensity:
                animationIntensity.value
        };

        if (!bannerAnimation) {

            bannerAnimation =
                new window.PortalAnimation(
                    options
                );

            return;
        }

        bannerAnimation.setOptions(
            options
        );
    }


    function updateBannerAnimationControlState() {

        if (
            !animationEnabled
            || !animationStyle
            || !animationIntensity
        ) {
            return;
        }

        const enabled =
            animationEnabled.checked;

        animationStyle.disabled =
            !enabled;

        animationIntensity.disabled =
            !enabled;

        if (animationSettings) {

            animationSettings.classList.toggle(
                'is-disabled',
                !enabled
            );
        }
    }


    async function persistBannerAnimation(
        successMessage
    ) {

        if (
            !animationEnabled
            || !animationStyle
            || !animationIntensity
        ) {
            return;
        }

        setBusy(true);

        animationEnabled.disabled = true;
        animationStyle.disabled = true;
        animationIntensity.disabled = true;

        try {

            await saveBannerSettings({
                banner_animation_enabled:
                    animationEnabled.checked
                        ? 'true'
                        : 'false',

                banner_animation_style:
                    animationStyle.value,

                banner_animation_intensity:
                    animationIntensity.value
            });

            showMessage(
                successMessage
                || 'Banner animation settings saved.',
                true
            );

        } catch (error) {

            showMessage(
                error.message
                || 'Unable to save Banner animation settings.',
                false
            );

        } finally {

            animationEnabled.disabled = false;

            updateBannerAnimationControlState();
            setBusy(false);
        }
    }


    if (animationEnabled) {

        animationEnabled.addEventListener(
            'change',
            async function () {

                updateBannerAnimationControlState();
                refreshBannerAnimationPreview();

                await persistBannerAnimation(
                    animationEnabled.checked
                        ? 'Banner animation enabled.'
                        : 'Banner animation disabled.'
                );
            }
        );
    }


    if (animationStyle) {

        animationStyle.addEventListener(
            'change',
            async function () {

                refreshBannerAnimationPreview();

                await persistBannerAnimation(
                    'Banner animation style saved.'
                );
            }
        );
    }


    if (animationIntensity) {

        animationIntensity.addEventListener(
            'change',
            async function () {

                refreshBannerAnimationPreview();

                await persistBannerAnimation(
                    'Banner animation intensity saved.'
                );
            }
        );
    }


    updateBannerAnimationControlState();
    refreshBannerAnimationPreview();


    /*
     * Fit / Cover display mode.
     *
     * Switching modes keeps the saved focal position and zoom.
     * It does not reset the user's framing.
     */
    if (fitModeSelect) {

        fitModeSelect.addEventListener(
            'change',
            async function () {

                const requestedMode =
                    fitModeSelect.value === 'cover'
                        ? 'cover'
                        : 'fit';

                bannerCropState.fitMode =
                    requestedMode;

                savedPositionToPixels();
                renderBannerCrop();

                setBusy(true);

                try {

                    await saveBannerSettings({
                        banner_fit_mode:
                            requestedMode
                    });

                    showMessage(
                        'Banner display mode saved.',
                        true
                    );

                } catch (error) {

                    showMessage(
                        error.message
                        || 'Unable to save banner display mode.',
                        false
                    );

                } finally {

                    setBusy(false);
                }
            }
        );
    }


    /*
     * Center framing.
     */
    if (centerButton) {

        centerButton.addEventListener(
            'click',
            async function () {

                centreBannerCrop();

                await persistFraming(
                    false,
                    'Banner centered.'
                );
            }
        );
    }


    /*
     * Upload static image or WebM.
     */
    if (
        chooseButton
        &&
        fileInput
    ) {

        chooseButton.addEventListener(
            'click',
            function () {

                fileInput.value = '';
                fileInput.click();
            }
        );


        fileInput.addEventListener(
            'change',
            async function () {

                const file =
                    fileInput.files[0];

                if (!file) {
                    return;
                }


                const imageTypes = [
                    'image/jpeg',
                    'image/png',
                    'image/webp'
                ];

                const isImage =
                    imageTypes.includes(
                        file.type
                    );

                const isWebm =
                    file.type === 'video/webm';


                if (
                    !isImage
                    &&
                    !isWebm
                ) {

                    showMessage(
                        'Please select JPG, PNG, WebP or WebM.',
                        false
                    );

                    return;
                }


                const maximumSize =
                    isWebm
                        ? (20 * 1024 * 1024)
                        : (5 * 1024 * 1024);


                if (
                    file.size <= 0
                    ||
                    file.size > maximumSize
                ) {

                    showMessage(
                        isWebm
                            ? 'WebM banner must be 20 MB or smaller.'
                            : 'Image banner must be 5 MB or smaller.',
                        false
                    );

                    return;
                }


                const formData =
                    new FormData();

                formData.append(
                    'action',
                    'upload'
                );

                formData.append(
                    'banner',
                    file
                );


                setBusy(true);

                try {

                    const response =
                        await fetch(
                            'appearance-banner-upload.php',
                            {
                                method: 'POST',
                                body: formData
                            }
                        );

                    const data =
                        await response.json();


                    if (
                        !response.ok
                        ||
                        !data.success
                    ) {

                        throw new Error(
                            data.message
                            || 'Banner upload failed.'
                        );
                    }


                    showMessage(
                        data.message
                        || 'Banner uploaded.',
                        true
                    );


                    window.setTimeout(
                        function () {
                            window.location.reload();
                        },
                        450
                    );

                } catch (error) {

                    showMessage(
                        error.message
                        || 'Banner upload failed.',
                        false
                    );

                    setBusy(false);
                }
            }
        );
    }


    /*
     * Restore immutable Basic factory banner.
     */
    if (restoreButton) {

        restoreButton.addEventListener(
            'click',
            async function () {

                if (
                    !window.confirm(
                        'Restore the Basic default banner?'
                    )
                ) {
                    return;
                }


                const formData =
                    new FormData();

                formData.append(
                    'action',
                    'restore'
                );


                setBusy(true);

                try {

                    const response =
                        await fetch(
                            'appearance-banner-upload.php',
                            {
                                method: 'POST',
                                body: formData
                            }
                        );

                    const data =
                        await response.json();


                    if (
                        !response.ok
                        ||
                        !data.success
                    ) {

                        throw new Error(
                            data.message
                            || 'Unable to restore the default banner.'
                        );
                    }


                    showMessage(
                        data.message
                        || 'Default banner restored.',
                        true
                    );


                    window.setTimeout(
                        function () {
                            window.location.reload();
                        },
                        350
                    );

                } catch (error) {

                    showMessage(
                        error.message
                        || 'Unable to restore the default banner.',
                        false
                    );

                    setBusy(false);
                }
            }
        );
    }


    /*
     * Initialise only after the browser knows the
     * intrinsic image/video dimensions.
     */
    if (previewMedia) {

        if (
            previewMedia.tagName
                .toLowerCase()
            === 'video'
        ) {

            if (
                previewMedia.readyState >= 1
                &&
                previewMedia.videoWidth > 0
            ) {
                initialiseBannerCrop();

            } else {

                previewMedia.addEventListener(
                    'loadedmetadata',
                    initialiseBannerCrop,
                    {
                        once: true
                    }
                );
            }

        } else {

            if (
                previewMedia.complete
                &&
                previewMedia.naturalWidth > 0
            ) {
                initialiseBannerCrop();

            } else {

                previewMedia.addEventListener(
                    'load',
                    initialiseBannerCrop,
                    {
                        once: true
                    }
                );
            }
        }
    }


    window.addEventListener(
        'resize',
        function () {

            if (
                bannerCropState.sourceWidth <= 0
                ||
                bannerCropState.sourceHeight <= 0
            ) {
                return;
            }

            savedPositionToPixels();
            renderBannerCrop();
        }
    );

})();
</script>


</body>
</html>
