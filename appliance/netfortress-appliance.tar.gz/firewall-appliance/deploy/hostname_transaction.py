#!/usr/bin/env python3
"""Root-only transactional hostname activator.

Candidates are created under /var/lib/firewall-appliance/hostname-candidates
by the appliance API and contain hostname.txt plus manifest.json. The helper
never accepts paths or shell fragments. It snapshots /etc/hostname and the
/etc/hosts 127.0.1.1 entry before applying, and can restore them.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

STATE = Path("/var/lib/firewall-appliance")
CANDIDATES = STATE / "hostname-candidates"
ROLLBACK = Path("/var/lib/firewall-appliance-rollback/hostname")
ACTIVE = STATE / "hostname-active.json"
TXN_RE = re.compile(r"^host_[0-9a-f]{16}$")
HOSTNAME_RE = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$")


def fail(message: str, code: int = 1) -> None:
    print(json.dumps({"ok": False, "message": message}))
    raise SystemExit(code)


def run(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(args, text=True, capture_output=True, timeout=30, check=False)


def load_candidate(txn: str) -> tuple[dict, str, Path]:
    if not TXN_RE.fullmatch(txn):
        fail("Invalid transaction identifier", 2)
    candidate, snapshot = CANDIDATES / txn, ROLLBACK / txn
    if not (candidate / "manifest.json").is_file() or not (candidate / "hostname.txt").is_file():
        fail("Candidate is incomplete")
    manifest = json.loads((candidate / "manifest.json").read_text())
    hostname = (candidate / "hostname.txt").read_text().strip().lower()
    if manifest.get("sha256") != hashlib.sha256(hostname.encode()).hexdigest():
        fail("Candidate hash mismatch")
    if not HOSTNAME_RE.fullmatch(hostname):
        fail("Candidate hostname is invalid")
    return manifest, hostname, snapshot


def hosts_127_line() -> str:
    for line in Path("/etc/hosts").read_text(encoding="utf-8").splitlines():
        fields = line.split()
        if fields and fields[0] in {"127.0.1.1", "127.0.1.0"}:
            return line
    return ""


def apply(txn: str) -> None:
    manifest, hostname, snapshot = load_candidate(txn)
    snapshot.mkdir(parents=True, exist_ok=False)
    (snapshot / "hostname").write_text(Path("/etc/hostname").read_text())
    (snapshot / "hosts-127").write_text(hosts_127_line())
    Path("/etc/hostname").write_text(hostname + "\n")
    set_live = run(["hostname", hostname])
    if set_live.returncode:
        rollback(txn)
        fail("The kernel rejected the hostname change; the previous name was restored")
    hosts = Path("/etc/hosts").read_text(encoding="utf-8").splitlines()
    previous = hosts_127_line()
    if previous:
        hosts = [f"127.0.1.1 {hostname}" if line == previous else line for line in hosts]
    else:
        hosts.append(f"127.0.1.1 {hostname}")
    Path("/etc/hosts").write_text("\n".join(hosts) + "\n")
    record = {"transaction_id": txn, "state": "committed", "hostname": hostname, "applied_at": time.time()}
    ACTIVE.write_text(json.dumps(record, sort_keys=True))
    print(json.dumps({"ok": True, **record}))


def rollback(txn: str) -> None:
    snapshot = ROLLBACK / txn
    if not (snapshot / "hostname").is_file():
        fail("Rollback snapshot does not exist")
    hostname = (snapshot / "hostname").read_text().strip()
    Path("/etc/hostname").write_text(hostname + "\n")
    run(["hostname", hostname])
    previous_hosts = (snapshot / "hosts-127").read_text()
    hosts = Path("/etc/hosts").read_text(encoding="utf-8").splitlines()
    if previous_hosts:
        hosts = [previous_hosts if line == hosts_127_line() else line for line in hosts]
    else:
        hosts = [line for line in hosts if line != hosts_127_line()]
    Path("/etc/hosts").write_text("\n".join(hosts) + "\n")
    record = json.loads(ACTIVE.read_text()) if ACTIVE.is_file() else {"transaction_id": txn}
    record.update({"state": "rolled-back", "rolled_back_at": time.time()})
    ACTIVE.write_text(json.dumps(record, sort_keys=True))
    print(json.dumps({"ok": True, **record}))


def status(_txn: str) -> None:
    record = json.loads(ACTIVE.read_text()) if ACTIVE.is_file() else {}
    print(json.dumps({"ok": True, **record}))


def main() -> None:
    if os.geteuid() != 0 or len(sys.argv) != 3:
        fail("Usage: firewall-hostname-transaction apply|rollback|status host_<id>", 2)
    action, txn = sys.argv[1:]
    if action == "apply":
        apply(txn)
    elif action == "rollback":
        rollback(txn)
    elif action == "status":
        status(txn)
    else:
        fail("Unsupported action", 2)


if __name__ == "__main__":
    main()
