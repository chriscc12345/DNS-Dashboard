#!/opt/firewall-appliance/backend/.venv/bin/python
"""Firewall Appliance pools + policy-portal reconciler (root).

Two entry points:

1. Imported by the policy-refresh reconciler (runs as root from systemd):
   sync_pools_and_kea(database, marker) brings VLAN subinterfaces, Kea DHCP and
   the captive-portal set/page/site in step with the database.

2. CLI for the API through sudo (fixed verbs, no shell input):
     firewall-pools-sync sync                 -> same full sync, immediate
     firewall-pools-sync portal-accept <id>   -> add one device to the accepted
                                                 set from a staged candidate

Design notes:
* Each IP pool gets a VLAN subinterface of the configured LAN adapter
  (e.g. ens19.20 for VLAN 20). Only interfaces this module created (tracked in
  the state marker) or currently desires are ever touched.
* Kea is only restarted when the rendered config changed AND the new config
  passes `kea-dhcp4 -t`; a failing start restores the previous config.
* The portal set (hash:mac) is flushed and rebuilt from the acceptance table
  on every sync, so revocations take effect within one reconciler cycle.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

STATE = Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance"))
MARKER = STATE / "pools-state.json"
INTERFACES_FILE = Path("/etc/network/interfaces.d/firewall-pools")
KEA_CONFIG = Path("/etc/kea/kea-dhcp4.conf")
PORTAL_ROOT = Path("/var/www/firewall-portal")
PORTAL_SITE = Path("/etc/nginx/sites-available/firewall-portal")
PORTAL_LINK = Path("/etc/nginx/sites-enabled/firewall-portal")
PORTAL_SET = "fw-portal-accepted"
CANDIDATES = STATE / "portal-candidates"
TXN_RE = re.compile(r"^portal_[0-9a-f]{16}$")
MAC_RE = re.compile(r"^(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$")


def run(args: list[str], timeout: int = 60) -> subprocess.CompletedProcess:
    return subprocess.run(args, text=True, capture_output=True, timeout=timeout, check=False)


def emit(body: dict, code: int = 0) -> None:
    print(json.dumps(body))
    raise SystemExit(code)


def load_environment() -> None:
    """Root CLI runs without the service environment; source it explicitly."""
    env_file = Path("/etc/firewall-appliance/environment")
    if env_file.is_file():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                os.environ.setdefault(key.strip(), value.strip())


def marker_read() -> dict:
    if MARKER.is_file():
        try:
            return json.loads(MARKER.read_text())
        except ValueError:
            pass
    return {}


def marker_write(marker: dict) -> None:
    MARKER.parent.mkdir(parents=True, exist_ok=True)
    temporary = MARKER.with_suffix(".tmp")
    temporary.write_text(json.dumps(marker, indent=2, sort_keys=True))
    temporary.replace(MARKER)


def settings_json(database, key: str, model, default):
    raw = database.setting(key)
    return model.model_validate_json(raw) if raw else default


def sync_interfaces(database, marker: dict) -> dict:
    """Create/remove VLAN subinterfaces for IP pools and persist them for boot."""
    from app.services.network_engine import safe_interface

    dhcp = settings_json(database, "dhcp_settings", __import__("app.models", fromlist=["DhcpSettings"]).DhcpSettings, None)
    if not dhcp or not dhcp.enabled:
        return {"status": "disabled"}
    base = safe_interface(dhcp.interface)
    pools = [row for row in database.ip_pools() if row.get("enabled", 1)]
    desired: dict[str, str] = {}
    for pool in pools:
        iface = f"{base}.{pool['vlan_id']}"
        prefixlen = ipaddress.ip_network(pool["subnet"]).prefixlen
        desired[iface] = f"{pool['router']}/{prefixlen}"
    stanzas = [
        "# Managed by Firewall Appliance — IP pools (VLAN subinterfaces). Do not edit.",
        f"# Each pool is a virtual adapter on the LAN adapter ({base}).",
    ]
    for iface, address in sorted(desired.items()):
        stanzas += [f"auto {iface}", f"iface {iface} inet static", f"    address {address}", f"    vlan-raw-device {base}"]
    content = "\n".join(stanzas) + "\n"
    changed = []
    # Interfaces this module owns: previously recorded, or in the desired set.
    owned = set(marker.get("owned_interfaces", [])) | set(desired)
    # `ip -o link` lines are "5: ens19.20@ens19: <...>" — the NAME is the second
    # field, not the first (the first is the interface index number).
    live = {line.split(":")[1].split("@")[0].strip() for line in run(["ip", "-o", "link"]).stdout.splitlines() if ":" in line}
    for iface, address in sorted(desired.items()):
        if iface in live:
            continue
        vlan_id = iface.rsplit(".", 1)[1]
        run(["ip", "link", "add", "link", base, "name", iface, "type", "vlan", "id", vlan_id])
        run(["ip", "addr", "add", address, "dev", iface])
        run(["ip", "link", "set", iface, "up"])
        changed.append(f"created {iface}")
    for iface in sorted(owned - set(desired)):
        if iface in live:
            run(["ip", "link", "del", iface])
            changed.append(f"removed {iface}")
    marker["owned_interfaces"] = sorted(set(desired))
    if not INTERFACES_FILE.is_file() or INTERFACES_FILE.read_text() != content:
        INTERFACES_FILE.parent.mkdir(parents=True, exist_ok=True)
        INTERFACES_FILE.write_text(content)
        changed.append("interfaces.d updated")
    return {"status": "changed" if changed else "unchanged", "interfaces": sorted(desired), "changes": changed}


def sync_kea(database, marker: dict) -> dict:
    from app.services.appliance_ops import render_kea_config

    dhcp = settings_json(database, "dhcp_settings", __import__("app.models", fromlist=["DhcpSettings"]).DhcpSettings, None)
    if not dhcp or not dhcp.enabled:
        return {"status": "disabled"}
    config = render_kea_config(dhcp, database.dhcp_reservations(), database.ip_pools())
    digest = hashlib.sha256(config.encode()).hexdigest()
    if KEA_CONFIG.is_file() and hashlib.sha256(KEA_CONFIG.read_bytes()).hexdigest() == digest and marker.get("kea_sha256") == digest:
        return {"status": "unchanged"}
    # NOTE: `kea-dhcp4 -t` cannot open ANY file on this platform (AppArmor blocks
    # it, even for the live config), so validation is done the guarded way below:
    # write, restart, verify the service is active, and restore the previous
    # config + restart again if Kea rejects the new one.
    (KEA_CONFIG.parent / "kea-dhcp4.conf.candidate").unlink(missing_ok=True)
    backup = KEA_CONFIG.read_bytes() if KEA_CONFIG.is_file() else None
    KEA_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    KEA_CONFIG.write_text(config)
    restarted = run(["systemctl", "restart", "kea-dhcp4-server"], timeout=90)
    if restarted.returncode or run(["systemctl", "is-active", "kea-dhcp4-server", "--quiet"]).returncode:
        if backup is not None:
            KEA_CONFIG.write_bytes(backup)
            run(["systemctl", "restart", "kea-dhcp4-server"], timeout=90)
        return {"status": "failed", "message": "Kea failed to restart; previous configuration was restored."}
    marker["kea_sha256"] = digest
    return {"status": "applied"}


def sync_portal(database, marker: dict) -> dict:
    from app.services.content_filter import PORTAL_PORT, render_portal_nginx_site, render_portal_page

    portal = settings_json(database, "portal_settings", __import__("app.models", fromlist=["PortalSettings"]).PortalSettings, None)
    if portal is None:
        return {"status": "disabled"}
    # The portal renders under the client's original URL (transparent redirect),
    # so the certificate link must be absolute — the appliance's own LAN address.
    dhcp = settings_json(database, "dhcp_settings", __import__("app.models", fromlist=["DhcpSettings"]).DhcpSettings, None)
    enroll_base = f"http://{dhcp.router}" if dhcp and dhcp.router else ""
    page = render_portal_page(portal, enroll_base=enroll_base)
    site = render_portal_nginx_site()
    changes = []
    page_digest = hashlib.sha256(page.encode()).hexdigest()
    if marker.get("portal_page_sha256") != page_digest or not (PORTAL_ROOT / "index.html").is_file():
        PORTAL_ROOT.mkdir(parents=True, exist_ok=True)
        (PORTAL_ROOT / "index.html").write_text(page)
        marker["portal_page_sha256"] = page_digest
        changes.append("portal page rendered")
    if not PORTAL_SITE.is_file() or PORTAL_SITE.read_text() != site:
        PORTAL_SITE.parent.mkdir(parents=True, exist_ok=True)
        PORTAL_SITE.write_text(site)
        if not PORTAL_LINK.exists():
            PORTAL_LINK.symlink_to(PORTAL_SITE)
        tested = run(["nginx", "-t"], timeout=30)
        if tested.returncode:
            return {"status": "failed", "message": f"nginx rejected the portal site: {tested.stderr.strip()[:200]}"}
        run(["systemctl", "reload", "nginx"], timeout=30)
        changes.append("portal site installed")
    if portal.enabled:
        run(["ipset", "create", PORTAL_SET, "hash:mac", "-exist"])
        run(["ipset", "flush", PORTAL_SET])
        for row in database.portal_acceptances():
            run(["ipset", "add", PORTAL_SET, row["mac_address"], "-exist"])
    else:
        run(["ipset", "destroy", PORTAL_SET])
    return {"status": "changed" if changes else "unchanged", "enabled": portal.enabled, "changes": changes}


def sync_pools_and_kea(database, marker: dict) -> dict:
    """Full pools+portal sync (reconciler entry point). Caller persists marker."""
    interfaces = sync_interfaces(database, marker)
    kea = sync_kea(database, marker)
    portal = sync_portal(database, marker)
    return {"interfaces": interfaces, "kea": kea, "portal": portal}


def portal_accept(ident: str) -> dict:
    """Add one device (MAC) to the accepted set from a staged candidate."""
    if not TXN_RE.fullmatch(ident):
        emit({"ok": False, "message": "Invalid candidate identifier"}, 2)
    candidate = CANDIDATES / ident / "accept.json"
    if not candidate.is_file():
        emit({"ok": False, "message": "Candidate is incomplete"}, 3)
    try:
        body = json.loads(candidate.read_text())
        mac = str(body.get("mac", "")).lower()
    except ValueError:
        emit({"ok": False, "message": "Candidate is invalid"}, 3)
    if not MAC_RE.fullmatch(mac):
        emit({"ok": False, "message": "Candidate MAC is invalid"}, 3)
    run(["ipset", "create", PORTAL_SET, "hash:mac", "-exist"])
    run(["ipset", "add", PORTAL_SET, mac, "-exist"])
    return {"ok": True, "mac_address": mac, "message": "Device accepted; internet access is live."}


def main() -> int:
    if os.geteuid() != 0:
        emit({"ok": False, "message": "This helper must run as root."}, 5)
    load_environment()
    backend = "/opt/firewall-appliance/backend"
    if backend not in sys.path:
        sys.path.insert(0, backend)
    action = sys.argv[1] if len(sys.argv) > 1 else ""
    if action == "portal-accept":
        emit(portal_accept(sys.argv[2] if len(sys.argv) > 2 else ""))
    if action != "sync":
        emit({"ok": False, "message": "Usage: firewall-pools-sync sync | portal-accept portal_<hex>"}, 2)
    from app.database import Database

    database = Database()
    database.initialize()
    marker = marker_read()
    result = sync_pools_and_kea(database, marker)
    marker_write(marker)
    # Bring the kernel rules in step immediately (guarded: health check + confirm).
    sys.path.insert(0, "/opt/firewall-appliance/deploy")
    try:
        from policy_refresh import refresh_iptables, refresh_ids  # noqa: PLC0415

        state_marker = {}
        state_file = STATE / "refresh-state.json"
        if state_file.is_file():
            try:
                state_marker = json.loads(state_file.read_text())
            except ValueError:
                state_marker = {}
        result["iptables"] = refresh_iptables(database, state_marker)
        result["ids_ips"] = refresh_ids(database, state_marker)
        state_file.write_text(json.dumps(state_marker, indent=2, sort_keys=True))
    except Exception as exc:  # reconciler pieces are best-effort; sync still reports
        result["iptables"] = {"status": "skipped", "message": str(exc)[:200]}
    emit({"ok": True, **result})


if __name__ == "__main__":
    raise SystemExit(main())
