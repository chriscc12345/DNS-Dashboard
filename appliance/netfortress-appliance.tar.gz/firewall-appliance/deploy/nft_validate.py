#!/usr/bin/env python3
"""Root-only nftables candidate validator for deployment transactions.

Reads the staged candidate of an existing transaction directory, verifies the
manifest hash, and runs `nft --check` as root. Never modifies the live ruleset
and never accepts paths or shell fragments.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

STATE = Path("/var/lib/firewall-appliance")
TRANSACTIONS = STATE / "transactions"
TXN_RE = re.compile(r"^txn_[0-9a-f]{16}$")


def fail(message: str, code: int = 1) -> None:
    print(json.dumps({"ok": False, "valid": False, "message": message}))
    raise SystemExit(code)


def main() -> None:
    if os.geteuid() != 0 or len(sys.argv) != 3 or sys.argv[1] != "validate":
        fail("Usage: firewall-nft-validate validate txn_<id>", 2)
    txn = sys.argv[2]
    if not TXN_RE.fullmatch(txn):
        fail("Invalid transaction identifier", 2)
    candidate = TRANSACTIONS / txn / "nftables.conf"
    metadata_path = TRANSACTIONS / txn / "metadata.json"
    if not candidate.is_file() or not metadata_path.is_file():
        fail("Transaction candidate is incomplete")
    expected = json.loads(metadata_path.read_text()).get("sha256")
    if not expected or hashlib.sha256(candidate.read_bytes()).hexdigest() != expected:
        fail("Candidate hash mismatch")
    if not shutil.which("nft"):
        print(json.dumps({"ok": True, "valid": None, "message": "nft is not installed; structural checks only"}))
        return
    result = subprocess.run(["nft", "--check", "--file", str(candidate)], text=True, capture_output=True, timeout=15, check=False)
    message = (result.stderr or result.stdout or "nftables candidate passed kernel validation").strip()
    print(json.dumps({"ok": True, "valid": result.returncode == 0, "message": message}))


if __name__ == "__main__":
    main()
