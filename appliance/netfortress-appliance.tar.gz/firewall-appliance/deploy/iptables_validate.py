#!/usr/bin/env python3
"""Root-only candidate ruleset validator.

Stages are created under /var/lib/firewall-appliance/iptables-validate by the
unprivileged appliance API. The helper runs iptables-restore --test against the
staged file only; it never modifies the live ruleset and never accepts paths or
shell fragments from the caller.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

STATE = Path("/var/lib/firewall-appliance")
STAGES = STATE / "iptables-validate"
ID_RE = re.compile(r"^iptval_[0-9a-f]{16}$")


def fail(message: str, code: int = 1) -> None:
    print(json.dumps({"ok": False, "valid": False, "message": message}))
    raise SystemExit(code)


def validate(ident: str) -> None:
    if not ID_RE.fullmatch(ident):
        fail("Invalid staging identifier", 2)
    rules = STAGES / ident / "rules.v4"
    if not rules.is_file():
        fail("Staged candidate is incomplete")
    binary = shutil.which("iptables-restore") or fail("iptables-restore is unavailable")
    result = subprocess.run([binary, "--test"], input=rules.read_text(), text=True, capture_output=True, timeout=15, check=False)
    message = (result.stderr or result.stdout or "Rules passed kernel validation").strip()
    if result.returncode:
        message = result.stderr.strip() or "Kernel rejected the candidate"
    print(json.dumps({"ok": True, "valid": result.returncode == 0, "message": message}))


def main() -> None:
    if os.geteuid() != 0 or len(sys.argv) != 3:
        fail("Usage: firewall-iptables-validate validate iptval_<id>", 2)
    action, ident = sys.argv[1:]
    if action != "validate":
        fail("Unsupported action", 2)
    validate(ident)


if __name__ == "__main__":
    main()
