#!/usr/bin/env python3
"""Root-only appliance update applier.

Staged updates live under /var/lib/firewall-appliance/updates/<update_id>
(created by the signed-update staging path — the package is verified before
it ever reaches this helper). Applying an update:

  1. backs up the current code tree to the rollback area,
  2. extracts the package's firewall-appliance/ tree over
     /opt/firewall-appliance (never touching .venv or runtime state — those
     live outside the package),
  3. runs the new build's deploy/post_update.sh when present (installs new
     services, packages and sudoers entries — root powers only it has),
  4. restarts the appliance API into the new code.

On any failure the previous code tree is restored from the backup.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

STATE = Path("/var/lib/firewall-appliance")
ROLLBACK = Path("/var/lib/firewall-appliance-rollback/updates")
INSTALL_DIR = Path("/opt/firewall-appliance")
ID_RE = re.compile(r"^update_[0-9a-f]{16}$")


def fail(message: str, code: int = 1) -> None:
    print(json.dumps({"ok": False, "message": message}))
    raise SystemExit(code)


def run(args: list[str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(args, capture_output=True, text=True, timeout=900, check=False, **kwargs)


def apply_update(update_id: str) -> None:
    if not ID_RE.match(update_id):
        fail("Invalid update id")
    staged = STATE / "updates" / update_id
    package = staged / "package.bin"
    metadata_path = staged / "metadata.json"
    if not package.is_file() or not metadata_path.is_file():
        fail("Staged update not found")
    metadata = json.loads(metadata_path.read_text())
    sha256 = metadata["manifest"]["sha256"]
    if hashlib.sha256(package.read_bytes()).hexdigest() != sha256:
        fail("Staged package no longer matches its manifest hash")

    ROLLBACK.mkdir(parents=True, exist_ok=True)
    backup = ROLLBACK / f"code-before-{update_id}.tar.gz"
    archive = run(["tar", "-czf", str(backup), "--exclude=backend/.venv", "-C", "/opt", "firewall-appliance"])
    if archive.returncode:
        fail(f"Could not back up the current code tree: {archive.stderr.strip()[:200]}")

    extraction = Path("/tmp") / update_id
    shutil.rmtree(extraction, ignore_errors=True)
    extraction.mkdir(parents=True)
    try:
        with tarfile.open(package, mode="r:gz") as tar:
            members = [m for m in tar.getmembers() if m.name.startswith("firewall-appliance/")
                       and not m.name.startswith("firewall-appliance/backend/.venv")
                       and ".." not in m.name]
            tar.extractall(extraction, members=members, filter="data")
    except (tarfile.TarError, OSError) as exc:
        shutil.rmtree(extraction, ignore_errors=True)
        fail(f"Package extraction failed: {exc}")
    source = extraction / "firewall-appliance"
    if not (source / "backend").is_dir():
        shutil.rmtree(extraction, ignore_errors=True)
        fail("Package does not contain an appliance code tree")

    copy = run(["cp", "-a", str(source) + "/.", str(INSTALL_DIR)])
    shutil.rmtree(extraction, ignore_errors=True)
    if copy.returncode:
        fail(f"Copying the new code failed: {copy.stderr.strip()[:200]}")

    post = INSTALL_DIR / "deploy" / "post_update.sh"
    post_output = ""
    if post.is_file():
        completed = run(["bash", str(post)])
        post_output = (completed.stdout or "") + (completed.stderr or "")
        if completed.returncode:
            fail(f"post_update.sh failed: {post_output.strip()[:300]}")

    restarted = run(["systemctl", "restart", "firewall-api"])
    if restarted.returncode:
        # The code tree swap already happened; restore from the backup.
        restore(backup)
        fail("API failed to restart on the new code — previous code restored")

    metadata["status"] = "applied"
    metadata_path.write_text(json.dumps(metadata, indent=2))
    print(json.dumps({"ok": True, "version": metadata["manifest"]["version"], "post_update": post_output.strip()[-400:]}))


def restore(backup: Path) -> None:
    if backup.is_file():
        run(["rm", "-rf", str(INSTALL_DIR)])
        run(["mkdir", "-p", str(INSTALL_DIR)])
        run(["tar", "-xzf", str(backup), "-C", "/opt"])
        run(["systemctl", "restart", "firewall-api"])


def main() -> None:
    if len(sys.argv) == 3 and sys.argv[1] == "apply":
        apply_update(sys.argv[2])
    else:
        fail("usage: firewall-update apply <update_id>")


if __name__ == "__main__":
    main()
