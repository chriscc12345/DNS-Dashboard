#!/usr/bin/env python3
"""Threat feed updater (every edition — core hygiene).

Builds the fw-threat4 ipset the firewall engine references: known-bad IPv4
sources from free, public feeds:

  feodo     abuse.ch Feodo tracker  - active botnet C2 servers
  spamhaus  Spamhaus DROP + EDROP  - hijacked netblocks and worst attackers
  dshield   DShield block list     - top attacking sources this month
  tor       Tor exit nodes         - opt-in (some networks need Tor)

A failed or partial download never touches the live set — the last good
set keeps enforcing. The set is built atomically (temporary set + swap) so
the guarded firewall apply can never reference a half-built list.

Run as root (systemd: firewall-threats.service). Settings are read from the
appliance database (threat_settings).
"""
from __future__ import annotations

import json
import re
import sqlite3
import subprocess
import sys
import urllib.request
from datetime import UTC, datetime
from ipaddress import IPv4Address, IPv4Network, summarize_address_range
from pathlib import Path

DB_PATH = Path("/var/lib/firewall-appliance/appliance.db")
STATUS_FILE = Path("/var/lib/firewall-appliance/threat-status.json")
SET = "fw-threat4"
MAX_FILE_BYTES = 20_000_000
TIMEOUT = 60

FEEDS = {
    "feodo": ("https://feodotracker.abuse.ch/downloads/ipblocklist_recommended.txt",),
    "spamhaus": ("https://www.spamhaus.org/drop/drop.txt",
                 "https://www.spamhaus.org/drop/edrop.txt"),
    "dshield": ("https://www.dshield.org/block.txt",),
    "tor": ("https://check.torproject.org/torbulkexitlist",),
}

CIDR_RE = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}/\d{1,2}\b")
IP_RE = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
RANGE_RE = re.compile(r"(\d{1,3}(?:\.\d{1,3}){3})\s*-\s*(\d{1,3}(?:\.\d{1,3}){3})")


def read_settings() -> dict:
    connection = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
    try:
        row = connection.execute("SELECT value FROM system_settings WHERE key='threat_settings'").fetchone()
    finally:
        connection.close()
    return json.loads(row[0]) if row else {"feodo": True, "spamhaus": True, "dshield": True, "tor": False}


def run_ipset(args: list[str]) -> None:
    completed = subprocess.run(["ipset", *args], capture_output=True, text=True, check=False)
    if completed.returncode != 0:
        raise RuntimeError(f"ipset {' '.join(args[:2])} failed: {completed.stderr.strip()[:200]}")


def fetch_networks(urls: tuple[str, ...]) -> list[str]:
    """Download a feed and return its IPv4 networks. A feed that fails to
    download raises — the caller decides whether that aborts the update."""
    networks: list[str] = []
    for url in urls:
        request = urllib.request.Request(url, headers={"User-Agent": "curl/8.0"})
        with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
            raw = response.read(MAX_FILE_BYTES + 1)
        if len(raw) > MAX_FILE_BYTES:
            raise ValueError(f"Feed exceeds size limit: {url.rsplit('/', 1)[-1]}")
        for line in raw.decode("utf-8", "replace").splitlines():
            line = line.strip()
            if not line or line.startswith(("#", ";", "//")):
                continue
            match = RANGE_RE.search(line)
            if match:
                for network in summarize_address_range(IPv4Address(match.group(1)), IPv4Address(match.group(2))):
                    networks.append(str(network))
                continue
            match = CIDR_RE.search(line)
            if match:
                networks.append(match.group(0))
                continue
            match = IP_RE.search(line)
            if match:
                networks.append(f"{match.group(0)}/32")
    unique = sorted(set(networks), key=lambda value: int(IPv4Network(value).network_address))
    return unique


def build_set(networks: list[str]) -> None:
    # Both sets always exist so the guarded apply can never reference a
    # missing set (first run creates the target, every run recreates tmp).
    run_ipset(["create", SET, "hash:net", "family", "inet", "maxelem", "262144", "-exist"])
    run_ipset(["create", "fw-threat-tmp", "hash:net", "family", "inet", "maxelem", "262144", "-exist"])
    run_ipset(["flush", "fw-threat-tmp"])
    import tempfile
    handle = tempfile.NamedTemporaryFile("w", delete=False, suffix=".ipset")
    for cidr in networks:
        handle.write(f"add fw-threat-tmp {cidr} -exist\n")
    handle.flush()
    handle.close()
    try:
        completed = subprocess.run(["ipset", "restore", "-exist"], stdin=open(handle.name),
                                   capture_output=True, text=True, check=False)
        if completed.returncode != 0:
            raise RuntimeError(f"ipset restore failed: {completed.stderr.strip()[:200]}")
    finally:
        Path(handle.name).unlink(missing_ok=True)
    run_ipset(["swap", "fw-threat-tmp", SET])
    run_ipset(["destroy", "fw-threat-tmp"])


def write_status(counts: dict, ok: bool, message: str = "") -> None:
    STATUS_FILE.write_text(json.dumps({
        "updated_at": datetime.now(UTC).isoformat(),
        "feeds": counts,
        "entries": sum(counts.values()),
        "ok": ok,
        "message": message,
    }, indent=2))


def main() -> int:
    settings = read_settings()
    enabled = {name for name in FEEDS if settings.get(name, name != "tor")}
    if not enabled:
        write_status({name: 0 for name in FEEDS}, True, "No feeds selected.")
        print(json.dumps({"ok": True, "entries": 0, "message": "No feeds selected."}))
        return 0
    counts: dict = {}
    networks: list[str] = []
    failures: list[str] = []
    for name in sorted(enabled):
        try:
            found = fetch_networks(FEEDS[name])
        except Exception as exc:  # noqa: BLE001 — any failure keeps the last good set
            failures.append(f"{name}: {str(exc)[:120]}")
            continue
        counts[name] = len(found)
        networks += found
    # Every selected feed must succeed: a partial update must not replace
    # the last good set (a missing feed would silently shrink coverage).
    if failures:
        message = "Update failed — the previous set is kept. " + "; ".join(failures)
        previous_ok = STATUS_FILE.is_file() and json.loads(STATUS_FILE.read_text()).get("ok")
        write_status(counts if counts else {name: 0 for name in enabled}, False, message)
        print(json.dumps({"ok": False, "message": message}))
        return 0 if previous_ok else 1
    unique = sorted(set(networks))
    build_set(unique)
    write_status(counts, True, f"{len(unique)} known-bad networks from {len(counts)} feeds.")
    print(json.dumps({"ok": True, "entries": len(unique), "feeds": counts}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
