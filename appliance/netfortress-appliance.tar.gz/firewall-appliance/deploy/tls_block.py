#!/usr/bin/env python3
"""Appliance CA block-page TLS server (HTTPS block screens).

Browsers only reach this service for domains the DNS layer hijacked to the
appliance — blocked categories, applications and custom domains. Allowed
traffic resolves to its real destination, so nothing is ever intercepted:
this is a targeted block-page presenter, not a MITM proxy.

For each TLS ClientHello the service mints a certificate for the requested
hostname on the fly, signed by the appliance Certificate Authority, and
serves the branded block page over HTTPS. Clients that installed the
appliance CA (downloadable from the dashboard) see the branded page on
https:// URLs; clients that did not get an instant certificate warning.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import ssl
import sys
import tempfile
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID
from datetime import datetime, timedelta, timezone

STATE = Path(os.environ.get("FIREWALL_TLS_STATE", "/var/lib/firewall-appliance/tls-block"))
CA_KEY = STATE / "ca.key"
CA_CERT = STATE / "ca.crt"
CERTS = STATE / "certs"
TLS_CONFIG = STATE / "config.json"  # written by firewall-acme when public certs exist
DASHBOARD_UPSTREAM = ("127.0.0.1", 8080)
BLOCK_PAGE = Path(os.environ.get("FIREWALL_BLOCK_PAGE", "/var/www/firewall-block/index.html"))
DNSMASQ_CONF = Path("/etc/dnsmasq.d/99-firewall-appliance.conf")
HOSTNAME_RE = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$")
HOST_RE = re.compile(r"^host-record=([A-Za-z0-9.-]+),")


def public_names() -> dict[str, str]:
    """Names with real (Let's Encrypt) certificates, when ACME is configured."""
    try:
        config = json.loads(TLS_CONFIG.read_text(encoding="utf-8"))
        if Path(config["certificate"]).is_file():
            return {config["appliance_fqdn"].lower(): "dashboard", config["block_fqdn"].lower(): "block"}
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return {}


def block_hostname() -> str:
    names = public_names()
    if names:
        return next(name for name, role in sorted(names.items()) if role == "block")
    try:
        for line in DNSMASQ_CONF.read_text(encoding="utf-8").splitlines():
            match = HOST_RE.match(line.strip())
            if match:
                return match.group(1).lower()
    except OSError:
        pass
    return "blocked.firewall.lan"


def write_private(path: Path, data: bytes) -> None:
    path.write_bytes(data)
    path.chmod(0o600)


def ensure_ca() -> tuple[x509.Certificate, ec.EllipticCurvePrivateKey]:
    """Create the appliance CA once; reuse it forever afterwards."""
    if CA_KEY.is_file() and CA_CERT.is_file():
        key = serialization.load_pem_private_key(CA_KEY.read_bytes(), password=None)
        return x509.load_pem_x509_certificate(CA_CERT.read_bytes()), key
    key = ec.generate_private_key(ec.SECP256R1())
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Firewall Appliance Root CA"),
                      x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Firewall Appliance")])
    now = datetime.now(timezone.utc)
    certificate = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
                    .public_key(key.public_key()).serial_number(x509.random_serial_number())
                    .not_valid_before(now - timedelta(days=1)).not_valid_after(now + timedelta(days=3650))
                    .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
                    .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True,
                                                  content_commitment=False, data_encipherment=False, decipher_only=False,
                                                  encipher_only=False, key_agreement=False, key_encipherment=False), critical=True)
                    .sign(key, hashes.SHA256()))
    STATE.mkdir(parents=True, exist_ok=True)
    write_private(CA_KEY, key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    CA_CERT.write_bytes(certificate.public_bytes(serialization.Encoding.PEM))
    CA_CERT.chmod(0o644)
    CERTS.mkdir(parents=True, exist_ok=True)
    return certificate, key


class CertificateFactory:
    """Mints and caches short-lived leaf certificates signed by the appliance CA."""

    def __init__(self, certificate: x509.Certificate, key: ec.EllipticCurvePrivateKey):
        self.ca_certificate, self.ca_key = certificate, key
        self.contexts: dict[str, ssl.SSLContext] = {}

    def _mint(self, hostname: str) -> tuple[Path, Path]:
        CERTS.mkdir(parents=True, exist_ok=True)
        leaf = ec.generate_private_key(ec.SECP256R1())
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, hostname[:64])])
        now = datetime.now(timezone.utc)
        certificate = (x509.CertificateBuilder().subject_name(name).issuer_name(self.ca_certificate.subject)
                        .public_key(leaf.public_key()).serial_number(x509.random_serial_number())
                        .not_valid_before(now - timedelta(hours=1)).not_valid_after(now + timedelta(days=30))
                        .add_extension(x509.SubjectAlternativeName([x509.DNSName(hostname)]), critical=False)
                        .sign(self.ca_key, hashes.SHA256()))
        cert_path, key_path = CERTS / f"{hostname}.crt", CERTS / f"{hostname}.key"
        cert_path.write_bytes(certificate.public_bytes(serialization.Encoding.PEM) + self.ca_certificate.public_bytes(serialization.Encoding.PEM))
        write_private(key_path, leaf.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        return cert_path, key_path

    def context(self, hostname: str) -> ssl.SSLContext:
        hostname = hostname.strip().lower().rstrip(".")
        if not HOSTNAME_RE.fullmatch(hostname):
            hostname = block_hostname()
        cached = self.contexts.get(hostname)
        if cached:
            return cached
        real = public_names()
        if hostname in real:
            config = json.loads(TLS_CONFIG.read_text(encoding="utf-8"))
            cert_path, key_path = Path(config["certificate"]), Path(config["private_key"])
        else:
            cert_path, key_path = (CERTS / f"{hostname}.crt", CERTS / f"{hostname}.key") if (CERTS / f"{hostname}.crt").is_file() else self._mint(hostname)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(str(cert_path), str(key_path))
        self.contexts[hostname] = context
        return context

    def sni_callback(self, connection, server_name, _context):
        try:
            if server_name:
                connection.context = self.context(server_name)
        except (ValueError, OSError, ssl.SSLError):
            pass
        return None


FALLBACK_PAGE = b"""<!doctype html><html><head><meta charset="utf-8"><title>Access blocked</title></head>
<body style="font-family:sans-serif;background:#141a22;color:#eef;padding:3rem"><h1>Access blocked</h1>
<p>This website is restricted by your network policy.</p></body></html>\n"""


def block_page() -> bytes:
    try:
        return BLOCK_PAGE.read_bytes() or FALLBACK_PAGE
    except OSError:
        return FALLBACK_PAGE


async def _pipe(source: asyncio.StreamReader, destination: asyncio.StreamWriter) -> None:
    try:
        while data := await source.read(65536):
            destination.write(data)
            await destination.drain()
    except (ConnectionError, OSError):
        pass
    finally:
        try:
            destination.close()
        except (ConnectionError, OSError):
            pass


async def serve(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        raw = b""
        while b"\r\n\r\n" not in raw:
            chunk = await asyncio.wait_for(reader.read(4096), timeout=10)
            if not chunk:
                return
            raw += chunk
        head, _, rest = raw.partition(b"\r\n\r\n")
        request_line = head.split(b"\r\n")[0].split(b" ")
        path = request_line[1].decode("latin-1") if len(request_line) > 1 else "/"
        host = ""
        for line in head.split(b"\r\n")[1:]:
            if b":" in line:
                key, _, value = line.partition(b":")
                if key.decode("latin-1").strip().lower() == "host":
                    host = value.decode("latin-1").split(":")[0].strip().lower()
        peer = writer.get_extra_info("peername")
        if path.startswith("/api/"):
            # Block-page scripts call the appliance API from the block hostname
            # (access requests, client info). Relay them to the API with the real
            # client address so requests are attributed to the right device.
            try:
                upstream_reader, upstream_writer = await asyncio.open_connection(*DASHBOARD_UPSTREAM)
            except OSError:
                body = b"The appliance API is unavailable."
                writer.write(b"HTTP/1.1 503 Service Unavailable\r\nContent-Length: " + str(len(body)).encode() + b"\r\nConnection: close\r\n\r\n" + body)
                await writer.drain()
                return
            kept = [line for line in head.split(b"\r\n") if not line.lower().startswith((b"connection:", b"x-real-ip:", b"x-forwarded-for:"))]
            peer_ip = peer[0] if peer else ""
            kept.append(f"X-Real-IP: {peer_ip}".encode("latin-1"))
            kept.append(f"X-Forwarded-For: {peer_ip}".encode("latin-1"))
            upstream_writer.write(b"\r\n".join(kept) + b"\r\nConnection: close\r\n\r\n")
            if rest:
                upstream_writer.write(rest)
            await upstream_writer.drain()
            await asyncio.gather(_pipe(reader, upstream_writer), _pipe(upstream_reader, writer))
            return
        names = public_names()
        if host and host in names and names[host] == "dashboard":
            # Real public certificate: relay the whole session to the dashboard/API.
            try:
                upstream_reader, upstream_writer = await asyncio.open_connection(*DASHBOARD_UPSTREAM)
            except OSError:
                body = b"The dashboard service is unavailable."
                writer.write(b"HTTP/1.1 503 Service Unavailable\r\nContent-Length: " + str(len(body)).encode() + b"\r\nConnection: close\r\n\r\n" + body)
                await writer.drain()
                return
            # Ask the upstream to close after its response so the pipes finish cleanly.
            kept = [line for line in head.split(b"\r\n") if not line.lower().startswith(b"connection:")]
            upstream_writer.write(b"\r\n".join(kept) + b"\r\nConnection: close\r\n\r\n")
            if rest:
                upstream_writer.write(rest)
            await upstream_writer.drain()
            await asyncio.gather(_pipe(reader, upstream_writer), _pipe(upstream_reader, writer))
            return
        target = block_hostname()
        if host and host != target:
            location = f"https://{target}/?host={host}"
            body = f"Redirecting to the block page for {host}".encode()
            writer.write(b"HTTP/1.1 302 Found\r\nLocation: " + location.encode() + b"\r\nContent-Length: " + str(len(body)).encode() + b"\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n" + body)
        else:
            body = block_page()
            # no-cache: the block page changes when features change (redirect,
            # countdown); a heuristically cached old copy would break the client.
            writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + str(len(body)).encode() + b"\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n" + body)
        await writer.drain()
    except (asyncio.TimeoutError, ConnectionError, ssl.SSLError, OSError):
        pass
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except (ConnectionError, ssl.SSLError, OSError):
            pass


async def main() -> None:
    certificate, key = ensure_ca()
    factory = CertificateFactory(certificate, key)
    context = factory.context(block_hostname())
    context.sni_callback = factory.sni_callback
    server = await asyncio.start_server(serve, host=None, port=443, ssl=context, reuse_address=True)
    print(f"tls-block: serving HTTPS block pages on :443 (CA {CA_CERT})", file=sys.stderr)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
