#!/usr/bin/env python3
"""Firewall Appliance enforcement reconciler.

Runs once a minute from a systemd timer. Recomputes the desired enforcement
state from the database (categories, blocklists, device policies, schedules)
and, when it differs from the last applied state, activates new guarded
transactions:

* DNS: renders the dnsmasq candidate and activates it through the
  root transaction helper (auto-health-checked).
* iptables: renders the candidate, activates it through the root
  transaction helper, health checks management access and confirms; a
  failed health check triggers automatic rollback.

Schedule transitions (time-based access) and category toggles are enforced
here without human confirmation because the administrator pre-approved the
policy itself; the guarded confirmation window remains for interactive
topology and firewall changes made through the wizard.

Gated by FIREWALL_ENABLE_POLICY_REFRESH=1. Run with the appliance venv python.
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import socket
import struct
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

BACKEND = "/opt/firewall-appliance/backend"
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from app.database import Database  # noqa: E402
from app.models import DnsSettings, IptablesSettings  # noqa: E402
from app.services.content_filter import compiled_domains, render_block_page_live, render_dnsmasq_with_overrides, render_nginx_block_site  # noqa: E402
from app.services.iptables_engine import candidate_payload, resolve_module_state, default_module_state  # noqa: E402
from app.services.policies import compile_block_targets  # noqa: E402

STATE = Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance"))
MARKER = STATE / "refresh-state.json"
DNS_HELPER = "/usr/local/sbin/firewall-dns-transaction"
IPT_HELPER = "/usr/local/sbin/firewall-iptables-transaction"


def json_setting(database: Database, key: str, model, default):
    raw = database.setting(key)
    return model.model_validate_json(raw) if raw else default


def helper(binary: str, action: str, txn: str) -> dict:
    completed = subprocess.run([binary, action, txn], text=True, capture_output=True, timeout=120, check=False)
    try:
        body = json.loads(completed.stdout)
    except json.JSONDecodeError:
        body = {"ok": False, "message": completed.stderr.strip() or "helper produced no output"}
    body["returncode"] = completed.returncode
    return body


def load_marker() -> dict:
    if MARKER.is_file():
        try:
            return json.loads(MARKER.read_text())
        except ValueError:
            pass
    return {}


def save_marker(marker: dict) -> None:
    STATE.mkdir(parents=True, exist_ok=True)
    temporary = MARKER.with_suffix(".tmp")
    temporary.write_text(json.dumps(marker, indent=2, sort_keys=True))
    temporary.replace(MARKER)


def refresh_dns(database: Database, marker: dict) -> dict:
    settings = json_setting(database, "dns_settings", DnsSettings, DnsSettings())
    if not settings.enabled:
        return {"status": "disabled"}
    # Time-limited rules (for example a 1-hour approved access request) are
    # removed as soon as they run out, so the allow fades automatically.
    expired = database.delete_expired_local_domains()
    compiled = compiled_domains(database.local_domains(), database.application_policies(), database.blocklists(), STATE, custom_services=database.custom_services(), service_extensions=database.service_extensions())
    result = {"status": "unchanged", "expired_rules_removed": expired}
    config = render_dnsmasq_with_overrides(settings, compiled, database.dns_records())
    digest = hashlib.sha256(config.encode()).hexdigest()
    changed = digest != marker.get("dns_sha256")
    if changed:
        txn = f"dns_{secrets.token_hex(8)}"
        base = STATE / "dns-candidates" / txn
        base.mkdir(parents=True, mode=0o750, exist_ok=False)
        (base / "dnsmasq.conf").write_text(config)
        (base / "manifest.json").write_text(json.dumps({"transaction_id": txn, "sha256": digest, "created_at": time.time(), "domain_count": compiled["blocked_count"]}, sort_keys=True))
        outcome = helper(DNS_HELPER, "activate", txn)
        if outcome.get("ok"):
            marker["dns_sha256"] = digest
            database.create_security_event({"event_type": "dns", "action": "applied", "policy": "policy-refresh", "details": {"transaction_id": txn, "domain_count": compiled["blocked_count"]}})
            result = {"status": "applied", "transaction_id": txn, "domain_count": compiled["blocked_count"]}
        else:
            return {"status": "failed", "transaction_id": txn, "message": outcome.get("message")}
    # Keep the branded block URL (nginx site + live page) in step with the DNS settings.
    block_result = refresh_block_page(database, marker, settings)
    if isinstance(result, dict):
        result["block_page"] = block_result
    return result


def refresh_block_page(database: Database, marker: dict, dns_settings: DnsSettings) -> dict:
    import socket

    from app.models import BlockPageSettings

    block = json_setting(database, "block_page_settings", BlockPageSettings, BlockPageSettings())
    if not dns_settings.block_hostname:
        return {"status": "disabled"}
    dashboard_names: list[str] = []
    try:
        dashboard_names.append(socket.gethostname())
        for info in socket.getaddrinfo(socket.gethostname(), None, family=socket.AF_INET):
            dashboard_names.append(info[4][0])
    except OSError:
        pass
    try:
        from app.services.interfaces import discover_interfaces

        for info in discover_interfaces():
            for address in info.addresses:
                dashboard_names.append(str(address).split("/")[0])
    except Exception:
        pass
    dashboard_names.extend(["127.0.0.1", "localhost"])
    nginx_config = render_nginx_block_site(dns_settings.block_hostname, dashboard_names)
    live_page = render_block_page_live(block)
    digest = hashlib.sha256((nginx_config + live_page).encode()).hexdigest()
    if digest == marker.get("blockpage_sha256"):
        return {"status": "unchanged"}
    site = Path("/etc/nginx/sites-available/firewall-block-page")
    root = Path("/var/www/firewall-block")
    try:
        root.mkdir(parents=True, exist_ok=True)
        (root / "index.html").write_text(live_page)
        site.write_text(nginx_config)
        enabled = Path("/etc/nginx/sites-enabled/default")
        if enabled.exists() or enabled.is_symlink():
            enabled.unlink()
        symlink = Path("/etc/nginx/sites-enabled/firewall-block-page")
        if not symlink.exists():
            symlink.symlink_to(site)
        checked = subprocess.run(["nginx", "-t"], text=True, capture_output=True, timeout=30, check=False)
        if checked.returncode:
            return {"status": "failed", "message": (checked.stderr or "nginx rejected the block page configuration").strip()}
        reloaded = subprocess.run(["systemctl", "reload", "nginx"], text=True, capture_output=True, timeout=30, check=False)
        if reloaded.returncode:
            return {"status": "failed", "message": (reloaded.stderr or "nginx reload failed").strip()}
    except OSError as exc:
        return {"status": "failed", "message": str(exc)}
    marker["blockpage_sha256"] = digest
    database.create_security_event({"event_type": "proxy", "action": "applied", "policy": "policy-refresh", "details": {"block_hostname": dns_settings.block_hostname}})
    return {"status": "applied", "block_url": f"http://{dns_settings.block_hostname}/"}


def refresh_iptables(database: Database, marker: dict) -> dict:
    settings = json_setting(database, "iptables_settings", IptablesSettings, IptablesSettings())
    raw_modules = database.setting("iptables_modules")
    modules = resolve_module_state(json.loads(raw_modules) if raw_modules else default_module_state())
    dns_settings = json_setting(database, "dns_settings", DnsSettings, DnsSettings())
    applications = database.application_policies()
    from app.models import BlockPageSettings

    block_page = json_setting(database, "block_page_settings", BlockPageSettings, BlockPageSettings())
    portal = json_setting(database, "portal_settings", __import__("app.models", fromlist=["PortalSettings"]).PortalSettings, __import__("app.models", fromlist=["PortalSettings"]).PortalSettings())
    controls = {
        "block_quic": any(row["enabled"] and row["block_quic"] for row in applications),
        "block_dot": dns_settings.block_dot,
        "block_doh": dns_settings.block_doh,
        "force_local_dns": dns_settings.enabled,
        "tls_block": block_page.https_block,
        "portal_enabled": portal.enabled,
    }
    network_rules = {"zones": database.zones(), "port_forwards": database.port_forwards(), "pools": database.ip_pools()}
    block_targets = compile_block_targets(database.policy_sources())
    payload = candidate_payload(modules, settings.model_dump(), network_rules, block_targets, controls)
    if not payload["validation"]["valid"]:
        return {"status": "invalid", "message": payload["validation"]["message"]}
    if payload["sha256"] == marker.get("iptables_sha256"):
        return {"status": "unchanged", "blocking_targets": block_targets}
    txn = f"ipt_{secrets.token_hex(8)}"
    base = STATE / "iptables-candidates" / txn
    base.mkdir(parents=True, mode=0o750, exist_ok=False)
    (base / "rules.v4").write_text(payload["rules"])
    if payload.get("rules6"):
        (base / "rules.v6").write_text(payload["rules6"])
    (base / "manifest.json").write_text(json.dumps({"transaction_id": txn, "sha256": payload["sha256"], "created_at": time.time(), "expires_at": time.time() + 900, "rollback_seconds": 45, "modules": payload["modules"]}, sort_keys=True))
    activated = helper(IPT_HELPER, "activate", txn)
    if not activated.get("ok"):
        return {"status": "failed", "transaction_id": txn, "message": activated.get("message")}
    if not management_healthy():
        helper(IPT_HELPER, "rollback", txn)
        database.create_security_event({"event_type": "firewall", "action": "alert", "policy": "policy-refresh", "details": {"transaction_id": txn, "outcome": "rolled-back", "reason": "management health check failed"}})
        return {"status": "rolled-back", "transaction_id": txn, "message": "management health check failed; previous ruleset restored"}
    confirmed = helper(IPT_HELPER, "confirm", txn)
    if confirmed.get("ok"):
        marker["iptables_sha256"] = payload["sha256"]
        database.create_security_event({"event_type": "firewall", "action": "applied", "policy": "policy-refresh", "details": {"transaction_id": txn, "blocked_ipv4": len(block_targets.get("ipv4", [])), "blocked_mac": len(block_targets.get("mac", []))}})
        return {"status": "applied", "transaction_id": txn, "blocking_targets": block_targets}
    return {"status": "failed", "transaction_id": txn, "message": confirmed.get("message")}


def refresh_ids(database: Database, marker: dict) -> dict:
    """Keep the Suricata service in step with the IDS/IPS module switch.

    The NFQUEUE kernel rule comes and goes with the module through the normal
    iptables candidate flow. This step makes sure the engine process itself is
    running whenever the module is on (and stopped when it is off), so a manual
    `systemctl stop` cannot silently disable inspection.
    """
    import shutil

    raw_modules = database.setting("iptables_modules")
    modules = resolve_module_state(json.loads(raw_modules) if raw_modules else default_module_state())
    if not shutil.which("suricata") or not Path("/etc/systemd/system/firewall-ids.service").is_file():
        return {"status": "not-installed"}
    desired = bool(modules.get("ids_ips"))
    active = subprocess.run(["systemctl", "is-active", "firewall-ids", "--quiet"], check=False).returncode == 0
    if active == desired:
        return {"status": "unchanged", "running": active}
    outcome = subprocess.run(["systemctl", "start" if desired else "stop", "firewall-ids"], text=True, capture_output=True, timeout=60, check=False)
    if outcome.returncode:
        return {"status": "failed", "message": (outcome.stderr or outcome.stdout or "systemctl failed").strip()[:200]}
    database.create_security_event({"event_type": "firewall", "action": "applied" if desired else "stopped", "policy": "ids-ips-reconcile", "details": {"service": "firewall-ids"}})
    return {"status": "started" if desired else "stopped"}


def refresh_alerts(database: Database) -> dict:
    """Bring Suricata alerts (eve.json) into the dashboard's event log."""
    from app.services.ids_alerts import ingest_ids_alerts

    try:
        return {"status": "ok", "ingested": ingest_ids_alerts(database)}
    except Exception as exc:  # ingestion must never break the refresh cycle
        return {"status": "failed", "message": str(exc)[:200]}


def management_healthy() -> bool:
    """The appliance management API must answer after any ruleset change."""
    try:
        with urllib.request.urlopen("http://127.0.0.1:8080/api/v1/health", timeout=8) as response:
            return response.status == 200
    except OSError:
        return False


def main() -> int:
    if os.environ.get("FIREWALL_ENABLE_POLICY_REFRESH") != "1":
        print(json.dumps({"ok": True, "skipped": "policy refresh disabled"}))
        return 0
    database = Database()
    database.initialize()
    marker = load_marker()
    # Pools + portal first: VLAN adapters must exist before the ruleset that
    # references them, and the portal set before any rule uses it.
    from pools_sync import sync_pools_and_kea  # noqa: E402 — same deploy package

    result = {"pools": sync_pools_and_kea(database, marker), "dns": refresh_dns(database, marker), "iptables": refresh_iptables(database, marker), "ids_ips": refresh_ids(database, marker), "ids_alerts": refresh_alerts(database), "checked_at": time.time()}
    save_marker(marker)
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
