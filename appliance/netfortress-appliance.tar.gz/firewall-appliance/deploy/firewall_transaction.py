#!/usr/bin/env python3
"""Root-only nftables transaction helper.

The API service never runs as root. This helper accepts only a validated
transaction identifier and one of four fixed operations.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path


TRANSACTION_RE = re.compile(r"^txn_[0-9a-f]{16}$")
STATE_DIR = Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance"))
TRANSACTIONS = STATE_DIR / "transactions"
ROLLBACKS = Path(os.environ.get("FIREWALL_ROLLBACK_DIR", "/var/lib/firewall-appliance-rollback"))
INTERFACE_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,15}$")
ALLOWED_ACTIONS = {"sysctl", "create_bridge", "create_vlan", "set_master", "link_up", "delete_address", "replace_address", "replace_default_route"}
SERVICE_TARGETS = {
    "dns.json": Path("/etc/firewall-appliance/dns-policy.json"),
    "kea-dhcp4.conf": Path("/etc/kea/kea-dhcp4.conf"),
    "squid.conf": Path("/etc/squid/squid.conf"),
    "block-page.html": Path("/var/www/firewall-appliance/block.html"),
}


def run(command: list[str], *, check: bool = True, timeout: int = 20) -> subprocess.CompletedProcess:
    return subprocess.run(command, check=check, capture_output=True, text=True, timeout=timeout)


def paths(transaction_id: str) -> tuple[Path, Path, Path, Path]:
    if not TRANSACTION_RE.fullmatch(transaction_id):
        raise ValueError("Invalid transaction identifier")
    transaction = TRANSACTIONS / transaction_id
    rollback = ROLLBACKS / transaction_id
    if not transaction.is_dir():
        raise FileNotFoundError("Transaction does not exist")
    return transaction, transaction / "nftables.conf", transaction / "network-plan.json", rollback


def metadata(transaction: Path) -> dict:
    return json.loads((transaction / "metadata.json").read_text(encoding="utf-8"))


def write_status(transaction: Path, status: str, **extra) -> dict:
    data = metadata(transaction)
    data.update(extra)
    data["status"] = status
    data["updated_at"] = datetime.now(UTC).isoformat()
    temporary = transaction / "metadata.json.tmp"
    temporary.write_text(json.dumps(data, indent=2), encoding="utf-8")
    temporary.replace(transaction / "metadata.json")
    return data


def require_status(transaction: Path, expected: str) -> None:
    current = metadata(transaction).get("status")
    if current != expected:
        raise ValueError(f"Transaction must be {expected}; current status is {current}")


def verify_candidate(transaction: Path, candidate: Path) -> None:
    if candidate.is_symlink() or not candidate.is_file():
        raise ValueError("Candidate must be a regular file")
    data = candidate.read_bytes()
    expected = metadata(transaction).get("sha256")
    actual = hashlib.sha256(data).hexdigest()
    if not expected or not hmac.compare_digest(expected, actual):
        raise ValueError("Candidate hash mismatch")
    text = data.decode("utf-8")
    allowed_tables = {"table inet firewall_appliance", "table ip firewall_appliance_nat"}
    table_lines = {line.strip().rstrip(" {") for line in text.splitlines() if line.strip().startswith("table ")}
    if not table_lines or not table_lines.issubset(allowed_tables):
        raise ValueError("Candidate contains an unauthorized nftables table")
    run(["nft", "--check", "--file", str(candidate)])


def verify_network_plan(transaction: Path, plan_path: Path) -> list[dict]:
    if plan_path.is_symlink() or not plan_path.is_file():
        raise ValueError("Network plan must be a regular file")
    content = plan_path.read_bytes()
    expected = metadata(transaction).get("network_plan_sha256")
    if not expected or not hmac.compare_digest(expected, hashlib.sha256(content).hexdigest()):
        raise ValueError("Network plan hash mismatch")
    plan = json.loads(content)
    if not isinstance(plan, list) or len(plan) > 64:
        raise ValueError("Invalid network plan")
    for operation in plan:
        if not isinstance(operation, dict) or set(operation) != {"action", "interface", "value", "parent"}:
            raise ValueError("Invalid network operation structure")
        if operation["action"] not in ALLOWED_ACTIONS:
            raise ValueError("Unauthorized network operation")
        for key in ("interface", "parent"):
            value = operation[key]
            if value is not None and not INTERFACE_RE.fullmatch(value):
                raise ValueError(f"Invalid {key}")
    return plan


def verify_service_configs(transaction: Path) -> dict[str, Path]:
    expected = metadata(transaction).get("service_config_sha256", {})
    if not isinstance(expected, dict) or set(expected) - set(SERVICE_TARGETS):
        raise ValueError("Invalid service configuration manifest")
    verified: dict[str, Path] = {}
    for name, digest in expected.items():
        candidate = transaction / "services" / name
        if candidate.is_symlink() or not candidate.is_file() or not hmac.compare_digest(hashlib.sha256(candidate.read_bytes()).hexdigest(), digest):
            raise ValueError(f"Service configuration hash mismatch: {name}")
        verified[name] = candidate
    if "kea-dhcp4.conf" in verified and Path("/usr/sbin/kea-dhcp4").exists():
        # kea's AppArmor profile only permits reading configuration under
        # /etc/kea, so validation runs against a temporary copy there. The
        # check must also run as the _kea service user: as root, kea-dhcp4
        # requests DAC capabilities that its profile denies, so the syntax
        # test fails for every configuration including valid ones.
        test_copy = Path("/etc/kea/candidate-validation.conf")
        shutil.copyfile(verified["kea-dhcp4.conf"], test_copy)
        test_copy.chmod(0o644)
        try:
            run(["runuser", "-u", "_kea", "--", "/usr/sbin/kea-dhcp4", "-t", str(test_copy)])
        finally:
            test_copy.unlink(missing_ok=True)
    if "squid.conf" in verified and Path("/usr/sbin/squid").exists():
        run(["/usr/sbin/squid", "-k", "parse", "-f", verified["squid.conf"]])
    json.loads(verified["dns.json"].read_text(encoding="utf-8")) if "dns.json" in verified else None
    return verified


def apply_service_configs(configs: dict[str, Path], rollback: Path) -> None:
    snapshot_dir = rollback / "services"
    snapshot_dir.mkdir(mode=0o700)
    state: dict[str, bool] = {}
    for name, candidate in configs.items():
        target = SERVICE_TARGETS[name]
        target.parent.mkdir(parents=True, exist_ok=True)
        state[name] = target.exists()
        (snapshot_dir / "state.json").write_text(json.dumps(state), encoding="utf-8")
        if target.exists():
            (snapshot_dir / name).write_bytes(target.read_bytes())
        temporary = target.with_suffix(target.suffix + ".new")
        temporary.write_bytes(candidate.read_bytes())
        # 0644 like the distribution defaults: kea and squid run as unprivileged
        # service users that must be able to read their own configuration.
        temporary.chmod(0o644)
        temporary.replace(target)
    for unit in ("kea-dhcp4-server", "squid"):
        # Restart unconditionally (not try-restart): a failed unit must be
        # revived. squid can wait up to 30 seconds for connections to close.
        run(["systemctl", "restart", unit], check=False, timeout=90)


def rollback_service_configs(rollback: Path) -> None:
    snapshot_dir = rollback / "services"
    state_path = snapshot_dir / "state.json"
    if not state_path.exists():
        return
    for name, existed in json.loads(state_path.read_text()).items():
        target = SERVICE_TARGETS[name]
        snapshot = snapshot_dir / name
        if existed and snapshot.exists():
            target.write_bytes(snapshot.read_bytes())
        elif not existed and target.exists():
            target.unlink()
    for unit in ("kea-dhcp4-server", "squid"):
        run(["systemctl", "restart", unit], check=False, timeout=90)


def json_command(command: list[str]) -> list[dict]:
    result = run(command, check=False)
    if result.returncode != 0:
        return []
    parsed = json.loads(result.stdout or "[]")
    return parsed if isinstance(parsed, list) else []


def apply_network_plan(plan: list[dict], rollback: Path) -> None:
    undo: list[dict] = []

    def record_undo(operation: dict) -> None:
        undo.append(operation)
        temporary = rollback / "network.undo.json.tmp"
        temporary.write_text(json.dumps(undo, indent=2), encoding="utf-8")
        temporary.replace(rollback / "network.undo.json")

    for operation in plan:
        action, interface, value, parent = (operation[key] for key in ("action", "interface", "value", "parent"))
        if action == "sysctl":
            key, new_value = str(value).split("=", 1)
            if key not in {"net.ipv4.ip_forward", "net.ipv6.conf.all.forwarding"} or new_value != "1":
                raise ValueError("Unauthorized sysctl")
            previous = run(["sysctl", "-n", key]).stdout.strip()
            run(["sysctl", "-w", f"{key}=1"])
            record_undo({"action": "sysctl", "key": key, "value": previous})
        elif action == "create_bridge":
            existed = Path(f"/sys/class/net/{interface}").exists()
            if not existed:
                run(["ip", "link", "add", "name", interface, "type", "bridge"])
                record_undo({"action": "delete_link", "interface": interface})
        elif action == "create_vlan":
            existed = Path(f"/sys/class/net/{interface}").exists()
            vlan_id = int(value)
            if not 1 <= vlan_id <= 4094:
                raise ValueError("Invalid VLAN identifier")
            if not existed:
                run(["ip", "link", "add", "link", parent, "name", interface, "type", "vlan", "id", str(vlan_id)])
                record_undo({"action": "delete_link", "interface": interface})
        elif action == "set_master":
            master_link = Path(f"/sys/class/net/{interface}/master")
            previous = master_link.resolve().name if master_link.exists() else None
            run(["ip", "link", "set", "dev", interface, "master", parent])
            record_undo({"action": "set_master", "interface": interface, "parent": previous})
        elif action == "link_up":
            info = json_command(["ip", "-j", "link", "show", "dev", interface])
            was_up = bool(info and "UP" in info[0].get("flags", []))
            run(["ip", "link", "set", "dev", interface, "up"])
            if not was_up:
                record_undo({"action": "link_down", "interface": interface})
        elif action == "replace_address":
            previous = json_command(["ip", "-j", "address", "show", "dev", interface])
            prior = [f"{item['local']}/{item['prefixlen']}" for row in previous for item in row.get("addr_info", []) if item.get("family") in {"inet", "inet6"}]
            run(["ip", "address", "replace", str(value), "dev", interface])
            record_undo({"action": "restore_address", "interface": interface, "added": str(value), "prior": prior})
        elif action == "delete_address":
            previous = json_command(["ip", "-j", "address", "show", "dev", interface])
            prior = [f"{item['local']}/{item['prefixlen']}" for row in previous for item in row.get("addr_info", []) if f"{item['local']}/{item['prefixlen']}" == str(value)]
            run(["ip", "address", "delete", str(value), "dev", interface], check=False)
            if prior:
                record_undo({"action": "restore_deleted_address", "interface": interface, "prior": prior})
        elif action == "replace_default_route":
            family = "-6" if ":" in str(value) else "-4"
            previous = json_command(["ip", family, "-j", "route", "show", "default"])
            run(["ip", family, "route", "replace", "default", "via", str(value), "dev", interface])
            record_undo({"action": "restore_default", "family": family, "interface": interface, "prior": previous})


def rollback_network(rollback: Path) -> None:
    path = rollback / "network.undo.json"
    if not path.is_file():
        return
    for operation in reversed(json.loads(path.read_text(encoding="utf-8"))):
        action = operation["action"]
        if action == "sysctl":
            run(["sysctl", "-w", f"{operation['key']}={operation['value']}"], check=False)
        elif action == "delete_link":
            run(["ip", "link", "delete", "dev", operation["interface"]], check=False)
        elif action == "set_master":
            command = ["ip", "link", "set", "dev", operation["interface"]]
            command += ["master", operation["parent"]] if operation["parent"] else ["nomaster"]
            run(command, check=False)
        elif action == "link_down":
            run(["ip", "link", "set", "dev", operation["interface"], "down"], check=False)
        elif action == "restore_address":
            run(["ip", "address", "delete", operation["added"], "dev", operation["interface"]], check=False)
            for address in operation["prior"]:
                run(["ip", "address", "replace", address, "dev", operation["interface"]], check=False)
        elif action == "restore_deleted_address":
            for address in operation["prior"]:
                run(["ip", "address", "replace", address, "dev", operation["interface"]], check=False)
        elif action == "restore_default":
            run(["ip", operation["family"], "route", "delete", "default", "dev", operation["interface"]], check=False)
            for route in operation["prior"]:
                command = ["ip", operation["family"], "route", "replace", "default"]
                if route.get("gateway"):
                    command += ["via", route["gateway"]]
                if route.get("dev"):
                    command += ["dev", route["dev"]]
                if route.get("metric") is not None:
                    command += ["metric", str(route["metric"])]
                run(command, check=False)


def unit_name(transaction_id: str) -> str:
    return f"firewall-rollback-{transaction_id}.timer"


def activate(transaction_id: str) -> dict:
    transaction, candidate, plan_path, rollback = paths(transaction_id)
    require_status(transaction, "prepared")
    verify_candidate(transaction, candidate)
    plan = verify_network_plan(transaction, plan_path)
    service_configs = verify_service_configs(transaction)
    rollback.mkdir(parents=True, mode=0o700, exist_ok=False)
    snapshot = rollback / "nftables.snapshot"
    current = run(["nft", "--stateless", "list", "ruleset"])
    snapshot.write_text("flush ruleset\n" + current.stdout, encoding="utf-8")
    snapshot.chmod(0o600)
    helper = str(Path(__file__).resolve())
    run(["systemd-run", "--quiet", f"--unit=firewall-rollback-{transaction_id}", "--on-active=120s", helper, "auto-rollback", transaction_id])
    try:
        apply_network_plan(plan, rollback)
        run(["nft", "--file", str(candidate)])
        apply_service_configs(service_configs, rollback)
    except Exception:
        rollback_now(transaction_id, automatic=True)
        raise
    return write_status(transaction, "awaiting_confirmation", activated_at=datetime.now(UTC).isoformat(), rollback_deadline_seconds=120)


def confirm(transaction_id: str) -> dict:
    transaction, _, _, rollback = paths(transaction_id)
    require_status(transaction, "awaiting_confirmation")
    run(["systemctl", "stop", unit_name(transaction_id)], check=False)
    marker = rollback / "confirmed"
    marker.write_text(datetime.now(UTC).isoformat(), encoding="utf-8")
    marker.chmod(0o600)
    return write_status(transaction, "committed", confirmed_at=datetime.now(UTC).isoformat())


def rollback_now(transaction_id: str, automatic: bool = False) -> dict:
    transaction, _, _, rollback = paths(transaction_id)
    if not automatic:
        require_status(transaction, "awaiting_confirmation")
    snapshot = rollback / "nftables.snapshot"
    if not snapshot.is_file() or snapshot.is_symlink():
        raise FileNotFoundError("Rollback snapshot is unavailable")
    run(["nft", "--file", str(snapshot)])
    rollback_network(rollback)
    rollback_service_configs(rollback)
    if not automatic:
        run(["systemctl", "stop", unit_name(transaction_id)], check=False)
    return write_status(transaction, "rolled_back", rolled_back_at=datetime.now(UTC).isoformat(), automatic_rollback=automatic)


def show_status(transaction_id: str) -> dict:
    transaction, _, _, _ = paths(transaction_id)
    return metadata(transaction)


def health(transaction_id: str) -> dict:
    """Run the privileged subset of activation health checks.

    The API process is unprivileged and sandboxed: nft inspection, route
    lookups and the kea/squid configuration tests must run as root (and kea
    as its service user). Never mutates anything.
    """
    paths(transaction_id)
    checks: dict[str, dict] = {}

    def record(name: str, command: list[str], timeout: int = 20) -> None:
        result = run(command, check=False, timeout=timeout)
        checks[name] = {"passed": result.returncode == 0, "message": (result.stdout or result.stderr or "completed").strip()[:800]}

    record("nftables_table", ["nft", "list", "table", "inet", "firewall_appliance"])
    record("default_route", ["ip", "route", "get", "1.1.1.1"])
    if Path("/usr/sbin/kea-dhcp4").exists():
        record("kea_configuration", ["runuser", "-u", "_kea", "--", "/usr/sbin/kea-dhcp4", "-t", "/etc/kea/kea-dhcp4.conf"])
    if Path("/usr/sbin/squid").exists():
        record("squid_configuration", ["/usr/sbin/squid", "-k", "parse", "-f", "/etc/squid/squid.conf"], timeout=30)
    return {"ok": True, "transaction_id": transaction_id, "checks": checks}


def main() -> int:
    if os.geteuid() != 0:
        print(json.dumps({"error": "This helper must run as root"}))
        return 77
    if len(sys.argv) != 3 or sys.argv[1] not in {"activate", "confirm", "rollback", "auto-rollback", "status", "health"}:
        print(json.dumps({"error": "Usage: firewall-transaction <activate|confirm|rollback|status|health> <transaction-id>"}))
        return 64
    action, transaction_id = sys.argv[1:]
    try:
        handlers = {"activate": activate, "confirm": confirm, "rollback": rollback_now, "auto-rollback": lambda value: rollback_now(value, automatic=True), "status": show_status, "health": health}
        result = handlers[action](transaction_id)
        print(json.dumps(result))
        return 0
    except Exception as exc:
        print(json.dumps({"error": str(exc), "type": type(exc).__name__}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
