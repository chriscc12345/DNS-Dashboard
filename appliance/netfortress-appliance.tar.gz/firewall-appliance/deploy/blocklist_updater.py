#!/usr/bin/env python3
from app.database import Database
from app.services.content_filter import update_due_blocklists


def main() -> None:
    database = Database()
    database.initialize()
    result = update_due_blocklists(database)
    failed = [item for item in result["sources"] if item["status"] == "failed"]
    database.audit(actor_type="system", actor_id="blocklist-updater", action="blocklist.scheduled_update", resource_type="blocklist", outcome="failure" if failed else "success", details={"sources": result["sources"]})
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
