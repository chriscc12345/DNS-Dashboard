#!/usr/bin/env python3
"""Root-only transactional iptables activator.

Candidates must be created under /var/lib/firewall-appliance/iptables-candidates
by the appliance API and contain rules.v4 plus manifest.json. This helper never
accepts paths or shell fragments from the caller.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

STATE = Path("/var/lib/firewall-appliance")
CANDIDATES = STATE / "iptables-candidates"
ROLLBACK = Path("/var/lib/firewall-appliance-rollback/iptables")
ACTIVE = STATE / "iptables-active.json"
TXN_RE = re.compile(r"^ipt_[0-9a-f]{16}$")


def fail(message: str, code: int = 1) -> None:
    print(json.dumps({"ok": False, "message": message}))
    raise SystemExit(code)


def run(args: list[str], *, stdin: str | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(args, input=stdin, text=True, capture_output=True, timeout=30, check=False)


def paths(txn: str) -> tuple[Path, Path]:
    if not TXN_RE.fullmatch(txn):
        fail("Invalid transaction identifier", 2)
    return CANDIDATES / txn, ROLLBACK / txn


def load_candidate(txn: str) -> tuple[dict, str, Path]:
    candidate, snapshot = paths(txn)
    manifest_path = candidate / "manifest.json"
    rules_path = candidate / "rules.v4"
    if not manifest_path.is_file() or not rules_path.is_file():
        fail("Candidate is incomplete")
    manifest = json.loads(manifest_path.read_text())
    rules = rules_path.read_text()
    digest = hashlib.sha256(rules.encode()).hexdigest()
    if manifest.get("sha256") != digest:
        fail("Candidate hash mismatch")
    if manifest.get("expires_at", 0) < time.time():
        fail("Candidate expired")
    return manifest, rules, snapshot


def activate(txn: str) -> None:
    manifest, rules, snapshot = load_candidate(txn)
    restore = shutil.which("iptables-restore") or fail("iptables-restore is unavailable")
    save = shutil.which("iptables-save") or fail("iptables-save is unavailable")
    checked = run([restore, "--test"], stdin=rules)
    if checked.returncode:
        fail(f"Kernel rejected candidate: {checked.stderr.strip()}")
    snapshot.mkdir(parents=True, exist_ok=False)
    current = run([save])
    if current.returncode:
        fail(f"Could not snapshot active rules: {current.stderr.strip()}")
    (snapshot / "rules.v4").write_text(current.stdout)
    applied = run([restore, "--wait", "5"], stdin=rules)
    if applied.returncode:
        run([restore], stdin=current.stdout)
        fail(f"Activation failed and was rolled back: {applied.stderr.strip()}")
    deadline = time.time() + min(max(int(manifest.get("rollback_seconds", 120)), 30), 900)
    record = {"transaction_id": txn, "state": "pending-confirmation", "activated_at": time.time(), "rollback_deadline": deadline, "sha256": manifest["sha256"]}
    ACTIVE.write_text(json.dumps(record, sort_keys=True))
    print(json.dumps({"ok": True, **record}))


def confirm(txn: str) -> None:
    record = json.loads(ACTIVE.read_text()) if ACTIVE.is_file() else {}
    if record.get("transaction_id") != txn or record.get("state") != "pending-confirmation":
        fail("Transaction is not awaiting confirmation")
    record["state"] = "committed"
    record["confirmed_at"] = time.time()
    ACTIVE.write_text(json.dumps(record, sort_keys=True))
    print(json.dumps({"ok": True, **record}))


def rollback(txn: str) -> None:
    _, snapshot = paths(txn)
    rules_path = snapshot / "rules.v4"
    if not rules_path.is_file():
        fail("Rollback snapshot does not exist")
    restore = shutil.which("iptables-restore") or fail("iptables-restore is unavailable")
    result = run([restore, "--wait", "5"], stdin=rules_path.read_text())
    if result.returncode:
        fail(f"Rollback failed: {result.stderr.strip()}")
    record = json.loads(ACTIVE.read_text()) if ACTIVE.is_file() else {"transaction_id": txn}
    record["state"] = "rolled-back"
    record["rolled_back_at"] = time.time()
    ACTIVE.write_text(json.dumps(record, sort_keys=True))
    print(json.dumps({"ok": True, **record}))


def status(txn: str) -> None:
    paths(txn)
    record = json.loads(ACTIVE.read_text()) if ACTIVE.is_file() else {}
    if record.get("transaction_id") != txn:
        fail("Transaction is not active")
    print(json.dumps({"ok": True, **record}))


def main() -> None:
    if os.geteuid() != 0 or len(sys.argv) != 3:
        fail("Usage: firewall-iptables-transaction activate|confirm|rollback|status ipt_<id>", 2)
    action, txn = sys.argv[1:]
    {"activate": activate, "confirm": confirm, "rollback": rollback, "status": status}.get(action, lambda _: fail("Unsupported action", 2))(txn)


if __name__ == "__main__":
    main()
