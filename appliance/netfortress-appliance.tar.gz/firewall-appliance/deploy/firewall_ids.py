#!/usr/bin/env python3
"""Root helper for the IDS/IPS module (Suricata).

The appliance ships WITHOUT Suricata: a customer installs it on demand from
the dashboard (POST /api/v1/firewall/modules/ids_ips/install). This helper is
the only privileged path:

  install    apt-install Suricata, write the managed configuration, create and
             start the firewall-ids service (NFQUEUE mode).
  status     report installed / running / version for the dashboard.
  uninstall  stop and remove the service, purge the package and config.

It takes no arguments beyond the fixed action, never evaluates untrusted
input, and derives the monitored network ranges from the live interfaces.
Traffic safety: the kernel rules send traffic to Suricata with --queue-bypass,
so inspection never becomes an outage. Removing the package does not touch
the iptables state; the reconciler drops the NFQUEUE rule when the module is
switched off.
"""
from __future__ import annotations

import ipaddress
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
from datetime import UTC, datetime
from pathlib import Path

CONFIG = Path("/etc/suricata/firewall-appliance.yaml")
SERVICE = Path("/etc/systemd/system/firewall-ids.service")
STATE = Path("/var/lib/firewall-appliance/ids-state.json")
RULES_DIR = Path("/var/lib/firewall-appliance/ids-rules")
RULES_STAGING = Path("/var/lib/firewall-appliance/ids-rules.staging")
RULES_PREVIOUS = Path("/var/lib/firewall-appliance/ids-rules.previous")
RULES_SERVICE = Path("/etc/systemd/system/firewall-ids-rules.service")
RULES_TIMER = Path("/etc/systemd/system/firewall-ids-rules.timer")
ET_URL = "https://rules.emergingthreats.net/open/suricata-7/emerging.rules.tar.gz"
PACKAGE = "suricata"
QUEUE_NUM = 1


def emit(body: dict, code: int = 0) -> None:
    print(json.dumps(body, indent=None))
    raise SystemExit(code)


def run(args: list[str], timeout: int = 60, env: dict | None = None) -> subprocess.CompletedProcess:
    environ = {**os.environ, "DEBIAN_FRONTEND": "noninteractive"}
    if env:
        environ.update(env)
    return subprocess.run(args, text=True, capture_output=True, timeout=timeout, check=False, env=environ)


def home_networks() -> list[str]:
    """Every global IPv4 network the appliance is attached to = protected space."""
    completed = run(["ip", "-4", "-o", "addr", "show", "scope", "global"])
    networks: list[str] = []
    for line in completed.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 4:
            try:
                networks.append(str(ipaddress.ip_interface(parts[3]).network))
            except ValueError:
                pass
    return sorted(set(networks)) or ["192.168.0.0/16"]


def service_active() -> bool:
    return run(["systemctl", "is-active", "firewall-ids", "--quiet"]).returncode == 0


def suricata_version() -> str | None:
    completed = run([f"/usr/bin/{PACKAGE}", "-V"])
    if completed.returncode:
        return None
    for line in (completed.stdout + completed.stderr).splitlines():
        if line.strip():
            return line.strip()[-120:]
    return None


def status() -> dict:
    installed = Path(f"/usr/bin/{PACKAGE}").is_file()
    body = {
        "ok": True,
        "installed": installed,
        "running": installed and service_active(),
        "enabled_in_kernel": False,
        "version": suricata_version() if installed else None,
        "home_networks": home_networks(),
        "queue": QUEUE_NUM,
    }
    if installed:
        saved = run(["iptables-save"])
        body["enabled_in_kernel"] = f"--queue-num {QUEUE_NUM}" in saved.stdout
    if STATE.is_file():
        try:
            saved = json.loads(STATE.read_text())
            body["installed_at"] = saved.get("installed_at")
            body["ruleset"] = saved.get("ruleset")
            body["rules_count"] = saved.get("rules_count")
            body["updated_at"] = saved.get("updated_at")
            body["rules_auto_update"] = RULES_TIMER.is_file()
        except ValueError:
            pass
    return body


def render_config(home: str, rules_dir: Path | None, rule_files: list[str], extra_header: str = "") -> str:
    """The single managed-config template shared by install and rules-update."""
    if rules_dir is not None:
        rules_block = f"default-rule-path: {rules_dir}\n" + extra_header + "rule-files:\n" + "".join(f"  - {item}\n" for item in rule_files)
    else:
        rules_block = "# No signature rules found yet; Suricata runs without rules.\n# Use Update rules to load the ET Open attack-signature feed.\n"
    return f"""%YAML 1.1
---
# Managed by Firewall Appliance (firewall-ids helper). Manual edits are
# replaced on reinstall. Traffic arrives through kernel NFQUEUE rules.
vars:
  address-groups:
    HOME_NET: "[{home}]"
    EXTERNAL_NET: "!$HOME_NET"
    HTTP_SERVERS: "$HOME_NET"
    SMTP_SERVERS: "$HOME_NET"
    SQL_SERVERS: "$HOME_NET"
    TELNET_SERVERS: "$HOME_NET"
    DNS_SERVERS: "$HOME_NET"
    DNP3_SERVERS: "$HOME_NET"
    MODBUS_CLIENT: "any"
    MODBUS_SERVER: "any"
    ENIP_CLIENT: "any"
    ENIP_SERVER: "any"
    DC_SERVERS: "$HOME_NET"
  port-groups:
    HTTP_PORTS: "[80,8080]"
    SHELLCODE_PORTS: "!80"
    SSH_PORTS: 22
    ORACLE_PORTS: 1521
    DNP3_PORTS: 20000
    MODBUS_PORTS: 502
    FILE_DATA_PORTS: "[$HTTP_PORTS,110,143]"
    GENEVE_PORTS: 6081
    VXLAN_PORTS: 4789
    TEREDO_PORTS: 3544
{rules_block}
default-app-layer:
  tls:
    enabled: yes
# The bundled protocol-event rules and many ET signatures reference these
# protocols; without detection-enabled Suricata refuses to load them.
app-layer:
  protocols:
    modbus: {{enabled: yes, detection-enabled: yes}}
    dnp3: {{enabled: yes, detection-enabled: yes, detection-ports: {{dp: 20000}}}}
    nfs: {{enabled: yes, detection-enabled: yes}}
    kerberos: {{enabled: yes, detection-enabled: yes}}
    smb: {{enabled: yes, detection-enabled: yes}}
    rfb: {{enabled: yes, detection-enabled: yes}}
    mqtt: {{enabled: yes, detection-enabled: yes}}
    ipsec: {{enabled: yes, detection-enabled: yes}}
    dhcp: {{enabled: yes, detection-enabled: yes}}
    ntp: {{enabled: yes, detection-enabled: yes}}
    quic: {{enabled: yes, detection-enabled: yes}}
    http2: {{enabled: yes, detection-enabled: yes}}
    ftp: {{enabled: yes, detection-enabled: yes}}
    smtp: {{enabled: yes, detection-enabled: yes}}
    ssh: {{enabled: yes, detection-enabled: yes}}
    tls: {{enabled: yes, detection-enabled: yes}}
    dns: {{enabled: yes, detection-enabled: yes}}
    http: {{enabled: yes, detection-enabled: yes}}

nfq:
  # 'accept' = terminal verdict: Suricata passes clean packets, drops ones
  # matching attack signatures (IPS). No mark-loop handling needed.
  mode: accept
  threads: auto
  queue: {QUEUE_NUM}
  fail-open: yes

outputs:
  - eve-log:
      enabled: yes
      types:
        - alert:
            tagged-packets: no
        - anomaly:
            enabled: no
      community-id: yes
      community-id-seed: 0
  - stats:
      enabled: yes
      interval: 30

logging:
  default-log-level: notice
  outputs:
    - console:
        enabled: no
    - file:
        enabled: yes
        level: info
        filename: /var/log/suricata/firewall-ids.log
"""


def write_rules_timer() -> None:
    """Daily automatic rules refresh — customers should not have to remember it."""
    RULES_SERVICE.write_text("""[Unit]
Description=Firewall Appliance IDS/IPS daily rules update

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/firewall-ids rules-update
""")
    RULES_TIMER.write_text("""[Unit]
Description=Firewall Appliance IDS/IPS daily rules update

[Timer]
OnCalendar=daily
RandomizedDelaySec=30m
Persistent=true

[Install]
WantedBy=timers.target
""")
    run(["systemctl", "daemon-reload"])
    run(["systemctl", "enable", "--now", "firewall-ids-rules.timer"], timeout=60)


def apply_rules_dir(rules_dir: Path, home: str, config_path: Path = CONFIG) -> None:
    """Point a config at a rules directory (used for validation, apply, rollback)."""
    classification = rules_dir / "classification.config"
    reference = rules_dir / "reference.config"
    extra = ""
    if classification.is_file():
        extra += f"classification-file: {classification}\n"
    else:
        extra += "classification-file: /etc/suricata/classification.config\n"
    extra += f"reference-file: {reference if reference.is_file() else Path('/etc/suricata/reference.config')}\n"
    config_path.write_text(render_config(home, rules_dir, ['"*.rules"'], extra_header=extra))


def rules_update() -> dict:
    """Download the ET Open feed, validate it, and live-reload — with rollback.

    Never leaves the IDS down: the candidate is syntax-checked first, and if
    the reload with the new rules fails, the previous rules and config are
    restored and the service restarted on them."""
    if not Path(f"/usr/bin/{PACKAGE}").is_file():
        emit({"ok": False, "message": "Install the IDS/IPS software first."}, 3)
    shutil.rmtree(RULES_STAGING, ignore_errors=True)
    RULES_STAGING.mkdir(parents=True)
    try:
        # Keep the decoder/app-layer event rules — they power protocol logging.
        for item in sorted(Path("/etc/suricata/rules").glob("*.rules")):
            shutil.copy2(item, RULES_STAGING / item.name)
        archive = RULES_STAGING / "et-open.tar.gz"
        completed = run(["curl", "-sfL", "--max-time", "240", "-o", str(archive), ET_URL], timeout=300)
        if completed.returncode or not archive.is_file() or archive.stat().st_size < 100_000:
            emit({"ok": False, "message": "Could not download the ET Open feed — check the appliance internet connection."}, 6)
        with tarfile.open(archive) as bundle:
            for member in bundle.getmembers():
                # Only flat rule/config files are extracted — never directories
                # or paths, so a hostile archive cannot escape the staging dir.
                name = Path(member.name).name
                if member.isfile() and (name.endswith(".rules") or name in {"classification.config", "reference.config"}):
                    bundle.extract(member, RULES_STAGING / "et", filter="data")
        feed_dir = RULES_STAGING / "et" / "rules"
        if not feed_dir.is_dir():
            emit({"ok": False, "message": "The downloaded feed contained no rules."}, 6)
        for item in sorted(feed_dir.glob("*.rules")):
            shutil.copy2(item, RULES_STAGING / item.name)
        for name in ("classification.config", "reference.config"):
            if (feed_dir / name).is_file():
                shutil.copy2(feed_dir / name, RULES_STAGING / name)
        total = sum(1 for path in RULES_STAGING.glob("*.rules") for line in path.read_text(encoding="utf-8", errors="ignore").splitlines() if line.strip() and not line.lstrip().startswith("#"))
        home = ", ".join(home_networks())
        # Validate the candidate BEFORE touching anything live.
        candidate_config = RULES_STAGING / "candidate.yaml"
        apply_rules_dir(RULES_STAGING, home, candidate_config)
        # The template's log filename is absolute — point the validation run at
        # a staging file so failures are visible without touching the live log.
        candidate_config.write_text(candidate_config.read_text(encoding="utf-8").replace("filename: /var/log/suricata/firewall-ids.log", f"filename: {RULES_STAGING / 'validate.log'}"))
        tested = run(["suricata", "-T", "-c", str(candidate_config)], timeout=180)
        test_log = RULES_STAGING / "validate.log"
        diagnostics = ""
        if test_log.is_file():
            diagnostics = "\n".join(line for line in test_log.read_text(encoding="utf-8", errors="ignore").splitlines() if " Error: " in line)[-600:]
        if tested.returncode:
            emit({"ok": False, "message": "New rules failed validation — the previous rules were kept. " + (diagnostics or (tested.stderr or tested.stdout or "No diagnostics were produced.")[-300:])}, 7)
        # The final rules directory must contain only rules and configs.
        shutil.rmtree(RULES_STAGING / "et", ignore_errors=True)
        for junk in (candidate_config, test_log, archive):
            junk.unlink(missing_ok=True)
        # Apply: swap directories, rewrite config, live-reload (no restart).
        shutil.rmtree(RULES_PREVIOUS, ignore_errors=True)
        if RULES_DIR.is_dir():
            RULES_DIR.rename(RULES_PREVIOUS)
        RULES_STAGING.rename(RULES_DIR)
        apply_rules_dir(RULES_DIR, home)
        if service_active():
            # Restart rather than live-reload: the NFQUEUE rules are queue-bypass,
            # so traffic passes un-inspected for ~2s but never drops. A restart
            # is verifiable (the startup log names what loaded); a SIGHUP is not.
            log_path = Path("/var/log/suricata/firewall-ids.log")
            log_before = log_path.stat().st_size if log_path.is_file() else 0
            run(["systemctl", "restart", "firewall-ids"], timeout=120)
            time.sleep(12)  # loading ~52k signatures takes a few seconds
            tail = ""
            try:
                with log_path.open("r", encoding="utf-8", errors="ignore") as handle:  # only what THIS restart wrote — old diagnostics must not trip the check
                    handle.seek(log_before)
                    tail = handle.read(4000)
            except OSError:
                pass
            if not service_active() or "Loading signatures failed" in tail:
                shutil.rmtree(RULES_DIR, ignore_errors=True)
                if RULES_PREVIOUS.is_dir():
                    RULES_PREVIOUS.rename(RULES_DIR)
                apply_rules_dir(RULES_DIR, home)
                run(["systemctl", "restart", "firewall-ids"], timeout=90)
                emit({"ok": False, "message": "The engine rejected the new rules — the previous rules were kept and the service restarted on them."}, 8)
        write_rules_timer()
        saved = {}
        if STATE.is_file():
            try:
                saved = json.loads(STATE.read_text())
            except ValueError:
                saved = {}
        saved.update({"ruleset": "ET Open", "rules_count": total, "updated_at": datetime.now(UTC).isoformat()})
        STATE.write_text(json.dumps(saved))
        shutil.rmtree(RULES_PREVIOUS, ignore_errors=True)
        return {**status(), "ok": True, "message": f"ET Open feed applied: {total:,} signatures loaded."}
    finally:
        shutil.rmtree(RULES_STAGING, ignore_errors=True)


def install() -> dict:
    if Path(f"/usr/bin/{PACKAGE}").is_file() and service_active():
        return {**status(), "message": "IDS/IPS is already installed and running."}
    if not run(["apt-get", "update"], timeout=300).returncode == 0:
        emit({"ok": False, "message": "apt-get update failed — check the appliance internet connection."}, 3)
    completed = run(["apt-get", "install", "-y", "--no-install-recommends", PACKAGE], timeout=600)
    if completed.returncode or not Path(f"/usr/bin/{PACKAGE}").is_file():
        emit({"ok": False, "message": (completed.stderr or completed.stdout or "Suricata installation failed")[-400:]}, 3)

    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    networks = home_networks()
    # Suricata expects address vars as a quoted bracket string, e.g.
    # HOME_NET: "[192.168.0.0/16, 10.0.0.0/8]" — a real YAML list is rejected.
    home = ", ".join(networks)
    rules_dir: Path | None = None
    rules_files: list[Path] = []
    for base in (Path("/var/lib/suricata/rules"), Path("/etc/suricata/rules")):
        if base.is_dir():
            found = sorted(base.glob("*.rules"))
            if found:
                rules_dir, rules_files = base, found
                break
    CONFIG.write_text(render_config(home, rules_dir, [item.name for item in rules_files]))

    # Default package service is not used: our unit runs Suricata in NFQUEUE
    # mode with the managed configuration only.
    run(["systemctl", "disable", "--now", PACKAGE], timeout=60)
    SERVICE.write_text(
        f"""[Unit]
Description=Firewall Appliance IDS/IPS (Suricata NFQUEUE)
Documentation=https://suricata.readthedocs.io
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
ExecStartPre=/bin/rm -f /run/suricata.pid
ExecStart=/usr/bin/suricata -c {CONFIG} -q {QUEUE_NUM} --runmode workers
ExecReload=/bin/kill -HUP $MAINPID
ExecStop=/bin/kill -TERM $MAINPID
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
"""
    )
    run(["systemctl", "daemon-reload"])
    if SERVICE.is_file() and service_active():
        started = run(["systemctl", "restart", "firewall-ids"], timeout=90)
    else:
        started = run(["systemctl", "enable", "--now", "firewall-ids"], timeout=90)
    if started.returncode:
        emit({"ok": False, "message": "Suricata installed but the service failed to start."}, 4)
    STATE.write_text(json.dumps({"installed_at": __import__("time").time()}))
    return {**status(), "message": "IDS/IPS installed and running. Enable the module to route traffic through it."}


def uninstall() -> dict:
    run(["systemctl", "disable", "--now", "firewall-ids-rules.timer"], timeout=60)
    run(["systemctl", "disable", "--now", "firewall-ids"], timeout=60)
    run(["systemctl", "disable", "--now", PACKAGE], timeout=60)
    SERVICE.unlink(missing_ok=True)
    CONFIG.unlink(missing_ok=True)
    STATE.unlink(missing_ok=True)
    RULES_TIMER.unlink(missing_ok=True)
    RULES_SERVICE.unlink(missing_ok=True)
    for directory in (RULES_DIR, RULES_STAGING, RULES_PREVIOUS):
        shutil.rmtree(directory, ignore_errors=True)
    run(["systemctl", "daemon-reload"])
    completed = run(["apt-get", "purge", "-y", PACKAGE], timeout=300)
    if completed.returncode:
        run(["apt-get", "remove", "-y", PACKAGE], timeout=300)
    run(["apt-get", "autoremove", "-y"], timeout=300)
    return {"ok": True, "message": "IDS/IPS software removed. Switch the module off to remove the inspection rule.", **status()}


def main() -> int:
    if os.geteuid() != 0:
        emit({"ok": False, "message": "This helper must run as root."}, 5)
    action = sys.argv[1] if len(sys.argv) > 1 else ""
    if action == "install":
        emit(install())
    if action == "status":
        emit(status())
    if action == "uninstall":
        emit(uninstall())
    if action == "rules-update":
        emit(rules_update())
    emit({"ok": False, "message": "Usage: firewall-ids install|status|uninstall|rules-update"}, 2)


if __name__ == "__main__":
    raise SystemExit(main())
