#!/usr/bin/env bash
# Post-update deploy steps, run as ROOT by the firewall-update applier after
# the new code tree is in place. Idempotent: safe on every update.
set -Eeuo pipefail

SOURCE_DIR=/opt/firewall-appliance

# --- Threat feed updater: service, timer, sudoers entry --------------------
install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-threats.service" /etc/systemd/system/firewall-threats.service
install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-threats.timer" /etc/systemd/system/firewall-threats.timer
grep -q 'firewall-threats.service' /etc/sudoers.d/firewall-appliance || cat >> /etc/sudoers.d/firewall-appliance <<'SUDO'
firewall-api ALL=(root) NOPASSWD: /usr/bin/systemctl start firewall-threats.service
firewall-api ALL=(root) NOPASSWD: /usr/local/sbin/firewall-update apply update_[0-9a-f]*
SUDO
visudo -cf /etc/sudoers.d/firewall-appliance
systemctl daemon-reload
systemctl enable --now firewall-threats.timer

# --- vnStat: bandwidth counting (Essential+ reporting) ---------------------
if ! dpkg -s vnstat >/dev/null 2>&1; then
    DEBIAN_FRONTEND=noninteractive apt-get install -y vnstat
fi
systemctl enable --now vnstat

# --- Update applier helper (this may be the update that introduced it) -----
install -m 0755 "${SOURCE_DIR}/deploy/update_apply.py" /usr/local/sbin/firewall-update

echo "post_update: threat timer enabled, vnStat ensured, update helper installed"
