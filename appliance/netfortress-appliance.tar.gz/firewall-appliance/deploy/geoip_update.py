#!/usr/bin/env python3
"""GeoIP country set updater (Professional/Corporate edition).

Builds the country ipsets the firewall engine references:
  geoip-allow — in allowlist mode: the ONLY countries that may connect in
  geoip-block — in blocklist mode: countries that may not connect in

Source of truth: the five Regional Internet Registries' delegated statistics
(RIPE, AFRINIC, APNIC, ARIN, LACNIC) — official allocation data, stable URLs,
refreshed daily. Each file lists every allocated IPv4 range with its country
code; the updater converts ranges to CIDR blocks for the selected countries.

A failed or partial download never touches the live sets — the last good
policy keeps enforcing. Both sets always exist so the guarded firewall apply
can never reference a missing set.

Run as root (systemd: firewall-geoip.service). Settings are read from the
appliance database (geoip_settings).
"""
from __future__ import annotations

import gzip
import json
import sqlite3
import subprocess
import sys
import urllib.request
from datetime import UTC, datetime
from ipaddress import IPv4Address, summarize_address_range
from pathlib import Path

DB_PATH = Path("/var/lib/firewall-appliance/appliance.db")
STATUS_FILE = Path("/var/lib/firewall-appliance/geoip-status.json")
SOURCES = (
    "https://ftp.ripe.net/pub/stats/ripencc/delegated-ripencc-extended-latest",
    "https://ftp.afrinic.net/pub/stats/afrinic/delegated-afrinic-extended-latest",
    "https://ftp.apnic.net/stats/apnic/delegated-apnic-extended-latest",
    "https://ftp.arin.net/pub/stats/arin/delegated-arin-extended-latest",
    "https://ftp.lacnic.net/pub/stats/lacnic/delegated-lacnic-extended-latest",
)
SETS = ("geoip-allow", "geoip-block")
MAX_FILE_BYTES = 60_000_000
TIMEOUT = 120


def read_settings() -> dict:
    connection = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
    try:
        row = connection.execute("SELECT value FROM system_settings WHERE key='geoip_settings'").fetchone()
    finally:
        connection.close()
    return json.loads(row[0]) if row else {}


def run_ipset(args: list[str]) -> None:
    completed = subprocess.run(["ipset", *args], capture_output=True, text=True, check=False)
    if completed.returncode != 0:
        raise RuntimeError(f"ipset {' '.join(args[:2])} failed: {completed.stderr.strip()[:200]}")


def ensure_sets() -> None:
    for name in SETS:
        run_ipset(["create", name, "hash:net", "family", "inet", "-exist"])


def fetch_networks(countries: set[str]) -> dict[str, list[str]]:
    """Download the five RIR delegated files and collect IPv4 CIDRs per
    selected country. Any source failure aborts the whole update — a partial
    world view must never replace the last good sets."""
    found: dict[str, list[str]] = {code: [] for code in countries}
    for url in SOURCES:
        request = urllib.request.Request(url, headers={"User-Agent": "curl/8.0"})
        with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
            raw = response.read(MAX_FILE_BYTES + 1)
        if len(raw) > MAX_FILE_BYTES:
            raise ValueError(f"Registry file exceeds size limit: {url.rsplit('/', 1)[-1]}")
        if url.endswith(".gz"):
            raw = gzip.decompress(raw)
        for line in raw.decode("utf-8", "replace").splitlines():
            if line.startswith("#") or "|" not in line:
                continue
            parts = line.split("|")
            if len(parts) < 7 or parts[2] != "ipv4":
                continue
            code = parts[1].upper()
            if code not in countries:
                continue
            start = IPv4Address(parts[3])
            count = int(parts[4])
            for network in summarize_address_range(start, IPv4Address(int(start) + count - 1)):
                found[code].append(str(network))
    missing = [code for code, networks in found.items() if not networks]
    if missing:
        raise ValueError(f"No address data found for: {', '.join(missing)} — check the country codes")
    return found


def build_set(target: str, networks: list[str]) -> int:
    run_ipset(["create", "geoip-tmp", "hash:net", "family", "inet", "-exist"])
    run_ipset(["flush", "geoip-tmp"])
    with tempfile_batch(networks) as batch:
        completed = subprocess.run(["ipset", "restore", "-exist"], stdin=batch, capture_output=True, text=True, check=False)
        if completed.returncode != 0:
            raise RuntimeError(f"ipset restore failed: {completed.stderr.strip()[:200]}")
    run_ipset(["swap", "geoip-tmp", target])
    run_ipset(["destroy", "geoip-tmp"])
    return len(networks)


def tempfile_batch(networks: list[str]):
    import tempfile
    handle = tempfile.NamedTemporaryFile("w", delete=False)
    for cidr in networks:
        handle.write(f"add geoip-tmp {cidr} -exist\n")
    handle.flush()
    handle.close()

    class _Batch:
        def __enter__(self):
            return open(handle.name)

        def __exit__(self, *exc):
            Path(handle.name).unlink(missing_ok=True)

    return _Batch()


def write_status(mode: str, countries: list[str], cidr_count: int, ok: bool, message: str = "") -> None:
    STATUS_FILE.write_text(json.dumps({
        "updated_at": datetime.now(UTC).isoformat(),
        "mode": mode,
        "countries": countries,
        "cidr_count": cidr_count,
        "ok": ok,
        "message": message,
    }, indent=2))


def main() -> int:
    settings = read_settings()
    ensure_sets()
    if not settings.get("enabled") or not settings.get("countries"):
        # Nothing configured: keep the sets (and any previous status) as they are.
        print("GeoIP policy not enabled or no countries selected; sets untouched.")
        return 0
    mode = settings.get("mode", "allowlist")
    target = "geoip-allow" if mode == "allowlist" else "geoip-block"
    countries = sorted({str(c).upper() for c in settings["countries"]})
    try:
        found = fetch_networks(set(countries))
        networks = [cidr for code in countries for cidr in found[code]]
        total = build_set(target, networks)
        # In allowlist mode the block set must be empty (and vice versa) so a
        # mode switch can never double-judge a country.
        stale = "geoip-block" if target == "geoip-allow" else "geoip-allow"
        run_ipset(["flush", stale])
        write_status(mode, countries, total, ok=True,
                     message=f"{len(countries)} countries, {total:,} networks from RIR registry data ({target})")
        print(f"GeoIP sets updated: {total:,} networks for {len(countries)} countries into {target}")
        return 0
    except Exception as exc:  # noqa: BLE001 - never blank the live sets
        write_status(mode, countries, 0, ok=False, message=f"Update failed: {exc}; last good sets retained")
        print(f"GeoIP update failed (last good sets retained): {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
