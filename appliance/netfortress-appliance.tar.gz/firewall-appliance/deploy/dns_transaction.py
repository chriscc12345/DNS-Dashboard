#!/usr/bin/env python3
"""Root-only transactional dnsmasq activator.

Candidates are created under /var/lib/firewall-appliance/dns-candidates by the
appliance API and contain dnsmasq.conf plus manifest.json. The helper never
accepts paths or shell fragments. Activation validates syntax, snapshots the
previous managed configuration, applies atomically, restarts dnsmasq, health
checks resolution, and restores the snapshot automatically on failure.

DNS activation auto-commits when healthy: unlike routing or firewall changes
it cannot remove management access from the appliance.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import socket
import struct
import subprocess
import sys
import time
from pathlib import Path

STATE = Path("/var/lib/firewall-appliance")
CANDIDATES = STATE / "dns-candidates"
ROLLBACK = Path("/var/lib/firewall-appliance-rollback/dns")
ACTIVE = STATE / "dns-active.json"
MANAGED_CONF = Path("/etc/dnsmasq.d/99-firewall-appliance.conf")
TXN_RE = re.compile(r"^dns_[0-9a-f]{16}$")


def fail(message: str, code: int = 1) -> None:
    print(json.dumps({"ok": False, "message": message}))
    raise SystemExit(code)


def run(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(args, text=True, capture_output=True, timeout=60, check=False)


def paths(txn: str) -> tuple[Path, Path]:
    if not TXN_RE.fullmatch(txn):
        fail("Invalid transaction identifier", 2)
    return CANDIDATES / txn, ROLLBACK / txn


def load_candidate(txn: str) -> tuple[dict, str, Path]:
    candidate, snapshot = paths(txn)
    manifest_path = candidate / "manifest.json"
    conf_path = candidate / "dnsmasq.conf"
    if not manifest_path.is_file() or not conf_path.is_file():
        fail("Candidate is incomplete")
    manifest = json.loads(manifest_path.read_text())
    config = conf_path.read_text()
    digest = hashlib.sha256(config.encode()).hexdigest()
    if manifest.get("sha256") != digest:
        fail("Candidate hash mismatch")
    return manifest, config, snapshot


def resolution_healthy() -> bool:
    """Ask the local resolver for an A record and require a plausible answer."""
    query = b"".join(
        [
            b"\x12\x34",  # transaction id
            b"\x01\x00",  # recursion desired
            b"\x00\x01\x00\x00\x00\x00\x00\x00",  # one question
            b"\x06github\x03com\x00",
            b"\x00\x01\x00\x01",  # A, IN
        ]
    )
    for _ in range(2):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.settimeout(4)
                sock.sendto(query, ("127.0.0.1", 53))
                data, _ = sock.recvfrom(512)
            header = struct.unpack("!HHHHHH", data[:12])
            return header[1] & 0x000F in (0, 3) and header[3] > 0  # NOERROR/NXDOMAIN with an answer or SOA
        except OSError:
            time.sleep(1)
    return False


def install(config: str) -> bool:
    MANAGED_CONF.parent.mkdir(parents=True, exist_ok=True)
    temporary = MANAGED_CONF.with_suffix(".tmp")
    temporary.write_text(config)
    temporary.replace(MANAGED_CONF)
    restarted = run(["systemctl", "restart", "dnsmasq"])
    return restarted.returncode == 0


def activate(txn: str) -> None:
    manifest, config, snapshot = load_candidate(txn)
    if not shutil.which("dnsmasq"):
        fail("dnsmasq is not installed")
    checked = run(["dnsmasq", "--test", f"--conf-file={CANDIDATES / txn / 'dnsmasq.conf'}"])
    if checked.returncode:
        fail(f"dnsmasq rejected candidate: {(checked.stderr or checked.stdout).strip()}")
    snapshot.mkdir(parents=True, exist_ok=False)
    if MANAGED_CONF.is_file():
        (snapshot / "dnsmasq.conf").write_text(MANAGED_CONF.read_text())
    else:
        (snapshot / "dnsmasq.conf").write_text("")
    if not install(config) or not resolution_healthy():
        restore(snapshot / "dnsmasq.conf")
        fail("Activation failed health checks; the previous DNS configuration was restored")
    record = {"transaction_id": txn, "state": "committed", "activated_at": time.time(), "sha256": manifest["sha256"], "domain_count": manifest.get("domain_count")}
    ACTIVE.write_text(json.dumps(record, sort_keys=True))
    print(json.dumps({"ok": True, **record}))


def restore(conf: Path) -> None:
    content = conf.read_text()
    if content:
        MANAGED_CONF.write_text(content)
    else:
        MANAGED_CONF.unlink(missing_ok=True)
    run(["systemctl", "restart", "dnsmasq"])


def rollback(txn: str) -> None:
    _, snapshot = paths(txn)
    conf = snapshot / "dnsmasq.conf"
    if not conf.is_file():
        fail("Rollback snapshot does not exist")
    restore(conf)
    record = json.loads(ACTIVE.read_text()) if ACTIVE.is_file() else {"transaction_id": txn}
    record.update({"state": "rolled-back", "rolled_back_at": time.time()})
    ACTIVE.write_text(json.dumps(record, sort_keys=True))
    print(json.dumps({"ok": True, **record}))


def status(_txn: str) -> None:
    record = json.loads(ACTIVE.read_text()) if ACTIVE.is_file() else {}
    print(json.dumps({"ok": True, **record}))


def main() -> None:
    if os.geteuid() != 0 or len(sys.argv) != 3:
        fail("Usage: firewall-dns-transaction activate|rollback|status dns_<id>", 2)
    action, txn = sys.argv[1:]
    if action == "activate":
        activate(txn)
    elif action == "rollback":
        rollback(txn)
    elif action == "status":
        status(txn)
    else:
        fail("Unsupported action", 2)


if __name__ == "__main__":
    main()
