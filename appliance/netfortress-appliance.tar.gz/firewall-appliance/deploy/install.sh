#!/usr/bin/env bash
set -Eeuo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "Run this installer as root." >&2
  exit 1
fi

if [[ ! -r /etc/os-release ]]; then
  echo "Unable to identify this operating system." >&2
  exit 1
fi

. /etc/os-release
case "${ID:-}" in
  debian|ubuntu) ;;
  *) echo "Supported operating systems: Debian and Ubuntu." >&2; exit 1 ;;
esac

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_DIR=/opt/firewall-appliance
STATE_DIR=/var/lib/firewall-appliance
ROLLBACK_DIR=/var/lib/firewall-appliance-rollback
CONFIG_DIR=/etc/firewall-appliance
SERVICE_USER=firewall-api

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip iptables iptables-persistent ipset conntrack ebtables arptables bridge-utils iproute2 iputils-ping nginx sqlite3 sudo squid kea-dhcp4-server ca-certificates curl ulogd2 dnsmasq bind9-dnsutils vnstat wireguard-tools

if ! id "${SERVICE_USER}" >/dev/null 2>&1; then
  useradd --system --home "${STATE_DIR}" --shell /usr/sbin/nologin "${SERVICE_USER}"
fi
# Read-only access to Kea lease records so device discovery can resolve hostnames.
usermod -aG _kea "${SERVICE_USER}" || true

install -d -m 0750 -o "${SERVICE_USER}" -g "${SERVICE_USER}" "${STATE_DIR}"
install -d -m 0700 -o root -g root "${ROLLBACK_DIR}"
install -d -m 0750 -o root -g "${SERVICE_USER}" "${CONFIG_DIR}"
install -d -m 0750 -o "${SERVICE_USER}" -g "${SERVICE_USER}" "${STATE_DIR}/blocklists" "${STATE_DIR}/generated"
install -d -m 0750 -o "${SERVICE_USER}" -g "${SERVICE_USER}" "${STATE_DIR}/iptables-candidates" "${STATE_DIR}/dns-candidates" "${STATE_DIR}/hostname-candidates" "${STATE_DIR}/iptables-validate"
install -d -m 0700 -o root -g root "${ROLLBACK_DIR}/iptables" "${ROLLBACK_DIR}/dns" "${ROLLBACK_DIR}/hostname"
install -d -m 0755 "${INSTALL_DIR}"
cp -a "${SOURCE_DIR}/." "${INSTALL_DIR}/"

python3 -m venv "${INSTALL_DIR}/backend/.venv"
"${INSTALL_DIR}/backend/.venv/bin/pip" install --upgrade pip
"${INSTALL_DIR}/backend/.venv/bin/pip" install -e "${INSTALL_DIR}/backend"

if [[ ! -f "${CONFIG_DIR}/environment" ]]; then
  signing_key="$(python3 -c 'import secrets; print(secrets.token_urlsafe(64))')"
  install -m 0640 -o root -g "${SERVICE_USER}" /dev/null "${CONFIG_DIR}/environment"
  printf 'FIREWALL_DB_PATH=%s/appliance.db\nFIREWALL_STATE_DIR=%s\nFIREWALL_SIGNING_KEY=%s\n# FIREWALL_ENABLE_LIVE_APPLY=1\n# FIREWALL_ENABLE_NETWORK_APPLY=1\n# FIREWALL_LICENSE_SERVER_URL=https://licensing.example.com/v1/activate\n# FIREWALL_LICENSE_PUBLIC_KEY=%s/license-public-key.pem\n# FIREWALL_UPDATE_PUBLIC_KEY=%s/update-public-key.pem\n' "${STATE_DIR}" "${STATE_DIR}" "${signing_key}" "${CONFIG_DIR}" "${CONFIG_DIR}" > "${CONFIG_DIR}/environment"
fi

install -m 0755 -o root -g root "${SOURCE_DIR}/deploy/firewall_transaction.py" /usr/local/sbin/firewall-transaction
install -m 0755 -o root -g root "${SOURCE_DIR}/deploy/iptables_transaction.py" /usr/local/sbin/firewall-iptables-transaction
install -m 0755 -o root -g root "${SOURCE_DIR}/deploy/iptables_rollback_check.py" /usr/local/sbin/firewall-iptables-rollback-check
install -m 0755 -o root -g root "${SOURCE_DIR}/deploy/dns_transaction.py" /usr/local/sbin/firewall-dns-transaction
install -m 0755 -o root -g root "${SOURCE_DIR}/deploy/hostname_transaction.py" /usr/local/sbin/firewall-hostname-transaction
install -m 0755 -o root -g root "${SOURCE_DIR}/deploy/iptables_validate.py" /usr/local/sbin/firewall-iptables-validate
install -m 0755 -o root -g root "${SOURCE_DIR}/deploy/nft_validate.py" /usr/local/sbin/firewall-nft-validate
install -m 0440 -o root -g root "${SOURCE_DIR}/deploy/sudoers-firewall-appliance" /etc/sudoers.d/firewall-appliance
visudo -cf /etc/sudoers.d/firewall-appliance

install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-api.service" /etc/systemd/system/firewall-api.service
install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-blocklists.service" /etc/systemd/system/firewall-blocklists.service
install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-blocklists.timer" /etc/systemd/system/firewall-blocklists.timer
install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-iptables-rollback.service" /etc/systemd/system/firewall-iptables-rollback.service
install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-iptables-rollback.timer" /etc/systemd/system/firewall-iptables-rollback.timer
install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-policy-refresh.service" /etc/systemd/system/firewall-policy-refresh.service
install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-policy-refresh.timer" /etc/systemd/system/firewall-policy-refresh.timer
install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-threats.service" /etc/systemd/system/firewall-threats.service
install -m 0644 "${SOURCE_DIR}/deploy/systemd/firewall-threats.timer" /etc/systemd/system/firewall-threats.timer
install -m 0755 "${SOURCE_DIR}/deploy/update_apply.py" /usr/local/sbin/firewall-update
# The update verification key ships with the package: fresh installs trust
# the same update signing key as the rest of the fleet.
install -m 0640 -o root -g "${SERVICE_USER}" "${SOURCE_DIR}/deploy/update-public-key.pem" "${CONFIG_DIR}/update-public-key.pem" 2>/dev/null || true
sysctl_file=/etc/sysctl.d/90-firewall-appliance.conf
printf 'net.ipv4.ip_forward=1\nnet.ipv4.conf.all.rp_filter=1\nnet.ipv4.conf.default.rp_filter=1\nnet.ipv4.conf.all.accept_redirects=0\nnet.ipv4.conf.all.send_redirects=0\nnet.ipv6.conf.all.accept_redirects=0\n' > "${sysctl_file}"
sysctl --system >/dev/null
systemctl daemon-reload
systemctl enable --now firewall-api.service
systemctl enable --now firewall-blocklists.timer
systemctl enable --now firewall-iptables-rollback.timer
systemctl enable --now firewall-policy-refresh.timer
systemctl enable --now firewall-threats.timer

echo "Firewall Appliance iptables edition installed. Open http://SERVER-IP:8080 to continue setup."
echo "Live activation remains disabled. Enable FIREWALL_ENABLE_LIVE_APPLY=1 only on an isolated test appliance."
echo "Interface changes require the separate FIREWALL_ENABLE_NETWORK_APPLY=1 recovery-access acknowledgement."
echo "Time-based policy automation requires FIREWALL_ENABLE_POLICY_REFRESH=1; DNS activation requires FIREWALL_ENABLE_DNS_APPLY=1."
