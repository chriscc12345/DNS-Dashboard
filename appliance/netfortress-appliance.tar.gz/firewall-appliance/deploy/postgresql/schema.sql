CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'operator', 'viewer')),
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_login_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS api_tokens (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    token_prefix TEXT NOT NULL UNIQUE,
    token_hash TEXT NOT NULL UNIQUE,
    scopes_json JSONB NOT NULL,
    expires_at TIMESTAMPTZ,
    revoked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_used_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS audit_events (
    id BIGSERIAL PRIMARY KEY,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    actor_type TEXT NOT NULL,
    actor_id TEXT,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT,
    outcome TEXT NOT NULL,
    source_ip INET,
    details_json JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_audit_occurred_at ON audit_events(occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_tokens_user ON api_tokens(user_id);

CREATE TABLE IF NOT EXISTS system_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS license_state (
    singleton_id SMALLINT PRIMARY KEY CHECK (singleton_id = 1),
    payload_json JSONB NOT NULL,
    signature TEXT NOT NULL,
    last_verified_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS license_events (
    id BIGSERIAL PRIMARY KEY,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    event_type TEXT NOT NULL,
    state TEXT,
    details_json JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS discovered_devices (
    ip_address INET NOT NULL,
    mac_address MACADDR,
    hostname TEXT,
    interface TEXT,
    state TEXT NOT NULL,
    source TEXT NOT NULL,
    first_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (ip_address, mac_address)
);

CREATE INDEX IF NOT EXISTS idx_devices_last_seen ON discovered_devices(last_seen_at DESC);

CREATE TABLE IF NOT EXISTS device_groups (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS device_group_members (
    id BIGSERIAL PRIMARY KEY,
    group_id BIGINT NOT NULL REFERENCES device_groups(id) ON DELETE CASCADE,
    target_type TEXT NOT NULL CHECK(target_type IN ('mac','ip','hostname')),
    target_value TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(group_id,target_type,target_value)
);
CREATE TABLE IF NOT EXISTS blocking_policies (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    target_type TEXT NOT NULL CHECK(target_type IN ('mac','ip','hostname','group')),
    target_value TEXT NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    reason TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    schedule_id BIGINT
);

CREATE TABLE IF NOT EXISTS blocklist_sources (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    url TEXT NOT NULL,
    format TEXT NOT NULL CHECK(format IN ('hosts','domains')),
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    update_hours INTEGER NOT NULL DEFAULT 24 CHECK(update_hours BETWEEN 1 AND 720),
    status TEXT NOT NULL DEFAULT 'never_updated',
    domain_count INTEGER NOT NULL DEFAULT 0,
    content_sha256 TEXT,
    last_error TEXT,
    last_updated_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS local_domains (
    id BIGSERIAL PRIMARY KEY,
    domain TEXT NOT NULL,
    action TEXT NOT NULL CHECK(action IN ('block','allow')),
    category TEXT NOT NULL DEFAULT 'custom',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(domain, action)
);
CREATE TABLE IF NOT EXISTS application_policies (
    application TEXT PRIMARY KEY,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    block_quic BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS schedules (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    timezone TEXT NOT NULL,
    days_json JSONB NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS security_events (
    id BIGSERIAL PRIMARY KEY,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    event_type TEXT NOT NULL,
    action TEXT NOT NULL,
    client_ip INET,
    hostname TEXT,
    destination TEXT,
    category TEXT,
    policy TEXT,
    details_json JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_security_events_time ON security_events(occurred_at DESC);
CREATE TABLE IF NOT EXISTS access_requests (
    id BIGSERIAL PRIMARY KEY,
    requested_host TEXT NOT NULL,
    client_ip INET NOT NULL,
    device_name TEXT,
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    reviewed_at TIMESTAMPTZ,
    reviewed_by TEXT,
    review_note TEXT
);
CREATE TABLE IF NOT EXISTS firewall_zones (id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL UNIQUE,interfaces_json JSONB NOT NULL,networks_json JSONB NOT NULL,default_action TEXT NOT NULL CHECK(default_action IN ('accept','drop')),created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS port_forwards (id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL,protocol TEXT NOT NULL CHECK(protocol IN ('tcp','udp')),external_port INTEGER NOT NULL CHECK(external_port BETWEEN 1 AND 65535),internal_ip INET NOT NULL,internal_port INTEGER NOT NULL CHECK(internal_port BETWEEN 1 AND 65535),source_network CIDR,enabled BOOLEAN NOT NULL DEFAULT TRUE,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),UNIQUE(protocol,external_port));
CREATE TABLE IF NOT EXISTS dhcp_reservations (id BIGSERIAL PRIMARY KEY,mac_address MACADDR NOT NULL UNIQUE,ip_address INET NOT NULL UNIQUE,hostname TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS local_dns_records (id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL,record_type TEXT NOT NULL CHECK(record_type IN ('A','AAAA','CNAME')),value TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),UNIQUE(name,record_type));
