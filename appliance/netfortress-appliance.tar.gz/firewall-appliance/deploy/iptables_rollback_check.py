#!/usr/bin/env python3
import json, subprocess, time
from pathlib import Path

active = Path("/var/lib/firewall-appliance/iptables-active.json")
if active.is_file():
    record = json.loads(active.read_text())
    if record.get("state") == "pending-confirmation" and time.time() >= record.get("rollback_deadline", 0):
        subprocess.run(["/usr/local/sbin/firewall-iptables-transaction", "rollback", record["transaction_id"]], check=False)
