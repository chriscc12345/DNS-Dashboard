# Firewall Appliance Technical Specification

## Product objective

Build a deployable Debian/Ubuntu network-security appliance for dedicated
hardware and virtual machines. The appliance combines routing, stateful
firewalling, device identity, DNS filtering, website/application policies,
web caching, a branded block page, reporting, and a complete REST API.

## Supported deployment architectures

1. **Two-NIC routed gateway** — full enforcement, routing, NAT, DHCP, DNS, VLANs.
2. **Two-NIC transparent bridge** — inline enforcement while retaining an
   existing router.
3. **One-NIC VLAN trunk** — full enforcement using tagged WAN/LAN VLANs and a
   managed switch.
4. **One-NIC DNS/proxy service** — filtering and caching with explicitly stated
   bypass limitations.

The setup wizard must show a network diagram, requirements, feature coverage,
bypass risks, management path, and recovery procedure. Architecture, cabling,
and recovery acknowledgement are compulsory.

## Target components

| Layer | Component | Responsibility |
|---|---|---|
| Packet enforcement | nftables | Stateful firewall, NAT, zones, sets, MAC/IP policy |
| DNS | Technitium DNS | Recursive/forwarding DNS, local zones, policy feeds |
| DHCP | Kea DHCP | Leases, reservations, client identity and relay data |
| Web proxy/cache | Squid | Explicit/transparent proxy functions and safe caching |
| Control plane | FastAPI | Versioned REST API, orchestration and health checks |
| Data | PostgreSQL | Desired state, identities, rules, events and audit trail |
| Web | React (target) | Administration dashboard and deployment workflow |
| Edge | NGINX | API/UI TLS termination and block-page hosting |
| Services | systemd | Process supervision and startup ordering |

## Identity and policy targets

Policies can target MAC addresses, IPv4/IPv6 addresses and prefixes, DHCP
hostnames, devices, users, device groups, VLANs, and networks. Identity is
correlated using DHCP leases, ARP/IPv6 neighbour tables, hostname observations,
MAC history, and administrator assignment.

MAC enforcement applies to directly connected broadcast domains. Routed remote
networks require IP identity, DHCP relay metadata, authentication, or an agent.
Randomized Wi-Fi MAC addresses must be identified and quarantined or approved.

## Website and application blocking

The policy engine compiles a single desired policy into multiple enforcement
layers:

- DNS response policy and blocklists;
- HTTPS hostname/SNI policy where observable;
- nftables address and protocol sets;
- QUIC/HTTP3 control where policy requires visibility;
- explicit proxy ACLs;
- DoH/DoT and common bypass controls;
- optional TLS inspection for managed networks only.

Application definitions group all known service domains. A Social Media policy
can block Facebook, Messenger, Instagram, and WhatsApp definitions independently
or as a category. Lists support local entries, StevenBlack-format hosts files,
domain lists, allowlists, source health, signatures/hashes, deduplication,
scheduled updates, staged compilation, and rollback.

## Block page

The branded block page records and, where technically possible, displays the
client IP, hostname/device, requested hostname, category, matched policy, time,
and access-request action. HTTPS interception is not silently enabled: without
a trusted managed certificate, some HTTPS blocks produce a browser connection
failure rather than a redirect.

## Caching

HTTP and explicitly supported repositories can be cached normally. General
HTTPS caching requires managed TLS inspection and is disabled by default.
Administrators can scope inspection to managed devices, groups, or VLANs.

## API design

All dashboard actions use `/api/v1`. API tokens have scopes, expiry, rotation,
revocation, rate limits, and audit attribution. Planned resource groups include:

- `/system`, `/deployment`, `/interfaces`, `/routes`, `/vlans`;
- `/firewall`, `/nat`, `/zones`, `/schedules`;
- `/devices`, `/groups`, `/users`, `/identity`;
- `/dns`, `/blocklists`, `/applications`, `/categories`;
- `/proxy`, `/cache`, `/inspection`;
- `/events`, `/reports`, `/audit`;
- `/backup`, `/restore`, `/updates`, `/health`.

## Safe configuration transaction

Every change follows: validate desired state, render candidate files, validate
component syntax, snapshot current state, arm timed rollback, atomically apply,
test management/gateway/DNS health, request confirmation, then commit. Failure
at any stage restores the snapshot. Secrets never appear in rendered plans or
audit payloads.

The web API remains unprivileged. A root-owned transaction helper accepts only
validated transaction identifiers and fixed activate, confirm, rollback, and
status operations. Live activation is disabled unless explicitly enabled on an
isolated test appliance. Each activation snapshots the complete nftables
ruleset, records reversible interface/route operations, and arms a 120-second
systemd rollback timer before loading candidates. Network mutation requires a
second independent enable switch and verified console recovery access.

## Licensing

New installations begin in minimal unlicensed mode and may activate one online
60-day full-feature trial. Trial expiry immediately returns the appliance to
basic monitoring, diagnostics, backup export, licensing, and network-recovery
functions. Essential forwarding and management access are never deliberately
interrupted by licence state changes.

Purchased subscriptions receive a 30-day grace period after expiry. Perpetual
licences retain purchased features indefinitely; update entitlement may expire
separately. Licence documents are bound to an installation identity and signed
by an online service with Ed25519. Only the public verification key is installed
on the appliance. The private signing key never ships with the product.

## Delivery milestones

1. Safe graphical deployment wizard and architecture validator.
2. PostgreSQL desired-state model, authentication, roles and API tokens.
3. Transactional interface, route, VLAN and nftables engine.
4. Device discovery and MAC/IP/hostname policy.
5. Technitium, Kea, blocklist and application-category integration.
6. Squid caching, optional inspection and block-page workflow.
7. Reporting, backup/restore, signed updates and appliance hardening.
