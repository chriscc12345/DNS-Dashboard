# Firewall Appliance 2.0 RC1 Acceptance Test

Run this only on an isolated Debian or Ubuntu VM with console access.

## 1. Install and sign in

1. Run `sudo bash deploy/install.sh`.
2. Confirm `systemctl status firewall-api --no-pager` reports active.
3. Open `http://SERVER-IP:8080`, create the first administrator and start the 60-day trial.
4. Confirm the dashboard reports version `2.0.0-rc1`.

## 2. Architecture and recovery

1. Select the intended 1-NIC or 2-NIC architecture.
2. Verify the displayed topology, limitations and interface assignments.
3. Prepare a candidate without enabling live apply.
4. From the VM console, enable live/network apply in `/etc/firewall-appliance/environment` only for the isolated test.
5. Activate a candidate, verify access, and confirm it before 120 seconds.
6. Repeat without confirming and verify automatic rollback restores access.

## 3. Device enforcement

1. Confirm Devices shows IP, MAC and hostname observations.
2. Create individual IP, MAC and hostname blocks.
3. Create a device group, add members and block the group.
4. Render a deployment candidate and confirm the nftables preview contains the compiled sets.

## 4. DNS and application policy

1. Open Web Control and add the StevenBlack source.
2. Update it and confirm a healthy state and non-zero domain count.
3. Add a custom blocked domain and an allow override.
4. Enable Facebook and confirm the compiled set includes Facebook, Messenger and CDN domains.
5. Verify `/api/v1/dns/render` returns the current compiled policy.

## 5. DHCP, proxy and block page

1. Configure the Kea subnet, pool, router and interface under Operations.
2. Verify `/api/v1/dhcp/render` returns valid Kea JSON.
3. Enable the explicit proxy/cache and verify `/api/v1/proxy/render`.
4. Change block-page branding and open the authenticated preview endpoint.
5. Confirm TLS inspection cannot be enabled without managed-CA provisioning.

## 6. Licensing and operations

1. Confirm unlicensed mode exposes monitoring/licensing only.
2. Start the one-time 60-day trial and verify full features become available.
3. Check Audit after each configuration mutation.
4. Export a backup and validate the exact archive through `POST /api/v1/backup/validate`.
5. Download the redacted support bundle and confirm it contains no secrets.
6. Open `/docs` and execute health, device, policy, DNS, DHCP, report and licensing calls.

Record the exact failing step, response body and relevant audit entry for any failure.
