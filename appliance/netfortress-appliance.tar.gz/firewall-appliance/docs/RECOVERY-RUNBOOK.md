# Recovery Runbook

Keep hypervisor or physical console access throughout network testing.

## Automatic recovery

An activated network/firewall transaction arms an independent 120-second rollback. If the administrator does not confirm connectivity, the previous nftables ruleset, addresses, routes and links are restored.

## Manual rollback

From the console, identify the transaction under `/var/lib/firewall-appliance/transactions`, then run:

```bash
sudo /usr/local/sbin/firewall-transaction rollback txn_IDENTIFIER
```

## Restore management access

```bash
sudo systemctl stop firewall-api
sudo nft flush ruleset
sudo systemctl restart networking 2>/dev/null || true
sudo systemctl restart systemd-networkd 2>/dev/null || true
sudo systemctl start firewall-api
```

Use these emergency commands only from console access. They intentionally remove active filtering until a validated candidate is applied again.

## Disable live changes

Remove or comment out `FIREWALL_ENABLE_LIVE_APPLY=1` and `FIREWALL_ENABLE_NETWORK_APPLY=1` in `/etc/firewall-appliance/environment`, then restart `firewall-api`.
