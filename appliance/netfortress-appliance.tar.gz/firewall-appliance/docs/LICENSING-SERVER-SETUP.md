# Licensing Server Setup Runbook — Debian VM

Complete setup for the online licensing host. Read this whole document before
starting. The licensing code lives in `firewall-appliance/licensing/` and is
pushed from the workspace to the VM during installation.

## What the host does

- Signs edition-based licences (Home / Essential / Professional / Corporate)
  with a private Ed25519 key kept ONLY on this VM.
- Serves `POST /v1/activate` for appliances (installation-bound activation).
- Provides a bearer-token admin API for issuing/suspending/revoking keys.
- The CLI (`license_admin.py`) also produces **offline licence files** for
  appliances on sites with no internet — the signed envelope JSON is uploaded
  to the appliance dashboard directly.

## Editions (defined once, in the backend license models — both sides import it)

| Edition | Features | Devices | Accounts |
|---|---|---|---|
| home_lite (FREE) | core protection, no reports | 10 | 1 |
| home | core protection, no reports | 25 | 1 |
| essential | core + reports/audit, backup/restore | 50 | 2 |
| professional | everything (IDS/IPS, HTTPS block page, portal, IP pools, API, public TLS) | 250 | unlimited |
| corporate | same as professional | 1000+ (per licence) | unlimited |

## Installation steps

1. **Copy the product tree** to the VM (scp from the workstation), including
   `firewall-appliance/licensing/` and `firewall-appliance/backend/` (the
   licensing code imports the backend licence models so the signed format
   can never drift).

2. **Install runtime + venv** (Debian):

   ```bash
   apt update && apt install -y python3-venv python3-pip
   python3 -m venv /opt/firewall-license-server/venv
   /opt/firewall-license-server/venv/bin/pip install fastapi uvicorn cryptography pydantic
   ```

3. **Environment file** `/etc/firewall-license-server/environment`:

   ```
   LICENSE_DB_PATH=/var/lib/firewall-license-server/licenses.db
   LICENSE_SIGNING_KEY=/etc/firewall-license-server/signing-key.pem
   LICENSE_PUBLIC_KEY_PATH=/etc/firewall-appliance/license-public-key.pem
   LICENSE_ADMIN_TOKEN=GENERATE_A_LONG_RANDOM_TOKEN_HERE
   ```

4. **Generate the master signing keypair** (root only — this is the crown
   jewel; losing it invalidates every licence, leaking it lets anyone forge
   licences):

   ```bash
   cd /opt/firewall-appliance/licensing
   ../../venv/bin/python license_admin.py keygen
   # -> /etc/firewall-license-server/signing-key.pem   (0600, never leaves the VM)
   # -> /etc/firewall-appliance/license-public-key.pem (distribute to appliances)
   ```

   Back the private key up offline (USB, password manager). There is no way to
   recover a lost key.

5. **Systemd service** — install `deploy/systemd/firewall-license-server.service`
   (adjust paths to the venv created above), then:

   ```bash
   systemctl daemon-reload && systemctl enable --now firewall-license-server
   curl -s http://127.0.0.1:8090/healthz
   ```

6. **Point each appliance at the host** — on every appliance, set in
   `/etc/firewall-appliance/environment`:

   ```
   FIREWALL_LICENSE_SERVER_URL=http://LICENSE-HOST:8090/v1/activate
   FIREWALL_LICENSE_PUBLIC_KEY=/etc/firewall-appliance/license-public-key.pem
   ```

   and copy the public key PEM to that path, then
   `systemctl restart firewall-api`. (For production, put the licensing host
   behind TLS/nginx.)

## Daily operations (CLI as root on the licensing VM)

```bash
# sell a subscription
license_admin.py issue --type subscription --edition professional
# corporate with a custom device count
license_admin.py issue --type subscription --edition corporate --devices 2000
# perpetual with 12 months of update entitlement
license_admin.py issue --type perpetual --edition home --update-days 365

# a customer's site has no internet: make their licence file
license_admin.py offline FA-XXXXX-XXXXX-XXXXX-XXXXX install_CUSTOMER_ID > licence.json
# customer uploads licence.json on their appliance dashboard (licence banner -> Offline licence file)

license_admin.py list                       # every issued key
license_admin.py activations                # who activated what, when
license_admin.py suspend FA-XXXXX-...      # lapse enforcement (appliance freezes config on next activation)
license_admin.py unsuspend FA-XXXXX-...    # payment received
license_admin.py revoke FA-XXXXX-...        # permanent
```

The installation_id needed for offline files is shown on the appliance's
licence status (dashboard banner / `GET /api/v1/licensing/status`).

## Edition-reference licensing (Option 2 — shipped)

Licences reference the **edition**, not a frozen feature list. At every
activation and every 15-minute refresh the licensing host signs the
**current catalogue** for the licence's edition. Consequence: add a new
module to an edition in `license_models.py` (both sides import it), deploy,
and every licensed customer of that edition receives it on their next
refresh — automatically. The appliance-side edition cap still guarantees a
licence can never exceed its edition.

## Master → fleet update notification (shipped)

When a new build is cut on the master appliance, publish the notification:

```bash
python3 publish_update.py https://lic-srv-001.example/api $ADMIN_TOKEN \
    --version 3.2 --notes "Adds GeoIP policy and VPN gateway" \
    --download-url https://example.com/firewall-appliance-3.2.tar.gz
```

Every appliance polls `GET /v1/product-update` on the same 15-minute licence
refresh cycle and shows *"New product update available — version 3.2"* on its
Operations page, with the download link. Publishing requires the admin bearer
token (verified 401 without it). The appliance stores the notice and exposes
it via `GET /api/v1/licensing/refresh` (the `product_update` field).

## How the appliance enforces (already shipped in Version 3.1)

- **Active licence**: the edition's features decide what the dashboard and
  API expose; device and account limits are enforced (account creation is
  refused past the limit; over-limit devices raise a visible warning).
- **Trial**: 60 days, all Professional features, once per installation.
- **Lapsed or suspended**: the honest firewall — filtering, block page, portal
  and DNS keep protecting the network; all configuration writes are locked
  with a clear message until renewal.
- Every licence is bound to the first installation that activates it; a key
  cannot be reused elsewhere until deactivated.

## Free Home Lite tier (shipped)

A free edition for small home networks: full protection, no reports, one dashboard
account, 10 devices. It is **perpetual and free** - no expiry, no renewal.

**How an appliance gets it** (never manual, never a pre-created key):

1. When nothing is licensed (fresh install, trial used up, subscription lapsed)
   the appliance dashboard shows a **Get free Home Lite** button.
2. The appliance POSTs to `/api/activate` with the reserved key
   `FA-HOMELITE-<installation_id>` and its own installation id.
3. The licensing server auto-issues a **perpetual Home Lite licence** for that
   installation (`customer_name` = "Home Lite (free)", 1 activation) and signs
   it. The key is installation-bound; a different installation id is denied.
4. The licence row appears in the portal dashboard like any other - audit it,
   and disable it there if a free installation is ever abused. The appliance
   picks the change up on its 15-minute licence refresh.

## Licence type to edition rules (shipped)

The dashboard's Create License form now stores the chosen licence type and
enforces, server-side (the dropdown filtering is only convenience):

| Licence type | Allowed editions |
|---|---|
| Free | Home Lite only |
| Trial | Corporate only |
| Subscription | every paid edition (no Home Lite) |
| Perpetual | every paid edition (no Home Lite) |

Details:

- **Free signs as perpetual.** The appliance only accepts
  `trial | subscription | perpetual` in signed payloads, so a FREE licence is
  stored and displayed as FREE on the portal but signs as perpetual - free
  never expires and the Home Lite edition caps its features anyway. Both the
  activation endpoint and the offline licence download do this.
- **Trials expire after 60 days** when created (same evaluation window as the
  appliance's built-in full trial). Subscription/Perpetual/Free have no expiry.
- **Perpetual includes 12 months of product updates** (`maintenance_expires_at`
  = created + 365 days, signed as `updates_until`). After the window the
  appliance keeps working exactly as it was - protection, filtering, every
  setting - it just stops receiving signed update packages (the appliance
  reports "Perpetual licence is active; the update entitlement has expired.
  Everything else keeps working."). The window starts when the licence key
  is created, not when it is activated.
- **Firewall Appliance licences must carry an edition** - the old loophole of
  creating an FA licence with no edition (which silently signed as Corporate)
  is refused.
- Other products (Standard editions) are unconstrained.
- Refusals redirect back to the dashboard with a red error banner explaining
  the rule.

## Subscriptions, deactivation and resellers (shipped)

**Subscription billing periods:** the create form has a Billing period selector
(visible for Subscription only): Monthly = expires 30 days after creation,
Annual = expires 12 months after creation. Subscription payloads also carry a
14-day grace window past expiry, so a lapsed customer keeps working while they
renew - only configuration changes lock after the grace period.

**What happens when you deactivate (disable) a licence:**

1. Within 15 minutes the appliance's licence refresh receives a **signed
   suspended envelope** (not an error) and switches to the honest SUSPENDED
   state: *"Licence suspended. Filtering continues to protect the network;
   configuration is locked until the licence is restored."* Nothing silently
   stops - the firewall, DNS, block page and portal keep enforcing exactly
   what was last configured; only settings changes are refused.
2. First-time activation of a disabled key is refused ("License is disabled").
3. Press **Enable** in the licence list and the appliance restores itself on
   its next refresh - no re-activation needed.

**Reseller NFR licences:** tag client licences with the Reseller field. Every
reseller with at least one ACTIVE client licence for a product earns one free
Not-For-Resale Corporate licence (edition CORP, 1 activation, no expiry,
license type NFR, signs as perpetual Corporate). The dashboard's Resellers
section shows each reseller's client counts and NFR status; **Issue earned NFR
licences** with a product selected issues all due NFRs in one click and never
duplicates while an active NFR exists. NFR licences never count as client
licences, so an NFR alone never earns another NFR.

Guards:

- A still-running trial or an active paid licence is **never downgraded** - the
  appliance refuses the request with 409 until the current licence is deactivated.
- Admin-issued keys can never collide with the reserved prefix: portal keys use
  uppercase hex random parts, the reserved key contains `install_<32 hex>`.
- The feature-sync script (`scripts/sync_features.py`) treats `home_lite` as
  optional in the catalogue and creates the `HOME_LITE` edition row on its
  first `--apply` run, so the sync never breaks on older appliances.

## Verified behaviour (already proven end-to-end)

- edition-aware issue (Home 25/1, Corporate 2000 override)
- offline file generation, appliance signature verification, evaluation
- tampered payloads rejected by signature
- over-limit warnings
- appliance freeze while unlicensed (reads open, writes locked, client paths open)
