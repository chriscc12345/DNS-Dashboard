# iptables Edition 3.0 RC1

## Enforcement lifecycle

1. The web console or API changes desired state only.
2. The compiler resolves module dependencies, policies, blocked devices and NAT objects.
3. `iptables-restore --test` validates the complete candidate against the running kernel.
4. The candidate rules and manifest are bound by SHA-256 and expire after 15 minutes.
5. The root-only helper snapshots the active rules and applies the candidate atomically.
6. The administrator verifies connectivity and confirms the transaction.
7. A systemd timer restores the snapshot if confirmation is not received before the deadline.

The API process never accepts a filesystem path or shell command for privileged execution. Sudo permits only fixed actions and transaction IDs matching `ipt_[0-9a-f]{16}`.

## Deployment modes

- Two-NIC routed gateway: complete forwarding, NAT and client enforcement.
- Two-NIC transparent bridge: inline filtering with `br_netfilter`.
- One-NIC VLAN trunk: tagged WAN/LAN separation.
- One-NIC DNS/proxy: DNS and explicit proxy controls without full gateway visibility.

## API workflow

Use a scoped bearer token with `deployment:read` and `deployment:write`.

1. `PUT /api/v1/firewall/engine/settings`
2. `PUT /api/v1/firewall/modules/{module_key}`
3. `POST /api/v1/firewall/iptables/render`
4. `POST /api/v1/firewall/iptables/candidates`
5. `POST /api/v1/firewall/iptables/transactions/{id}/activate`
6. `POST /api/v1/firewall/iptables/transactions/{id}/confirm`

Call the rollback action instead of confirm if any health or connectivity check fails. Interactive API documentation is exposed at `/docs`, and the machine-readable specification is at `/openapi.json`.

## Production warning

Install first on an isolated Debian test appliance with console access. Keep `FIREWALL_ENABLE_LIVE_APPLY` disabled until interfaces, management CIDRs and rollback have been tested. HTTPS termination and trusted certificates are mandatory before exposing the management console beyond a protected administrator network.
