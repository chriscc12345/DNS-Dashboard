#!/usr/bin/env python3
"""Build the NetFortress Dashboard User Manual PDF.

Covers every dashboard page in plain English, matching the shipped product
(Build 5: user groups and permissions, guarded blocking, web control, IDS,
admin port). Run anywhere ReportLab is installed:

    python3 build_user_manual.py
"""
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (BaseDocTemplate, Frame, PageBreak, PageTemplate,
                                Paragraph, Spacer, Table, TableStyle)

OUT = Path(__file__).resolve().parents[1] / "output" / "pdf"
OUT.mkdir(parents=True, exist_ok=True)

NAVY = colors.HexColor("#071019")
PANEL = colors.HexColor("#102030")
BLUE = colors.HexColor("#36A3FF")
GREEN = colors.HexColor("#35D49A")
GOLD = colors.HexColor("#A68E17")
MUTED = colors.HexColor("#607789")
LIGHT = colors.HexColor("#EAF4FA")
LINE = colors.HexColor("#C9D8E2")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="CoverTitle", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=30, leading=35, textColor=colors.white, alignment=TA_CENTER, spaceAfter=10))
styles.add(ParagraphStyle(name="CoverSub", parent=styles["Normal"], fontSize=13, leading=19, textColor=LIGHT, alignment=TA_CENTER))
styles.add(ParagraphStyle(name="H1x", parent=styles["Heading1"], fontSize=20, leading=24, textColor=NAVY, spaceBefore=8, spaceAfter=10))
styles.add(ParagraphStyle(name="H2x", parent=styles["Heading2"], fontSize=14, leading=18, textColor=colors.HexColor("#126BA3"), spaceBefore=10, spaceAfter=6))
styles.add(ParagraphStyle(name="Bodyx", parent=styles["BodyText"], fontSize=9.2, leading=13.5, textColor=colors.HexColor("#20313D"), spaceAfter=6))
styles.add(ParagraphStyle(name="Smallx", parent=styles["BodyText"], fontSize=7.8, leading=10.5, textColor=MUTED))
styles.add(ParagraphStyle(name="Callout", parent=styles["BodyText"], fontSize=9.4, leading=13.5, textColor=NAVY, leftIndent=10, rightIndent=10, borderColor=BLUE, borderWidth=1, borderPadding=8, backColor=colors.HexColor("#EAF7FF"), spaceBefore=7, spaceAfter=8))
styles.add(ParagraphStyle(name="Toc", parent=styles["BodyText"], fontSize=10.5, leading=17, textColor=colors.HexColor("#20313D")))


def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(LINE)
    canvas.line(18 * mm, 14 * mm, A4[0] - 18 * mm, 14 * mm)
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(MUTED)
    canvas.drawString(18 * mm, 9 * mm, "NetFortress - Dashboard User Manual")
    canvas.drawRightString(A4[0] - 18 * mm, 9 * mm, f"Page {doc.page}")
    canvas.restoreState()


def h1(text): return Paragraph(text, styles["H1x"])
def h2(text): return Paragraph(text, styles["H2x"])
def p(text): return Paragraph(text, styles["Bodyx"])
def callout(text): return Paragraph(text, styles["Callout"])
def bullets(items): return [Paragraph(f"•  {item}", styles["Bodyx"]) for item in items]


def steps(items):
    return [Paragraph(f"<b>{i + 1}.</b>  {item}", styles["Bodyx"]) for i, item in enumerate(items)]


def grid(headers, rows, widths=None, small=False):
    data = [[Paragraph(str(c), styles["Smallx"]) for c in headers]] + [[Paragraph(str(c), styles["Smallx"] if small else styles["Bodyx"]) for c in row] for row in rows]
    t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), PANEL), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("GRID", (0, 0), (-1, -1), .45, LINE), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F4F8FA")])]))
    return t


def flatten(items):
    result = []
    for item in items:
        result.extend(flatten(item) if isinstance(item, list) else [item])
    return result


# ---------------------------------------------------------------- content ---

CHAPTERS = [
    ("Getting started",
     "Opening the dashboard for the first time, the setup wizard, and how the safety design works.",
     [
         ("h2", "Sign in"),
         ("p", "Open the dashboard in a browser (for example http://192.168.50.2/ - the Operations page lets you move it to another port later). The first account you create is the administrator. Sessions last 8 hours; the Log out button always asks first so a stray tap never signs you out. If a session does end while you work, sign back in and you return to the page you were on."),
         ("h2", "The setup wizard (5 steps)"),
         ("p", "The wizard runs once per appliance. It walks through: architecture (how the appliance sits in your network - two-NIC routed gateway, transparent bridge, or one-NIC VLAN trunk), adapters (which network card faces the internet and which faces your devices), the client network and DHCP range, and activation."),
         ("callout", "The golden rule: nothing risky is ever applied silently. The final step shows an activation phrase you must type exactly. The new configuration goes live with a countdown - if you do not confirm that everything works before the countdown ends, the previous configuration restores itself automatically."),
     ]),
    ("Dashboard",
     "Live status at a glance: is the firewall enforcing, is DNS protecting clients, what happened recently.",
     [
         ("p", "The dashboard shows protection cards with honest state colours: green (up) means enforced, amber (partial) means some of it is active, red (down) means it is off or not working. Clicking a card drills into the matching page. Recent devices, event counts and licence state are shown as metrics. The dashboard never hides a problem - a failed service shows as failed."),
     ]),
    ("Devices",
     "Every client the appliance has seen, with one-click blocking.",
     [
         ("p", "The Devices page lists observed client devices with hostname, IP address, MAC address, interface and state. States come from live observation, not guesswork: <b>Online</b> means the appliance just verified the device, <b>Recently seen</b> means it was talking moments ago or has gone quiet but is still in the network tables, and <b>Offline</b> means it was seen before but is missing from the latest sweep - switched off or left the network. A device that disappears is marked offline at the next scan; nothing keeps showing as online after it is gone."),
         ("bullets", [
             "<b>Block button</b> - blocks that device by every identity it has (name, IP and MAC together), so a new DHCP address does not sneak past it.",
             "<b>Unblock</b> - removes the blocking rules and restores access.",
             "<b>Search</b> - filter by any part of the hostname, IP or MAC.",
         ]),
         ("callout", "Blocking a device compiles into the guarded firewall flow: the rule appears in the next candidate and goes live only through the apply-and-confirm steps."),
     ]),
    ("Device blocking",
     "Blocking rules, device groups, group members, and time-based schedules.",
     [
         ("h2", "Blocking rules"),
         ("p", "A blocking rule stops one client from reaching the network. Create one with New blocking rule and choose:"),
         ("bullets", [
             "<b>Rule name</b> - what you will recognise later, e.g. 'Block office laptop'.",
             "<b>Target type</b> - MAC address, IP address, hostname, or a device group.",
             "<b>Target value</b> - the address or hostname, or the group selector.",
             "<b>Reason</b> - stored with the rule and shown in the audit log.",
             "<b>Schedule</b> - Always, or one of your time windows.",
         ]),
         ("h2", "Device groups and members"),
         ("p", "A device group applies one rule to many identities - useful for 'guests', 'printers' or 'the warehouse PCs'. Type a name and Add group, then add members (MACs, IPs or hostnames) to it. Create a blocking rule with Target type: Device group and the whole group is blocked together. Remove a member and it stops being covered by the group's rules."),
         ("h2", "Time-based schedules"),
         ("p", "A schedule is a named time window, for example 'Evening block' from 20:00 to 22:00 in your chosen time zone. A blocking rule with a schedule only applies inside that window - the same rule can be harmless by day and enforced by night. Schedules are listed with their windows so you can double-check them at a glance."),
     ]),
    ("Web Control",
     "Site and application blocking: category groups, services, DNS enforcement, blocklists, the block page, proxy and the policy portal.",
     [
         ("h2", "Category and application groups"),
         ("p", "Categories are cards - Social media, Ads, Streaming and so on. Click a card to open it and see every service inside (Facebook, Instagram, TikTok...), the feed covering it, and any custom domains you added. The card's switch blocks or unblocks the whole group; inside, each service has its own tick - untick Facebook and Facebook alone stays reachable while the rest of the group stays blocked."),
         ("callout", "Related domains: services often sit on shared infrastructure - threads.com uses the same static.cdninstagram.com addresses as Instagram. The domain scan finds every related address before a service is added, so a 'blocked' brand is really blocked, not just its front door. You can extend an existing service with more domains at any time."),
         ("h2", "Custom domains and blocklists"),
         ("p", "Add any single domain with Block or Allow override. Blocklists download curated feeds (StevenBlack and category feeds), validate them and stage them safely - a broken feed never takes enforcement down; the last good list keeps running."),
         ("h2", "DNS enforcement and resolver"),
         ("p", "The compiled domain set is served by the local resolver. Apply DNS now pushes it live; the status row shows whether enforcement is active and how many domains are compiled. The resolver form sets upstream servers, whether blocked names go to the block page or NXDOMAIN, and DNSSEC validation."),
         ("h2", "Block page"),
         ("p", "Three ways to serve it, in priority order: (1) forward blocked visits to your own URL, (2) upload your own HTML design, or (3) use the generated branded page (logo, colours, contact, policy link). With Allow access requests on, the page shows a request form - submissions land in Reports → Access requests, and approving creates the allow rule automatically."),
         ("callout", "HTTPS sites: browsers encrypt traffic before any page can be shown, so the appliance serves the branded page over its own HTTPS with an appliance certificate. Show the branded block page on HTTPS sites too requires the client to trust the appliance certificate - once installed, blocked HTTPS sites show the branded page instead of a browser error."),
         ("h2", "Web proxy and cache"),
         ("p", "Optional explicit proxy with disk and memory caching. Enable it, set the listen port and cache sizes. HTTPS inspection stays off until a managed certificate authority is provisioned."),
         ("h2", "Policy acceptance (new devices)"),
         ("p", "When on, every new device must open a web page, read your policy and press accept before it gets internet. On acceptance the device can also install the network certificate. The Accepted devices list shows who accepted and lets you revoke - a revoked device must accept again."),
     ]),
    ("Firewall",
     "Live traffic rules in three guarded steps - a mistake can never lock you out.",
     [
         ("p", "The Firewall page sets the basics: which adapter reaches the internet (WAN), which reaches your devices (LAN), your client IP range, the trusted management networks (only these may open the dashboard and SSH), NAT sharing, and the automatic-undo countdown length."),
         ("steps", [
             "<b>Preview</b> - press '1 · Check my changes'. The firewall builds the rules and checks them with the kernel. Nothing changes yet.",
             "<b>Apply with a safety timer</b> - the new rules go live and a countdown arms. If it runs out, the previous rules return automatically.",
             "<b>Confirm</b> - test internet and this dashboard from a client. Works? Press 'Keep these changes'. Doesn't? Press 'Undo now' - or just wait.",
         ]),
     ]),
    ("Security modules",
     "Protection layers you switch on - with the plain-English truth about each one.",
     [
         ("p", "Each card is one protection layer: stateful firewall, NAT, anti-spoofing, port-scan quarantine, rate limiting, logging, MAC filtering, DNS enforcement, web filtering, IDS/IPS and more. Every card says what it does - press 'What does this do?' - and its honesty label:"),
         ("grid", ["Label", "Meaning"], [
             ["Automatic", "Protects traffic as soon as it is on"],
             ["Configured", "On, but does nothing until you add rules in the Network section"],
             ["Needs software", "Install it from the card (for example the Suricata IDS/IPS engine)"],
             ["Planned", "Announced capability, not wired to live traffic yet"],
         ], [30 * mm, 146 * mm]),
         ("h2", "Recommended resources"),
         ("p", "A module that wants more than this appliance has shows a warning on its card with the recommended resources - for example IDS/IPS recommends at least 4 GB of RAM and 2 CPU cores. You can still switch it on after acknowledging the warning, but expect a slower appliance. The recommendation appears only when the appliance falls short; a well-sized appliance shows nothing."),
         ("h2", "GeoIP country policy"),
         ("p", "The GeoIP country policy panel sits below the module cards, but only while the GeoIP module is switched on. Switch the module off and the panel disappears with it. Switch it back on and your saved country policy is exactly where you left it. In allow-list mode only the chosen countries may connect in; in block-list mode the chosen ones may not."),
         ("h2", "IDS/IPS (Suricata)"),
         ("p", "Install the engine from the card. It inspects client traffic inline (NFQUEUE with queue-bypass: if the engine stops, traffic keeps flowing - inspection never becomes an outage). The ET Open signature feed (tens of thousands of rules, updated daily by Proofpoint) is downloaded, validated with the engine's own config test BEFORE touching live traffic, then applied - a rejected ruleset restores the previous one automatically. Alerts appear in Security reports within a minute."),
     ]),
    ("Users, groups and permissions",
     "Who can sign in, and exactly what each account may do.",
     [
         ("h2", "How it works"),
         ("p", "Every account belongs to one group; a group is a named set of permissions. When an account signs in, the firewall grants exactly what its group allows - and changing a group changes what every member can do on their very next click, no re-login needed."),
         ("h2", "The 11 permissions"),
         ("bullets", [
             "<b>Full access</b> - everything, including user and system management.",
             "<b>Dashboard</b> - the live status page.",
             "<b>Devices</b> - view and block connected devices.",
             "<b>Web control</b> - sites, groups and feeds.",
             "<b>Access requests</b> - review client unblock requests.",
             "<b>Reports</b> - security reports and events.",
             "<b>Network</b> - adapters, DHCP, objects.",
             "<b>Firewall</b> - guarded rule changes.",
             "<b>Modules</b> - security modules.",
             "<b>Operations</b> - backup, restore and updates.",
             "<b>Users</b> - accounts, groups and API tokens.",
         ]),
         ("h2", "Built-in groups"),
         ("grid", ["Group", "Permissions"], [
             ["Administrators", "Full access. Can never lose full access; the last enabled administrator cannot be disabled, deleted or demoted."],
             ["Operators", "Dashboard, devices, web control, access requests, reports, modules, operations - everything except network, firewall and user management."],
             ["Viewers", "Dashboard and reports, read-only."],
         ], [32 * mm, 144 * mm], True),
         ("h2", "Your own groups"),
         ("p", "New group → name it, tick the permissions, save. Edit permissions any time. A group cannot be deleted while a member is still in it - move them first. On the Accounts panel, each row has a group dropdown (moves the account instantly), Enable/Disable and Delete."),
         ("h2", "API tokens"),
         ("p", "Bearer tokens for integrations - scoped, expiring, revocable. The secret is shown once at creation. A token never gets more access than the account that created it."),
     ]),
    ("Network",
     "Adapters and roles, IP pools, DHCP and service objects.",
     [
         ("h2", "Adapters"),
         ("p", "Each adapter gets a role: the internet side (WAN) takes its address from your router; the client side (LAN) keeps a fixed address so the appliance can serve DHCP and DNS. You can rename adapters (the name appears everywhere, including the setup wizard) and switch between static and DHCP addressing per adapter."),
         ("h2", "IP pools - more client networks"),
         ("p", "Each pool is an extra client network (a guest or IoT range). The appliance automatically creates a virtual adapter for it on the LAN adapter, serves DHCP there, and filters it exactly like the main network."),
         ("h2", "Kea DHCP"),
         ("p", "The DHCP service hands client addresses. The interface field is locked to the LAN adapter you assigned in Adapters - it cannot drift to another network by accident. Set the pool range, router and lease time here."),
         ("h2", "Network service objects"),
         ("p", "Reusable named objects (hosts, networks, services) that rules can refer to, so a change to the object updates every rule that uses it."),
     ]),
    ("Operations",
     "Backup, updates, restore, public certificates and the admin port.",
     [
         ("h2", "Back up and update (one click)"),
         ("p", "One button saves a timestamped configuration backup on the appliance (downloadable via the link) and reports any pending signed update packages."),
         ("h2", "Restore configuration"),
         ("p", "Upload a backup archive; it is validated and staged, then applied only after you type the restore confirmation phrase - the same guarded flow as every risky change."),
         ("h2", "Public TLS certificate"),
         ("p", "Real Let's Encrypt certificates via Cloudflare DNS - padlocked HTTPS for the dashboard and block page with no client-side installs. Enter your Cloudflare zone and an API token with Zone/DNS/Edit permission, request the certificate, and the appliance renews it."),
         ("h2", "Admin page port"),
         ("p", "Choose the TCP port the admin dashboard answers on (default 80). Reserved ports belong to appliance services: 22, 53, 67, 68, 443, 3128, 8080, 8420. On apply: the firewall is re-applied first so the new port is reachable from your networks, then the web server switches - the current page keeps answering until the very last step, and you are redirected to the new address. Client pages (block page, portal) never move."),
     ]),
    ("Reports",
     "What was blocked, what was requested, and the decision trail.",
     [
         ("h2", "Overview and events"),
         ("p", "Counts for events, blocked traffic and configured sources. Recent security events shows the last 10 by default - press 'View all (100 events)' for the full list and 'Show last 10 only' to collapse it. Export CSV downloads everything for external analysis. Top categories and destinations show where blocking pressure comes from."),
         ("h2", "Access requests"),
         ("p", "When the block page allows requests, each submission appears here with the client's IP - the panel refreshes automatically every 10 seconds. Approve asks how long: 1 hour, 4 hours, 8 hours, 24 hours, 3 days, 7 days, 30 days, or Permanent - until you remove it. Approving can auto-create the allow rule; the decision, duration and note are audited. Clear reviewed removes approved/denied entries while pending ones stay."),
     ]),
    ("Licensing",
     "Editions, activation (online and offline), the trial, and what happens when a licence lapses.",
     [
         ("h2", "What the licence banner shows"),
         ("p", "The top of the dashboard shows your edition, the licence state, days left and device/account usage. Two ways to activate: paste the purchased key (FA-XXXXX-...) or upload the offline licence file for sites without internet. The 60-day trial unlocks every Professional feature once per installation."),
         ("h2", "What is included in what"),
         ("grid", ["Edition", "Includes", "Devices", "Accounts"], [
             ["Home Lite", "Free — full protection, no reports", "10", "1"],
             ["Home", "Full protection — no reports", "25", "1"],
             ["Essential", "+ Reports, audit, backup/restore", "50", "2"],
             ["Professional", "+ IDS/IPS, HTTPS block page, portal, IP pools, API automation, public TLS", "250", "unlimited"],
             ["Corporate", "Same as Professional with larger device counts per licence", "1000+", "unlimited"],
         ], [26 * mm, 92 * mm, 20 * mm, 38 * mm], True),
         ("h2", "The free Home Lite licence"),
         ("p", "When nothing is licensed - the trial was never used, it has expired, or a subscription lapsed - the dashboard offers <b>Get free Home Lite</b>. One click asks the licence server for a free perpetual Home Lite licence: full protection, no reports, one dashboard account and up to 10 devices. A still-running trial or a paid licence is never replaced automatically - deactivate it first if you want the free edition. The free licence appears in the licence server's dashboard like any other licence, so it can be audited and, if misused, disabled from there; the appliance picks that up on its next licence check."),
         ("h2", "The honest firewall"),
         ("callout", "When a subscription expires or a key is suspended, filtering, the block page, the portal and DNS keep protecting the network — nothing silently stops. What locks is configuration: every settings change is refused with a clear message until the licence is renewed. Device and account limits are enforced: accounts past the limit cannot be created, and crossing the device limit raises a visible warning."),
     ]),
    ("Audit log",
     "Every configuration and access decision, forever searchable.",
     [
         ("p", "The audit log records who did what, when, from where: sign-ins (including failures), rule and policy changes, group and permission edits, port changes, portal acceptances, backups and restores. Use it to answer 'what changed?' after any incident."),
     ]),
    ("Safety rails (quick reference)",
     "The guarantees that hold on every page.",
     [
         ("grid", ["Rail", "What it guarantees"], [
             ["Activation phrases", "Destructive steps (activate, restore) require typing the exact phrase - no accidental confirms."],
             ["Rollback timers", "Every live change runs with a countdown; not confirmed in time means automatic undo."],
             ["Last administrator", "The final enabled full-access account cannot be disabled, deleted or demoted."],
             ["Port moves", "Firewall opens the new port before the page moves; a failed switch rolls the setting back."],
             ["Feed failures", "A broken blocklist or IDS ruleset never replaces the last good one."],
             ["Session", "8 hours, logout confirmation, and you return to where you were after re-sign-in."],
         ], [40 * mm, 136 * mm], True),
     ]),
]


def build_manual():
    story = []
    data = [[Paragraph("◆", ParagraphStyle(name="Diamond", fontSize=42, textColor=GREEN, alignment=TA_CENTER))],
            [Paragraph("NetFortress", styles["CoverTitle"])],
            [Paragraph("Dashboard User Manual", styles["CoverSub"])],
            [Spacer(1, 10 * mm)],
            [Paragraph("Every page explained in plain English", styles["CoverSub"])],
            [Spacer(1, 8 * mm)],
            [Paragraph("Version 3.1 - September 2026", styles["CoverSub"])]]
    table = Table(data, colWidths=[174 * mm], rowHeights=[25 * mm, None, None, 10 * mm, None, 8 * mm, None])
    table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), NAVY), ("BOX", (0, 0), (-1, -1), 1.2, BLUE), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8)]))
    story += [Spacer(1, 35 * mm), table, PageBreak()]

    # contents
    story += [h1("Contents")]
    for i, (title, _, _) in enumerate(CHAPTERS, start=1):
        story.append(Paragraph(f"{i}.  {title}", styles["Toc"]))
    story += [PageBreak()]

    for i, (title, intro, blocks) in enumerate(CHAPTERS, start=1):
        story += [h1(f"{i}. {title}"), p(intro)]
        for block in blocks:
            kind = block[0]
            if kind == "p":
                story.append(p(block[1]))
            elif kind == "h2":
                story.append(h2(block[1]))
            elif kind == "bullets":
                story += bullets(block[1])
            elif kind == "steps":
                story += steps(block[1])
            elif kind == "callout":
                story.append(callout(block[1]))
            elif kind == "grid":
                story.append(grid(block[1], block[2], block[3] if len(block) > 3 else None, block[3 + 1] if len(block) > 4 else False))
        if i < len(CHAPTERS):
            story.append(PageBreak())

    path = OUT / "firewall-appliance-dashboard-manual.pdf"
    d = BaseDocTemplate(str(path), pagesize=A4, rightMargin=18 * mm, leftMargin=18 * mm, topMargin=18 * mm, bottomMargin=19 * mm, title="NetFortress Dashboard User Manual", author="NetFortress")
    d.addPageTemplates(PageTemplate(id="normal", frames=[Frame(d.leftMargin, d.bottomMargin, d.width, d.height, id="body")], onPage=footer))
    d.build(flatten(story))
    return path


if __name__ == "__main__":
    print(build_manual())
