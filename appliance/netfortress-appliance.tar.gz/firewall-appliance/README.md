# Firewall Appliance — iptables Edition

An API-first Debian/Ubuntu firewall appliance with a graphical deployment wizard.

Version 3.1 adds live core enforcement: dnsmasq DNS blocking, category feeds, LAN routing rules, and minute-level schedule reconciliation.

## New live enforcement core (3.1)

- **Real DNS filtering**: the compiled domain set is rendered into a dnsmasq configuration, activated through the hash-bound `firewall-dns-transaction` root helper, syntax-checked with `dnsmasq --test`, health-checked after restart and rolled back automatically on failure.
- **Category catalog**: Social media, Adult, Gambling, Fake news, Ads & trackers, Streaming and Gaming categories, each combining curated application domain sets with the matching StevenBlack `alternates` feeds (a single feed registration covers thousands of domains).
- **AAA and IPv6 protection**: blocked domains answer with the block-page IPv4 address for A queries and NODATA for every other type, so IPv6 cannot bypass the filter.
- **Client DNS hijack and bypass prevention**: LAN DNS is redirected to the appliance; DNS-over-TLS (853) and known DNS-over-HTTPS endpoints are rejected; QUIC/HTTP3 is rejected so browsers fall back to filterable TCP.
- **Time-based access**: the `firewall-policy-refresh` systemd timer re-evaluates schedules, categories and blocklists every minute, re-activating the iptables transaction (management health check, auto-rollback) and the DNS transaction when the desired state changes.
- **Gateway forwarding fixed**: LAN-to-WAN forwarding and appliance service ports (DNS, DHCP, block page, proxy) are rendered explicitly, so activating the default-deny ruleset no longer breaks client internet.
- DHCP (Kea) and the branded block page (nginx) are deployed with the same desired-state configuration.

Safety gates: `FIREWALL_ENABLE_LIVE_APPLY`, `FIREWALL_ENABLE_DNS_APPLY` and `FIREWALL_ENABLE_POLICY_REFRESH` (all in `/etc/firewall-appliance/environment`) keep activation opt-in; interactive firewall changes still use the candidate/confirm/rollback window.

## New iptables management plane

- responsive firewall console with desired-state module switches;
- REST endpoints for engine settings, module state, rule rendering and live inspection;
- 15 dependency-aware modules covering stateful filtering, NAT, forwarding, ipset, rate limits, scans, spoofing, MAC, GeoIP, DNS, web controls, IDS/IPS, NFLOG, IPv6, bridging and HA;
- hash-bound rules, `iptables-restore --test`, root-only activation and automatic rollback;
- persistent system settings and append-only audit records for every change;
- Debian installation of iptables, ipset, conntrack, ebtables, arptables, ulogd and persistence tooling.

The existing 2.0 features remain included:

- automatic network-interface discovery;
- graphical one-NIC and two-NIC architecture selection;
- routed gateway, transparent bridge, VLAN trunk, and DNS/proxy modes;
- compulsory architecture acknowledgement;
- network, VLAN, subnet, and management-access validation;
- a generated deployment plan;
- simulation-only apply endpoint while rollback support is being built.
- first-administrator bootstrap and secure scrypt password storage;
- signed, expiring login sessions;
- scoped API tokens stored only as SHA-256 digests;
- role-aware authorization and append-only audit events;
- SQLite development persistence and a PostgreSQL production schema;
- Debian/Ubuntu installer foundation.
- unlicensed minimal mode and a one-time 60-day full trial;
- subscription, 30-day grace, perpetual, update-expiry and suspension states;
- Ed25519-signed licence verification and online activation client;
- hardware-bound installation identity and trial-consumption tracking;
- nftables rendering for routed, bridge, VLAN-trunk and DNS/proxy modes;
- versioned network transaction candidates with hashes and syntax checking.
- root-separated transaction helper with a narrowly scoped sudo policy;
- complete nftables snapshots before every activation;
- automatic rollback after 120 seconds unless connectivity is confirmed;
- critical route, gateway, management API, and nftables health checks;
- exact transaction activation phrase, manual rollback, and audit events;
- live activation disabled by default behind `FIREWALL_ENABLE_LIVE_APPLY=1`.
- declarative, hash-verified network plans with no arbitrary shell commands;
- IPv4/IPv6 forwarding, management addresses, default routes, VLAN links, and bridges;
- incremental reverse-operation journals for partial-failure recovery;
- network changes protected by the independent `FIREWALL_ENABLE_NETWORK_APPLY=1` gate;
- systemd runtime-directory creation included in the service definition.
- authenticated overview dashboard with appliance, interface, memory and uptime health;
- dedicated network, device inventory, deployment and audit views;
- IPv4 ARP and IPv4/IPv6 kernel neighbour discovery;
- persistent IP, MAC, hostname, interface, state, first-seen and last-seen identity records;
- responsive desktop, tablet and mobile administration layout.
- blocking rules for MAC address, IPv4/IPv6 address, hostname, and device group;
- group membership by MAC, IP, or hostname;
- hostname-to-observed-IP resolution with unresolved-host reporting;
- native nftables address and Ethernet sets compiled into guarded candidates;
- dashboard controls and full REST endpoints for policy administration.
- DNS resolver settings and compiled domain filtering;
- safe HTTPS blocklist ingestion with one-click StevenBlack registration;
- whole-application blocking definitions for major social and media services;
- branded block-page preview and Squid proxy/cache configuration;
- a unified Web Control dashboard backed by authenticated REST endpoints.
- Kea DHCP configuration and validation;
- schedules, security events, reports and access requests;
- integrity-manifested backup export and restore validation;
- redacted support bundles and service inventory;
- 72 authenticated API routes and guarded network/firewall activation.
- hash-bound DNS, DHCP, proxy and block-page service candidates;
- native Kea/Squid validation, atomic activation, health checks and unified rollback.
- Social Media category-wide controls across Facebook, Instagram, WhatsApp and TikTok;
- nftables QUIC/HTTP3, external DNS, DoT/DoQ and known public DoH enforcement;
- administrator/operator/viewer account management with final-admin safety controls;
- cache capacity status and audited URL-specific purge operations.
- timezone-aware schedule enforcement, including overnight windows;
- signed update manifest and package verification before staging;
- restore upload, hash validation, exact confirmation and atomic database replacement;
- automatic pre-restore safety copy and audited recovery dashboard workflow.
- firewall zone objects and interface/network membership;
- audited TCP/UDP port-forward rules compiled into nftables DNAT;
- Kea DHCP reservations compiled from MAC, IP and hostname records;
- local A, AAAA and CNAME records compiled into DNS candidates;
- responsive dashboard management for network service objects.
- hourly systemd blocklist scheduler with due-time calculation and last-known-good retention;
- normalized firewall, DNS, proxy, application and system security-event ingestion;
- security reports, top categories/destinations and CSV export;
- access-request approval/denial with optional automatic allow-rule creation;
- configurable event, audit and request retention with audited purge;
- responsive Reports dashboard with live review workflow.

## Run the milestone

```bash
cd backend
python3 -m venv .venv
. .venv/bin/activate
pip install -e .
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

Open `http://SERVER-IP:8080`.

## Test

```bash
cd backend
python3 -m unittest discover -s tests -v
```

## Safety status

The authenticated `POST /api/v1/deployment/apply` route only prepares and
validates a candidate. It does not alter the live system. Guarded activation
requires both `FIREWALL_ENABLE_LIVE_APPLY=1` and
`FIREWALL_ENABLE_NETWORK_APPLY=1`, snapshots nftables, journals every network
mutation, and automatically restores both layers after 120 seconds unless an
administrator confirms connectivity. DHCP and DNS service configuration remain
candidate-only for the next milestone.

See [docs/technical-specification.md](docs/technical-specification.md) for the
complete target architecture.
