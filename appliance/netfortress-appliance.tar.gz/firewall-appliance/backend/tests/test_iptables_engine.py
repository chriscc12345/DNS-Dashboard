from app.services.iptables_engine import candidate_payload, default_module_state, module_inventory, render_ip6tables, render_iptables, resolve_module_state


def test_defaults_enable_foundational_modules():
    state = default_module_state()
    assert state["stateful"] and state["nat"] and state["logging"]
    assert not state["ids_ips"]


def test_dependencies_are_enabled_automatically():
    state = resolve_module_state({"stateful": False, "nat": False, "ipset": False, "web_filter": True})
    assert state["web_filter"] and state["ipset"]


def test_unknown_module_is_rejected():
    try:
        resolve_module_state({"does_not_exist": True})
        assert False
    except ValueError as exc:
        assert "Unknown firewall modules" in str(exc)


def test_rules_include_default_deny_nat_blocks_and_forward():
    state = resolve_module_state({"port_forwarding": True, "dns_enforcement": True, "mac_filter": True})
    rules = render_iptables(state, {"management_network": "10.0.0.0/24", "wan_interface": "wan0", "lan_interface": "lan0", "masquerade": True}, {"port_forwards": [{"protocol": "tcp", "external_port": 443, "internal_ip": "10.0.0.20", "internal_port": 8443, "source_network": None, "enabled": True}]}, {"ipv4": ["10.0.0.55"], "mac": ["aa:bb:cc:dd:ee:ff"]})
    assert ":INPUT DROP" in rules
    assert "-o wan0 -j MASQUERADE" in rules
    assert "--dport 443 -j DNAT --to-destination 10.0.0.20:8443" in rules
    assert "-s 10.0.0.55 -j DROP" in rules
    assert "--mac-source aa:bb:cc:dd:ee:ff -j DROP" in rules
    assert "--dport 53 -j REDIRECT --to-ports 53" in rules


def test_controls_add_service_accepts_forward_bypass_and_quic_rules():
    state = resolve_module_state({"dns_enforcement": True, "web_filter": True})
    rules = render_iptables(
        state,
        {"management_network": "192.168.50.0/24", "wan_interface": "ens19", "lan_interface": "ens18", "lan_network": "192.168.50.0/24", "masquerade": True},
        {},
        {},
        {"force_local_dns": True, "block_dot": True, "block_doh": True, "block_quic": True},
    )
    assert "-A INPUT -i ens18 -p udp --dport 53 -j ACCEPT" in rules
    assert "-A INPUT -i ens18 -p tcp --dport 80 -j ACCEPT" in rules
    assert "-A INPUT -i ens18 -p tcp --dport 443 -j REJECT --reject-with tcp-reset" in rules
    assert "-A FORWARD -i ens18 -s 192.168.50.0/24 -o ens19 -j ACCEPT" in rules
    assert "-A FORWARD -i ens18 -p udp --dport 443 -j REJECT" in rules
    assert "-A FORWARD -p tcp --dport 853 -j REJECT --reject-with tcp-reset" in rules
    assert "-A FORWARD -d 8.8.8.8 -p tcp --dport 443 -j REJECT" in rules


def test_bypass_controls_absent_when_disabled():
    state = resolve_module_state({"dns_enforcement": True, "web_filter": True})
    rules = render_iptables(state, {"wan_interface": "wan0", "lan_interface": "lan0", "lan_network": "10.1.0.0/24"}, {}, {}, {"force_local_dns": False, "block_dot": False, "block_doh": False, "block_quic": False})
    assert "--dport 853" not in rules
    assert "-A FORWARD -i lan0 -p udp --dport 443 -j REJECT" not in rules  # QUIC block is a control
    assert "-A FORWARD -d 8.8.8.8 -p tcp --dport 443 -j REJECT" not in rules  # DoH block is a control
    assert "-A INPUT -i lan0 -p tcp --dport 443 -j REJECT --reject-with tcp-reset" in rules  # block-page UX stays


def test_port_scan_quarantine_rules_when_enabled():
    state = resolve_module_state({"port_scan": True})
    rules = render_iptables(state, {"management_network": "10.0.0.0/24", "wan_interface": "wan0", "lan_interface": "lan0"}, {}, {})
    assert "-m recent --name fwscan --set" in rules
    assert "-m recent --name fwscan --rcheck --seconds 60 --hitcount 8" in rules
    assert "-m recent --name fwscanblock --rcheck --seconds 300" in rules
    assert "--dports 22,53,67,80,443,3128,8080" in rules  # answered/rejected ports never counted


def test_port_scan_rules_absent_when_disabled():
    state = resolve_module_state({})
    rules = render_iptables(state, {"wan_interface": "wan0", "lan_interface": "lan0"}, {}, {})
    assert "fwscan" not in rules


def test_ipv6_ruleset_is_default_deny_with_icmpv6_and_lan_services():
    state = resolve_module_state({"dns_enforcement": True, "web_filter": True, "logging": False})
    rules6 = render_ip6tables(state, {"wan_interface": "wan0", "lan_interface": "lan0"}, {"ipv6": ["2001:db8:bad::1"]}, {})
    assert ":INPUT DROP" in rules6 and ":FORWARD DROP" in rules6
    assert "-A INPUT -p ipv6-icmp -j ACCEPT" in rules6
    assert "-A INPUT -i lan0 -p udp -m udp --dport 53 -j ACCEPT" in rules6
    assert "-A INPUT -i lan0 -p tcp -m tcp --dport 3128 -j ACCEPT" in rules6
    assert "-A INPUT -s 2001:db8:bad::1 -j DROP" in rules6  # logged verdict disabled for this test
    assert "-A FORWARD -s 2001:db8:bad::1 -j DROP" in rules6
    assert "-A PREROUTING -i lan0 -p udp -m udp --dport 53 -j REDIRECT --to-ports 53" in rules6
    assert "MASQUERADE" not in rules6  # never NAT IPv6


def test_candidate_payload_carries_both_stacks():
    payload = candidate_payload(resolve_module_state({"dns_enforcement": True}), {"wan_interface": "wan0", "lan_interface": "lan0", "management_network": "10.0.0.0/24"}, {}, {}, {})
    assert payload["rules"].startswith("*filter")
    assert payload["rules6"].startswith("*filter")
    assert payload["modules"]["ipv6"] is True
    import hashlib
    assert payload["sha256"] == hashlib.sha256((payload["rules"] + "\x00" + payload["rules6"]).encode()).hexdigest()


def test_candidate_payload_omits_ipv6_when_module_disabled():
    state = default_module_state() | {"ipv6": False}
    payload = candidate_payload(state, {"wan_interface": "wan0"}, {}, {}, {})
    assert payload["rules6"] == ""


def test_tls_block_control_swaps_reject_for_accept():
    state = resolve_module_state({"dns_enforcement": True, "web_filter": True})
    base = {"wan_interface": "wan0", "lan_interface": "lan0"}
    off = render_iptables(state, base, {}, {}, {"tls_block": False})
    on = render_iptables(state, base, {}, {}, {"tls_block": True})
    assert "-A INPUT -i lan0 -p tcp --dport 443 -j REJECT --reject-with tcp-reset" in off  # fast-fail without the service
    assert "-A INPUT -i lan0 -p tcp --dport 443 -j ACCEPT" in on  # CA block-page service reachable
    assert "--dport 443 -j REJECT" not in on
    assert "-A INPUT -i lan0 -p tcp -m tcp --dport 443 -j ACCEPT" in render_ip6tables(state, base, {}, {"tls_block": True})


def test_ids_ips_nfqueue_rule_when_enabled():
    state = resolve_module_state({"ids_ips": True})
    rules = render_iptables(state, {"wan_interface": "wan0", "lan_interface": "lan0", "lan_network": "10.1.0.0/24"}, {}, {})
    assert "-A FORWARD -i lan0 -o wan0 -j NFQUEUE --queue-num 1 --queue-bypass" in rules
    # The inspection sits before the allow so every new client connection is seen.
    assert rules.index("NFQUEUE --queue-num 1") < rules.index("-A FORWARD -i lan0 -s 10.1.0.0/24 -o wan0 -j ACCEPT")


def test_ids_ips_rule_absent_when_disabled():
    state = resolve_module_state({})
    rules = render_iptables(state, {"wan_interface": "wan0", "lan_interface": "lan0"}, {}, {})
    assert "NFQUEUE" not in rules


def test_ip_pool_gets_vlan_adapter_service_and_forward_rules():
    state = resolve_module_state({"dns_enforcement": True})
    rules = render_iptables(state, {"wan_interface": "wan0", "lan_interface": "lan0"}, {"pools": [{"vlan_id": 20, "subnet": "192.168.20.0/24", "enabled": 1}]}, {})
    assert "-A INPUT -i lan0.20 -p udp --dport 67 -j ACCEPT" in rules
    assert "-A FORWARD -i lan0.20 -s 192.168.20.0/24 -o wan0 -j ACCEPT" in rules
    assert "-A PREROUTING -i lan0.20 -p udp --dport 53 -j REDIRECT --to-ports 53" in rules


def test_portal_holds_unaccepted_until_they_accept():
    state = resolve_module_state({"logging": False})  # plain DROP verdict for the assert
    rules = render_iptables(state, {"wan_interface": "wan0", "lan_interface": "lan0"}, {"pools": [{"vlan_id": 20, "subnet": "192.168.20.0/24", "enabled": 1}]}, {}, {"portal_enabled": True})
    assert "-A FORWARD -i lan0 -m set ! --match-set fw-portal-accepted src -j DROP" in rules
    assert "-A FORWARD -i lan0.20 -m set ! --match-set fw-portal-accepted src -j DROP" in rules
    assert "-A PREROUTING -i lan0 -p tcp --dport 80 -m set ! --match-set fw-portal-accepted src -j REDIRECT --to-ports 8420" in rules
    assert "-A INPUT -i lan0 -p tcp --dport 8420 -j ACCEPT" in rules


def test_geoip_rules_follow_mode_and_readiness():
    state = resolve_module_state({"geoip": True, "logging": True})
    base = {"wan_interface": "wan0", "lan_interface": "lan0"}
    # allowlist mode: everything except the listed countries is dropped
    rules = render_iptables(state, base, {}, {}, {"geoip_enabled": True, "geoip_mode": "allowlist"})
    assert "-i wan0 -o lan0 -m conntrack --ctstate NEW -m set ! --match-set geoip-allow src -j FW-LOGDROP" in rules
    # blocklist mode: only listed countries are dropped
    rules = render_iptables(state, base, {}, {}, {"geoip_enabled": True, "geoip_mode": "blocklist"})
    assert "-m set --match-set geoip-block src -j FW-LOGDROP" in rules
    # without the feed the engine never references a set that may not exist
    rules = render_iptables(state, base, {}, {}, {"geoip_enabled": False, "geoip_mode": "allowlist"})
    assert "geoip-allow" not in rules and "geoip-block" not in rules
    # module off: no geoip rules even with controls on
    off = resolve_module_state({})
    rules = render_iptables(off, base, {}, {}, {"geoip_enabled": True, "geoip_mode": "allowlist"})
    assert "geoip-allow" not in rules
    # NEW-only so live sessions survive a set swap
    assert "--ctstate NEW -m set" in render_iptables(state, base, {}, {}, {"geoip_enabled": True, "geoip_mode": "allowlist"})


def test_admin_port_is_allowed_from_management_and_lan():
    state = resolve_module_state({"port_scan": True})
    settings = {"management_network": "10.0.0.0/24", "wan_interface": "wan0", "lan_interface": "lan0", "admin_port": 8081}
    rules = render_iptables(state, settings, {"pools": [{"vlan_id": 100, "enabled": 1, "subnet": "10.10.100.0/24"}]}, {}, {})
    # trusted management networks may reach the dashboard on the chosen port
    assert "--dports 22,80,443,8080,8081 -j ACCEPT" in rules
    # the LAN interface accepts it next to the other appliance services
    assert "-i lan0 -p tcp --dport 8081 -j ACCEPT" in rules
    # pool subinterfaces get the same accept
    assert "-i lan0.100 -p tcp --dport 8081 -j ACCEPT" in rules
    # the port-scan detector ignores it like every other service port
    assert "! --dports 22,53,67,80,443,3128,8080,8081" in rules


def test_default_admin_port_80_needs_no_extra_rules():
    rules = render_iptables(resolve_module_state({}), {"wan_interface": "wan0", "lan_interface": "lan0", "admin_port": 80}, {}, {}, {})
    assert "--dport 8081" not in rules
    assert "--dports 22,80,443,8080 -j ACCEPT" in rules
    assert ",80,80" not in rules


def test_portal_rules_absent_when_disabled():
    rules = render_iptables(resolve_module_state({}), {"wan_interface": "wan0", "lan_interface": "lan0"}, {}, {}, {"portal_enabled": False})
    assert "fw-portal-accepted" not in rules and "8420" not in rules


def test_inventory_has_unique_keys():
    rows = module_inventory()
    keys = [row["key"] for row in rows]
    assert len(keys) >= 15
    assert len(keys) == len(set(keys))


def test_inventory_carries_minimum_requirements():
    rows = {row["key"]: row for row in module_inventory()}
    # The only module with a recommended minimum today is IDS/IPS (Suricata is heavy).
    assert rows["ids_ips"]["min_ram_mb"] == 4096
    assert rows["ids_ips"]["min_cores"] == 2
    assert rows["geoip"]["min_ram_mb"] == 0 and rows["geoip"]["min_cores"] == 0


def test_inventory_carries_plain_language_detail():
    rows = {row["key"]: row for row in module_inventory()}
    for key, row in rows.items():
        assert row.get("detail"), f"module {key} is missing its plain-language explanation"
        assert row.get("readiness") in {"enforced", "configured", "software", "planned"}, f"module {key} has an invalid readiness"
    assert rows["ids_ips"]["readiness"] == "software"
    assert rows["geoip"]["readiness"] == "configured"  # shipped in the Professional/Corporate editions
    assert {"bridge", "high_availability"}.issubset({key for key, row in rows.items() if row["readiness"] == "planned"})
