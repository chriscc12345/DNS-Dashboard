import json

import pytest

from app.models import BlockPageSettings, DnsSettings, ProxySettings
from app.services.content_filter import (
    application_catalog,
    category_catalog,
    compiled_domains,
    normalize_domain,
    parse_blocklist,
    render_block_page,
    render_dnsmasq_config,
    render_dns_config,
    render_squid_config,
)


def test_hosts_and_domain_lists_are_normalized():
    parsed = parse_blocklist("0.0.0.0 Facebook.COM\n127.0.0.1 localhost\nexample.org\n", "hosts")
    assert parsed == {"facebook.com", "example.org"}
    assert normalize_domain("BÜCHER.example.") == "xn--bcher-kva.example"


def test_application_and_allow_override_compilation(tmp_path):
    root = tmp_path / "blocklists"
    root.mkdir()
    (root / "source-1.domains").write_text("ads.example\nfacebook.com\n")
    result = compiled_domains(
        [{"domain": "facebook.com", "action": "allow"}, {"domain": "local.example", "action": "block"}],
        [{"application": "facebook", "enabled": True}],
        [{"id": 1, "enabled": True}],
        tmp_path,
    )
    assert "local.example" in result["blocked"]
    assert "fbcdn.net" in result["blocked"]
    assert "facebook.com" not in result["blocked"]
    assert result["allowed"] == ["facebook.com"]


def test_time_limited_rules_expire(tmp_path):
    from datetime import UTC, datetime, timedelta

    expired = (datetime.now(UTC) - timedelta(minutes=5)).isoformat()
    soon = (datetime.now(UTC) + timedelta(hours=1)).isoformat()
    result = compiled_domains(
        [
            {"domain": "facebook.com", "action": "allow", "expires_at": expired},
            {"domain": "still-allowed.example", "action": "allow", "expires_at": soon},
            {"domain": "local.example", "action": "block", "expires_at": expired},
        ],
        [{"application": "facebook", "enabled": True}],
        [],
        tmp_path,
    )
    assert "facebook.com" in result["blocked"]  # the temporary allow ran out
    assert "still-allowed.example" in result["allowed"]
    assert "local.example" not in result["blocked"]  # the temporary block also ran out


def test_switched_off_service_frees_its_feed_domains(tmp_path):
    root = tmp_path / "blocklists"
    root.mkdir()
    # the social feed carries literal facebook asset hostnames
    (root / "source-1.domains").write_text("facebook.com\nstatic.xx.fbcdn.net\ntiktok.com\n")
    result = compiled_domains(
        [],
        [{"application": "facebook", "enabled": False}],   # unticked inside the group
        [{"id": 1, "enabled": True}],
        tmp_path,
    )
    assert "facebook.com" not in result["blocked"]          # feed entry freed
    assert "static.xx.fbcdn.net" not in result["blocked"]    # literal feed subdomain freed
    assert "tiktok.com" in result["blocked"]                 # other feed domains keep blocking


def test_explicit_local_block_beats_a_switched_off_service(tmp_path):
    root = tmp_path / "blocklists"
    root.mkdir()
    (root / "source-1.domains").write_text("facebook.com\n")
    result = compiled_domains(
        [{"domain": "facebook.com", "action": "block"}],   # the administrator typed it explicitly
        [{"application": "facebook", "enabled": False}],
        [{"id": 1, "enabled": True}],
        tmp_path,
    )
    assert "facebook.com" in result["blocked"]              # explicit rules still win


def test_service_extension_domains_block_and_free_with_the_service(tmp_path):
    extensions = [{"name": "instagram", "domains": ["threads.com", "threads.net"]}]
    # on: the added domains block with the service
    on = compiled_domains([], [{"application": "instagram", "enabled": True}], [], tmp_path, service_extensions=extensions)
    assert "threads.com" in on["blocked"]
    assert "cdninstagram.com" in on["blocked"]
    # off: the added domains are freed with the service (feed or not)
    off = compiled_domains([], [{"application": "instagram", "enabled": False}], [], tmp_path, service_extensions=extensions)
    assert "threads.com" not in off["blocked"]
    # the catalog shows the merged list
    catalog = application_catalog([{"application": "instagram", "enabled": True}], [], extensions)
    instagram = next(item for item in catalog if item["name"] == "instagram")
    assert "threads.com" in instagram["domains"] and "instagram.com" in instagram["domains"]
    assert instagram.get("extended") is True


def test_host_discovery_from_markup():
    from app.services.content_filter import hosts_from_markup

    page = '''
    <script src="https://static.example-cdn.com/app.js"></script>
    <link rel="stylesheet" href="//fonts.example.org/style.css">
    <img srcset="https://img.example-cdn.com/a.png 2x, /b.png 1x">
    <a href="https://www.example-partner.co.za/page">partner</a>
    <iframe data-src="https://video.example-cdn.net/embed"></iframe>
    '''
    found = hosts_from_markup(page)
    assert "static.example-cdn.com" in found
    assert "fonts.example.org" in found
    assert "img.example-cdn.com" in found
    assert "www.example-partner.co.za" in found
    assert "video.example-cdn.net" in found


def test_disabled_blocklist_sources_are_excluded(tmp_path):
    root = tmp_path / "blocklists"
    root.mkdir()
    (root / "source-1.domains").write_text("ads.example\n")
    (root / "source-2.domains").write_text("casino.example\n")
    result = compiled_domains([], [], [{"id": 1, "enabled": True}, {"id": 2, "enabled": False}], tmp_path)
    assert "ads.example" in result["blocked"]
    assert "casino.example" not in result["blocked"]


def test_generated_configs_and_block_page_escape_input():
    dns = json.loads(render_dns_config(DnsSettings(), ["example.com"], [{"name": "printer.lan", "record_type": "A", "value": "192.168.10.25"}]))
    assert dns["blocked_domains"] == ["example.com"]
    assert dns["local_records"][0]["name"] == "printer.lan"
    squid = render_squid_config(ProxySettings(enabled=True, cache_size_mb=2048))
    assert "cache_dir ufs /var/spool/squid 2048" in squid
    page = render_block_page(BlockPageSettings(organization="<script>alert(1)</script>"))
    assert "<script>alert(1)</script>" not in page
    assert "&lt;script&gt;" in page


def test_catalog_exposes_full_facebook_domain_set():
    facebook = next(item for item in application_catalog([]) if item["name"] == "facebook")
    assert {"facebook.com", "fbcdn.net", "messenger.com"} <= set(facebook["domains"])
    assert facebook["enabled"] is False


def test_social_media_category_tracks_all_applications():
    policies = [{"application": name, "enabled": True, "block_quic": True} for name in ["facebook", "instagram", "whatsapp", "tiktok", "twitter", "snapchat", "discord", "reddit", "telegram", "linkedin", "pinterest"]]
    social = next(item for item in category_catalog(policies, []) if item["name"] == "social-media")
    assert "facebook" in social["applications"]
    assert "hollywoodbets" not in social["applications"]
    assert social["feed"] is not None
    assert social["enabled"] is True


def test_categories_cover_core_filtering_sets():
    names = {item["name"] for item in category_catalog([], [])}
    assert {"social-media", "adult", "gambling", "fakenews", "ads-trackers", "drugs", "gaming", "streaming-media"} <= names


def test_category_feed_registration_state():
    blocklists = [
        {"id": 1, "name": "StevenBlack — Adult content", "category": "adult", "enabled": True, "domain_count": 150000, "status": "healthy"},
    ]
    adult = next(item for item in category_catalog([], blocklists) if item["name"] == "adult")
    assert adult["feed_registered"] and adult["feed_enabled"]
    assert adult["feed_domain_count"] == 150000
    gambling = next(item for item in category_catalog([], blocklists) if item["name"] == "gambling")
    assert gambling["feed_registered"] is False and gambling["enabled"] is False


def test_dnsmasq_render_blocks_and_local_records():
    settings = DnsSettings(block_response="block_page", block_page_ipv4="192.168.50.2", upstream_servers=["1.1.1.1"])
    config = render_dnsmasq_config(settings, ["facebook.com"], [{"name": "printer.lan", "record_type": "A", "value": "192.168.50.25"}])
    assert "server=1.1.1.1" in config
    assert "address=/facebook.com/192.168.50.2" in config
    assert "host-record=printer.lan,192.168.50.25" in config
    assert "no-resolv" in config


def test_dnsmasq_render_nxdomain_mode():
    config = render_dnsmasq_config(DnsSettings(block_response="nxdomain"), ["casino.example"], [])
    assert "address=/casino.example/" in config
    assert "block_page" not in config


def test_dnsmasq_block_hostname_gets_a_host_record():
    settings = DnsSettings(block_response="block_page", block_page_ipv4="192.168.100.2", block_hostname="Blocked.Firewall.LAN.")
    config = render_dnsmasq_config(settings, ["facebook.com"], [])
    assert "host-record=blocked.firewall.lan,192.168.100.2" in config


def test_nginx_block_site_redirects_to_branded_url():
    from app.services.content_filter import render_nginx_block_site

    config = render_nginx_block_site("blocked.firewall.lan")
    assert "return 302 http://blocked.firewall.lan/?host=$host;" in config
    assert "server_name blocked.firewall.lan;" in config
    assert "return 301 https://blocked.firewall.lan$request_uri;" in config  # plain-HTTP block host upgrades to the padlocked page


def test_live_block_page_reads_redirect_query():
    from app.services.content_filter import render_block_page_live

    page = render_block_page_live(BlockPageSettings(title="Access blocked"))
    assert "fw-requested-host" in page
    assert "URLSearchParams" in page
    assert "{{REQUESTED_HOST}}" not in page


@pytest.mark.parametrize("bad", ["localhost", "http://example.com", "bad domain", "-bad.example"])
def test_invalid_domains_rejected(bad):
    with pytest.raises(ValueError):
        normalize_domain(bad)
