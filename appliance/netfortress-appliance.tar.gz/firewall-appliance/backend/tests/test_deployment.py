import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.models import DeploymentMode, DeploymentRequest, InterfaceInfo, VlanAssignment, AddressMode
from app.services.deployment import build_plan, validate_deployment


INTERFACES = [InterfaceInfo(name="wan0"), InterfaceInfo(name="lan0"), InterfaceInfo(name="eth0")]


class DeploymentValidationTests(unittest.TestCase):
    def base(self, **changes):
        values = dict(
            mode=DeploymentMode.ROUTED_GATEWAY,
            wan_interface="wan0",
            lan_interface="lan0",
            management_interface="lan0",
            management_address="192.168.10.1/24",
            architecture_acknowledged=True,
            cabling_acknowledged=True,
            recovery_acknowledged=True,
        )
        values.update(changes)
        return DeploymentRequest(**values)

    def test_valid_routed_gateway(self):
        result = validate_deployment(self.base(), INTERFACES)
        self.assertTrue(result.valid)

    def test_rejects_same_wan_and_lan(self):
        result = validate_deployment(self.base(lan_interface="wan0", management_interface="wan0"), INTERFACES)
        self.assertFalse(result.valid)
        self.assertIn("same_interface", {m.code for m in result.messages})

    def test_requires_acknowledgements(self):
        result = validate_deployment(self.base(recovery_acknowledged=False), INTERFACES)
        self.assertFalse(result.valid)
        self.assertIn("acknowledgement_required", {m.code for m in result.messages})

    def test_vlan_mode_requires_wan_and_lan(self):
        request = self.base(
            mode=DeploymentMode.VLAN_TRUNK,
            wan_interface=None,
            lan_interface=None,
            trunk_interface="eth0",
            management_interface="eth0",
            vlans=[VlanAssignment(role="lan", vlan_id=20, address_mode=AddressMode.STATIC, address="192.168.20.1/24")],
        )
        result = validate_deployment(request, INTERFACES)
        self.assertFalse(result.valid)
        self.assertIn("missing_vlan_role", {m.code for m in result.messages})

    def test_dns_proxy_is_partial_enforcement(self):
        request = self.base(
            mode=DeploymentMode.DNS_PROXY,
            wan_interface=None,
            lan_interface="eth0",
            management_interface="eth0",
        )
        plan = build_plan(request, INTERFACES)
        self.assertFalse(plan.full_enforcement)
        self.assertIn("partial_enforcement", {m.code for m in plan.validation.messages})


if __name__ == "__main__":
    unittest.main()
