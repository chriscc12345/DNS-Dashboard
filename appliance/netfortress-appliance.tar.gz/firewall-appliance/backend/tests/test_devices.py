import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.database import Database
from app.services import devices as devices_module
from app.services.devices import discover_devices


class DeviceDiscoveryTests(unittest.TestCase):
    @patch("app.services.devices._arp_neighbours", return_value=[])
    @patch("app.services.devices._lease_names", return_value={"192.168.10.22": "office-laptop"})
    @patch("app.services.devices.subprocess.run")
    def test_neighbour_has_identity(self, run, _leases, _arp):
        run.return_value = Mock(stdout=json.dumps([{"dst": "192.168.10.22", "dev": "lan0", "lladdr": "aa:bb:cc:dd:ee:ff", "state": ["REACHABLE"]}]))
        devices = discover_devices()
        self.assertEqual(devices[0].hostname, "office-laptop")
        self.assertEqual(devices[0].mac_address, "aa:bb:cc:dd:ee:ff")
        self.assertEqual(devices[0].state, "reachable")

    def test_device_observation_is_persisted(self):
        with tempfile.TemporaryDirectory() as directory:
            database = Database(Path(directory) / "test.db")
            database.initialize()
            rows = database.record_devices([{"ip_address": "10.0.0.4", "mac_address": "00:11:22:33:44:55", "hostname": "printer", "interface": "lan0", "state": "reachable", "source": "arp"}])
            self.assertEqual(rows[0]["hostname"], "printer")
            self.assertIsNotNone(rows[0]["first_seen_at"])
            self.assertIsNotNone(rows[0]["last_seen_at"])


    def test_kernel_state_map_is_honest(self):
        """Kernel neighbour states must map to the states the dashboard shows."""
        state_map = devices_module.STATE_MAP
        self.assertEqual(state_map["reachable"], "reachable")
        self.assertEqual(state_map["permanent"], "reachable")
        self.assertEqual(state_map["delay"], "delay")
        self.assertEqual(state_map["probe"], "delay")
        self.assertEqual(state_map["stale"], "stale")
        self.assertEqual(state_map["failed"], "offline")
        self.assertEqual(state_map["incomplete"], "offline")

    def test_arp_flags_decide_reachable_vs_stale(self):
        """The flags column is the verdict: 0x2 complete, otherwise the device has not been verified."""
        fake = (
            "IP address       HW type     Flags       HW address            Mask     Device\n"
            "192.168.10.22    0x1         0x2         aa:bb:cc:dd:ee:01     *        lan0\n"
            "192.168.10.23    0x1         0x0         aa:bb:cc:dd:ee:02     *        lan0\n"
        )
        with patch.object(devices_module, "Path") as mock_path:
            mock_path.return_value.read_text.return_value = fake
            rows = devices_module._arp_neighbours()
        self.assertEqual((rows[0]["ip_address"], rows[0]["state"]), ("192.168.10.22", "reachable"))
        self.assertEqual((rows[1]["ip_address"], rows[1]["state"]), ("192.168.10.23", "stale"))

    def test_failed_neighbours_report_offline(self):
        run = Mock(stdout=json.dumps([
            {"dst": "192.168.10.24", "dev": "lan0", "lladdr": "aa:bb:cc:dd:ee:03", "state": ["failed"]},
        ]))
        with patch("app.services.devices._arp_neighbours", return_value=[]), patch("app.services.devices.subprocess.run", return_value=run):
            rows = devices_module._ip_neighbours()
        self.assertEqual(rows[0]["state"], "offline")

    def test_device_switched_off_is_downgraded_to_offline(self):
        """A device that was reachable but is missing from the next sweep must not keep showing as reachable."""
        with tempfile.TemporaryDirectory() as directory:
            database = Database(Path(directory) / "test.db")
            database.initialize()
            database.record_devices([
                {"ip_address": "10.0.0.10", "mac_address": "00:11:22:33:44:01", "hostname": "left-on", "interface": "lan0", "state": "reachable", "source": "arp"},
                {"ip_address": "10.0.0.11", "mac_address": "00:11:22:33:44:02", "hostname": "already-stale", "interface": "lan0", "state": "stale", "source": "arp"},
            ])
            rows = {row["ip_address"]: row for row in database.record_devices([])}
            self.assertEqual(rows["10.0.0.10"]["state"], "offline")
            self.assertEqual(rows["10.0.0.11"]["state"], "stale")


if __name__ == "__main__":
    unittest.main()
