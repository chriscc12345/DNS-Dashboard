from app.database import Database
from app.security import hash_password


def test_user_administration_and_last_admin_guard_data(tmp_path):
    database = Database(tmp_path / "users.db")
    database.initialize()
    admin = database.create_user("admin", hash_password("Correct-Horse-99!"), "admin")
    viewer = database.create_user("viewer", hash_password("Another-Horse-99!"), "viewer")
    assert database.enabled_admin_count() == 1
    updated = database.update_user(viewer["id"], "operator", True)
    assert updated["role"] == "operator"
    assert len(database.users()) == 2
    assert database.delete_user(viewer["id"])
    assert database.user_by_id(admin["id"])["role"] == "admin"
