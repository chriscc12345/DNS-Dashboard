from app.database import Database


def test_network_resources_persist_and_delete(tmp_path):
    database = Database(tmp_path / "network.db")
    database.initialize()
    zone = database.create_zone({"name": "lan", "interfaces": ["eth1"], "networks": ["192.168.10.0/24"], "default_action": "drop"})
    forward = database.create_port_forward({"name": "HTTPS", "protocol": "tcp", "external_port": 8443, "internal_ip": "192.168.10.20", "internal_port": 443, "source_network": None, "enabled": True})
    reservation = database.create_dhcp_reservation({"mac_address": "AA:BB:CC:DD:EE:FF", "ip_address": "192.168.10.25", "hostname": "printer"})
    record = database.create_dns_record({"name": "printer.lan", "record_type": "A", "value": "192.168.10.25"})
    assert database.zones()[0]["interfaces"] == ["eth1"]
    assert database.port_forwards()[0]["enabled"] is True
    assert database.dhcp_reservations()[0]["mac_address"] == "aa:bb:cc:dd:ee:ff"
    assert database.dns_records()[0]["value"] == "192.168.10.25"
    assert database.delete_zone(zone["id"])
    assert database.delete_port_forward(forward["id"])
    assert database.delete_dhcp_reservation(reservation["id"])
    assert database.delete_dns_record(record["id"])
