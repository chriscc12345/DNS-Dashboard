"""Build 5 — user groups: permissions map to scopes, groups CRUD, safety rails."""
import json

from app.database import Database
from app.security import PERMISSION_SCOPES, group_scopes


def test_group_scopes_from_permissions():
    assert group_scopes(["full_access"]) == frozenset({"*"})
    scopes = group_scopes(["devices", "reports"])
    assert "policies:write" in scopes        # devices may block
    assert "audit:read" in scopes           # reports
    assert "users:write" not in scopes       # not granted
    assert group_scopes([]) == frozenset()


def test_builtin_groups_are_seeded_and_legacy_roles_migrate(tmp_path):
    database = Database(tmp_path / "groups.db")
    database.initialize()
    admin = database.create_user("boss", "x" * 20, "admin")
    viewer = database.create_user("reader", "x" * 20, "viewer")

    # role -> group migration runs at initialize() (i.e. on service start),
    # so freshly created role-based users only pick up their group on the
    # next initialize. Mirror the real lifecycle here.
    database.initialize()

    names = {group["name"] for group in database.user_groups()}
    assert {"Administrators", "Operators", "Viewers"} <= names

    admin_after = database.user_by_id(admin["id"])
    viewer_after = database.user_by_id(viewer["id"])
    assert admin_after["group_id"] is not None      # migrated onto Administrators
    assert viewer_after["group_id"] is not None      # migrated onto Viewers
    assert database.enabled_full_access_count() == 1
    assert database.user_has_full_access(admin_after)
    assert not database.user_has_full_access(viewer_after)


def test_group_lifecycle_and_guards(tmp_path):
    database = Database(tmp_path / "groups.db")
    database.initialize()
    helpdesk = database.create_user_group("Helpdesk", "First line support", ["devices", "access_requests"])
    assert "devices" in helpdesk["permissions"]

    # a member keeps the group busy
    member = database.create_user("help1", "x" * 20, "viewer", helpdesk["id"])
    assert database.group_member_count(helpdesk["id"]) == 1
    assert not database.delete_user_group(helpdesk["id"])           # has members
    assert [row for row in database.users() if row["id"] == member["id"]][0]["group_name"] == "Helpdesk"

    # permission edits replace the set
    updated = database.update_user_group(helpdesk["id"], None, None, ["reports"])
    assert updated["permissions"] == ["reports"]

    # once empty, the group can go
    database.update_user(member["id"], "viewer", False, None)
    assert database.delete_user_group(helpdesk["id"])
    assert database.user_group(helpdesk["id"]) is None


def test_builtin_groups_cannot_be_deleted(tmp_path):
    database = Database(tmp_path / "groups.db")
    database.initialize()
    admins = database.user_group_by_name("Administrators")
    assert admins["builtin"] and "full_access" in admins["permissions"]
    assert not database.delete_user_group(admins["id"])


def test_permission_keys_in_catalog_have_scope_mappings():
    from app.security import PERMISSION_CATALOG
    for key in PERMISSION_CATALOG:
        assert key == "full_access" or key in PERMISSION_SCOPES, f"{key} has no scopes"
