from datetime import UTC, datetime, timedelta

from app.database import Database


def test_security_events_and_retention(tmp_path):
    database = Database(tmp_path / "events.db"); database.initialize()
    event = database.create_security_event({"event_type": "dns", "action": "blocked", "client_ip": "192.168.10.5", "hostname": "laptop", "destination": "facebook.com", "category": "social-media", "policy": "Social Media", "details": {"source": "dns"}})
    assert event["details"]["source"] == "dns"
    assert database.security_events()[0]["destination"] == "facebook.com"
    future = (datetime.now(UTC) + timedelta(days=1)).isoformat()
    result = database.purge_operational_data(future, "1970-01-01T00:00:00+00:00", "1970-01-01T00:00:00+00:00")
    assert result["security_events"] == 1


def test_access_request_review_is_one_way(tmp_path):
    database = Database(tmp_path / "requests.db"); database.initialize()
    request = database.create_access_request({"requested_host": "example.com", "client_ip": "192.168.10.8", "device_name": "laptop", "reason": "Required for work"})
    reviewed = database.review_access_request(request["id"], "approved", "admin", "Approved")
    assert reviewed["status"] == "approved"
    database.review_access_request(request["id"], "denied", "other", "Too late")
    assert database.access_request(request["id"])["status"] == "approved"


def test_last_known_good_blocklist_status_is_preserved(tmp_path):
    database = Database(tmp_path / "lists.db"); database.initialize()
    source = database.create_blocklist("Example", "https://example.com/list", "domains", True, 24)
    database.update_blocklist_status(source["id"], status="healthy", domain_count=100, digest="abc")
    database.update_blocklist_status(source["id"], status="failed", domain_count=100, digest="abc", error="network failure")
    failed = database.blocklist(source["id"])
    assert failed["domain_count"] == 100
    assert failed["content_sha256"] == "abc"
    assert failed["last_error"] == "network failure"
