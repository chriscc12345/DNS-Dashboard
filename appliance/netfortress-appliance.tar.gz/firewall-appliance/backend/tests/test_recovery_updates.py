import base64
import hashlib
import json
from datetime import UTC, datetime

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from app.services.appliance_ops import backup_archive
from app.services.policies import compile_block_targets
from app.services.recovery_updates import apply_restore, stage_restore, stage_signed_update


def test_scheduled_policy_is_active_only_inside_window():
    source = {"members": [], "devices": [], "schedules": [{"id": 7, "timezone": "UTC", "days": [0], "start_time": "08:00", "end_time": "10:00", "enabled": True}], "policies": [{"target_type": "ip", "target_value": "10.0.0.8", "schedule_id": 7}]}
    active = compile_block_targets(source, datetime(2026, 9, 21, 9, 0, tzinfo=UTC))
    inactive = compile_block_targets(source, datetime(2026, 9, 21, 12, 0, tzinfo=UTC))
    assert active["ipv4"] == ["10.0.0.8"]
    assert inactive["ipv4"] == []


def test_backup_can_be_staged_and_atomically_applied(tmp_path):
    original = tmp_path / "original.db"
    original.write_bytes(b"restored database")
    archive = backup_archive(str(original), str(tmp_path / "state-source"))
    staged = stage_restore(archive, tmp_path / "state")
    destination = tmp_path / "live.db"
    destination.write_bytes(b"old database")
    result = apply_restore(staged["candidate_id"], destination, tmp_path / "state")
    assert destination.read_bytes() == b"restored database"
    assert result["status"] == "applied"
    assert (tmp_path / "state" / "restores" / staged["candidate_id"] / "pre-restore-appliance.db").read_bytes() == b"old database"


def test_signed_update_manifest_and_package_are_verified(tmp_path, monkeypatch):
    private = Ed25519PrivateKey.generate()
    public_path = tmp_path / "update-public.pem"
    public_path.write_bytes(private.public_key().public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo))
    monkeypatch.setenv("FIREWALL_UPDATE_PUBLIC_KEY", str(public_path))
    package = b"signed update payload"
    manifest = {"version": "1.3.0", "minimum_version": "1.2.0", "size": len(package), "sha256": hashlib.sha256(package).hexdigest()}
    canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
    result = stage_signed_update(manifest, base64.b64encode(private.sign(canonical)).decode(), base64.b64encode(package).decode(), tmp_path / "state")
    assert result["status"] == "staged"
    assert result["manifest"]["version"] == "1.3.0"
