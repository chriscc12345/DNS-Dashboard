import json

import pytest

from app.models import DhcpSettings, ScheduleCreate
from app.services.appliance_ops import backup_archive, render_kea_config, validate_backup


def test_kea_configuration_contains_valid_pool():
    rendered = json.loads(render_kea_config(DhcpSettings(interface="eth1")))
    dhcp = rendered["Dhcp4"]
    assert dhcp["interfaces-config"]["interfaces"] == ["eth1"]
    assert dhcp["subnet4"][0]["pools"][0]["pool"] == "192.168.10.100 - 192.168.10.220"


def test_kea_pools_each_get_a_vlan_subnet_and_interface():
    pools = [{"vlan_id": 20, "subnet": "192.168.20.0/24", "pool_start": "192.168.20.100", "pool_end": "192.168.20.200", "router": "192.168.20.1", "enabled": 1}, {"vlan_id": 30, "subnet": "192.168.30.0/24", "pool_start": "192.168.30.50", "pool_end": "192.168.30.60", "router": "192.168.30.1", "enabled": 0}]
    rendered = json.loads(render_kea_config(DhcpSettings(interface="eth1"), [], pools))
    dhcp = rendered["Dhcp4"]
    assert dhcp["interfaces-config"]["interfaces"] == ["eth1", "eth1.20"]  # disabled pools are skipped
    assert [subnet["subnet"] for subnet in dhcp["subnet4"]] == ["192.168.10.0/24", "192.168.20.0/24"]
    assert dhcp["subnet4"][1]["pools"][0]["pool"] == "192.168.20.100 - 192.168.20.200"
    assert dhcp["subnet4"][1]["option-data"][0] == {"name": "routers", "data": "192.168.20.1"}


def test_kea_configuration_contains_reservations():
    rendered = json.loads(render_kea_config(DhcpSettings(), [{"mac_address": "aa:bb:cc:dd:ee:ff", "ip_address": "192.168.10.25", "hostname": "printer"}]))
    assert rendered["Dhcp4"]["subnet4"][0]["reservations"][0]["hostname"] == "printer"


def test_dhcp_rejects_addresses_outside_subnet():
    with pytest.raises(ValueError):
        DhcpSettings(pool_end="10.0.0.10")


def test_schedule_validation_and_deduplication():
    schedule = ScheduleCreate(name="Work hours", days=[4, 1, 1, 0], start_time="08:00", end_time="17:00")
    assert schedule.days == [0, 1, 4]


def test_backup_round_trip_validation(tmp_path):
    database = tmp_path / "appliance.db"
    database.write_bytes(b"sqlite fixture")
    lists = tmp_path / "state" / "blocklists"
    lists.mkdir(parents=True)
    (lists / "source-1.domains").write_text("example.com\n")
    data = backup_archive(str(database), str(tmp_path / "state"))
    result = validate_backup(data)
    assert result["valid"] is True
    assert result["file_count"] == 2
    assert result["secrets_included"] is False


def test_corrupt_backup_is_rejected():
    with pytest.raises((ValueError, OSError)):
        validate_backup(b"not a backup")
