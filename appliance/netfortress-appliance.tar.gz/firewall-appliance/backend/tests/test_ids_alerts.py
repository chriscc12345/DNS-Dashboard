"""IDS alert ingestion: eve.json lines become dashboard security events."""
import json

from app.database import Database
from app.services.ids_alerts import ingest_ids_alerts, parse_eve_line

ALERT = json.dumps({
    "event_type": "alert",
    "action": "blocked",
    "src_ip": "192.168.100.50",
    "src_port": 44444,
    "dest_ip": "203.0.113.7",
    "dest_port": 80,
    "proto": "TCP",
    "alert": {"signature": "ET EXPLOIT Something Malicious", "signature_id": 2011001, "severity": 1, "category": ["Attempted Administrator Privilege Gain"]},
})


def test_only_alert_lines_are_ingested():
    assert parse_eve_line(ALERT)["policy"] == "ET EXPLOIT Something Malicious"
    assert parse_eve_line(ALERT)["action"] == "blocked"
    assert parse_eve_line(ALERT)["destination"] == "203.0.113.7:80"
    assert parse_eve_line(json.dumps({"event_type": "stats"})) is None
    assert parse_eve_line("not json at all") is None


def test_ingest_is_offset_aware_and_idempotent(tmp_path):
    database = Database(tmp_path / "ids.db")
    database.initialize()
    eve = tmp_path / "eve.json"
    state = tmp_path / "ids-state.json"
    eve.write_text(ALERT + "\n" + json.dumps({"event_type": "flow"}) + "\n", encoding="utf-8")

    first = ingest_ids_alerts(database, eve, state)
    assert first == 1
    assert database.security_events(10)[0]["event_type"] == "ids"

    # nothing new -> nothing inserted, offset preserved
    assert ingest_ids_alerts(database, eve, state) == 0

    with eve.open("a", encoding="utf-8") as handle:  # logs grow by append
        handle.write(ALERT + "\n")
    assert ingest_ids_alerts(database, eve, state) == 1  # only the new line
    assert len(database.security_events(10)) == 2


def test_truncated_log_resets_and_old_offset_is_kept_by_helper_keys(tmp_path):
    database = Database(tmp_path / "ids.db")
    database.initialize()
    eve = tmp_path / "eve.json"
    state = tmp_path / "ids-state.json"
    state.write_text(json.dumps({"ruleset": "ET Open", "rules_count": 40000}), encoding="utf-8")
    eve.write_text(ALERT + "\n", encoding="utf-8")

    assert ingest_ids_alerts(database, eve, state) == 1
    saved = json.loads(state.read_text(encoding="utf-8"))
    assert saved["ruleset"] == "ET Open"      # helper-written keys survive
    assert saved["eve_offset"] > 0

    # the log shrank behind our back (rotation) — start over, do not re-ingest forever
    eve.write_text("", encoding="utf-8")
    assert ingest_ids_alerts(database, eve, state) == 0


def test_large_fully_ingested_log_is_compacted(tmp_path, monkeypatch):
    database = Database(tmp_path / "ids.db")
    database.initialize()
    eve = tmp_path / "eve.json"
    state = tmp_path / "ids-state.json"
    import app.services.ids_alerts as module
    monkeypatch.setattr(module, "COMPACT_AFTER_BYTES", 10)
    eve.write_text(ALERT + "\n", encoding="utf-8")

    assert ingest_ids_alerts(database, eve, state) == 1
    assert eve.read_text(encoding="utf-8") == ""            # compacted
    assert json.loads(state.read_text(encoding="utf-8"))["eve_offset"] == 0
