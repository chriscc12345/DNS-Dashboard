import base64
import tempfile
import unittest
from datetime import UTC, datetime, timedelta
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.license_models import (BASIC_FEATURES, EDITIONS, ESSENTIAL_FEATURES, FULL_FEATURES, HOME_FEATURES,
                                 PROFESSIONAL_FEATURES, LicenseState, SignedLicenseEnvelope, SignedLicensePayload)
from app.services.licensing import (canonical_payload, clamped_with_features, controls_with_features,
                                 evaluate, modules_with_features, verify_envelope)


class LicenceClampTests(unittest.TestCase):
    """Trial expiring to free Home Lite must disable corporate enforcement
    completely - not just lock the configuration UI."""

    def test_home_lite_disables_ids_geoip_portal_and_tls_block(self):
        resolved = {"stateful": True, "nat": True, "dns_enforcement": True, "web_filter": True,
                    "ids_ips": True, "geoip": True, "logging": True}
        controls = {"force_local_dns": True, "tls_block": True, "portal_enabled": True, "block_quic": True}
        modules = modules_with_features(set(HOME_FEATURES), resolved)
        controls2 = controls_with_features(set(HOME_FEATURES), controls)
        self.assertFalse(modules["ids_ips"])
        self.assertFalse(modules["geoip"])
        self.assertFalse(controls2["tls_block"])
        self.assertFalse(controls2["portal_enabled"])
        # Core protection is untouched on every edition.
        self.assertTrue(modules["stateful"])
        self.assertTrue(modules["nat"])
        self.assertTrue(modules["dns_enforcement"])
        self.assertTrue(modules["web_filter"])
        self.assertTrue(controls2["force_local_dns"])
        self.assertTrue(controls2["block_quic"])

    def test_professional_keeps_everything_running(self):
        resolved = {"stateful": True, "ids_ips": True, "geoip": True}
        controls = {"tls_block": True, "portal_enabled": True}
        modules = modules_with_features(set(PROFESSIONAL_FEATURES), resolved)
        controls2 = controls_with_features(set(PROFESSIONAL_FEATURES), controls)
        self.assertTrue(all(modules.values()))
        self.assertTrue(controls2["tls_block"] and controls2["portal_enabled"])

    def test_trial_expiry_state_clamps_licence_features(self):
        # TRIAL_EXPIRED carries BASIC_FEATURES only - even stricter than Home
        # Lite - but core protection modules are never licence-clamped, so
        # filtering keeps protecting while Home Lite is being claimed.
        resolved = {"ids_ips": True, "web_filter": True, "stateful": True}
        controls = {"tls_block": True, "portal_enabled": True, "force_local_dns": True}
        modules = modules_with_features(set(BASIC_FEATURES), resolved)
        controls2 = controls_with_features(set(BASIC_FEATURES), controls)
        self.assertFalse(modules["ids_ips"])
        self.assertFalse(controls2["tls_block"])
        self.assertFalse(controls2["portal_enabled"])
        self.assertTrue(modules["stateful"])
        self.assertTrue(modules["web_filter"])
        self.assertTrue(controls2["force_local_dns"])

    def test_clamped_list_names_what_was_forced_off(self):
        resolved = {"ids_ips": True, "geoip": True, "stateful": True}
        controls = {"portal_enabled": True, "tls_block": True}
        clamped = clamped_with_features(set(HOME_FEATURES), resolved, controls)
        self.assertIn("ids_ips", clamped)
        self.assertIn("geoip", clamped)
        self.assertIn("portal_enabled (control)", clamped)
        self.assertIn("tls_block (control)", clamped)
        self.assertNotIn("stateful", clamped)


class LicensingTests(unittest.TestCase):
    def payload(self, kind="trial", expires=None, grace=None, updates=None):
        now = datetime.now(UTC)
        return SignedLicensePayload(license_id="lic_test", installation_id="install_test", license_type=kind, edition="full", features=sorted(FULL_FEATURES), device_limit=100, issued_at=now, expires_at=expires, grace_until=grace, updates_until=updates)

    def test_unlicensed_is_basic_and_trial_available(self):
        status = evaluate(None, install_id="install_test")
        self.assertEqual(status.state, LicenseState.UNLICENSED)
        self.assertTrue(status.trial_available)
        self.assertNotIn("web_filtering", status.features)

    def test_trial_active_then_expires_without_grace(self):
        now = datetime.now(UTC)
        active = evaluate(self.payload(expires=now + timedelta(days=60)), install_id="install_test", now=now)
        expired = evaluate(self.payload(expires=now - timedelta(seconds=1)), install_id="install_test", now=now)
        self.assertEqual(active.state, LicenseState.TRIAL_ACTIVE)
        self.assertIn("web_filtering", active.features)
        self.assertEqual(expired.state, LicenseState.TRIAL_EXPIRED)
        self.assertNotIn("web_filtering", expired.features)

    def test_subscription_has_30_day_grace(self):
        now = datetime.now(UTC)
        payload = self.payload("subscription", expires=now - timedelta(days=1), grace=now + timedelta(days=29))
        self.assertEqual(evaluate(payload, install_id="install_test", now=now).state, LicenseState.SUBSCRIPTION_GRACE)

    def test_perpetual_keeps_features_when_updates_expire(self):
        now = datetime.now(UTC)
        status = evaluate(self.payload("perpetual", updates=now - timedelta(days=1)), install_id="install_test", now=now)
        self.assertEqual(status.state, LicenseState.PERPETUAL_UPDATES_EXPIRED)
        self.assertIn("firewall", status.features)
        self.assertNotIn("updates", status.features)

    def test_home_lite_is_a_free_10_device_home_edition(self):
        self.assertEqual(EDITIONS["home_lite"]["device_limit"], 10)
        self.assertEqual(EDITIONS["home_lite"]["account_limit"], 1)
        self.assertEqual(EDITIONS["home_lite"]["features"], EDITIONS["home"]["features"])
        self.assertNotIn("reporting", EDITIONS["home_lite"]["features"])

    def test_home_lite_payload_caps_features_and_is_perpetual(self):
        now = datetime.now(UTC)
        payload = SignedLicensePayload(license_id="lic_lite", installation_id="install_test", license_type="perpetual",
                                       edition="home_lite", features=sorted(HOME_FEATURES) + ["ids_ips", "reporting", "portal"],
                                       device_limit=10, account_limit=1, issued_at=now)
        status = evaluate(payload, install_id="install_test", now=now)
        self.assertEqual(status.state, LicenseState.PERPETUAL_ACTIVE)
        self.assertNotIn("ids_ips", status.features)
        self.assertNotIn("reporting", status.features)
        self.assertIn("web_filtering", status.features)
        self.assertEqual(status.device_limit, 10)
        self.assertFalse(status.free_tier_available)  # already on the free tier

    def test_free_tier_offered_only_when_nothing_is_licensed(self):
        now = datetime.now(UTC)
        unlicensed = evaluate(None, install_id="install_test", now=now)
        self.assertTrue(unlicensed.free_tier_available)
        trial_active = evaluate(self.payload(expires=now + timedelta(days=60)), install_id="install_test", now=now)
        self.assertFalse(trial_active.free_tier_available)
        trial_expired = evaluate(self.payload(expires=now - timedelta(seconds=1)), install_id="install_test", now=now)
        self.assertTrue(trial_expired.free_tier_available)
        self.assertIn("Home Lite", trial_expired.message)

    def test_edition_catalog_matches_the_commercial_design(self):
        self.assertEqual(EDITIONS["home"]["device_limit"], 25)
        self.assertEqual(EDITIONS["home"]["account_limit"], 1)
        self.assertNotIn("reporting", EDITIONS["home"]["features"])
        self.assertEqual(EDITIONS["essential"]["device_limit"], 50)
        self.assertIn("reporting", EDITIONS["essential"]["features"])
        self.assertNotIn("ids_ips", EDITIONS["essential"]["features"])
        for feature in ("ids_ips", "https_block_page", "portal", "ip_pools", "api_automation", "public_tls"):
            self.assertIn(feature, EDITIONS["professional"]["features"])
        for name in ("home", "essential"):
            self.assertLess(set(EDITIONS[name]["features"]), set(PROFESSIONAL_FEATURES))

    def test_home_edition_excludes_reports_and_caps_features(self):
        now = datetime.now(UTC)
        payload = SignedLicensePayload(license_id="lic_home", installation_id="install_test", license_type="subscription",
                                       edition="home", features=sorted(HOME_FEATURES) + ["ids_ips", "reporting"],
                                       device_limit=25, account_limit=1, issued_at=now, expires_at=now + timedelta(days=365))
        status = evaluate(payload, install_id="install_test", now=now)
        self.assertEqual(status.state, LicenseState.SUBSCRIPTION_ACTIVE)
        self.assertNotIn("reporting", status.features)
        self.assertNotIn("ids_ips", status.features)
        self.assertIn("web_filtering", status.features)
        self.assertEqual(status.device_limit, 25)
        self.assertEqual(status.account_limit, 1)

    def test_device_and_account_counts_surface_with_over_limit_warning(self):
        now = datetime.now(UTC)
        payload = SignedLicensePayload(license_id="lic_home", installation_id="install_test", license_type="subscription",
                                       edition="essential", features=sorted(ESSENTIAL_FEATURES), device_limit=50, account_limit=2,
                                       issued_at=now, expires_at=now + timedelta(days=365))
        status = evaluate(payload, install_id="install_test", now=now, device_count=63, account_count=2)
        self.assertEqual(status.device_count, 63)
        self.assertEqual(status.account_count, 2)
        self.assertIn("Device limit reached", status.message)

    def test_lapsed_states_keep_basic_and_announce_home_lite(self):
        now = datetime.now(UTC)
        expired = evaluate(self.payload(expires=now - timedelta(days=1)), install_id="install_test", now=now)
        self.assertFalse(expired.licensed)
        self.assertEqual(expired.state, LicenseState.TRIAL_EXPIRED)
        # Expired trials announce the automatic free Home Lite continuation
        # (claimed on the next refresh cycle) and stay configuration-frozen.
        self.assertIn("Home Lite", expired.message)
        # Lapsed subscriptions still announce the configuration freeze.
        lapsed = evaluate(self.payload(kind="subscription", expires=now - timedelta(days=40), grace=now - timedelta(days=10)),
                          install_id="install_test", now=now)
        self.assertEqual(lapsed.state, LicenseState.SUBSCRIPTION_EXPIRED)
        self.assertIn("locked", lapsed.message)

    def test_deleted_licence_revocation_is_unlicensed(self):
        now = datetime.now(UTC)
        payload = SignedLicensePayload(license_id="revoked-deadbeefdeadbeef", installation_id="install_test", license_type="perpetual", edition="corporate", features=sorted(PROFESSIONAL_FEATURES), device_limit=100, issued_at=now)
        status = evaluate(payload, install_id="install_test", now=now, trial_consumed=True)
        self.assertEqual(status.state, LicenseState.UNLICENSED)
        self.assertFalse(status.licensed)
        self.assertEqual(status.features, sorted(BASIC_FEATURES))
        self.assertTrue(status.free_tier_available)
        self.assertFalse(status.trial_available)  # the trial was consumed before the licence was deleted

    def test_ed25519_signature_verification(self):
        private = Ed25519PrivateKey.generate()
        public_pem = private.public_key().public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo)
        payload = self.payload(expires=datetime.now(UTC) + timedelta(days=60))
        signature = base64.b64encode(private.sign(canonical_payload(payload))).decode()
        verify_envelope(SignedLicenseEnvelope(payload=payload, signature=signature), public_pem)


if __name__ == "__main__":
    unittest.main()
