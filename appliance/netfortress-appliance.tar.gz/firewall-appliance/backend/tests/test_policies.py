import tempfile
import unittest
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.database import Database
from app.services.policies import compile_block_targets


class PolicyTests(unittest.TestCase):
    def test_compiles_ip_mac_hostname_and_group(self):
        source = {
            "policies": [
                {"target_type": "ip", "target_value": "10.0.0.8"},
                {"target_type": "mac", "target_value": "AA:BB:CC:DD:EE:FF"},
                {"target_type": "hostname", "target_value": "tablet"},
                {"target_type": "group", "target_value": "4"},
            ],
            "members": [{"group_id": 4, "target_type": "ip", "target_value": "10.0.0.9"}],
            "devices": [{"hostname": "tablet", "ip_address": "10.0.0.10"}],
        }
        result = compile_block_targets(source)
        self.assertEqual(result["ipv4"], ["10.0.0.10", "10.0.0.8", "10.0.0.9"])
        self.assertEqual(result["mac"], ["aa:bb:cc:dd:ee:ff"])

    def test_unresolved_hostname_is_reported(self):
        result = compile_block_targets({"policies": [{"target_type": "hostname", "target_value": "missing"}], "members": [], "devices": []})
        self.assertEqual(result["unresolved_hostnames"], ["missing"])

    def test_group_and_policy_persistence(self):
        with tempfile.TemporaryDirectory() as directory:
            database = Database(Path(directory) / "test.db")
            database.initialize()
            group = database.create_group("Children", "Restricted devices")
            database.add_group_member(group["id"], "mac", "00:11:22:33:44:55")
            database.create_policy("Block children", "group", str(group["id"]), True, "Scheduled restriction")
            self.assertEqual(database.groups()[0]["member_count"], 1)
            compiled = compile_block_targets(database.policy_sources())
            self.assertEqual(compiled["mac"], ["00:11:22:33:44:55"])


if __name__ == "__main__":
    unittest.main()
