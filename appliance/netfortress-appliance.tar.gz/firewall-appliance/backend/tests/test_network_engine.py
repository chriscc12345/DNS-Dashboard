import tempfile
import unittest
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.models import DeploymentMode, DeploymentRequest, VlanAssignment
from app.services.network_engine import NetworkTransactionManager, render_nftables
from app.services.network_plan import render_network_plan


def routed():
    return DeploymentRequest(mode=DeploymentMode.ROUTED_GATEWAY, wan_interface="wan0", lan_interface="lan0", management_interface="lan0", management_address="192.168.10.1/24", architecture_acknowledged=True, cabling_acknowledged=True, recovery_acknowledged=True)


class NetworkEngineTests(unittest.TestCase):
    def test_routed_rules_have_forwarding_and_nat(self):
        rules = render_nftables(routed())
        self.assertIn('iifname "lan0" oifname "wan0" accept', rules)
        self.assertIn('oifname "wan0" masquerade', rules)

    def test_block_targets_compile_into_native_sets(self):
        rules = render_nftables(routed(), {"ipv4": ["10.0.0.8"], "ipv6": [], "mac": ["aa:bb:cc:dd:ee:ff"]})
        self.assertIn("set blocked_ipv4", rules)
        self.assertIn("ip saddr @blocked_ipv4 drop", rules)
        self.assertIn("ether saddr @blocked_macs drop", rules)

    def test_bypass_controls_compile_into_forward_chain(self):
        rules = render_nftables(routed(), security_controls={"block_quic": True, "block_dot": True, "block_doh": True, "force_local_dns": True})
        self.assertIn("udp dport 443 drop", rules)
        self.assertIn("tcp dport 853 drop", rules)
        self.assertIn("udp dport 53 drop", rules)
        self.assertIn("known_doh_ipv4", rules)

    def test_port_forward_compiles_into_dnat(self):
        network_rules = {"port_forwards": [{"name": "Web", "protocol": "tcp", "external_port": 8443, "internal_ip": "192.168.10.20", "internal_port": 443, "source_network": "203.0.113.0/24", "enabled": True}]}
        rules = render_nftables(routed(), network_rules=network_rules)
        self.assertIn("chain prerouting", rules)
        self.assertIn("ip saddr 203.0.113.0/24 tcp dport 8443 dnat to 192.168.10.20:443", rules)

    def test_vlan_rules_use_subinterfaces(self):
        request = DeploymentRequest(mode=DeploymentMode.VLAN_TRUNK, trunk_interface="eth0", management_interface="eth0", management_address="192.168.20.1/24", vlans=[VlanAssignment(role="wan", vlan_id=10), VlanAssignment(role="lan", vlan_id=20)], architecture_acknowledged=True, cabling_acknowledged=True, recovery_acknowledged=True)
        rules = render_nftables(request)
        self.assertIn('iifname "eth0.20" oifname "eth0.10" accept', rules)

    def test_candidate_is_written_with_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = NetworkTransactionManager(directory)
            candidate = manager.prepare(routed())
            self.assertTrue(Path(candidate.path).exists())
            self.assertEqual(len(candidate.sha256), 64)
            self.assertTrue((Path(candidate.path).parent / "network-plan.json").exists())
            metadata = manager.transaction(candidate.transaction_id)
            self.assertEqual(len(metadata["network_plan_sha256"]), 64)

    def test_service_configs_are_hash_bound_to_transaction(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = NetworkTransactionManager(directory)
            configs = {"dns.json": '{"version":1}\n', "squid.conf": "http_port 3128\n", "kea-dhcp4.conf": '{"Dhcp4":{}}\n', "block-page.html": "<h1>Blocked</h1>"}
            candidate = manager.prepare(routed(), service_configs=configs)
            self.assertEqual(candidate.service_configurations, sorted(configs))
            metadata = manager.transaction(candidate.transaction_id)
            self.assertEqual(set(metadata["service_config_sha256"]), set(configs))
            for name in configs:
                self.assertTrue((Path(candidate.path).parent / "services" / name).is_file())

    def test_routed_network_plan_enables_forwarding_and_management(self):
        plan = render_network_plan(routed())
        self.assertIn({"action": "sysctl", "interface": None, "value": "net.ipv4.ip_forward=1", "parent": None}, plan)
        self.assertIn({"action": "replace_address", "interface": "lan0", "value": "192.168.10.1/24", "parent": None}, plan)

    def test_bridge_plan_moves_management_to_bridge(self):
        request = DeploymentRequest(mode=DeploymentMode.TRANSPARENT_BRIDGE, wan_interface="wan0", lan_interface="lan0", management_interface="lan0", management_address="192.168.10.2/24")
        plan = render_network_plan(request)
        self.assertIn({"action": "create_bridge", "interface": "br-firewall", "value": None, "parent": None}, plan)
        self.assertIn({"action": "replace_address", "interface": "br-firewall", "value": "192.168.10.2/24", "parent": None}, plan)

    def test_unsafe_interface_is_rejected(self):
        request = routed().model_copy(update={"wan_interface": "wan0;bad"})
        with self.assertRaises(ValueError):
            render_nftables(request)

    def test_live_activation_is_disabled_by_default(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = NetworkTransactionManager(directory)
            candidate = manager.prepare(routed())
            with self.assertRaises(PermissionError):
                manager.privileged_action("activate", candidate.transaction_id)


if __name__ == "__main__":
    unittest.main()
