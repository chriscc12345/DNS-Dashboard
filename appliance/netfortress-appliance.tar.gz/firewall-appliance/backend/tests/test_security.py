import os
import tempfile
import unittest
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.database import Database
from app.security import Principal, create_session_token, decode_session_token, generate_api_token, hash_password, session_scopes, token_digest, token_scopes_allowed, verify_password


class SecurityTests(unittest.TestCase):
    def test_session_scopes_follow_roles(self):
        self.assertIn("*", session_scopes("admin"))
        self.assertIn("policies:write", session_scopes("operator"))
        self.assertNotIn("policies:write", session_scopes("viewer"))
        self.assertNotIn("users:write", session_scopes("operator"))
        self.assertNotIn("tokens:write", session_scopes("operator"))

    def test_token_scope_grants_cannot_escalate(self):
        self.assertTrue(token_scopes_allowed(["policies:read"], "viewer", session_scopes("viewer")))
        self.assertFalse(token_scopes_allowed(["*"], "viewer", session_scopes("viewer")))
        self.assertFalse(token_scopes_allowed(["users:write"], "viewer", session_scopes("viewer")))
        self.assertFalse(token_scopes_allowed(["made:up:scope"], "admin", session_scopes("admin")))
        self.assertTrue(token_scopes_allowed(["*"], "admin", session_scopes("admin")))
        self.assertTrue(token_scopes_allowed(["dns:read", "dns:write"], "operator", session_scopes("operator")))
        self.assertFalse(token_scopes_allowed(["audit:write"], "operator", session_scopes("operator")))

    def test_api_token_principals_are_scope_bound(self):
        token_principal = Principal(1, "admin", "admin", "api_token", frozenset({"audit:read"}), "1")
        self.assertTrue(token_principal.allows("audit:read"))
        self.assertFalse(token_principal.allows("dns:write"))  # role shortcut must not widen tokens
        session_principal = Principal(1, "admin", "admin", "user", frozenset({"*"}), "1")
        self.assertTrue(session_principal.allows("anything"))

    def test_password_round_trip(self):
        encoded = hash_password("Correct-Horse-42")
        self.assertTrue(verify_password("Correct-Horse-42", encoded))
        self.assertFalse(verify_password("wrong", encoded))

    def test_session_round_trip(self):
        os.environ["FIREWALL_SIGNING_KEY"] = "test-key-only"
        token = create_session_token(7, "admin")
        payload = decode_session_token(token)
        self.assertEqual(payload["sub"], 7)
        self.assertEqual(payload["role"], "admin")

    def test_api_token_is_only_stored_as_digest(self):
        raw, prefix = generate_api_token()
        self.assertTrue(raw.startswith(f"fw_{prefix}_"))
        self.assertNotIn(raw, token_digest(raw))


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        handle = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        handle.close()
        self.path = handle.name
        self.db = Database(self.path)
        self.db.initialize()

    def tearDown(self):
        Path(self.path).unlink(missing_ok=True)

    def test_bootstrap_user_and_audit(self):
        self.assertFalse(self.db.has_users())
        user = self.db.create_user("admin", hash_password("Correct-Horse-42"))
        self.assertTrue(self.db.has_users())
        self.db.audit(actor_type="user", actor_id=str(user["id"]), action="test", resource_type="unit")
        self.assertEqual(self.db.audit_events(1)[0]["action"], "test")

    def test_api_token_lifecycle(self):
        user = self.db.create_user("admin", hash_password("Correct-Horse-42"))
        raw, prefix = generate_api_token()
        record = self.db.store_api_token(user["id"], "automation", prefix, token_digest(raw), ["audit:read"], None)
        self.assertIsNotNone(self.db.api_token_by_hash(token_digest(raw)))
        self.assertTrue(self.db.revoke_api_token(record["id"], user["id"]))
        self.assertIsNotNone(self.db.api_token_by_hash(token_digest(raw))["revoked_at"])


if __name__ == "__main__":
    unittest.main()
