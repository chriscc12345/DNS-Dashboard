from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field

class FeatureDefinition(BaseModel):
    code: str
    name: str
    description: str | None = None


class EditionDefinition(BaseModel):
    code: str
    name: str
    features: list[str]


class FeatureCatalog(BaseModel):
    features: list[FeatureDefinition]
    editions: list[EditionDefinition]


class LicenseState(StrEnum):
    UNLICENSED = "UNLICENSED"
    TRIAL_ACTIVE = "TRIAL_ACTIVE"
    TRIAL_EXPIRED = "TRIAL_EXPIRED"
    SUBSCRIPTION_ACTIVE = "SUBSCRIPTION_ACTIVE"
    SUBSCRIPTION_GRACE = "SUBSCRIPTION_GRACE"
    SUBSCRIPTION_EXPIRED = "SUBSCRIPTION_EXPIRED"
    PERPETUAL_ACTIVE = "PERPETUAL_ACTIVE"
    PERPETUAL_UPDATES_EXPIRED = "PERPETUAL_UPDATES_EXPIRED"
    SUSPENDED = "SUSPENDED"


# Always available, in every state, on every edition. These are the floor:
# authentication itself, health, and the recovery paths.
BASIC_FEATURES = frozenset({
    "authentication", "licensing", "health", "monitoring", "diagnostics",
    "logs", "backup_export", "network_recovery", "shutdown_restart",
})

# The core protection stack — included from Home upward.
CORE_FEATURES = frozenset({
    "routing", "nat", "firewall", "dns", "dns_filtering", "web_filtering",
    "block_page", "device_policy", "schedules", "updates",
})

HOME_FEATURES = CORE_FEATURES
ESSENTIAL_FEATURES = CORE_FEATURES | frozenset({"reporting", "backup_restore"})
PROFESSIONAL_FEATURES = ESSENTIAL_FEATURES | frozenset({
    "web_cache", "ids_ips", "https_block_page", "portal", "ip_pools",
    "api_automation", "public_tls", "users", "geoip",
})
CORPORATE_FEATURES = PROFESSIONAL_FEATURES

# The edition catalogue: what is included in what. The licensing server
# issues keys against these definitions; the appliance also caps any signed
# payload at its edition's feature set, so a malformed license can never
# grant more than the edition allows.
EDITIONS: dict[str, dict] = {
    "home_lite": {
        "label": "Home Lite", "features": sorted(HOME_FEATURES),
        "device_limit": 10, "account_limit": 1,
        "description": "Free home use — full protection, no reports, one dashboard account, 10 devices.",
    },
    "home": {
        "label": "Home", "features": sorted(HOME_FEATURES),
        "device_limit": 25, "account_limit": 1,
        "description": "Home use — full protection, no reports, one dashboard account, 25 devices.",
    },
    "essential": {
        "label": "Essential", "features": sorted(ESSENTIAL_FEATURES),
        "device_limit": 50, "account_limit": 2,
        "description": "Small office — protection plus reports and audit, two accounts, 50 devices.",
    },
    "professional": {
        "label": "Professional", "features": sorted(PROFESSIONAL_FEATURES),
        "device_limit": 250, "account_limit": 0,
        "description": "Company use — everything: IDS/IPS, HTTPS block page, portal, IP pools, API automation, 250 devices.",
    },
    "corporate": {
        "label": "Corporate", "features": sorted(CORPORATE_FEATURES),
        "device_limit": 1000, "account_limit": 0,
        "description": "Corporate sites — the full feature set with larger device counts set per license.",
    },
    "full-trial": {
        "label": "Full trial", "features": sorted(PROFESSIONAL_FEATURES),
        "device_limit": 10000, "account_limit": 0,
        "description": "60-day evaluation with every Professional feature unlocked.",
    },
}

# Full set the trial evaluates against (kept for compatibility with the
# previous all-or-nothing model).
FULL_FEATURES = frozenset(PROFESSIONAL_FEATURES)

# The free tier. After the full trial is used up, an unlicensed appliance may
# request a free Home Lite licence from the licensing server: it activates
# with this reserved key (its own installation id makes it unique) and the
# licensing server auto-issues a perpetual Home Lite licence for that
# installation. Admin-issued keys never collide: their random parts are
# uppercase hex, never "install_...".
FREE_EDITION = "home_lite"
FREE_HOME_LITE_PREFIX = "FA-HOMELITE-"

# A licence deleted on the licence host is announced through a signed
# envelope whose licence id carries this prefix. The appliance drops the
# licence completely and asks for a new one (protection keeps enforcing).
REVOKED_LICENSE_PREFIX = "revoked-"


class SignedLicensePayload(BaseModel):
    license_id: str
    installation_id: str
    license_type: str = Field(pattern=r"^(trial|subscription|perpetual)$")
    edition: str
    features: list[str]
    device_limit: int = Field(ge=1)
    account_limit: int = Field(default=0, ge=0)  # 0 = unlimited
    issued_at: datetime
    expires_at: datetime | None = None
    grace_until: datetime | None = None
    updates_until: datetime | None = None
    suspended: bool = False


class SignedLicenseEnvelope(BaseModel):
    payload: SignedLicensePayload
    signature: str


class ActivateRequest(BaseModel):
    license_key: str = Field(min_length=8, max_length=256)


class OfflineLicenseRequest(BaseModel):
    """Offline activation: the signed license file downloaded from the
    licensing host and uploaded to this appliance."""
    envelope: SignedLicenseEnvelope


class LicenseStatus(BaseModel):
    state: LicenseState
    licensed: bool
    trial_available: bool
    edition: str
    edition_label: str
    license_type: str | None
    features: list[str]
    restricted_features: list[str]
    expires_at: datetime | None
    grace_until: datetime | None
    updates_until: datetime | None
    days_remaining: int | None
    installation_id: str
    last_verified_at: datetime | None
    device_limit: int = Field(default=0, ge=0)      # 0 = unlimited
    device_count: int = Field(default=0, ge=0)
    account_limit: int = Field(default=0, ge=0)     # 0 = unlimited
    account_count: int = Field(default=0, ge=0)
    free_tier_available: bool = False  # a free Home Lite licence may be requested now
    message: str
