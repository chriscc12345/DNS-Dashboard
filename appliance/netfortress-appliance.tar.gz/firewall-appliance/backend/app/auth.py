from __future__ import annotations

import json
from datetime import UTC, datetime

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.database import Database
from app.security import Principal, decode_session_token, group_scopes, session_scopes, token_digest


bearer = HTTPBearer(auto_error=False)


def get_database(request: Request) -> Database:
    return request.app.state.database


def current_principal(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
    database: Database = Depends(get_database),
) -> Principal:
    if not credentials or credentials.scheme.lower() != "bearer":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Bearer token required")
    raw = credentials.credentials
    if raw.startswith("fw_"):
        record = database.api_token_by_hash(token_digest(raw))
        if not record or record["revoked_at"]:
            raise HTTPException(status_code=401, detail="Invalid or revoked API token")
        if record["expires_at"] and datetime.fromisoformat(record["expires_at"]) <= datetime.now(UTC):
            raise HTTPException(status_code=401, detail="API token expired")
        user = database.user_by_id(record["user_id"])
        if not user or not user["enabled"]:
            raise HTTPException(status_code=401, detail="User disabled")
        return Principal(user["id"], user["username"], user["role"], "api_token", frozenset(json.loads(record["scopes_json"])), str(record["id"]))

    payload = decode_session_token(raw)
    user = database.user_by_id(int(payload["sub"])) if payload else None
    if not user or not user["enabled"]:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    # Build 5 — the account's group decides what the session may do; accounts
    # without a group keep their legacy role behaviour.
    role, scopes = user["role"], session_scopes(user["role"])
    if user.get("group_id"):
        group = database.user_group(int(user["group_id"]))
        if group:
            permissions = list(group["permissions"])
            scopes = group_scopes(permissions)
            role = "admin" if "full_access" in permissions else "custom"
    return Principal(user["id"], user["username"], role, "user", scopes, str(user["id"]))


def require_scope(scope: str):
    def dependency(principal: Principal = Depends(current_principal)) -> Principal:
        if not principal.allows(scope):
            raise HTTPException(status_code=403, detail=f"Missing required scope: {scope}")
        return principal
    return dependency
