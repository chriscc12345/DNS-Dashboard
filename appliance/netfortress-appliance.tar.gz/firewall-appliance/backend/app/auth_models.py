from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, field_validator


class BootstrapRequest(BaseModel):
    username: str = Field(min_length=3, max_length=64, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=12, max_length=256)

    @field_validator("password")
    @classmethod
    def password_complexity(cls, value: str) -> str:
        categories = [any(c.islower() for c in value), any(c.isupper() for c in value), any(c.isdigit() for c in value), any(not c.isalnum() for c in value)]
        if sum(categories) < 3:
            raise ValueError("Password must use at least three character categories")
        return value


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenCreateRequest(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    scopes: list[str] = Field(min_length=1)
    expires_at: datetime | None = None

    @field_validator("expires_at")
    @classmethod
    def timezone_required(cls, value: datetime | None) -> datetime | None:
        if value is not None and value.tzinfo is None:
            raise ValueError("Token expiry must include a timezone")
        return value


class AuthResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: dict
