from __future__ import annotations

import re
from enum import StrEnum
from ipaddress import ip_address, ip_interface, ip_network
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class DeploymentMode(StrEnum):
    VLAN_TRUNK = "vlan_trunk"
    DNS_PROXY = "dns_proxy"
    ROUTED_GATEWAY = "routed_gateway"
    TRANSPARENT_BRIDGE = "transparent_bridge"


class AddressMode(StrEnum):
    DHCP = "dhcp"
    STATIC = "static"
    NONE = "none"


class VlanAssignment(BaseModel):
    role: Literal["wan", "lan", "guest", "iot", "servers"]
    vlan_id: int = Field(ge=1, le=4094)
    address_mode: AddressMode = AddressMode.NONE
    address: str | None = None

    @field_validator("address")
    @classmethod
    def valid_address(cls, value: str | None) -> str | None:
        if value:
            ip_interface(value)
        return value


class DeploymentRequest(BaseModel):
    mode: DeploymentMode
    wan_interface: str | None = None
    lan_interface: str | None = None
    trunk_interface: str | None = None
    management_interface: str
    management_address: str
    upstream_gateway: str | None = None
    vlans: list[VlanAssignment] = Field(default_factory=list)
    enable_dhcp: bool = True
    architecture_acknowledged: bool = False
    cabling_acknowledged: bool = False
    recovery_acknowledged: bool = False

    @field_validator("management_address")
    @classmethod
    def valid_management_address(cls, value: str) -> str:
        ip_interface(value)
        return value

    @field_validator("upstream_gateway")
    @classmethod
    def valid_upstream_gateway(cls, value: str | None) -> str | None:
        if value:
            ip_address(value)
        return value

    @model_validator(mode="after")
    def mode_has_required_interfaces(self) -> "DeploymentRequest":
        if self.mode in {DeploymentMode.ROUTED_GATEWAY, DeploymentMode.TRANSPARENT_BRIDGE}:
            if not self.wan_interface or not self.lan_interface:
                raise ValueError("Two-NIC modes require WAN and LAN interfaces")
        if self.mode == DeploymentMode.VLAN_TRUNK and not self.trunk_interface:
            raise ValueError("VLAN trunk mode requires a trunk interface")
        return self


class ValidationMessage(BaseModel):
    level: Literal["error", "warning", "info"]
    code: str
    message: str


class ValidationResult(BaseModel):
    valid: bool
    messages: list[ValidationMessage]


class DeploymentPlan(BaseModel):
    mode: DeploymentMode
    title: str
    full_enforcement: bool
    diagram: list[str]
    interface_assignments: dict[str, str]
    generated_actions: list[str]
    safety_actions: list[str]
    limitations: list[str]
    validation: ValidationResult


class InterfaceInfo(BaseModel):
    name: str
    mac_address: str | None = None
    state: str = "unknown"
    mtu: int | None = None
    speed_mbps: int | None = None
    addresses: list[str] = Field(default_factory=list)
    is_virtual: bool = False
    label: str | None = None


class InterfaceLabels(BaseModel):
    labels: dict[str, str] = Field(default_factory=dict)

    @field_validator("labels")
    @classmethod
    def valid_labels(cls, value: dict[str, str]) -> dict[str, str]:
        cleaned: dict[str, str] = {}
        for name, label in value.items():
            if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,64}", name):
                raise ValueError(f"Invalid interface name: {name}")
            label = label.strip()
            if label:
                if len(label) > 50:
                    raise ValueError("Interface labels are limited to 50 characters")
                cleaned[name] = label
        return cleaned


class InterfaceLabelSet(BaseModel):
    interface: str = Field(pattern=r"^[A-Za-z0-9_.:-]{1,64}$")
    label: str = Field(default="", max_length=50)


class HostnameUpdate(BaseModel):
    hostname: str = Field(min_length=1, max_length=63)

    @field_validator("hostname")
    @classmethod
    def valid_hostname(cls, value: str) -> str:
        hostname = value.strip().lower()
        if not re.fullmatch(r"[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?", hostname):
            raise ValueError("Hostnames may use letters, digits and hyphens, and must start and end with a letter or digit")
        return hostname


class DeviceInfo(BaseModel):
    ip_address: str
    mac_address: str | None = None
    hostname: str | None = None
    interface: str | None = None
    state: str = "unknown"
    source: str = "neighbour"
    first_seen_at: str | None = None
    last_seen_at: str | None = None


class DeviceGroupCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    description: str = Field(default="", max_length=300)


class GroupMemberCreate(BaseModel):
    target_type: Literal["mac", "ip", "hostname"]
    target_value: str = Field(min_length=1, max_length=255)


class BlockingPolicyCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    target_type: Literal["mac", "ip", "hostname", "group"]
    target_value: str = Field(min_length=1, max_length=255)
    enabled: bool = True
    reason: str = Field(default="Blocked by administrator", max_length=300)
    schedule_id: int | None = Field(default=None, ge=1)


class DnsSettings(BaseModel):
    enabled: bool = True
    listen_addresses: list[str] = Field(default_factory=lambda: ["0.0.0.0", "::"])
    upstream_servers: list[str] = Field(default_factory=lambda: ["1.1.1.1", "1.0.0.1"])
    dnssec_validation: bool = True
    block_response: Literal["nxdomain", "refused", "block_page"] = "block_page"
    block_page_ipv4: str = "192.168.10.1"
    block_page_ipv6: str | None = None
    block_hostname: str | None = None
    block_doh: bool = True
    block_dot: bool = True

    @field_validator("block_hostname")
    @classmethod
    def valid_block_hostname(cls, value: str | None) -> str | None:
        hostname = (value or "").strip().lower().rstrip(".")
        if not hostname:
            return None
        if not re.fullmatch(r"[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*", hostname):
            raise ValueError("The block hostname may only use letters, digits, dots and hyphens")
        return hostname


class BlocklistSourceCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    url: str = Field(min_length=8, max_length=1000)
    format: Literal["hosts", "domains"] = "hosts"
    enabled: bool = True
    update_hours: int = Field(default=24, ge=1, le=720)
    category: str = Field(default="", max_length=80)


class DomainDiscoveryRequest(BaseModel):
    domain: str = Field(min_length=3, max_length=253)


class ServiceDomainsAdd(BaseModel):
    domains: list[str] = Field(min_length=1, max_length=50)


class LocalDomainCreate(BaseModel):
    domain: str = Field(min_length=1, max_length=253)
    action: Literal["block", "allow"] = "block"
    category: str = Field(default="custom", min_length=1, max_length=80)
    expires_at: str | None = None  # ISO timestamp; empty means the rule never expires


class ApplicationPolicyCreate(BaseModel):
    application: str = Field(min_length=1, max_length=80)
    enabled: bool = True
    block_quic: bool = True


class CategoryPolicyCreate(BaseModel):
    category: str = Field(min_length=1, max_length=80)
    enabled: bool = True
    block_quic: bool = True


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=80, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=12, max_length=256)
    role: Literal["admin", "operator", "viewer"] = "viewer"
    group_id: int | None = None


class UserUpdate(BaseModel):
    role: Literal["admin", "operator", "viewer"]
    enabled: bool = True
    group_id: int | None = None


class UserGroupCreate(BaseModel):
    name: str = Field(min_length=3, max_length=80)
    description: str = Field(default="", max_length=200)
    permissions: list[str] = Field(min_length=1, max_length=20)


class UserGroupUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=3, max_length=80)
    description: str | None = Field(default=None, max_length=200)
    permissions: list[str] = Field(min_length=1, max_length=20)


class BlockPageSettings(BaseModel):
    title: str = Field(default="Access blocked", max_length=100)
    organization: str = Field(default="NetFortress", max_length=100)
    message: str = Field(default="This website is restricted by your network policy.", max_length=500)
    support_contact: str = Field(default="Contact your network administrator.", max_length=200)
    accent_color: str = Field(default="#a68e17", pattern=r"^#[0-9A-Fa-f]{6}$")
    background_color: str = Field(default="#071019", pattern=r"^#[0-9A-Fa-f]{6}$")
    footer_text: str = Field(default="", max_length=200)
    policy_url: str = Field(default="", max_length=300)
    show_logo: bool = True
    show_client_ip: bool = True
    show_hostname: bool = True
    show_policy: bool = True
    allow_access_requests: bool = False
    https_block: bool = False
    # Custom block page: either an uploaded HTML page served by this appliance,
    # or a redirect to a URL hosted elsewhere (?host=<requested site> is added).
    custom_html: str = Field(default="", max_length=200000)
    custom_html_active: bool = False
    redirect_url: str = Field(default="", max_length=500)

    @field_validator("redirect_url")
    @classmethod
    def valid_redirect_url(cls, value: str) -> str:
        if value and not re.match(r"^https?://[A-Za-z0-9._~:/?#@!$&'()*+,;=%-]+$", value):
            raise ValueError("The redirect URL must start with http:// or https://")
        return value.rstrip("/")


class GeoipSettings(BaseModel):
    """Country policy for inbound (internet → client) connections.
    Allowlist mode: only the listed countries may connect.
    Blocklist mode: the listed countries may not connect."""
    enabled: bool = False
    mode: Literal["allowlist", "blocklist"] = "allowlist"
    countries: list[str] = []

    @field_validator("countries")
    @classmethod
    def valid_countries(cls, value: list[str]) -> list[str]:
        cleaned = sorted({item.strip().upper() for item in value if item.strip()})
        for code in cleaned:
            if not re.fullmatch(r"[A-Z]{2}", code):
                raise ValueError(f"Not an ISO country code: {code}")
        if len(cleaned) > 60:
            raise ValueError("Select at most 60 countries")
        return cleaned


class AcmeSettings(BaseModel):
    """Public TLS certificates via ACME DNS-01 (Cloudflare).

    The appliance lives on a private network, so the challenge is solved purely
    through the DNS provider API — nothing is exposed to the internet. The token
    is stored once and never returned by the API in clear text.
    """
    enabled: bool = False
    email: str = Field(default="", max_length=254)
    zone: str = Field(default="", max_length=253)
    appliance_fqdn: str = Field(default="", max_length=253)
    block_fqdn: str = Field(default="", max_length=253)
    api_token: str = Field(default="", max_length=512)


class ProxySettings(BaseModel):
    enabled: bool = False
    listen_port: int = Field(default=3128, ge=1024, le=65535)
    cache_enabled: bool = True
    cache_size_mb: int = Field(default=4096, ge=128, le=1048576)
    memory_cache_mb: int = Field(default=256, ge=16, le=65536)
    max_object_mb: int = Field(default=512, ge=1, le=10240)
    tls_inspection: bool = False


class CachePurgeRequest(BaseModel):
    url: str = Field(min_length=8, max_length=2000, pattern=r"^https?://")


class DhcpSettings(BaseModel):
    enabled: bool = True
    interface: str = "lan0"
    subnet: str = "192.168.10.0/24"
    pool_start: str = "192.168.10.100"
    pool_end: str = "192.168.10.220"
    router: str = "192.168.10.1"
    dns_servers: list[str] = Field(default_factory=lambda: ["192.168.10.1"])
    lease_seconds: int = Field(default=86400, ge=300, le=2592000)

    @model_validator(mode="after")
    def addresses_belong_to_subnet(self) -> "DhcpSettings":
        network = ip_network(self.subnet, strict=False)
        for value in [self.pool_start, self.pool_end, self.router, *self.dns_servers]:
            if ip_address(value) not in network:
                raise ValueError(f"{value} is outside DHCP subnet {network}")
        if int(ip_address(self.pool_start)) > int(ip_address(self.pool_end)):
            raise ValueError("DHCP pool start must not be greater than pool end")
        return self


class ScheduleCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    timezone: str = Field(default="UTC", min_length=1, max_length=80)
    days: list[int] = Field(default_factory=lambda: [0, 1, 2, 3, 4, 5, 6])
    start_time: str = Field(default="00:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    end_time: str = Field(default="23:59", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    enabled: bool = True

    @field_validator("days")
    @classmethod
    def valid_days(cls, value: list[int]) -> list[int]:
        if not value or any(day < 0 or day > 6 for day in value):
            raise ValueError("Schedule days must contain values from 0 to 6")
        return sorted(set(value))


class AccessRequestCreate(BaseModel):
    requested_host: str = Field(min_length=1, max_length=253)
    client_ip: str = ""  # public block-page requests leave this empty; the server fills it
    device_name: str | None = Field(default=None, max_length=255)
    reason: str = Field(min_length=1, max_length=1000)

    @field_validator("client_ip")
    @classmethod
    def valid_client_ip(cls, value: str) -> str:
        return value if not value else str(ip_address(value))


class UpdateStageRequest(BaseModel):
    manifest: dict
    signature: str = Field(min_length=40, max_length=1000)
    package_base64: str = Field(min_length=4)


class RestoreApplyRequest(BaseModel):
    candidate_id: str = Field(pattern=r"^restore_[0-9a-f]{16}$")
    confirmation: str = Field(min_length=20, max_length=80)


class FirewallZoneCreate(BaseModel):
    name: str = Field(min_length=1, max_length=40, pattern=r"^[A-Za-z0-9_-]+$")
    interfaces: list[str] = Field(default_factory=list)
    networks: list[str] = Field(default_factory=list)
    default_action: Literal["accept", "drop"] = "drop"

    @field_validator("networks")
    @classmethod
    def valid_networks(cls, values: list[str]) -> list[str]:
        return [str(ip_network(value, strict=False)) for value in values]


class PortForwardCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    protocol: Literal["tcp", "udp"]
    external_port: int = Field(ge=1, le=65535)
    internal_ip: str
    internal_port: int = Field(ge=1, le=65535)
    source_network: str | None = None
    enabled: bool = True

    @field_validator("internal_ip")
    @classmethod
    def valid_internal_ip(cls, value: str) -> str:
        address = ip_address(value)
        if address.version != 4:
            raise ValueError("Port forwarding currently requires an IPv4 target")
        return str(address)

    @field_validator("source_network")
    @classmethod
    def valid_source_network(cls, value: str | None) -> str | None:
        return str(ip_network(value, strict=False)) if value else None


class IpPoolCreate(BaseModel):
    """A client IP pool served on its own VLAN subinterface of the LAN adapter."""
    name: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9][A-Za-z0-9 ._-]*$")
    vlan_id: int = Field(ge=2, le=4094)
    subnet: str
    pool_start: str
    pool_end: str
    enabled: bool = True

    @field_validator("subnet")
    @classmethod
    def valid_subnet(cls, value: str) -> str:
        return str(ip_network(value, strict=False))

    @field_validator("pool_start", "pool_end")
    @classmethod
    def valid_pool_ip(cls, value: str) -> str:
        return str(ip_address(value))


class CategoryGroupCreate(BaseModel):
    """A custom web-control group card: applications + domains you choose."""
    name: str = Field(min_length=1, max_length=40, pattern=r"^[A-Za-z0-9][A-Za-z0-9 ._-]*$")
    description: str = Field(default="", max_length=200)


class CustomServiceCreate(BaseModel):
    """An administrator-defined service (name + domains) that behaves exactly
    like the curated ones: toggleable, groupable, enforced via DNS."""
    name: str = Field(min_length=1, max_length=40, pattern=r"^[a-z0-9][a-z0-9 ._-]*$")
    category: str = Field(min_length=1, max_length=60)
    domains: list[str] = Field(min_length=1, max_length=100)

    @field_validator("domains")
    @classmethod
    def valid_domains(cls, value: list[str]) -> list[str]:
        cleaned: list[str] = []
        for item in value:
            domain = item.strip().lower().rstrip(".")
            if not re.match(r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$", domain):
                raise ValueError(f"“{item}” is not a valid domain (use forms like service.example.com)")
            cleaned.append(domain)
        deduped = sorted(set(cleaned))
        if not deduped:
            raise ValueError("At least one domain is required")
        return deduped


class CategoryGroupMember(BaseModel):
    application: str = Field(min_length=1, max_length=40)


class PortalSettings(BaseModel):
    """Policy-acceptance captive portal: devices must accept the network policy
    (and can then install the HTTPS block certificate) before traffic flows."""
    enabled: bool = False
    title: str = Field(default="Welcome to the network", max_length=100)
    organization: str = Field(default="Network Security", max_length=100)
    message: str = Field(default="Before this device can use the network, please read and accept the network acceptable-use policy. Web activity on this network is filtered and logged for security purposes.", max_length=1000)
    support_contact: str = Field(default="Questions? Contact your network administrator.", max_length=200)


class DhcpReservationCreate(BaseModel):
    mac_address: str = Field(pattern=r"^(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$")
    ip_address: str
    hostname: str = Field(min_length=1, max_length=253, pattern=r"^[A-Za-z0-9][A-Za-z0-9.-]*$")

    @field_validator("ip_address")
    @classmethod
    def valid_reservation_ip(cls, value: str) -> str:
        return str(ip_address(value))


class LocalDnsRecordCreate(BaseModel):
    name: str = Field(min_length=1, max_length=253)
    record_type: Literal["A", "AAAA", "CNAME"]
    value: str = Field(min_length=1, max_length=253)

    @model_validator(mode="after")
    def matching_value(self) -> "LocalDnsRecordCreate":
        if self.record_type == "A" and ip_address(self.value).version != 4:
            raise ValueError("A records require an IPv4 address")
        if self.record_type == "AAAA" and ip_address(self.value).version != 6:
            raise ValueError("AAAA records require an IPv6 address")
        if self.record_type == "CNAME" and not self.value.strip().replace(".", "").replace("-", "").isalnum():
            raise ValueError("CNAME requires a hostname")
        return self


class SecurityEventCreate(BaseModel):
    event_type: Literal["firewall", "dns", "proxy", "application", "system"]
    action: Literal["blocked", "allowed", "alert"]
    client_ip: str | None = None
    hostname: str | None = Field(default=None, max_length=253)
    destination: str | None = Field(default=None, max_length=1000)
    category: str | None = Field(default=None, max_length=100)
    policy: str | None = Field(default=None, max_length=200)
    details: dict = Field(default_factory=dict)

    @field_validator("client_ip")
    @classmethod
    def valid_event_ip(cls, value: str | None) -> str | None:
        return str(ip_address(value)) if value else None


class AccessRequestReview(BaseModel):
    decision: Literal["approved", "denied"]
    note: str = Field(default="", max_length=500)
    create_allow_rule: bool = True
    duration: Literal["1h", "4h", "8h", "24h", "3d", "7d", "30d", "permanent"] = "permanent"


class RetentionSettings(BaseModel):
    security_event_days: int = Field(default=90, ge=1, le=3650)
    audit_days: int = Field(default=365, ge=30, le=3650)
    access_request_days: int = Field(default=365, ge=30, le=3650)


class FirewallModuleUpdate(BaseModel):
    enabled: bool


class AdminPortUpdate(BaseModel):
    """Move the admin dashboard to another TCP port (nginx)."""
    port: int = Field(ge=1, le=65535)


class IptablesSettings(BaseModel):
    wan_interface: str = Field(default="eth0", pattern=r"^[A-Za-z0-9_.:-]+$")
    lan_interface: str = Field(default="eth1", pattern=r"^[A-Za-z0-9_.:-]+$")
    lan_network: str = "192.168.10.0/24"
    management_network: str = "192.168.0.0/16"
    masquerade: bool = True
    ip_forward: bool = True
    default_input: Literal["drop", "reject"] = "drop"
    default_forward: Literal["drop", "reject"] = "drop"
    rollback_seconds: int = Field(default=120, ge=30, le=900)

    @field_validator("management_network")
    @classmethod
    def valid_management_network(cls, value: str) -> str:
        """One network or several, comma-separated (e.g. 10.0.0.0/24, 192.168.50.0/24)."""
        networks = [str(ip_network(item.strip(), strict=False)) for item in value.split(",") if item.strip()]
        if not networks:
            raise ValueError("At least one management network is required")
        return ", ".join(networks)

    @field_validator("lan_network")
    @classmethod
    def valid_lan_network(cls, value: str) -> str:
        return str(ip_network(value, strict=False))


def network_of(address: str):
    return ip_network(address, strict=False)
