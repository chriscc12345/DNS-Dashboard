from __future__ import annotations

import ipaddress
import re
from datetime import UTC, datetime, time
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


MAC_RE = re.compile(r"^(?:[0-9a-f]{2}:){5}[0-9a-f]{2}$", re.I)


def _schedule_active(schedule: dict, now: datetime) -> bool:
    if not schedule.get("enabled", True):
        return False
    try:
        local = now.astimezone(ZoneInfo(schedule["timezone"]))
    except ZoneInfoNotFoundError as exc:
        raise ValueError(f"Unknown schedule timezone: {schedule['timezone']}") from exc
    if local.weekday() not in schedule["days"]:
        return False
    start = time.fromisoformat(schedule["start_time"])
    end = time.fromisoformat(schedule["end_time"])
    current = local.time().replace(tzinfo=None)
    return start <= current <= end if start <= end else current >= start or current <= end


def compile_block_targets(source: dict, now: datetime | None = None) -> dict[str, list[str]]:
    members_by_group: dict[str, list[tuple[str, str]]] = {}
    for member in source["members"]:
        members_by_group.setdefault(str(member["group_id"]), []).append((member["target_type"], member["target_value"]))
    targets: list[tuple[str, str]] = []
    schedules = {row["id"]: row for row in source.get("schedules", [])}
    instant = now or datetime.now(UTC)
    for policy in source["policies"]:
        schedule_id = policy.get("schedule_id")
        if schedule_id and (schedule_id not in schedules or not _schedule_active(schedules[schedule_id], instant)):
            continue
        if policy["target_type"] == "group":
            targets.extend(members_by_group.get(str(policy["target_value"]), []))
        else:
            targets.append((policy["target_type"], policy["target_value"]))
    result: dict[str, set[str]] = {"ipv4": set(), "ipv6": set(), "mac": set(), "unresolved_hostnames": set()}
    devices = source["devices"]
    for target_type, value in targets:
        value = value.strip()
        if target_type == "ip":
            address = ipaddress.ip_address(value)
            result["ipv6" if address.version == 6 else "ipv4"].add(str(address))
        elif target_type == "mac":
            if not MAC_RE.fullmatch(value):
                raise ValueError(f"Invalid MAC address: {value}")
            result["mac"].add(value.lower())
        elif target_type == "hostname":
            matches = [row["ip_address"] for row in devices if (row.get("hostname") or "").lower() == value.lower()]
            if not matches:
                result["unresolved_hostnames"].add(value.lower())
            for match in matches:
                address = ipaddress.ip_address(match)
                result["ipv6" if address.version == 6 else "ipv4"].add(str(address))
    return {key: sorted(values) for key, values in result.items()}
