from __future__ import annotations

from ipaddress import ip_address, ip_interface

from app.models import (
    AddressMode,
    DeploymentMode,
    DeploymentPlan,
    DeploymentRequest,
    InterfaceInfo,
    ValidationMessage,
    ValidationResult,
    network_of,
)


MODE_DETAILS = {
    DeploymentMode.VLAN_TRUNK: {
        "title": "One NIC — VLAN trunk",
        "full": True,
        "diagram": ["Internet/Router", "Managed VLAN switch", "Firewall trunk NIC", "LAN / Guest / IoT"],
        "limitations": [
            "You need a managed switch with the same VLAN tags configured on its ports.",
        ],
    },
    DeploymentMode.DNS_PROXY: {
        "title": "One NIC — DNS and proxy server",
        "full": False,
        "diagram": ["Client devices", "Existing router", "Internet", "Firewall DNS/proxy"],
        "limitations": [
            "This mode cannot guarantee enforcement — the appliance is not in the traffic path.",
            "Clients can bypass filtering (alternate DNS, encrypted DNS, VPNs) unless your router blocks those routes.",
        ],
    },
    DeploymentMode.ROUTED_GATEWAY: {
        "title": "Two NIC — routed gateway",
        "full": True,
        "diagram": ["Internet/upstream router", "Firewall WAN", "Firewall LAN", "Switch and devices"],
        "limitations": [
            "LAN devices must use this firewall's LAN address as their gateway — the appliance's DHCP does that automatically for new clients.",
        ],
    },
    DeploymentMode.TRANSPARENT_BRIDGE: {
        "title": "Two NIC — transparent bridge",
        "full": True,
        "diagram": ["Existing router", "Firewall bridge", "LAN switch", "Client devices"],
        "limitations": [
            "Your router keeps handling addresses — some advanced features need a separate management address.",
        ],
    },
}


def validate_deployment(request: DeploymentRequest, interfaces: list[InterfaceInfo]) -> ValidationResult:
    messages: list[ValidationMessage] = []
    available = {item.name for item in interfaces}
    selected = [
        value
        for value in (request.wan_interface, request.lan_interface, request.trunk_interface, request.management_interface)
        if value
    ]

    for name in sorted(set(selected)):
        if name not in available:
            messages.append(ValidationMessage(level="error", code="interface_missing", message=f"The adapter \"{name}\" does not exist on this appliance — pick one from the list."))

    if request.mode in {DeploymentMode.ROUTED_GATEWAY, DeploymentMode.TRANSPARENT_BRIDGE}:
        if request.wan_interface == request.lan_interface:
            messages.append(ValidationMessage(level="error", code="same_interface", message="The internet side (WAN) and the client side (LAN) must be different adapters."))

    if request.mode == DeploymentMode.VLAN_TRUNK:
        if len(request.vlans) < 2:
            messages.append(ValidationMessage(level="error", code="vlan_roles", message="Add at least two VLANs — one for the internet side and one for the client side."))
        ids = [item.vlan_id for item in request.vlans]
        if len(ids) != len(set(ids)):
            messages.append(ValidationMessage(level="error", code="duplicate_vlan", message="Two VLANs share the same ID — every VLAN needs its own number."))
        roles = {item.role for item in request.vlans}
        if not {"wan", "lan"}.issubset(roles):
            messages.append(ValidationMessage(level="error", code="missing_vlan_role", message="You need one VLAN labelled \"wan\" and one labelled \"lan\"."))

    networks = []
    management_network = ip_interface(request.management_address).network
    networks.append(("management", management_network))
    for vlan in request.vlans:
        if vlan.address_mode == AddressMode.STATIC and vlan.address:
            networks.append((f"VLAN {vlan.vlan_id}", network_of(vlan.address)))
    for index, (left_name, left_net) in enumerate(networks):
        for right_name, right_net in networks[index + 1 :]:
            if left_net.version == right_net.version and left_net.overlaps(right_net):
                messages.append(ValidationMessage(level="error", code="subnet_overlap", message=f"Two networks use overlapping address ranges: {left_name} and {right_name}. Give each its own range (e.g. 192.168.50.x and 192.168.100.x)."))

    if request.upstream_gateway:
        try:
            gateway = ip_address(request.upstream_gateway)
            if gateway.version != ip_interface(request.management_address).version and request.mode == DeploymentMode.DNS_PROXY:
                messages.append(ValidationMessage(level="error", code="gateway_family", message="Gateway and management address use different IP families."))
        except ValueError:
            messages.append(ValidationMessage(level="error", code="gateway_invalid", message="That upstream gateway isn't a valid IP address — it should look like 192.168.50.1."))

    acknowledgements = {
        "architecture_acknowledged": request.architecture_acknowledged,
        "cabling_acknowledged": request.cabling_acknowledged,
        "recovery_acknowledged": request.recovery_acknowledged,
    }
    missing = [name.replace("_", " ") for name, accepted in acknowledgements.items() if not accepted]
    if missing:
        messages.append(ValidationMessage(level="error", code="acknowledgement_required", message="Tick all three confirmation boxes on the previous step before continuing: " + ", ".join(missing) + "."))

    if request.mode == DeploymentMode.DNS_PROXY:
        messages.append(ValidationMessage(level="warning", code="partial_enforcement", message="Heads-up: DNS/proxy mode only filters DNS and web-proxy traffic — it cannot police the rest of the network."))

    if not any(item.level == "error" for item in messages):
        messages.append(ValidationMessage(level="info", code="ready", message="Everything checks out — this configuration is valid and ready to prepare."))
    return ValidationResult(valid=not any(item.level == "error" for item in messages), messages=messages)


def build_plan(request: DeploymentRequest, interfaces: list[InterfaceInfo]) -> DeploymentPlan:
    details = MODE_DETAILS[request.mode]
    assignments = {"management": request.management_interface}
    if request.wan_interface:
        assignments["wan"] = request.wan_interface
    if request.lan_interface:
        assignments["lan"] = request.lan_interface
    if request.trunk_interface:
        assignments["trunk"] = request.trunk_interface

    actions = [
        "Prepare the change as a versioned candidate you can review first",
        "Check the firewall rules for syntax errors before anything is applied",
        "Keep your current dashboard access working throughout the change",
    ]
    if request.mode == DeploymentMode.VLAN_TRUNK:
        actions.extend(f"Add VLAN {vlan.vlan_id} for the {vlan.role.upper()} side of the trunk" for vlan in request.vlans)
    if request.mode == DeploymentMode.ROUTED_GATEWAY:
        actions.extend(["Turn on routing between the internet (WAN) and client (LAN) sides", "Share the internet connection with all LAN clients (NAT)", "Serve DHCP and filtered DNS to LAN clients from this appliance"])
    elif request.mode == DeploymentMode.TRANSPARENT_BRIDGE:
        actions.extend(["Create a transparent filter between the WAN and LAN adapters", "Attach both adapters to the filter", "Inspect all traffic passing through"])
    elif request.mode == DeploymentMode.DNS_PROXY:
        actions.extend(["Serve filtered DNS on the management adapter", "Enable the optional explicit web proxy"])

    safety = [
        "Take a full snapshot of the current configuration before changing anything",
        "Apply the whole change in a single step — no half-applied states",
        "Automatically test internet, DNS and dashboard access right after applying",
        "Wait for you to confirm everything works — otherwise restore the snapshot automatically",
    ]
    return DeploymentPlan(
        mode=request.mode,
        title=details["title"],
        full_enforcement=details["full"],
        diagram=details["diagram"],
        interface_assignments=assignments,
        generated_actions=actions,
        safety_actions=safety,
        limitations=details["limitations"],
        validation=validate_deployment(request, interfaces),
    )
