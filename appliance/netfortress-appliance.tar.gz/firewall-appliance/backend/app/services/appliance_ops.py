from __future__ import annotations

import io
import json
import os
import platform
import shutil
import subprocess
import tarfile
import hashlib
from datetime import UTC, datetime
from pathlib import Path

from app.models import DhcpSettings


def render_kea_config(settings: DhcpSettings, reservations: list[dict] | None = None, pools: list[dict] | None = None) -> str:
    """Kea DHCP config: the primary LAN subnet plus one VLAN subinterface
    subnet per configured IP pool (each pool gets its own virtual adapter)."""
    network = settings.subnet
    prefix = network.split("/")[1]
    extra_pools = [pool for pool in (pools or []) if pool.get("enabled", 1)]
    interfaces = [settings.interface] + [f"{settings.interface}.{pool['vlan_id']}" for pool in extra_pools]
    payload = {"Dhcp4": {"interfaces-config": {"interfaces": [settings.interface]}, "lease-database": {"type": "memfile", "persist": True, "name": "/var/lib/kea/kea-leases4.csv"}, "valid-lifetime": settings.lease_seconds, "subnet4": [{"id": 1, "subnet": network, "pools": [{"pool": f"{settings.pool_start} - {settings.pool_end}"}], "option-data": [{"name": "routers", "data": settings.router}, {"name": "domain-name-servers", "data": ", ".join(settings.dns_servers)}]}], "loggers": [{"name": "kea-dhcp4", "severity": "INFO"}], "control-socket": {"socket-type": "unix", "socket-name": "/run/kea/kea4-ctrl-socket"}, "authoritative": True, "echo-client-id": True, "match-client-id": True, "next-server": settings.router, "server-hostname": "firewall-appliance", "boot-file-name": "", "decline-probation-period": 86400, "dhcp4o6-port": 0, "hostname-char-set": "[^A-Za-z0-9.-]", "hostname-char-replacement": "", "reservations-global": False, "reservations-in-subnet": True, "reservations-out-of-pool": True, "store-extended-info": True, "calculate-tee-times": True, "t1-percent": 0.5, "t2-percent": 0.875, "cache-threshold": 0.25, "cache-max-age": 3600, "parked-packet-limit": 256, "multi-threading": {"enable-multi-threading": True, "thread-pool-size": 0, "packet-queue-size": 64}, "sanity-checks": {"lease-checks": "warn"}, "expired-leases-processing": {"reclaim-timer-wait-time": 10}, "compatibility": {"lenient-option-parsing": False}, "user-context": {"generated-by": "firewall-appliance", "subnet-prefix": prefix}}}
    payload["Dhcp4"]["subnet4"][0]["reservations"] = [{"hw-address": row["mac_address"], "ip-address": row["ip_address"], "hostname": row["hostname"]} for row in (reservations or [])]
    payload["Dhcp4"]["interfaces-config"]["interfaces"] = interfaces
    for pool in extra_pools:
        payload["Dhcp4"]["subnet4"].append({
            "id": 1000 + int(pool["vlan_id"]),
            "subnet": pool["subnet"],
            "pools": [{"pool": f"{pool['pool_start']} - {pool['pool_end']}"}],
            "option-data": [{"name": "routers", "data": pool["router"]}, {"name": "domain-name-servers", "data": pool["router"]}],
        })
    return json.dumps(payload, indent=2) + "\n"


def system_services() -> list[dict]:
    names = ["firewall-api", "nftables", "nginx", "kea-dhcp4-server", "squid"]
    root = Path("/run/systemd/system")
    return [{"name": name, "installed": any(Path(path).exists() for path in [f"/etc/systemd/system/{name}.service", f"/lib/systemd/system/{name}.service", f"/usr/lib/systemd/system/{name}.service"]), "runtime_available": root.exists()} for name in names]


def cache_status(cache_dir: str = "/var/spool/squid") -> dict:
    path = Path(cache_dir)
    usage = shutil.disk_usage(path if path.exists() else "/")
    return {"cache_directory": cache_dir, "directory_present": path.exists(), "disk_total_bytes": usage.total, "disk_used_bytes": usage.used, "disk_free_bytes": usage.free, "squidclient_available": shutil.which("squidclient") is not None}


def purge_cached_url(url: str, port: int) -> dict:
    executable = shutil.which("squidclient")
    if not executable:
        raise RuntimeError("squidclient is not installed")
    result = subprocess.run([executable, "-p", str(port), "-m", "PURGE", url], capture_output=True, text=True, timeout=15)
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "Squid purge failed").strip())
    first_line = (result.stdout or "").splitlines()[0] if result.stdout else "PURGE submitted"
    return {"url": url, "result": first_line}


def support_bundle(database_path: str, state_dir: str) -> bytes:
    summary = {"created_at": datetime.now(UTC).isoformat(), "platform": platform.platform(), "python": platform.python_version(), "database_present": Path(database_path).exists(), "state_dir_present": Path(state_dir).exists(), "secrets_included": False}
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:gz") as archive:
        data = json.dumps(summary, indent=2).encode()
        info = tarfile.TarInfo("system-summary.json"); info.size = len(data); info.mtime = int(datetime.now().timestamp()); archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def backup_archive(database_path: str, state_dir: str) -> bytes:
    output = io.BytesIO()
    files: list[tuple[str, bytes]] = []
    db = Path(database_path)
    if db.exists():
        files.append(("data/appliance.db", db.read_bytes()))
    root = Path(state_dir)
    for path in sorted((root / "blocklists").glob("*.domains")) if (root / "blocklists").exists() else []:
        files.append((f"data/blocklists/{path.name}", path.read_bytes()))
    manifest = {"format": 1, "product": "firewall-appliance", "created_at": datetime.now(UTC).isoformat(), "files": [{"path": name, "sha256": hashlib.sha256(data).hexdigest(), "size": len(data)} for name, data in files], "secrets_included": False}
    files.append(("manifest.json", json.dumps(manifest, indent=2).encode()))
    with tarfile.open(fileobj=output, mode="w:gz") as archive:
        for name, data in files:
            info = tarfile.TarInfo(name); info.size = len(data); info.mtime = int(datetime.now().timestamp()); archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


def validate_backup(data: bytes) -> dict:
    if len(data) > 512 * 1024 * 1024:
        raise ValueError("Backup exceeds 512 MiB")
    if not data.startswith(b"\x1f\x8b"):
        raise ValueError("Backup is not a gzip archive")
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        members = archive.getmembers()
        if any(member.name.startswith("/") or ".." in Path(member.name).parts or member.issym() or member.islnk() for member in members):
            raise ValueError("Backup contains unsafe paths or links")
        manifest_member = archive.getmember("manifest.json")
        manifest = json.loads(archive.extractfile(manifest_member).read())
        if manifest.get("product") != "firewall-appliance" or manifest.get("format") != 1:
            raise ValueError("Unsupported backup format")
        verified = 0
        for item in manifest.get("files", []):
            content = archive.extractfile(archive.getmember(item["path"])).read()
            if hashlib.sha256(content).hexdigest() != item["sha256"]:
                raise ValueError(f"Backup hash mismatch: {item['path']}")
            verified += 1
    return {"valid": True, "created_at": manifest["created_at"], "file_count": verified, "secrets_included": manifest.get("secrets_included", False)}
