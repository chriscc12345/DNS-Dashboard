from __future__ import annotations

import json
import subprocess
from pathlib import Path

from app.models import InterfaceInfo


SYS_CLASS_NET = Path("/sys/class/net")


def _read(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8").strip()
    except (OSError, ValueError):
        return None


def _addresses() -> dict[str, list[str]]:
    try:
        result = subprocess.run(
            ["ip", "-j", "address", "show"],
            check=True,
            capture_output=True,
            text=True,
            timeout=3,
        )
        rows = json.loads(result.stdout)
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError):
        return {}

    found: dict[str, list[str]] = {}
    for row in rows:
        values = []
        for address in row.get("addr_info", []):
            local = address.get("local")
            prefix = address.get("prefixlen")
            if local is not None and prefix is not None:
                values.append(f"{local}/{prefix}")
        found[row.get("ifname", "")] = values
    return found


def discover_interfaces() -> list[InterfaceInfo]:
    addresses = _addresses()
    interfaces: list[InterfaceInfo] = []
    if not SYS_CLASS_NET.exists():
        return interfaces

    for path in sorted(SYS_CLASS_NET.iterdir()):
        if path.name == "lo":
            continue
        speed = _read(path / "speed")
        interfaces.append(
            InterfaceInfo(
                name=path.name,
                mac_address=_read(path / "address"),
                state=_read(path / "operstate") or "unknown",
                mtu=int(value) if (value := _read(path / "mtu")) and value.isdigit() else None,
                speed_mbps=int(speed) if speed and speed.lstrip("-").isdigit() and int(speed) > 0 else None,
                addresses=addresses.get(path.name, []),
                is_virtual=not (path / "device").exists(),
            )
        )
    return interfaces
