from __future__ import annotations

import os
from pathlib import Path


def _memory() -> dict[str, int]:
    values: dict[str, int] = {}
    try:
        for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
            key, value = line.split(":", 1)
            values[key] = int(value.strip().split()[0]) * 1024
    except (OSError, ValueError):
        return {"total_bytes": 0, "available_bytes": 0, "used_percent": 0}
    total, available = values.get("MemTotal", 0), values.get("MemAvailable", 0)
    percent = round((total - available) * 100 / total) if total else 0
    return {"total_bytes": total, "available_bytes": available, "used_percent": percent}


def system_overview() -> dict:
    try:
        uptime = int(float(Path("/proc/uptime").read_text(encoding="utf-8").split()[0]))
    except (OSError, ValueError, IndexError):
        uptime = 0
    load = os.getloadavg()
    return {"hostname": os.uname().nodename, "kernel": os.uname().release, "uptime_seconds": uptime, "load_average": [round(value, 2) for value in load], "cpu_cores": os.cpu_count() or 1, "memory": _memory()}
