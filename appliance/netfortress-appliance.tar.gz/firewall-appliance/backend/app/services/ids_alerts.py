"""IDS alert ingestion: Suricata eve.json -> dashboard security events.

The reconciler calls ingest_ids_alerts() every minute. Alerts recorded by
Suricata (deep packet inspection matches from the ET Open feed) become rows
in security_events, so they appear in Security reports next to DNS and portal
events. The eve log is compacted once everything is ingested and it has grown
large, so the file never runs away.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

EVE_LOG = Path("/var/log/suricata/eve.json")
STATE = Path("/var/lib/firewall-appliance/ids-state.json")
COMPACT_AFTER_BYTES = 5 * 1024 * 1024


def parse_eve_line(line: str) -> dict | None:
    """One eve.json line -> a security-events payload, or None when not an alert."""
    try:
        row: dict[str, Any] = json.loads(line)
    except ValueError:
        return None
    if row.get("event_type") != "alert":
        return None
    alert = row.get("alert") or {}
    category = alert.get("category") or []
    destination = row.get("dest_ip")
    if destination and row.get("dest_port") is not None:
        destination = f"{destination}:{row.get('dest_port')}"
    return {
        "event_type": "ids",
        "action": row.get("action") or "alerted",
        "client_ip": row.get("src_ip"),
        "destination": destination,
        "category": category[0] if isinstance(category, list) and category else (category if isinstance(category, str) else None),
        "policy": alert.get("signature"),
        "details": {
            "severity": alert.get("severity"),
            "signature_id": alert.get("signature_id"),
            "proto": row.get("proto"),
            "src_port": row.get("src_port"),
            "dest_port": row.get("dest_port"),
        },
    }


def _load_state(state_path: Path) -> dict:
    try:
        saved = json.loads(state_path.read_text(encoding="utf-8"))
        return saved if isinstance(saved, dict) else {}
    except (OSError, ValueError):
        return {}


def ingest_ids_alerts(database, eve_log: Path = EVE_LOG, state_path: Path = STATE) -> int:
    """Insert every new alert since the last run; returns the number ingested."""
    if not eve_log.is_file():
        return 0
    state = _load_state(state_path)
    offset = int(state.get("eve_offset") or 0)
    size = eve_log.stat().st_size
    if size < offset:  # the log was rotated or truncated — start over
        offset = 0
    if size == offset:
        return 0
    inserted = 0
    with eve_log.open("r", encoding="utf-8", errors="replace") as handle:
        handle.seek(offset)
        for line in handle:
            payload = parse_eve_line(line)
            if payload:
                database.create_security_event(payload)
                inserted += 1
        offset = handle.tell()
    state["eve_offset"] = offset
    if offset >= COMPACT_AFTER_BYTES:
        eve_log.write_text("", encoding="utf-8")
        state["eve_offset"] = 0
    state_path.write_text(json.dumps(state), encoding="utf-8")
    return inserted
