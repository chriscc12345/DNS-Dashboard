from __future__ import annotations

import ipaddress
from dataclasses import asdict, dataclass

from app.models import AddressMode, DeploymentMode, DeploymentRequest
from app.services.network_engine import safe_interface


@dataclass(frozen=True)
class NetworkOperation:
    action: str
    interface: str | None = None
    value: str | int | None = None
    parent: str | None = None


def _address(value: str) -> str:
    return str(ipaddress.ip_interface(value))


def _gateway(value: str) -> str:
    return str(ipaddress.ip_address(value))


def render_network_plan(request: DeploymentRequest) -> list[dict]:
    """Render a closed set of declarative operations; never shell text."""
    operations: list[NetworkOperation] = []
    management = safe_interface(request.management_interface)

    if request.mode in {DeploymentMode.ROUTED_GATEWAY, DeploymentMode.VLAN_TRUNK}:
        operations.extend([
            NetworkOperation("sysctl", value="net.ipv4.ip_forward=1"),
            NetworkOperation("sysctl", value="net.ipv6.conf.all.forwarding=1"),
        ])

    management_target = management
    if request.mode == DeploymentMode.TRANSPARENT_BRIDGE:
        wan = safe_interface(request.wan_interface or "")
        lan = safe_interface(request.lan_interface or "")
        management_target = "br-firewall"
        operations.extend([
            NetworkOperation("create_bridge", interface=management_target),
            NetworkOperation("set_master", interface=wan, parent=management_target),
            NetworkOperation("set_master", interface=lan, parent=management_target),
            NetworkOperation("link_up", interface=wan),
            NetworkOperation("link_up", interface=lan),
            NetworkOperation("link_up", interface=management_target),
        ])

    if request.mode == DeploymentMode.VLAN_TRUNK:
        trunk = safe_interface(request.trunk_interface or "")
        for vlan in request.vlans:
            child = safe_interface(f"{trunk}.{vlan.vlan_id}")
            operations.extend([
                NetworkOperation("create_vlan", interface=child, parent=trunk, value=vlan.vlan_id),
                NetworkOperation("link_up", interface=child),
            ])
            if vlan.address_mode == AddressMode.STATIC and vlan.address:
                operations.append(NetworkOperation("replace_address", interface=child, value=_address(vlan.address)))

    if management_target != management:
        operations.append(NetworkOperation("delete_address", interface=management, value=_address(request.management_address)))
    operations.append(NetworkOperation("replace_address", interface=management_target, value=_address(request.management_address)))

    if request.upstream_gateway:
        if request.mode == DeploymentMode.ROUTED_GATEWAY:
            route_interface = safe_interface(request.wan_interface or "")
        elif request.mode == DeploymentMode.VLAN_TRUNK:
            trunk = safe_interface(request.trunk_interface or "")
            wan_vlan = next((item for item in request.vlans if item.role == "wan"), None)
            if wan_vlan is None:
                raise ValueError("A WAN VLAN is required when an upstream gateway is configured")
            route_interface = safe_interface(f"{trunk}.{wan_vlan.vlan_id}")
        else:
            route_interface = management_target
        operations.append(NetworkOperation("replace_default_route", interface=route_interface, value=_gateway(request.upstream_gateway)))

    return [asdict(operation) for operation in operations]


def affected_interfaces(plan: list[dict]) -> list[str]:
    names = {value for operation in plan for key in ("interface", "parent") if (value := operation.get(key))}
    return sorted(names)
