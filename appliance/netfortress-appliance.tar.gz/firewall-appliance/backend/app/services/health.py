from __future__ import annotations

import socket
import subprocess
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class HealthCheck:
    name: str
    passed: bool
    critical: bool
    message: str


def _command(name: str, command: list[str], critical: bool) -> HealthCheck:
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=5)
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return HealthCheck(name, False, critical, str(exc))
    message = (result.stdout or result.stderr or "completed").strip()
    return HealthCheck(name, result.returncode == 0, critical, message)


def _privileged_checks(transaction_id: str) -> dict | None:
    """Run the privileged checks through the root transaction helper."""
    import json

    try:
        completed = subprocess.run(
            ["sudo", "-n", "/usr/local/sbin/firewall-transaction", "health", transaction_id],
            capture_output=True, text=True, timeout=90, check=False,
        )
        body = json.loads(completed.stdout)
        return body.get("checks") if completed.returncode == 0 else None
    except (OSError, ValueError):
        return None


def run_activation_health_checks(deployment: dict, transaction_id: str | None = None) -> list[dict]:
    privileged = _privileged_checks(transaction_id) if transaction_id else None
    if privileged is not None:
        checks = [
            HealthCheck(name, bool((privileged.get(name) or {}).get("passed")), critical, str((privileged.get(name) or {}).get("message", "check unavailable")))
            for name, critical in (("nftables_table", True), ("default_route", True), ("kea_configuration", False), ("squid_configuration", False))
        ]
    else:
        checks = [
            _command("nftables_table", ["nft", "list", "table", "inet", "firewall_appliance"], True),
            _command("default_route", ["ip", "route", "get", "1.1.1.1"], True),
            _command("kea_configuration", ["kea-dhcp4", "-t", "/etc/kea/kea-dhcp4.conf"], False),
            _command("squid_configuration", ["squid", "-k", "parse", "-f", "/etc/squid/squid.conf"], False),
        ]
    gateway = deployment.get("upstream_gateway")
    if gateway:
        checks.append(_command("upstream_gateway", ["ping", "-c", "1", "-W", "2", gateway], True))
    try:
        with socket.create_connection(("127.0.0.1", 8080), timeout=2):
            checks.append(HealthCheck("management_api", True, True, "Management API is reachable locally."))
    except OSError as exc:
        checks.append(HealthCheck("management_api", False, True, str(exc)))
    try:
        socket.getaddrinfo("example.com", 443)
        checks.append(HealthCheck("dns_resolution", True, False, "DNS resolution succeeded."))
    except OSError as exc:
        checks.append(HealthCheck("dns_resolution", False, False, str(exc)))
    return [asdict(check) for check in checks]


def critical_health_passed(checks: list[dict]) -> bool:
    return all(check["passed"] for check in checks if check["critical"])
