"""WireGuard VPN service: key handling, config rendering and status parsing.

The appliance runs one WireGuard interface (wg0). Peers are either
remote-access clients (keys generated here, config downloaded once) or
site-to-site tunnels to other appliances/networks (their keypair, our
endpoint). Interface changes go through the fixed root helper
(firewall-wireguard) with the same candidate/rollback pattern as the other
live-enforcement transactions.
"""
from __future__ import annotations

import base64
import subprocess
from ipaddress import ip_interface, ip_network
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey

INTERFACE = "wg0"
STATE = Path("/var/lib/firewall-appliance")
HELPER = "/usr/local/sbin/firewall-wireguard"


def generate_keypair() -> tuple[str, str]:
    """A fresh WireGuard keypair as (private_key, public_key) base64 strings."""
    private = X25519PrivateKey.generate()
    private_b64 = base64.b64encode(
        private.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                              serialization.NoEncryption())).decode()
    public_b64 = base64.b64encode(
        private.public_key().public_bytes(serialization.Encoding.Raw,
                                         serialization.PublicFormat.Raw)).decode()
    return private_b64, public_b64


def server_key(database) -> tuple[str, str]:
    """The appliance's persistent wg0 keypair (created on first use)."""
    key_path = STATE / "wireguard.key"
    if key_path.is_file():
        private_b64 = key_path.read_text().strip()
    else:
        private_b64, _public = generate_keypair()
        key_path.parent.mkdir(parents=True, exist_ok=True)
        key_path.write_text(private_b64 + "\n")
        try:
            key_path.chmod(0o600)
        except OSError:
            pass
    private = X25519PrivateKey.from_private_bytes(base64.b64decode(private_b64))
    public_b64 = base64.b64encode(
        private.public_key().public_bytes(serialization.Encoding.Raw,
                                          serialization.PublicFormat.Raw)).decode()
    return private_b64, public_b64


def tunnel_address(settings, peers) -> str:
    """The appliance's own address inside the tunnel network."""
    return f"{ip_network(settings.tunnel_subnet, strict=False).network_address + 1}"


def next_client_address(settings, peers) -> str:
    """Allocate the next free address in the tunnel network for a new client.
    Addresses already claimed by a peer's AllowedIPs are skipped."""
    network = ip_network(settings.tunnel_subnet, strict=False)
    used = set()
    for peer in peers:
        for item in str(peer.get("allowed_ips") or "").split(","):
            item = item.strip()
            if not item:
                continue
            try:
                used.add(str(ip_interface(item).ip))
            except ValueError:
                continue
    for candidate in network.hosts():
        text = str(candidate)
        if text == tunnel_address(settings, peers):
            continue
        if text not in used:
            return text
    raise ValueError("The tunnel network has no free addresses left")


def render_server_config(settings, private_key: str, peers: list[dict]) -> str:
    """wg-quick configuration for the appliance's wg0 interface."""
    address = tunnel_address(settings, peers)
    prefix = ip_network(settings.tunnel_subnet, strict=False).prefixlen
    lines = [
        "[Interface]",
        f"Address = {address}/{prefix}",
        f"ListenPort = {settings.listen_port}",
        f"PrivateKey = {private_key}",
    ]
    for peer in peers:
        if not peer.get("enabled", 1):
            continue
        lines.append("")
        lines.append(f"[Peer]  # {peer['name']}")
        lines.append(f"PublicKey = {peer['public_key']}")
        if peer.get("preshared_key"):
            lines.append(f"PresharedKey = {peer['preshared_key']}")
        lines.append(f"AllowedIPs = {peer['allowed_ips']}")
        if peer.get("endpoint_host") and int(peer.get("endpoint_port") or 0) > 0:
            lines.append(f"Endpoint = {peer['endpoint_host']}:{int(peer['endpoint_port'])}")
        if int(peer.get("keepalive") or 0) > 0:
            lines.append(f"PersistentKeepalive = {int(peer['keepalive'])}")
    return "\n".join(lines) + "\n"


def render_client_config(settings, server_public_key: str, peer: dict,
                         client_private_key: str, lan_network: str) -> str:
    """Downloadable config for a remote-access client. AllowedIPs decides what
    the client routes through the tunnel: only the local network, or
    everything (0.0.0.0/0) when the client should also browse through it."""
    address = str(peer["allowed_ips"]).split(",")[0].strip()
    if "/" not in address:
        address = f"{address}/{ip_network(settings.tunnel_subnet, strict=False).prefixlen}"
    route = "0.0.0.0/0, ::/0" if settings.allow_client_internet else f"{lan_network}"
    endpoint = settings.endpoint_host or "<appliance public address>"
    lines = [
        f"# NetFortress VPN - {peer['name']}",
        "[Interface]",
        f"PrivateKey = {client_private_key}",
        f"Address = {address}",
        "",
        "[Peer]",
        f"PublicKey = {server_public_key}",
    ]
    if peer.get("preshared_key"):
        lines.append(f"PresharedKey = {peer['preshared_key']}")
    lines += [f"AllowedIPs = {route}", f"Endpoint = {endpoint}:{settings.listen_port}"]
    if int(peer.get("keepalive") or 0) > 0:
        lines.append(f"PersistentKeepalive = {int(peer['keepalive'])}")
    return "\n".join(lines) + "\n"


def helper(action: str, transaction: str = "") -> dict:
    """Invoke the root helper (apply/rollback/status/down)."""
    command = ["sudo", "-n", HELPER, action] + ([transaction] if transaction else [])
    completed = subprocess.run(command, capture_output=True, text=True, timeout=60, check=False)
    import json
    try:
        return json.loads(completed.stdout or "{}")
    except ValueError:
        return {"ok": False, "message": (completed.stderr or completed.stdout or "helper returned nothing").strip()[:200]}


def status() -> dict:
    """Live tunnel status: handshake and transfer counters per peer."""
    result = helper("status")
    if not result.get("running"):
        return {"running": False, "peers": {}}
    peers = {}
    for line in (result.get("dump") or "").splitlines()[1:]:
        parts = line.split("\t")
        if len(parts) >= 5:
            peers[parts[0]] = {"endpoint": parts[2], "allowed_ips": parts[3],
                              "latest_handshake": int(parts[4] or 0),
                              "received_bytes": int(parts[5]) if len(parts) > 5 and parts[5].isdigit() else 0,
                              "sent_bytes": int(parts[6]) if len(parts) > 6 and parts[6].isdigit() else 0}
    return {"running": True, "peers": peers, "public_key": result.get("public_key", "")}