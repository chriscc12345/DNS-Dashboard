"""Automatic product updates: the appliance pulls new builds itself.

On each licence-sync cycle (15 minutes) the appliance compares the fleet
notice version with its own build. When the notice is newer, carries a
download URL, a SHA-256 and a server-signed manifest, the appliance:

  1. downloads the package and checks its hash,
  2. stages it through the signed-update path (Ed25519 signature verified
     against the locally installed update public key — the license server
     cannot push anything this appliance did not already trust),
  3. applies it through the fixed root helper: the current code tree is
     backed up first, the package is extracted over /opt/firewall-appliance,
     any post-update deploy script runs (new services, packages), and the
     API restarts into the new build.

Failures are non-fatal and retried on the next cycle. An update that fails
to verify never reaches the apply step.
"""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import subprocess
import urllib.request
from pathlib import Path

from app.licensing import PRODUCT_VERSION
from app.services.recovery_updates import stage_signed_update

_LOG = logging.getLogger(__name__)
STATE = Path("/var/lib/firewall-appliance")
MAX_PACKAGE_BYTES = 400 * 1024 * 1024
HELPER = "/usr/local/sbin/firewall-update"


def _notice(database) -> dict:
    raw = database.setting("product_update")
    return json.loads(raw) if raw else {}


def _already_applied(database, notice: dict) -> bool:
    raw = database.setting("auto_update_state")
    state = json.loads(raw) if raw else {}
    return state.get("applied_version") == notice.get("version") and state.get("applied_sha256") == notice.get("sha256")


def check_and_apply(database) -> dict | None:
    """One cycle of the auto-update check. Returns a result dict when an
    update was processed, None when there is nothing to do."""
    notice = _notice(database)
    version = str(notice.get("version") or "")
    manifest = notice.get("manifest") or {}
    signature = notice.get("signature") or ""
    url = str(notice.get("download_url") or "")
    sha256 = str(notice.get("sha256") or "")
    if not version or version == PRODUCT_VERSION:
        return None
    if _already_applied(database, notice):
        return None
    if not url or not sha256 or not manifest or not signature:
        _LOG.info("Update %s announced but not auto-downloadable (no package manifest) — manual staging applies", version)
        return None
    try:
        package = _download(url)
    except Exception as exc:  # noqa: BLE001 — any download failure retries next cycle
        _LOG.warning("Auto-update download failed (%s); retrying next cycle", exc)
        return {"ok": False, "stage": "download", "message": str(exc)[:200]}
    digest = hashlib.sha256(package).hexdigest()
    if digest != sha256:
        return {"ok": False, "stage": "verify", "message": "Package hash does not match the notice"}
    try:
        staged = stage_signed_update(manifest, signature,
                                     base64.b64encode(package).decode(),
                                     STATE)
    except Exception as exc:  # noqa: BLE001 — bad signature/manifest never applies
        return {"ok": False, "stage": "stage", "message": str(exc)[:200]}
    database.create_security_event({"event_type": "firewall", "action": "applied" if _apply(staged["update_id"], database) else "failed",
                                    "policy": "auto-update", "details": {"version": version, "sha256": sha256[:16], "update_id": staged["update_id"]}})
    database.set_setting("auto_update_state", json.dumps({"applied_version": version, "applied_sha256": sha256}))
    return {"ok": True, "version": version, "update_id": staged["update_id"]}


def _download(url: str) -> bytes:
    if not url.startswith("https://"):
        raise ValueError("Refusing to download an update over a non-HTTPS URL")
    request = urllib.request.Request(url, headers={"User-Agent": "curl/8.0"})
    with urllib.request.urlopen(request, timeout=300) as response:
        package = response.read(MAX_PACKAGE_BYTES + 1)
    if len(package) > MAX_PACKAGE_BYTES:
        raise ValueError("Update package exceeds the size limit")
    return package


def _apply(update_id: str, database) -> bool:
    # systemd-run launches the helper OUTSIDE this service's sandbox namespace
    # (ProtectSystem=strict makes /opt read-only in-process; the transient
    # unit runs unconfined as root — the same pattern as the admin-port helper).
    completed = subprocess.run(["sudo", "-n", "/usr/bin/systemd-run", "--quiet", "--wait", "--pipe",
                                HELPER, "apply", update_id],
                               capture_output=True, text=True, timeout=900, check=False)
    try:
        result = json.loads(completed.stdout or "{}")
    except ValueError:
        result = {"ok": False, "message": (completed.stderr or "helper returned nothing").strip()[:200]}
    if not result.get("ok"):
        database.create_security_event({"event_type": "firewall", "action": "alert", "policy": "auto-update",
                                        "details": {"update_id": update_id, "message": result.get("message", "")}})
    return bool(result.get("ok"))