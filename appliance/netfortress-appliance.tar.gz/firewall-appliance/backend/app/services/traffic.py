"""Bandwidth reports (vnStat, Essential and above — a reporting feature).

vnStat counts per-interface traffic in a tiny local database; this service
summarises it for the dashboard: today, this month and all-time totals per
adapter. vnStat starts counting from its installation day.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from datetime import UTC, datetime


def _fmt(value) -> int:
    try:
        return int(float(value or 0))
    except (TypeError, ValueError):
        return 0


def traffic_summary() -> dict:
    if shutil.which("vnstat") is None:
        return {"available": False, "interfaces": []}
    completed = subprocess.run(["vnstat", "--json"], capture_output=True, text=True, timeout=15, check=False)
    if completed.returncode != 0:
        return {"available": False, "interfaces": []}
    try:
        data = json.loads(completed.stdout)
    except ValueError:
        return {"available": False, "interfaces": []}
    interfaces = []
    for item in data.get("vnstat", []):
        traffic = item.get("traffic", {})
        day = traffic.get("day") or []
        month = traffic.get("month") or []
        total = traffic.get("total") or {}
        today = day[-1] if day else {}
        this_month = month[-1] if month else {}
        interfaces.append({
            "name": item.get("name", ""),
            "today_rx": _fmt(today.get("rx")), "today_tx": _fmt(today.get("tx")),
            "month_rx": _fmt(this_month.get("rx")), "month_tx": _fmt(this_month.get("tx")),
            "alltime_rx": _fmt(total.get("rx")), "alltime_tx": _fmt(total.get("tx")),
            "updated": datetime.now(UTC).isoformat(),
        })
    return {"available": True, "interfaces": interfaces}