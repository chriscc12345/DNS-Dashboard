"""Signed licence refresh, using the existing activation endpoint and verifier."""
from __future__ import annotations

import fcntl
import json
import logging
import os
import tempfile
import threading
import time
import urllib.parse
import urllib.request
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

from app.database import utcnow
from app.license_models import REVOKED_LICENSE_PREFIX, SignedLicenseEnvelope

INTERVAL_SECONDS = 900
_LOG = logging.getLogger(__name__)
_PROCESS_LOCK = threading.RLock()


def _directory(database):
    directory = database.path.resolve().with_name(database.path.name + '.licensing')
    if directory.is_symlink():
        raise RuntimeError('Licence refresh directory must not be a symbolic link')
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    directory.chmod(0o700)
    return directory


@contextmanager
def _locked(database):
    with _PROCESS_LOCK:
        directory = _directory(database)
        fd = os.open(directory / 'lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            yield directory
        finally:
            os.close(fd)


def _load(directory):
    try:
        fd = os.open(directory / 'state.json', os.O_RDONLY | os.O_NOFOLLOW)
    except FileNotFoundError:
        return None
    with os.fdopen(fd, 'r', encoding='utf-8') as stream:
        raw = stream.read(65537)
    if len(raw) > 65536:
        raise RuntimeError('Licence refresh state exceeds size limit')
    state = json.loads(raw)
    if not isinstance(state, dict) or not isinstance(state.get('license_key'), str):
        raise RuntimeError('Invalid licence refresh state')
    return state


def _write(directory, state):
    fd, temporary = tempfile.mkstemp(prefix='.state-', dir=directory)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(state, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, directory / 'state.json')
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _verify(service, envelope):
    from app.services.licensing import installation_id, verify_envelope
    if envelope.payload.installation_id != installation_id(service.database):
        raise ValueError('Licence belongs to a different installation')
    key_path = os.environ.get('FIREWALL_LICENSE_PUBLIC_KEY')
    if not key_path:
        raise ValueError('Licence public verification key is not configured')
    verify_envelope(envelope, Path(key_path).read_bytes())


def _save(service, envelope):
    service.database.save_license(envelope.payload.model_dump_json(), envelope.signature, utcnow())
    if envelope.payload.license_type == 'trial':
        service.database.set_setting('trial_consumed', '1')
    return service.status()


def _fetch(service, key, action):
    from app.services.licensing import installation_id, hardware_fingerprint, PRODUCT_VERSION
    url = os.environ.get('FIREWALL_LICENSE_SERVER_URL')
    if not url:
        raise RuntimeError('Online licensing server is not configured')
    body = json.dumps({'action': action, 'license_key': key,
                       'installation_id': installation_id(service.database),
                       'hardware_fingerprint': hardware_fingerprint(),
                       'product_version': PRODUCT_VERSION}).encode()
    request = urllib.request.Request(url, data=body, headers={
        'Content-Type': 'application/json', 'User-Agent': 'curl/8.0'}, method='POST')
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            raw = response.read(1_000_001)
        if len(raw) > 1_000_000:
            raise ValueError('Oversized licence response')
        envelope = SignedLicenseEnvelope.model_validate_json(raw)
        _verify(service, envelope)
        return envelope
    except Exception as exc:
        # Never return URLs, credentials, response bodies or SQL to the caller.
        raise RuntimeError('Unable to obtain a valid signed licence; existing licence retained') from exc


def _revoke_license_locked(service, directory):
    """A licence deleted on the licence host signs a revocation envelope.
    Drop it completely: licence record cleared, refresh state removed. The
    dashboard shows the unlicensed banner - trial (if never used), a
    purchased key, or the free Home Lite tier. Protection keeps enforcing;
    configuration locks.

    The caller must already hold the refresh lock - re-acquiring the flock
    from the same process on a second file descriptor would deadlock."""
    (directory / 'state.json').unlink(missing_ok=True)
    service.database.clear_license()
    return service.status()


def install_signed_license(service, envelope):
    """Offline replacement disables automatic refresh after verification."""
    with _locked(service.database) as directory:
        _verify(service, envelope)
        (directory / 'state.json').unlink(missing_ok=True)
        return _save(service, envelope)


def activate_signed_license(service, key, action='activate'):
    with _locked(service.database) as directory:
        envelope = _fetch(service, key, action)
        if action == 'activate' and envelope.payload.license_type != 'trial':
            now = datetime.now(UTC).isoformat()
            _write(directory, {
                'license_key': key, 'license_id': envelope.payload.license_id,
                'installation_id': envelope.payload.installation_id,
                'server_url': os.environ['FIREWALL_LICENSE_SERVER_URL'],
                'attempt_epoch': time.time(), 'last_attempt_at': now,
                'last_success_at': now, 'last_result': 'success'})
        else:
            (directory / 'state.json').unlink(missing_ok=True)
        return _save(service, envelope)


def deactivate_license(service):
    with _locked(service.database) as directory:
        (directory / 'state.json').unlink(missing_ok=True)
        service.database.clear_license()


def _eligible(service, state):
    if not state:
        return False, 'Online activation required once to enable refresh'
    record = service.database.license_record()
    if not record:
        return False, 'No installed licence'
    payload = json.loads(record['payload_json'])
    if payload.get('license_type') == 'trial':
        return False, 'Trial refresh is not configured'
    if (payload.get('license_id') != state.get('license_id') or
            payload.get('installation_id') != state.get('installation_id') or
            service.database.setting('installation_id') != state.get('installation_id')):
        return False, 'Saved refresh credentials do not match the installed licence'
    if os.environ.get('FIREWALL_LICENSE_SERVER_URL') != state.get('server_url'):
        return False, 'Licence server changed; activate online again'
    return True, 'Automatic refresh configured'


def refresh_status(service):
    with _locked(service.database) as directory:
        state = _load(directory)
        enabled, reason = _eligible(service, state)
        state = state or {}
        return {'enabled': enabled, 'reason': reason, 'interval_seconds': INTERVAL_SECONDS,
                'last_attempt_at': state.get('last_attempt_at'),
                'last_success_at': state.get('last_success_at'),
                'last_result': state.get('last_result'),
                'product_update': installed_product_update(service.database)}


def _product_update_url():
    url = os.environ.get('FIREWALL_LICENSE_SERVER_URL')
    if not url:
        return None
    return url.rsplit('/', 1)[0] + '/product-update'


def fetch_product_update(service):
    """Poll the licensing host for a published product update (master → fleet
    notification). Failures are non-fatal: a licensing host without the
    endpoint simply reports nothing."""
    from app.services.licensing import installation_id

    url = _product_update_url()
    if not url:
        return
    # Identify ourselves so the licence host can verify the fleet received
    # the notice (the admin console shows which appliances have seen it).
    url += '?installation_id=' + urllib.parse.quote(installation_id(service.database))
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'curl/8.0'}, method='GET')
        with urllib.request.urlopen(request, timeout=10) as response:
            raw = response.read(65_537)
        if len(raw) > 65_536:
            raise ValueError('Oversized product update response')
        update = json.loads(raw)
        if not isinstance(update, dict):
            raise ValueError('Invalid product update response')
        service.database.set_setting('product_update', json.dumps(update))
        return update
    except Exception:
        return None


def installed_product_update(database):
    raw = database.setting('product_update')
    try:
        update = json.loads(raw) if raw else None
        return update if isinstance(update, dict) else None
    except ValueError:
        return None


def refresh_online(service, *, force=False):
    with _locked(service.database) as directory:
        state = _load(directory)
        eligible, reason = _eligible(service, state)
        if not eligible:
            if force:
                raise RuntimeError(reason)
            return None
        now_epoch = time.time()
        elapsed = now_epoch - float(state.get('attempt_epoch', 0))
        if not force and 0 <= elapsed < INTERVAL_SECONDS:
            return None
        state.update(attempt_epoch=now_epoch, last_attempt_at=datetime.now(UTC).isoformat(),
                     last_result='attempting')
        _write(directory, state)
        try:
            envelope = _fetch(service, state['license_key'], 'refresh')
            if envelope.payload.license_id.startswith(REVOKED_LICENSE_PREFIX):
                # The licence was deleted on the licence host: drop it
                # completely and ask for a new one.
                return _revoke_license_locked(service, directory)
            if envelope.payload.license_id != state['license_id']:
                raise ValueError('Refresh returned a different licence')
            result = _save(service, envelope)
        except Exception as exc:
            state['last_result'] = 'failed'
            _write(directory, state)
            raise RuntimeError('Licence refresh failed; existing licence retained when verification fails') from exc
        state.update(last_result='success', last_success_at=datetime.now(UTC).isoformat())
        _write(directory, state)
        _LOG.info('Signed licence refresh succeeded')
        return result


class LicenseRefreshWorker:
    """One background thread per API worker; file lock and timestamps coordinate them."""
    def __init__(self, database):
        self.database = database
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, name='license-refresh', daemon=True)
        self._next_update_poll = 0.0

    def start(self):
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        self.thread.join(timeout=20)

    def _run(self):
        from app.services.licensing import LicenseService
        service = LicenseService(self.database)
        while not self.stop_event.wait(15):
            try:
                refresh_online(service)
            except Exception:
                _LOG.warning('Licence refresh failed; check authenticated licensing refresh status')
                # Also back off when malformed local state prevents timestamp updates.
                if self.stop_event.wait(INTERVAL_SECONDS):
                    break
            # Master → fleet notification: poll the published product update
            # on the same cadence as the licence refresh. Never fatal.
            if time.time() >= self._next_update_poll:
                self._next_update_poll = time.time() + INTERVAL_SECONDS
                try:
                    fetch_product_update(service)
                except Exception:
                    pass
                # Automatic product updates: when the notice is newer than
                # this build and carries a server-signed manifest, pull, verify
                # and apply it. Never fatal — retried on the next cycle.
                try:
                    from app.services.auto_update import check_and_apply
                    check_and_apply(service.database)
                except Exception as exc:
                    _LOG.warning('Auto-update check failed; retrying next cycle: %s', exc)
