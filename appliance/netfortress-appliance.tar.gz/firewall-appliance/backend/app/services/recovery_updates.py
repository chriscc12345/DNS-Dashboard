from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import secrets
import shutil
import tarfile
from datetime import UTC, datetime
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.serialization import load_pem_public_key

from app.services.appliance_ops import validate_backup


def stage_signed_update(manifest: dict, signature_b64: str, package_b64: str, state_dir: str | Path) -> dict:
    required = {"version", "sha256", "size", "minimum_version"}
    if not required <= set(manifest) or not isinstance(manifest["size"], int) or manifest["size"] < 1:
        raise ValueError("Update manifest is missing required fields")
    package = base64.b64decode(package_b64, validate=True)
    if len(package) != manifest["size"] or hashlib.sha256(package).hexdigest() != manifest["sha256"]:
        raise ValueError("Update package size or SHA-256 does not match the signed manifest")
    public_key_path = os.environ.get("FIREWALL_UPDATE_PUBLIC_KEY")
    if not public_key_path:
        raise RuntimeError("FIREWALL_UPDATE_PUBLIC_KEY is not configured")
    key = load_pem_public_key(Path(public_key_path).read_bytes())
    canonical = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()
    try:
        key.verify(base64.b64decode(signature_b64, validate=True), canonical)
    except (InvalidSignature, ValueError) as exc:
        raise ValueError("Update manifest signature is invalid") from exc
    update_id = "update_" + secrets.token_hex(8)
    target = Path(state_dir) / "updates" / update_id
    target.mkdir(parents=True, mode=0o750)
    (target / "package.bin").write_bytes(package)
    metadata = {"update_id": update_id, "status": "staged", "manifest": manifest, "staged_at": datetime.now(UTC).isoformat()}
    (target / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata


def stage_restore(data: bytes, state_dir: str | Path) -> dict:
    validation = validate_backup(data)
    restore_id = "restore_" + secrets.token_hex(8)
    target = Path(state_dir) / "restores" / restore_id
    target.mkdir(parents=True, mode=0o750)
    archive_path = target / "backup.tar.gz"
    archive_path.write_bytes(data)
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        try:
            database = archive.extractfile("data/appliance.db").read()
        except (KeyError, AttributeError) as exc:
            raise ValueError("Backup does not contain an appliance database") from exc
    (target / "appliance.db").write_bytes(database)
    metadata = {"candidate_id": restore_id, "status": "staged", "validation": validation, "staged_at": datetime.now(UTC).isoformat()}
    (target / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata


def apply_restore(candidate_id: str, database_path: str | Path, state_dir: str | Path) -> dict:
    candidate_dir = Path(state_dir) / "restores" / candidate_id
    metadata_path = candidate_dir / "metadata.json"
    candidate = candidate_dir / "appliance.db"
    if not metadata_path.is_file() or candidate.is_symlink() or not candidate.is_file():
        raise FileNotFoundError("Restore candidate not found")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    if metadata.get("status") != "staged":
        raise ValueError("Restore candidate is not staged")
    destination = Path(database_path)
    safety = candidate_dir / "pre-restore-appliance.db"
    if destination.exists():
        shutil.copy2(destination, safety)
    temporary = destination.with_suffix(".restore-new")
    shutil.copy2(candidate, temporary)
    try:
        temporary.replace(destination)
    except Exception:
        if safety.exists():
            shutil.copy2(safety, destination)
        raise
    metadata.update({"status": "applied", "applied_at": datetime.now(UTC).isoformat(), "safety_copy": str(safety) if safety.exists() else None})
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata
