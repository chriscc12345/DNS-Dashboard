from __future__ import annotations

import hashlib
import html
import ipaddress
import json
import os
import re
import socket
import urllib.parse
import urllib.request
from datetime import UTC, datetime, timedelta
from pathlib import Path

from app.models import BlockPageSettings, DnsSettings, PortalSettings, ProxySettings


PORTAL_SET = "fw-portal-accepted"
PORTAL_PORT = 8420


DOMAIN_RE = re.compile(r"^(?=.{1,253}\.?$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.?$", re.I)
MAX_LIST_BYTES = 50 * 1024 * 1024

APPLICATIONS = {
    # social-media
    "facebook": {"category": "social-media", "domains": ["facebook.com", "fb.com", "fbcdn.net", "fbsbx.com", "facebook.net", "messenger.com"]},
    "instagram": {"category": "social-media", "domains": ["instagram.com", "cdninstagram.com", "instagr.am"]},
    "whatsapp": {"category": "social-media", "domains": ["whatsapp.com", "whatsapp.net"]},
    "tiktok": {"category": "social-media", "domains": ["tiktok.com", "tiktokcdn.com", "tiktokv.com", "byteoversea.com", "ibytedtos.com", "musical.ly"]},
    "twitter": {"category": "social-media", "domains": ["twitter.com", "x.com", "twimg.com", "t.co", "periscope.tv"]},
    "snapchat": {"category": "social-media", "domains": ["snapchat.com", "sc-cdn.net", "snapkit.com"]},
    "discord": {"category": "social-media", "domains": ["discord.com", "discordapp.com", "discordapp.net", "discord.media", "dis.gg"]},
    "reddit": {"category": "social-media", "domains": ["reddit.com", "redd.it", "redditstatic.com", "redditinc.com"]},
    "telegram": {"category": "social-media", "domains": ["telegram.org", "t.me", "telegram-cdn.org", "telesco.pe"]},
    "linkedin": {"category": "social-media", "domains": ["linkedin.com", "licdn.com", "lnkd.in"]},
    "pinterest": {"category": "social-media", "domains": ["pinterest.com", "pin.it", "pinimg.com"]},
    # streaming-media
    "youtube": {"category": "streaming-media", "domains": ["youtube.com", "youtu.be", "googlevideo.com", "ytimg.com", "youtube-nocookie.com", "yt3.ggpht.com"]},
    "netflix": {"category": "streaming-media", "domains": ["netflix.com", "nflxvideo.net", "nflximg.net", "nflxext.com", "netflix.net"]},
    "twitch": {"category": "streaming-media", "domains": ["twitch.tv", "ttvnw.net", "twitchcdn.net", "jtvnw.net"]},
    "spotify": {"category": "streaming-media", "domains": ["spotify.com", "scdn.co", "spotifycdn.com", "pscdn.co"]},
    "showmax": {"category": "streaming-media", "domains": ["showmax.com", "showmax-a.akamaihd.net"]},
    # gambling
    "bet365": {"category": "gambling", "domains": ["bet365.com", "bet365.com.au", "365sb.com", "b365network.com"]},
    "betway": {"category": "gambling", "domains": ["betway.com", "betway.co.za", "betway.africa"]},
    "hollywoodbets": {"category": "gambling", "domains": ["hollywoodbets.net", "hollywoodbets.mobi", "hvbingo.com", "afri88.com"]},
    "supabets": {"category": "gambling", "domains": ["supabets.co.za", "supabets.com", "supabets.mobi"]},
    "lottostar": {"category": "gambling", "domains": ["lottostar.co.za", "lottostar.mobi"]},
    "sunbet": {"category": "gambling", "domains": ["sunbet.co.za", "suninternational.com"]},
    "sportingbet": {"category": "gambling", "domains": ["sportingbet.com", "sportingbet.co.za"]},
    # adult
    "pornhub": {"category": "adult", "domains": ["pornhub.com", "phncdn.com", "pornhubpremium.com"]},
    "xvideos": {"category": "adult", "domains": ["xvideos.com", "xvideos-red.com", "xv-cdn.com"]},
    "xnxx": {"category": "adult", "domains": ["xnxx.com", "xnxx-cdn.com", "xnx-cdn.net"]},
    "onlyfans": {"category": "adult", "domains": ["onlyfans.com", "ofcdn.com", "myln.be"]},
    # gaming
    "steam": {"category": "gaming", "domains": ["steampowered.com", "steamcommunity.com", "steamcontent.com", "steamserver.net", "steamstatic.com"]},
    "epicgames": {"category": "gaming", "domains": ["epicgames.com", "unrealengine.com", "epicgames.dev"]},
    "roblox": {"category": "gaming", "domains": ["roblox.com", "rbxcdn.com", "roblox.tools"]},
    "xbox": {"category": "gaming", "domains": ["xbox.com", "xboxlive.com", "xboxservices.com"]},
    "playstation": {"category": "gaming", "domains": ["playstation.com", "sony.com", "playstation.net"]},
}

# Curated category registry. Feeds follow the StevenBlack unified-hosts layout:
# every entry of a variant list also contains the base ads/malware domains.
CATEGORY_FEEDS = {
    "ads-trackers": {
        "name": "StevenBlack — Ads & Malware",
        "url": "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
    },
    "adult": {
        "name": "StevenBlack — Adult content",
        "url": "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/porn/hosts",
    },
    "gambling": {
        "name": "StevenBlack — Gambling",
        "url": "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/gambling/hosts",
    },
    "social-media": {
        "name": "StevenBlack — Social media",
        "url": "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/social/hosts",
    },
    "fakenews": {
        "name": "StevenBlack — Fake news",
        "url": "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/fakenews/hosts",
    },
    "drugs": {
        "name": "Block List Project — Drugs",
        "url": "https://raw.githubusercontent.com/blocklistproject/Lists/master/drugs.txt",
    },
}

CATEGORY_LABELS = {
    "adult": "Adult / nudity",
    "ads-trackers": "Ads and trackers",
    "drugs": "Drugs and pharmacies",
    "fakenews": "Fake news",
    "gambling": "Gambling and betting",
    "gaming": "Online gaming",
    "social-media": "Social media",
    "streaming-media": "Streaming and media",
}


def category_names() -> list[str]:
    names = {definition["category"] for definition in APPLICATIONS.values()}
    names.update(CATEGORY_FEEDS)
    return sorted(names)


def normalize_domain(value: str) -> str:
    domain = value.strip().lower().rstrip(".")
    try:
        domain = domain.encode("idna").decode("ascii")
    except UnicodeError as exc:
        raise ValueError(f"Invalid domain: {value}") from exc
    if not DOMAIN_RE.fullmatch(domain):
        raise ValueError(f"Invalid domain: {value}")
    return domain


def parse_blocklist(text: str, format_name: str) -> set[str]:
    domains: set[str] = set()
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if format_name == "hosts":
            fields = line.split()
            candidates = fields[1:] if fields and _is_ip(fields[0]) else fields
        else:
            candidates = [line.split()[0]]
        for candidate in candidates:
            if candidate.lower() in {"localhost", "localhost.localdomain", "broadcasthost", "ip6-allnodes", "ip6-allrouters"}:
                continue
            try:
                domains.add(normalize_domain(candidate))
            except ValueError:
                continue
    return domains


def _is_ip(value: str) -> bool:
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def _safe_https_url(url: str) -> str:
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Blocklist URL must be HTTPS without embedded credentials")
    addresses = {item[4][0] for item in socket.getaddrinfo(parsed.hostname, parsed.port or 443, type=socket.SOCK_STREAM)}
    if not addresses or any(ipaddress.ip_address(address).is_private or ipaddress.ip_address(address).is_loopback or ipaddress.ip_address(address).is_link_local for address in addresses):
        raise ValueError("Blocklist URL resolves to a private or unsafe address")
    return url


def update_blocklist(source: dict, state_dir: str | Path | None = None) -> dict:
    url = _safe_https_url(source["url"])
    request = urllib.request.Request(url, headers={"User-Agent": "Firewall-Appliance/1.0", "Accept": "text/plain"})
    with urllib.request.urlopen(request, timeout=20) as response:
        content = response.read(MAX_LIST_BYTES + 1)
    if len(content) > MAX_LIST_BYTES:
        raise ValueError("Blocklist exceeds the 50 MiB safety limit")
    text = content.decode("utf-8", errors="replace")
    domains = parse_blocklist(text, source["format"])
    if not domains:
        raise ValueError("Blocklist did not contain any valid domains")
    root = Path(state_dir or os.environ.get("FIREWALL_STATE_DIR", "./state")) / "blocklists"
    root.mkdir(parents=True, exist_ok=True)
    rendered = "\n".join(sorted(domains)) + "\n"
    target = root / f"source-{source['id']}.domains"
    temporary = target.with_suffix(".tmp")
    temporary.write_text(rendered, encoding="utf-8")
    temporary.replace(target)
    return {"domain_count": len(domains), "sha256": hashlib.sha256(rendered.encode()).hexdigest(), "path": str(target)}


def update_due_blocklists(database, *, force: bool = False) -> dict:
    now = datetime.now(UTC)
    results: list[dict] = []
    for source in database.blocklists():
        if not source["enabled"]:
            continue
        last = datetime.fromisoformat(source["last_updated_at"]) if source.get("last_updated_at") else None
        if not force and last and now < last + timedelta(hours=source["update_hours"]):
            results.append({"id": source["id"], "name": source["name"], "status": "not_due"})
            continue
        try:
            updated = update_blocklist(source)
            database.update_blocklist_status(source["id"], status="healthy", domain_count=updated["domain_count"], digest=updated["sha256"])
            results.append({"id": source["id"], "name": source["name"], "status": "updated", **updated})
        except Exception as exc:
            database.update_blocklist_status(source["id"], status="failed", domain_count=source.get("domain_count", 0), digest=source.get("content_sha256"), error=str(exc))
            results.append({"id": source["id"], "name": source["name"], "status": "failed", "error": str(exc), "last_known_good_retained": True})
    return {"checked_at": now.isoformat(), "sources": results}


def application_catalog(policies: list[dict], custom_services: list[dict] | None = None, service_extensions: list[dict] | None = None) -> list[dict]:
    """The full service catalog: built-in curated services plus the custom
    services the administrator created (they behave identically: same toggles,
    same enforcement, same group membership). Domains the administrator added
    to a service are merged in (for example threads.com onto instagram)."""
    selected = {row["application"].lower(): row for row in policies}
    extensions = {str(row["name"]).lower(): [str(item) for item in (row.get("domains") or [])] for row in (service_extensions or [])}
    catalog = [{"name": name, **definition, "enabled": bool(selected.get(name, {}).get("enabled", False)), "block_quic": bool(selected.get(name, {}).get("block_quic", True))} for name, definition in APPLICATIONS.items()]
    for service in (custom_services or []):
        name = str(service["name"]).lower()
        if any(item["name"] == name for item in catalog):
            continue
        catalog.append({"name": name, "category": service["category"], "domains": list(service.get("domains") or []), "enabled": bool(selected.get(name, {}).get("enabled", False)), "block_quic": bool(selected.get(name, {}).get("block_quic", True)), "custom": True})
    for item in catalog:
        extra = extensions.get(item["name"])
        if extra:
            item["domains"] = list(dict.fromkeys(list(item.get("domains") or []) + extra))
            item["extended"] = True
    return catalog


def category_catalog(policies: list[dict] | None = None, blocklists: list[dict] | None = None, custom_services: list[dict] | None = None, service_extensions: list[dict] | None = None) -> list[dict]:
    applications = application_catalog(policies or [], custom_services or [], service_extensions or [])
    sources = {str(row.get("category") or "").strip().lower(): row for row in (blocklists or []) if str(row.get("category") or "").strip()}
    catalog: list[dict] = []
    for name in category_names():
        category_apps = [item for item in applications if item["category"] == name]
        feed = CATEGORY_FEEDS.get(name)
        source = sources.get(name)
        apps_enabled = all(item["enabled"] for item in category_apps) if category_apps else False
        apps_on = sum(1 for item in category_apps if item["enabled"])
        feed_registered = feed is not None and source is not None
        feed_enabled = bool(source.get("enabled")) if source else False
        # Feed-only categories are enforced by their feed; app categories need
        # their apps on (and their feed when one is registered).
        if category_apps:
            active = apps_enabled and (not feed_registered or feed_enabled)
        else:
            active = feed_registered and feed_enabled
        # Card honesty: everything on -> blocking; something on -> partial;
        # nothing on -> off.
        if active:
            state = "blocking"
        elif apps_on > 0 or feed_enabled:
            state = "partial"
        else:
            state = "off"
        catalog.append({
            "name": name,
            "label": CATEGORY_LABELS.get(name, name.replace("-", " ").title()),
            "applications": [item["name"] for item in category_apps],
            "app_count": len(category_apps),
            "feed": {"name": feed["name"], "url": feed["url"]} if feed else None,
            "feed_source_id": source["id"] if source else None,
            "feed_registered": feed_registered,
            "feed_enabled": feed_enabled if feed_registered else False,
            "feed_domain_count": source.get("domain_count", 0) if source else 0,
            "feed_status": source.get("status") if source else ("unregistered" if feed else None),
            "apps_enabled_count": apps_on,
            "enabled": active,
            "state": state,
        })
    return catalog


# ---- Related-domain discovery: find every hostname a site really uses ----

QUOTED_HOST_RE = re.compile(r"""(?:href|src|data-src|action|data-domain)\s*=\s*[\"'][^\"']*?(?:https?:)?//([A-Za-z0-9.-]+\.[A-Za-z]{2,})""", re.I)
SRCSET_HOST_RE = re.compile(r"""(?:https?:)?//([A-Za-z0-9.-]+\.[A-Za-z]{2,})/[^\s\"'()]+""", re.I)
CSS_URL_RE = re.compile(r"""((?:https?:)?//[A-Za-z0-9.-]+/[^\s\"']*?\.css[^\s\"']*)""", re.I)


def hosts_from_markup(text: str) -> set[str]:
    """Every public hostname referenced by a page's attributes, srcsets and CSS imports."""
    found: set[str] = set()
    for pattern in (QUOTED_HOST_RE, SRCSET_HOST_RE, CSS_URL_RE):
        for host in pattern.findall(text):
            host = host.lower().strip(".")
            if host.endswith("."):
                host = host[:-1]
            if DOMAIN_RE.fullmatch(host):
                found.add(normalize_domain(host))
    return found


def _public_only(host: str) -> bool:
    """A scan may never reach into private networks — public internet only."""
    try:
        addresses = {item[4][0].split("%")[0] for item in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)}
    except OSError:
        return False
    for address in addresses:
        try:
            parsed = ipaddress.ip_address(address)
        except ValueError:
            return False
        if parsed.is_private or parsed.is_loopback or parsed.is_link_local or parsed.is_reserved:
            return False
    return True


def discover_related_domains(domain: str, max_stylesheets: int = 4) -> list[str]:
    """Load the site and list every hostname it depends on — the practical way
    to find a service's CDN and asset domains before adding it to a group.
    Raises ValueError for anything that is not a public, reachable site."""
    target = normalize_domain(domain)
    if not DOMAIN_RE.fullmatch(target):
        raise ValueError("That does not look like a domain name.")
    if not _public_only(target):
        raise ValueError("That domain is not on the public internet — internal addresses may not be scanned.")
    hosts: set[str] = set()
    # Many real sites refuse the default Python user-agent with a 403, which
    # would make the scanner useless — request like a browser instead.
    headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36", "Accept": "text/html,application/xhtml+xml"}
    page: str | None = None
    for scheme in ("https", "http"):
        try:
            request = urllib.request.Request(f"{scheme}://{target}/", headers=headers)
            with urllib.request.urlopen(request, timeout=10) as response:
                page = response.read(1024 * 1024).decode("utf-8", "replace")
                break
        except (OSError, ValueError):
            continue
    if page is None:
        raise ValueError("Could not load the site — it may be down, or it refuses simple requests.")
    hosts |= hosts_from_markup(page)
    for asset in CSS_URL_RE.findall(page)[:max_stylesheets]:
        url = asset if asset.startswith("http") else f"https:{asset}"
        host = url.split("//", 1)[1].split("/", 1)[0]
        if not DOMAIN_RE.fullmatch(host.lower().strip(".")) or not _public_only(host):
            continue
        try:
            asset_request = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(asset_request, timeout=8) as response:
                hosts |= hosts_from_markup(response.read(512 * 1024).decode("utf-8", "replace"))
        except (OSError, ValueError):
            continue
    hosts.discard(target)
    return sorted(hosts)


def compiled_domains(local: list[dict], policies: list[dict], blocklists: list[dict] | None = None, state_dir: str | Path | None = None, custom_services: list[dict] | None = None, service_extensions: list[dict] | None = None) -> dict:
    now = datetime.now(UTC).isoformat()
    def _active(row: dict) -> bool:
        expires = row.get("expires_at")
        return not expires or expires > now  # time-limited rules stop counting once expired
    def _covered(domain: str, roots: set[str]) -> bool:
        labels = domain.split(".")
        return any(".".join(labels[index:]) in roots for index in range(len(labels)))

    allow = {normalize_domain(row["domain"]) for row in local if row["action"] == "allow" and _active(row)}
    local_blocked = {normalize_domain(row["domain"]) for row in local if row["action"] == "block" and _active(row)}
    custom_map = {str(service["name"]).lower(): list(service.get("domains") or []) for service in (custom_services or [])}
    extensions_map = {str(row["name"]).lower(): [str(item) for item in (row.get("domains") or [])] for row in (service_extensions or [])}
    def _domains_of(name: str) -> list[str]:
        base = APPLICATIONS[name]["domains"] if name in APPLICATIONS else custom_map.get(name, [])
        return list(dict.fromkeys(list(base) + extensions_map.get(name, [])))
    app_blocked: set[str] = set()
    excluded: set[str] = set()
    for row in policies:
        name = row["application"].lower()
        if name not in APPLICATIONS and name not in custom_map:
            continue  # unknown service name — never enforce anything
        domains = _domains_of(name)
        if row["enabled"]:
            app_blocked.update(domains)
        else:
            # A service switched off inside a group must stop blocking even
            # when the group's feed also carries its domains — the feed is a
            # bulk implementation detail; the per-service switches are the
            # administrator's intent. Only feeds are freed this way: explicit
            # local block rules and other enabled services still enforce.
            excluded |= set(domains)
    feed_blocked: set[str] = set()
    root = Path(state_dir or os.environ.get("FIREWALL_STATE_DIR", "./state")) / "blocklists"
    enabled_sources: set[int] | None = None
    if blocklists is not None:
        enabled_sources = {row["id"] for row in blocklists if row.get("enabled")}
    if root.exists():
        for path in root.glob("source-*.domains"):
            source_id = int(path.stem.split("-")[1])
            if enabled_sources is not None and source_id not in enabled_sources:
                continue
            feed_blocked.update(line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip())
    # An allow covers its domain and everything under it. Feeds carry literal
    # subdomains (static.xx.fbcdn.net under fbcdn.net), so an exact set
    # difference is not enough — without this an approved site loads half-broken.
    blocked = local_blocked | app_blocked | {domain for domain in feed_blocked if not _covered(domain, excluded)}
    blocked = {domain for domain in blocked if not _covered(domain, allow)}
    return {"blocked": sorted(blocked), "allowed": sorted(allow), "blocked_count": len(blocked)}


def render_dns_config(settings: DnsSettings, domains: list[str], records: list[dict] | None = None) -> str:
    payload = {"version": 1, "settings": settings.model_dump(), "blocked_domains": domains, "local_records": records or []}
    return json.dumps(payload, indent=2, sort_keys=True) + "\n"


def render_dnsmasq_config(settings: DnsSettings, blocked: list[str], records: list[dict] | None = None) -> str:
    """Produce the live dnsmasq configuration consumed by the DNS transaction helper."""
    lines = [
        "# Generated by NetFortress — managed file, do not edit",
        "port=53",
        "domain-needed",
        "bogus-priv",
        "no-resolv",
        "no-poll",
        "cache-size=10000",
        "local-service",
    ]
    for upstream in settings.upstream_servers:
        lines.append(f"server={upstream}")
    # dnsmasq + bind-style filtering silently drops packets whose destination
    # is not a configured address, so wildcard addresses must never be emitted.
    for address in settings.listen_addresses:
        if address not in {"0.0.0.0", "::"}:
            lines.append(f"listen-address={address}")
    if settings.dnssec_validation:
        lines.append("# DNSSEC validation is delegated to the upstream resolvers above")
    if settings.block_hostname and settings.block_page_ipv4:
        # The branded block URL resolves to the appliance; nginx redirects blocked hosts to it.
        record = f"host-record={settings.block_hostname},{settings.block_page_ipv4}"
        if settings.block_page_ipv6:
            record += f",{settings.block_page_ipv6}"
        lines.append(record)
    for record in records or []:
        if record["record_type"] in {"A", "AAAA"}:
            lines.append(f"host-record={record['name']},{record['value']}")
        else:
            lines.append(f"cname={record['name']},{record['value']}")
    if settings.block_response == "block_page" and settings.block_page_ipv4:
        for domain in blocked:
            # IPv4 answer serves the block page; the bare entry returns NODATA for
            # AAAA and every other type so IPv6 cannot bypass the filter.
            lines.append(f"address=/{domain}/{settings.block_page_ipv4}")
            lines.append(f"address=/{domain}/")
        if settings.block_page_ipv6:
            for domain in blocked:
                lines.append(f"address=/{domain}/{settings.block_page_ipv6}")
    else:
        for domain in blocked:
            lines.append(f"address=/{domain}/")
    return "\n".join(lines) + "\n"


def render_dnsmasq_with_overrides(settings: DnsSettings, compiled: dict, records: list[dict] | None = None) -> str:
    config = render_dnsmasq_config(settings, compiled["blocked"], records)
    overrides = "".join(f"server=/{domain}/#\n" for domain in compiled.get("allowed", []))
    if overrides:
        config = config + "# Explicit allow overrides (highest precedence)\n" + overrides
    return config


def validate_dnsmasq_config(path: str) -> dict:
    import shutil
    import subprocess

    binary = shutil.which("dnsmasq")
    if not binary:
        return {"valid": False, "available": False, "message": "dnsmasq is not installed"}
    result = subprocess.run([binary, "--test", f"--conf-file={path}"], text=True, capture_output=True, timeout=60, check=False)
    return {"valid": result.returncode == 0, "available": True, "message": (result.stderr or result.stdout or "dnsmasq syntax accepted").strip()}


def render_nginx_block_site(hostname: str, dashboard_names: list[str] | None = None) -> str:
    """Nginx configuration for port 80.

    Three responsibilities, separated by Host header:
    1. Requests addressed to the appliance itself keep reaching the dashboard
       (proxied to the API process) — management access must never be hijacked.
    2. Any other host is a blocked domain resolving to this appliance; browsers
       are redirected to the branded block URL.
    3. The block hostname itself serves the branded page.
    """
    names = " ".join(sorted({"localhost", *(dashboard_names or [])}))
    return f'''# Generated by NetFortress — managed file, do not edit
server {{
    listen 80;
    listen [::]:80;
    server_name {names};
    # Logo/page uploads go through this proxy; nginx's 1 MiB default would
    # reject them with a plain-HTML error before the API could answer JSON.
    client_max_body_size 5m;
    location / {{
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }}
}}
server {{
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    # Every blocked domain resolves to this appliance; send browsers to the branded page.
    return 302 http://{hostname}/?host=$host;
}}
server {{
    listen 80;
    listen [::]:80;
    server_name {hostname};
    # The block hostname is served over HTTPS (real or appliance certificate);
    # plain-HTTP visits upgrade so users always see the padlocked branded page.
    return 301 https://{hostname}$request_uri;
}}
'''


def render_redirect_page(settings: BlockPageSettings) -> str:
    """Stub served when blocked sites should land on an external URL instead:
    the browser is sent to redirect_url with ?host=<requested site> appended."""
    target = json.dumps(settings.redirect_url)
    return f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Redirecting</title><meta http-equiv="refresh" content="0; url={html.escape(settings.redirect_url, quote=True)}"></head><body style="background:#071019;color:#edf7ff;font:16px system-ui;display:grid;min-height:100vh;place-items:center"><main><p>Redirecting you to the network notice page…</p></main><script>
(function(){{
  try {{
    var target = {target};
    var host = new URLSearchParams(window.location.search).get("host") || window.location.hostname;
    var joiner = target.indexOf("?") > -1 ? "&" : "?";
    window.location.replace(target + joiner + "host=" + encodeURIComponent(host));
  }} catch (error) {{}}
}})();
</script></body></html>'''


def render_block_page_live(settings: BlockPageSettings) -> str:
    """The deployed block page. Three modes, in priority order:
    1. redirect_url set -> a stub that forwards browsers to the external page
       (with ?host=<requested site> so that page can name the blocked site).
    2. custom_html_active -> the administrator's own uploaded page, with the
       same placeholders available as the generated one.
    3. the generated branded page."""
    state_dir = Path(os.environ.get("FIREWALL_STATE_DIR", "./state"))
    logo = state_dir / "block-page-logo"
    if settings.redirect_url:
        return render_redirect_page(settings)
    if settings.custom_html_active and settings.custom_html.strip():
        page = settings.custom_html
    else:
        page = render_block_page(settings, logo_available=logo.is_file())
    page = (
        page.replace("{{REQUESTED_HOST}}", '<span id="fw-requested-host">this site</span>')
        .replace("{{CLIENT_IP}}", '<span id="fw-client-ip">this device</span>')
        .replace("{{HOSTNAME}}", '<span id="fw-hostname">this device</span>')
        .replace("{{POLICY}}", '<span id="fw-policy">the active network policy</span>')
    )
    script = """<script>
(function(){
  try {
    var host = new URLSearchParams(window.location.search).get("host");
    if (host) {
      var el = document.getElementById("fw-requested-host");
      if (el) { el.textContent = host; }
      document.title = "Access blocked: " + host;
    }
    fetch("/api/v1/block-page/client-info" + (host ? "?host=" + encodeURIComponent(host) : ""))
      .then(function(response) { return response.json(); })
      .then(function(info) {
        var fill = function(id, value) { var el = document.getElementById(id); if (el && value) { el.textContent = value; } };
        fill("fw-client-ip", info.client_ip);
        fill("fw-hostname", info.hostname);
        fill("fw-policy", info.policy);
      })
      .catch(function() {});
  } catch (error) {}
  var form = document.getElementById("fw-access-request");
  var send = document.getElementById("fw-request-send");
  var result = document.getElementById("fw-request-result");
  var statusUrl = "/api/v1/access-requests/status" + (host ? "?host=" + encodeURIComponent(host) : "");
  function showResult(text, colour) { if (result) { result.textContent = text; result.style.color = colour || ""; } }
  function openApprovedSite() {
    // Send the client back to the site they asked for — reloading the block
    // page would just show the block page again.
    if (host && /^[a-z0-9.-]+$/i.test(host)) { window.location.replace("https://" + host + "/"); }
    else { window.location.reload(); }
  }
  function applyDecision(body) {
    if (body.status === "approved") {
      if (form) { form.style.display = "none"; }
      var tries = 0;
      try { tries = Number(sessionStorage.getItem("fw-tries-" + host) || 0); } catch (error) {}
      if (tries === 0) {
        try { sessionStorage.setItem("fw-tries-" + host, "1"); } catch (error) {}
        var remaining = 3;
        showResult("Approved! This site is now allowed — opening " + host + " in " + remaining + "…", "#35d49a");
        var countdown = setInterval(function() {
          remaining -= 1;
          if (remaining > 0) { showResult("Approved! This site is now allowed — opening " + host + " in " + remaining + "…", "#35d49a"); }
          else { clearInterval(countdown); openApprovedSite(); }
        }, 1000);
      } else if (tries <= 5) {
        try { sessionStorage.setItem("fw-tries-" + host, String(tries + 1)); } catch (error) {}
        showResult("Approved — the allow is being applied. Re-opening " + host + " in 20 seconds…", "#35d49a");
        setTimeout(openApprovedSite, 20000);
      } else {
        showResult("Approved! This site is now allowed — press refresh to open it.", "#35d49a");
      }
    } else if (body.status === "denied") {
      showResult("Your administrator declined this request" + (body.review_note ? ": " + body.review_note : ". You can send a new request with a better reason."), "#ff6678");
    } else if (body.status === "pending") {
      showResult("Waiting for your administrator to review this request…");
      if (form) { form.style.display = "none"; }
      setTimeout(pollStatus, 5000);
    } else if (form) { form.style.display = "block"; }
  }
  function pollStatus() {
    fetch(statusUrl).then(function(response) { return response.json(); }).then(applyDecision).catch(function() { setTimeout(pollStatus, 15000); });
  }
  pollStatus();
  if (send) {
    send.addEventListener("click", function() {
      var note = (document.getElementById("fw-request-note") || {}).value || "";
      if (!note.trim()) { showResult("Please write a short reason first."); return; }
      send.disabled = true; send.textContent = "Sending…";
      fetch("/api/v1/access-requests", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({requested_host: host || "the blocked site", reason: note.trim().slice(0, 900)})
      }).then(function(response) {
        if (response.ok) { pollStatus(); }
        else { showResult("Could not send the request — contact your administrator."); send.disabled = false; send.textContent = "Request access"; }
      }).catch(function() {
        showResult("Could not send the request.");
        send.disabled = false; send.textContent = "Request access";
      });
    });
  }
})();
</script></body>"""
    return page.replace("</body>", script)


def render_portal_page(settings: PortalSettings, enroll_base: str = "") -> str:
    """The policy-acceptance captive portal page (served by nginx on the portal
    port; only devices that have not yet accepted are redirected here).

    enroll_base: absolute address of the appliance (e.g. http://192.168.100.2).
    The portal renders under whatever URL the client originally requested —
    the transparent redirect keeps the original host — so every link MUST be
    absolute and point at the appliance itself."""
    title, organization, message, support = map(html.escape, (settings.title, settings.organization, settings.message, settings.support_contact))
    enroll_href = f"{enroll_base.rstrip('/')}/enroll" if enroll_base else "#"
    return f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>body{{margin:0;background:#071019;color:#edf7ff;font:16px system-ui;display:grid;min-height:100vh;place-items:center;padding:20px}}main{{max-width:640px;padding:34px;border:1px solid #233545;border-radius:18px;background:#0d1823}}h1{{color:#35d49a;margin:0 0 4px}}h2{{color:#91a6b8;font-weight:400;margin:0 0 18px;font-size:15px}}p{{line-height:1.7}}button{{width:100%;padding:14px;border:0;border-radius:12px;background:linear-gradient(135deg,#36a3ff,#35d49a);color:#08121b;font-size:16px;font-weight:700;cursor:pointer}}.ok{{display:none}}.err{{display:none;color:#ff6678}}.after{{display:none;margin-top:20px;padding-top:18px;border-top:1px solid #233545}}.after a{{color:#36a3ff}}</style></head><body><main><div id="form"><h1>{title}</h1><h2>{organization}</h2><p>{message}</p><p style="color:#91a6b8;font-size:13px">{support}</p><p style="color:#91a6b8;font-size:13px">On acceptance, this device can install the network's security certificate so blocked-site pages display correctly on secure (https) sites.</p><button id="accept">I accept — connect this device</button><p id="err" class="err"></p></div><div id="ok" class="after"><h1>You're connected</h1><p>Thank you. This device now has internet access through the network firewall.</p><p><b>Recommended:</b> install the network security certificate so branded block pages also show on https sites — it takes one click.</p><p><a id="enroll" href="{enroll_href}" target="_blank" rel="noopener">Install the network certificate →</a></p><p style="color:#91a6b8;font-size:13px">If browsing does not start immediately, turn Wi-Fi off and on again.</p></div></main><script>
(function(){{
  var accept=document.getElementById('accept'),form=document.getElementById('form'),ok=document.getElementById('ok'),err=document.getElementById('err');
  accept.addEventListener('click',function(){{
    accept.disabled=true;accept.textContent='Connecting this device…';
    fetch('/portal-accept',{{method:'POST',credentials:'omit'}}).then(function(response){{return response.json()}}).then(function(body){{
      if(body.ok){{form.style.display='none';ok.style.display='block';}}
      else{{accept.disabled=false;accept.textContent='I accept — connect this device';err.textContent=body.message||'Could not register this device. Reconnect to the Wi-Fi and try again.';err.style.display='block';}}
    }}).catch(function(){{accept.disabled=false;accept.textContent='I accept — connect this device';err.textContent='Connection failed. Reconnect to the Wi-Fi and try again.';err.style.display='block';}});
  }});
}})();
</script></body></html>'''


def render_portal_nginx_site() -> str:
    """The portal vhost on the dedicated portal port: static acceptance page
    plus a proxy for the accept action back to the appliance API."""
    return f'''server {{
    listen {PORTAL_PORT} default_server;
    listen [::]:{PORTAL_PORT} default_server;
    server_name _;
    root /var/www/firewall-portal;
    location / {{
        try_files $uri /index.html =404;
    }}
    # Enrollment paths pass straight through to the appliance even while a
    # device is still unaccepted — the certificate install must never bounce
    # back to the portal page.
    location /enroll {{
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Host $host;
    }}
    location /api/v1/block-page/ {{
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Host $host;
    }}
    location = /portal-accept {{
        proxy_pass http://127.0.0.1:8080/api/v1/portal/accept;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Host $host;
    }}
}}
'''


def render_squid_config(settings: ProxySettings) -> str:
    lines = [f"http_port {settings.listen_port}", "acl localnet src 10.0.0.0/8", "acl localnet src 172.16.0.0/12", "acl localnet src 192.168.0.0/16", "http_access allow localnet", "http_access deny all"]
    if settings.cache_enabled:
        lines.extend([f"cache_mem {settings.memory_cache_mb} MB", f"cache_dir ufs /var/spool/squid {settings.cache_size_mb} 16 256", f"maximum_object_size {settings.max_object_mb} MB"])
    else:
        lines.extend(["cache deny all", "cache_mem 0 MB"])
    lines.append("# TLS inspection remains disabled" if not settings.tls_inspection else "# TLS inspection requested; CA provisioning and explicit approval are required")
    return "\n".join(lines) + "\n"


ACCESS_REQUEST_FORM = """<div id="fw-access-request" style="display:none;margin-top:22px;padding-top:16px;border-top:1px solid #233545"><h3 style="margin:0 0 6px">Need this site for your work?</h3><p style="color:#91a6b8;font-size:14px;margin:0 0 10px">Tell your administrator why. They will review it and can allow this site.</p><textarea id="fw-request-note" rows="2" placeholder="Why do you need access to this site?" style="width:100%;box-sizing:border-box;background:#070b10;color:#edf7ff;border:1px solid #233545;border-radius:10px;padding:10px;font:inherit"></textarea><div style="display:flex;gap:10px;margin-top:8px;align-items:center;flex-wrap:wrap"><button id="fw-request-send" type="button" style="padding:10px 16px;border:0;border-radius:10px;background:#36a3ff;color:#06111a;font-weight:800;cursor:pointer">Request access</button><span id="fw-request-result" style="font-size:13px"></span></div></div>"""


def render_block_page(settings: BlockPageSettings, logo_available: bool = False) -> str:
    checks = lambda enabled, token: f'<div><strong>{token}</strong>: {{{{{token}}}}}</div>' if enabled else ""
    title, organization, message, support = map(html.escape, (settings.title, settings.organization, settings.message, settings.support_contact))
    logo = f'<img src="/api/v1/block-page/logo" alt="{organization}" style="max-height:72px;max-width:260px;margin:0 auto 14px;display:block">' if (settings.show_logo and logo_available) else ""
    footer = f'<p style="color:#5f7385;font-size:13px;margin:26px 0 0">{html.escape(settings.footer_text)}</p>' if settings.footer_text else ""
    policy = f'<p style="margin:22px 0 0"><a href="{html.escape(settings.policy_url, quote=True)}" target="_blank" rel="noopener" style="color:{settings.accent_color}">Read the full network policy</a></p>' if settings.policy_url else ""
    access_form = ACCESS_REQUEST_FORM if settings.allow_access_requests else ""
    return f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>{title}</title><style>body{{margin:0;background:{settings.background_color};color:#edf7ff;font:16px system-ui;display:grid;min-height:100vh;place-items:center}}main{{max-width:680px;padding:40px;border:1px solid #233545;border-radius:18px;background:#0d1823}}h1{{color:{settings.accent_color}}}.meta{{color:#91a6b8;line-height:1.8}}</style></head><body><main>{logo}<h1>{title}</h1><h2>{organization}</h2><p>{message}</p><div class="meta"><div><strong>Requested site</strong>: {{{{REQUESTED_HOST}}}}</div>{checks(settings.show_client_ip, 'CLIENT_IP')}{checks(settings.show_hostname, 'HOSTNAME')}{checks(settings.show_policy, 'POLICY')}</div><p>{support}</p>{policy}{access_form}{footer}</main></body></html>'''
