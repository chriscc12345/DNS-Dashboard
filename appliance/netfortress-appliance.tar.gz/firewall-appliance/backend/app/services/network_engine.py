from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import subprocess
from dataclasses import dataclass
from pathlib import Path

from app.models import DeploymentMode, DeploymentRequest


INTERFACE_PATTERN = re.compile(r"^[A-Za-z0-9_.:-]{1,15}$")


def safe_interface(name: str) -> str:
    if not INTERFACE_PATTERN.fullmatch(name):
        raise ValueError(f"Unsafe interface name: {name}")
    return name


def render_nftables(request: DeploymentRequest, block_targets: dict[str, list[str]] | None = None, security_controls: dict[str, bool] | None = None, network_rules: dict | None = None) -> str:
    management = safe_interface(request.management_interface)
    blocked = block_targets or {"ipv4": [], "ipv6": [], "mac": []}
    controls = security_controls or {}
    forwards = [row for row in (network_rules or {}).get("port_forwards", []) if row.get("enabled", True)]
    lines = [
        "#!/usr/sbin/nft -f",
        "add table inet firewall_appliance",
        "flush table inet firewall_appliance",
        "table inet firewall_appliance {",
    ]
    if blocked.get("ipv4"):
        lines.append(f"  set blocked_ipv4 {{ type ipv4_addr; elements = {{ {', '.join(blocked['ipv4'])} }} }}")
    if blocked.get("ipv6"):
        lines.append(f"  set blocked_ipv6 {{ type ipv6_addr; elements = {{ {', '.join(blocked['ipv6'])} }} }}")
    if blocked.get("mac"):
        lines.append(f"  set blocked_macs {{ type ether_addr; elements = {{ {', '.join(blocked['mac'])} }} }}")
    if controls.get("block_doh"):
        lines.append("  set known_doh_ipv4 { type ipv4_addr; elements = { 1.1.1.1, 1.0.0.1, 8.8.8.8, 8.8.4.4, 9.9.9.9, 149.112.112.112 } }")
    lines.extend([
        "  chain input {",
        "    type filter hook input priority filter; policy drop;",
        "    iifname \"lo\" accept",
        "    ct state established,related accept",
        "    ct state invalid drop",
        "    meta l4proto { icmp, ipv6-icmp } accept",
        f"    iifname \"{management}\" tcp dport {{ 22, 8080 }} accept",
        f"    iifname \"{management}\" udp dport {{ 53, 67, 68 }} accept",
        f"    iifname \"{management}\" tcp dport 53 accept",
        "  }",
        "  chain forward {",
        "    type filter hook forward priority filter; policy drop;",
        "    ct state established,related accept",
        "    ct state invalid drop",
    ])
    if blocked.get("ipv4"):
        lines.append("    ip saddr @blocked_ipv4 drop")
    if blocked.get("ipv6"):
        lines.append("    ip6 saddr @blocked_ipv6 drop")
    if blocked.get("mac"):
        lines.append("    ether saddr @blocked_macs drop")
    if controls.get("block_quic"):
        lines.append("    udp dport 443 drop comment \"block QUIC and HTTP3 for policy visibility\"")
    if controls.get("block_dot"):
        lines.extend(["    tcp dport 853 drop comment \"block external DNS over TLS\"", "    udp dport 853 drop comment \"block DNS over QUIC\""])
    if controls.get("force_local_dns"):
        lines.extend(["    udp dport 53 drop comment \"force appliance DNS\"", "    tcp dport 53 drop comment \"force appliance DNS\""])
    if controls.get("block_doh"):
        lines.append("    ip daddr @known_doh_ipv4 tcp dport 443 drop comment \"block known public DoH resolvers\"")
    if request.mode == DeploymentMode.ROUTED_GATEWAY:
        wan, lan = safe_interface(request.wan_interface or ""), safe_interface(request.lan_interface or "")
        lines.extend([f"    iifname \"{lan}\" oifname \"{wan}\" accept", "  }", "}", "add table ip firewall_appliance_nat", "flush table ip firewall_appliance_nat", "table ip firewall_appliance_nat {", "  chain prerouting {", "    type nat hook prerouting priority dstnat; policy accept;"])
        for row in forwards:
            source = f"ip saddr {row['source_network']} " if row.get("source_network") else ""
            lines.append(f"    {source}{row['protocol']} dport {row['external_port']} dnat to {row['internal_ip']}:{row['internal_port']}")
        lines.extend(["  }", "  chain postrouting {", "    type nat hook postrouting priority srcnat; policy accept;", f"    oifname \"{wan}\" masquerade", "  }", "}"])
    elif request.mode == DeploymentMode.VLAN_TRUNK:
        trunk = safe_interface(request.trunk_interface or "")
        roles = {item.role: item.vlan_id for item in request.vlans}
        wan, lan = f"{trunk}.{roles['wan']}", f"{trunk}.{roles['lan']}"
        lines.extend([f"    iifname \"{lan}\" oifname \"{wan}\" accept", "  }", "}", "add table ip firewall_appliance_nat", "flush table ip firewall_appliance_nat", "table ip firewall_appliance_nat {", "  chain prerouting {", "    type nat hook prerouting priority dstnat; policy accept;"])
        for row in forwards:
            source = f"ip saddr {row['source_network']} " if row.get("source_network") else ""
            lines.append(f"    {source}{row['protocol']} dport {row['external_port']} dnat to {row['internal_ip']}:{row['internal_port']}")
        lines.extend(["  }", "  chain postrouting {", "    type nat hook postrouting priority srcnat; policy accept;", f"    oifname \"{wan}\" masquerade", "  }", "}"])
    elif request.mode == DeploymentMode.TRANSPARENT_BRIDGE:
        wan, lan = safe_interface(request.wan_interface or ""), safe_interface(request.lan_interface or "")
        lines.extend([f"    iifname \"{lan}\" oifname \"{wan}\" accept", f"    iifname \"{wan}\" oifname \"{lan}\" accept", "  }", "}"])
    else:
        lines.extend(["  }", "}"])
    return "\n".join(lines) + "\n"


@dataclass(frozen=True)
class Candidate:
    transaction_id: str
    path: str
    sha256: str
    nftables_valid: bool | None
    validation_message: str
    network_plan: list[dict]
    service_configurations: list[str]


class NetworkTransactionManager:
    def __init__(self, state_dir: str | Path | None = None):
        configured = state_dir or os.environ.get("FIREWALL_STATE_DIR", "./state")
        self.state_dir = Path(configured)

    def prepare(self, request: DeploymentRequest, block_targets: dict[str, list[str]] | None = None, service_configs: dict[str, str] | None = None, security_controls: dict[str, bool] | None = None, network_rules: dict | None = None) -> Candidate:
        from app.services.network_plan import affected_interfaces, render_network_plan

        transaction_id = "txn_" + secrets.token_hex(8)
        target = self.state_dir / "transactions" / transaction_id
        target.mkdir(parents=True, exist_ok=False)
        rules = render_nftables(request, block_targets, security_controls, network_rules)
        rules_path = target / "nftables.conf"
        rules_path.write_text(rules, encoding="utf-8")
        network_plan = render_network_plan(request)
        plan_path = target / "network-plan.json"
        plan_path.write_text(json.dumps(network_plan, indent=2), encoding="utf-8")
        digest = hashlib.sha256(rules.encode()).hexdigest()
        plan_digest = hashlib.sha256(plan_path.read_bytes()).hexdigest()
        config_hashes: dict[str, str] = {}
        service_dir = target / "services"
        for name, content in sorted((service_configs or {}).items()):
            if name not in {"dns.json", "kea-dhcp4.conf", "squid.conf", "block-page.html"}:
                raise ValueError(f"Unsupported service configuration: {name}")
            service_dir.mkdir(exist_ok=True)
            path = service_dir / name
            path.write_text(content, encoding="utf-8")
            config_hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
        metadata = {"transaction_id": transaction_id, "status": "prepared", "sha256": digest, "network_plan_sha256": plan_digest, "service_config_sha256": config_hashes, "security_controls": security_controls or {}, "affected_interfaces": affected_interfaces(network_plan), "deployment": request.model_dump(mode="json")}
        (target / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        valid, message = self.validate(rules_path)
        return Candidate(transaction_id, str(rules_path), digest, valid, message, network_plan, sorted(config_hashes))

    def transaction(self, transaction_id: str) -> dict:
        if not re.fullmatch(r"txn_[0-9a-f]{16}", transaction_id):
            raise ValueError("Invalid transaction identifier")
        path = self.state_dir / "transactions" / transaction_id / "metadata.json"
        if not path.is_file():
            raise FileNotFoundError("Transaction not found")
        return json.loads(path.read_text(encoding="utf-8"))

    def privileged_action(self, action: str, transaction_id: str) -> dict:
        if action not in {"activate", "confirm", "rollback", "status"}:
            raise ValueError("Unsupported transaction action")
        if os.environ.get("FIREWALL_ENABLE_LIVE_APPLY") != "1" and action == "activate":
            raise PermissionError("Live activation is disabled. Set FIREWALL_ENABLE_LIVE_APPLY=1 only on a test appliance.")
        if os.environ.get("FIREWALL_ENABLE_NETWORK_APPLY") != "1" and action == "activate":
            raise PermissionError("Network activation is disabled. Set FIREWALL_ENABLE_NETWORK_APPLY=1 only after console recovery access is verified.")
        self.transaction(transaction_id)
        helper = os.environ.get("FIREWALL_TRANSACTION_HELPER", "/usr/local/sbin/firewall-transaction")
        command = ["sudo", "-n", helper, action, transaction_id]
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=120)
        except FileNotFoundError as exc:
            raise RuntimeError("Privileged transaction helper is not installed") from exc
        try:
            response = json.loads(result.stdout or "{}")
        except json.JSONDecodeError as exc:
            raise RuntimeError((result.stderr or "Invalid response from transaction helper").strip()) from exc
        if result.returncode != 0:
            raise RuntimeError(response.get("error") or result.stderr.strip() or "Transaction helper failed")
        return response

    @staticmethod
    def validate(path: Path) -> tuple[bool | None, str]:
        """Kernel-validate the staged nftables candidate.

        `nft --check` needs CAP_NET_ADMIN, so the unprivileged API validates
        through the fixed firewall-nft-validate root helper using the staged
        transaction directory; the activation helper re-validates as root
        before anything is applied. Permission failures fall back to structural
        checks rather than false negatives.
        """
        import shutil

        txn = path.parent.name
        if os.geteuid() != 0 and re.fullmatch(r"txn_[0-9a-f]{16}", txn or "") and shutil.which("sudo"):
            completed = subprocess.run(["sudo", "-n", "/usr/local/sbin/firewall-nft-validate", "validate", txn], text=True, capture_output=True, timeout=30, check=False)
            try:
                body = json.loads(completed.stdout)
            except json.JSONDecodeError:
                body = {}
            if body:
                return bool(body.get("valid")), body.get("message") or "nftables validation helper failed"
        try:
            result = subprocess.run(["nft", "--check", "--file", str(path)], capture_output=True, text=True, timeout=5)
        except FileNotFoundError:
            return None, "nft command is not installed; structural tests passed but system syntax check was skipped."
        except subprocess.TimeoutExpired:
            return False, "nftables validation timed out."
        if result.returncode == 0:
            return True, "nftables candidate passed system syntax validation."
        message = (result.stderr or result.stdout or "nftables validation failed").strip()
        if "Operation not permitted" in message or "cache initialization failed" in message:
            return None, "Kernel validation requires root; the staged candidate is re-validated by the activation helper before any change is applied."
        return False, message
