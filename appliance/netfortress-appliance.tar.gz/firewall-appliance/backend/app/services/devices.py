from __future__ import annotations

import ipaddress
import json
import re
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from app.models import DeviceInfo


MAC_RE = re.compile(r"^(?:[0-9a-f]{2}:){5}[0-9a-f]{2}$", re.I)
LEASE_PATHS = (Path("/var/lib/misc/dnsmasq.leases"), Path("/var/lib/dhcp/dhcpd.leases"))
KEA_LEASE_PATHS = (Path("/var/lib/kea/kea-leases4.csv"),)


def _lease_names() -> dict[str, str]:
    names: dict[str, str] = {}
    path = LEASE_PATHS[0]
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            fields = line.split()
            if len(fields) >= 4 and fields[3] not in {"*", "-"}:
                names[fields[2]] = fields[3]
    except OSError:
        pass
    return names


def _kea_lease_names() -> dict[str, str]:
    """Client-provided hostnames from Kea lease records.

    Column order (Kea memfile): address,hwaddr,client_id,valid_lifetime,expire,
    subnet_id,fqdn_fwd,fqdn_rev,hostname,state,user_context,pool_id.
    """
    names: dict[str, str] = {}
    for path in KEA_LEASE_PATHS:
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for line in lines:
            fields = line.split(",")
            if len(fields) < 9:
                continue
            address, hostname = fields[0].strip(), fields[8].strip()
            try:
                ipaddress.ip_address(address)
            except ValueError:
                continue  # header row or malformed entry
            if hostname and hostname not in {"*", "-"}:
                names[address] = hostname
    return names


def hostname_for_ip(address: str | None) -> str | None:
    """The lease-file hostname for an IP, if any (no ping sweep — safe to call per request)."""
    if not address:
        return None
    return (_lease_names() | _kea_lease_names()).get(address)


def _refresh_neighbours(subnet: str | None) -> None:
    """Ping sweep so the kernel neighbour cache reflects connected devices."""
    if not subnet:
        return
    try:
        network = ipaddress.ip_network(subnet, strict=False)
    except ValueError:
        return
    hosts = [str(host) for host in network.hosts()]
    if not hosts or len(hosts) > 512:
        return

    def probe(address: str) -> None:
        subprocess.run(["ping", "-c", "1", "-W", "1", "-n", address], capture_output=True, timeout=2, check=False)

    with ThreadPoolExecutor(max_workers=96) as executor:
        list(executor.map(probe, hosts))


def _ip_neighbours() -> list[dict]:
    try:
        result = subprocess.run(["ip", "-j", "neighbour", "show"], check=True, capture_output=True, text=True, timeout=4)
        rows = json.loads(result.stdout)
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError):
        return []
    found = []
    for row in rows:
        ip = row.get("dst")
        mac = row.get("lladdr")
        # Ping sweeps leave MAC-less incomplete entries for every empty pool
        # address; only real link-layer neighbours are devices.
        if not ip or not mac or not MAC_RE.fullmatch(mac):
            continue
        raw = row.get("state", ["unknown"])
        normalized = ", ".join(raw).lower() if isinstance(raw, list) else str(raw).lower()
        found.append({"ip_address": ip, "mac_address": mac.lower() if mac else None, "interface": row.get("dev"), "state": STATE_MAP.get(normalized.split(",")[0].strip(), "stale"), "source": "neighbour"})
    return found


STATE_MAP = {"reachable": "reachable", "permanent": "reachable", "delay": "delay", "probe": "delay", "stale": "stale", "none": "stale", "failed": "offline", "incomplete": "offline"}


def _arp_neighbours() -> list[dict]:
    try:
        lines = Path("/proc/net/arp").read_text(encoding="utf-8").splitlines()[1:]
    except OSError:
        return []
    found = []
    for line in lines:
        fields = line.split()
        # The flags column is the honest verdict: 0x2 = confirmed complete,
        # anything less means the kernel has not verified this entry — a
        # device that was switched off must not keep showing as reachable.
        try:
            complete = int(fields[2], 16) & 0x2
        except (ValueError, IndexError):
            complete = 0
        if len(fields) >= 6 and MAC_RE.fullmatch(fields[3]) and fields[3] != "00:00:00:00:00:00":
            found.append({"ip_address": fields[0], "mac_address": fields[3].lower(), "interface": fields[5], "state": "reachable" if complete else "stale", "source": "arp"})
    return found


def discover_devices(subnet: str | None = None) -> list[DeviceInfo]:
    _refresh_neighbours(subnet)
    names = _lease_names() | _kea_lease_names()
    merged: dict[tuple[str, str], dict] = {}
    for row in [*_arp_neighbours(), *_ip_neighbours()]:
        key = (row["ip_address"], row.get("mac_address") or "")
        row["hostname"] = names.get(row["ip_address"])
        merged[key] = merged.get(key, {}) | row
    return [DeviceInfo(**row) for row in sorted(merged.values(), key=lambda value: (value.get("interface") or "", value["ip_address"]))]
