from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import urllib.error
import urllib.request
from datetime import UTC, datetime, timedelta
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import load_pem_public_key

from app.database import Database, utcnow
from app.license_models import (BASIC_FEATURES, EDITIONS, FREE_EDITION, FREE_HOME_LITE_PREFIX,
                                 PROFESSIONAL_FEATURES, REVOKED_LICENSE_PREFIX, LicenseState,
                                 LicenseStatus, SignedLicenseEnvelope, SignedLicensePayload)

PRODUCT_VERSION = "3.1"
TRIAL_DAYS = 60


def canonical_payload(payload: SignedLicensePayload) -> bytes:
    data = payload.model_dump(mode="json", exclude_none=False)
    return json.dumps(data, separators=(",", ":"), sort_keys=True).encode()


def verify_envelope(envelope: SignedLicenseEnvelope, public_key_pem: bytes) -> None:
    key = load_pem_public_key(public_key_pem)
    if not isinstance(key, Ed25519PublicKey):
        raise ValueError("Licence verification key must be Ed25519")
    try:
        key.verify(base64.b64decode(envelope.signature), canonical_payload(envelope.payload))
    except (InvalidSignature, ValueError) as exc:
        raise ValueError("Licence signature verification failed") from exc


def hardware_fingerprint() -> str:
    components = []
    for path in (Path("/etc/machine-id"), Path("/sys/class/dmi/id/product_uuid"), Path("/sys/class/dmi/id/board_serial")):
        try:
            value = path.read_text(encoding="utf-8").strip()
            if value:
                components.append(value)
        except OSError:
            pass
    for path in sorted(Path("/sys/class/net").glob("*/address")):
        try:
            value = path.read_text(encoding="utf-8").strip()
            if value and value != "00:00:00:00:00:00":
                components.append(value)
        except OSError:
            pass
    seed = "|".join(components) or os.uname().nodename
    return hashlib.sha256(("firewall-appliance|" + seed).encode()).hexdigest()


def installation_id(database: Database) -> str:
    value = database.setting("installation_id")
    if value:
        return value
    value = "install_" + secrets.token_hex(16)
    database.set_setting("installation_id", value)
    return value


def edition_features(edition: str, signed_features: list[str]) -> frozenset[str]:
    """A payload never grants more than its edition allows, even if the
    licensing host made a mistake."""
    catalogue = EDITIONS.get(edition)
    if not catalogue:
        return frozenset(signed_features)
    return frozenset(catalogue["features"]) & frozenset(signed_features) | BASIC_FEATURES


def evaluate(payload: SignedLicensePayload | None, *, install_id: str, now: datetime | None = None,
             trial_consumed: bool = False, last_verified_at: datetime | None = None,
             device_count: int = 0, account_count: int = 0) -> LicenseStatus:
    now = now or datetime.now(UTC)
    # A revoked (deleted-on-the-server) licence is exactly like no licence at
    # all - even if an old copy is still stored somewhere.
    if payload is not None and payload.license_id.startswith(REVOKED_LICENSE_PREFIX):
        payload = None
    if payload is None or payload.installation_id != install_id:
        message = "No licence yet. Start the 60-day full trial, activate a purchased licence, or request the free Home Lite licence (10 devices, one account, full protection, no reports)."
        if trial_consumed:
            message = "No active licence. Filtering continues to protect the network, but configuration is locked until a licence is activated. The free Home Lite licence is available from the licence server — or activate a purchased licence."
        return LicenseStatus(state=LicenseState.UNLICENSED, licensed=False, trial_available=not trial_consumed,
                             edition="basic", edition_label="Basic (unlicensed)", license_type=None,
                             features=sorted(BASIC_FEATURES), restricted_features=sorted(PROFESSIONAL_FEATURES),
                             expires_at=None, grace_until=None, updates_until=None, days_remaining=None,
                             installation_id=install_id, last_verified_at=last_verified_at,
                             device_count=device_count, account_count=account_count, free_tier_available=True, message=message)
    features = edition_features(payload.edition, payload.features)
    edition_label = EDITIONS.get(payload.edition, {}).get("label", payload.edition)
    if payload.suspended:
        state, active, message = LicenseState.SUSPENDED, BASIC_FEATURES, "Licence suspended. Filtering continues to protect the network; configuration is locked until the licence is restored."
    elif payload.license_type == "trial":
        if payload.expires_at and now < payload.expires_at:
            state, active, message = LicenseState.TRIAL_ACTIVE, features, "Full trial is active — every Professional feature is unlocked."
        else:
            state, active, message = LicenseState.TRIAL_EXPIRED, BASIC_FEATURES, "Trial expired. The appliance automatically continues on the free Home Lite licence (10 devices, one account, full protection) as soon as the licensing server is reachable; activate a purchased licence any time to unlock more."
    elif payload.license_type == "subscription":
        if payload.expires_at and now < payload.expires_at:
            state, active, message = LicenseState.SUBSCRIPTION_ACTIVE, features, "Subscription is active."
        elif payload.grace_until and now < payload.grace_until:
            state, active, message = LicenseState.SUBSCRIPTION_GRACE, features, "Subscription expired — still inside the grace period. Renew to keep making changes afterwards."
        else:
            state, active, message = LicenseState.SUBSCRIPTION_EXPIRED, BASIC_FEATURES, "Subscription and grace period expired. Filtering continues to protect the network, but configuration is locked until renewal. The free Home Lite licence is available from the licence server, or renew / activate a purchased licence."
    else:
        if payload.updates_until and now >= payload.updates_until:
            state, active, message = LicenseState.PERPETUAL_UPDATES_EXPIRED, features - {"updates"}, "Perpetual licence is active; the update entitlement has expired. Everything else keeps working."
        else:
            state, active, message = LicenseState.PERPETUAL_ACTIVE, features, "Perpetual licence is active."
    licensed = state not in {LicenseState.UNLICENSED, LicenseState.TRIAL_EXPIRED, LicenseState.SUBSCRIPTION_EXPIRED, LicenseState.SUSPENDED}
    # The free tier is offered exactly when nothing is licensed: an active
    # trial or a paid licence is never silently downgraded.
    free_tier_available = not licensed
    deadline = payload.expires_at or payload.grace_until or payload.updates_until
    days = max(0, (deadline - now).days) if deadline else None
    if licensed and payload.device_limit and device_count > payload.device_limit:
        message += f" Device limit reached ({device_count} of {payload.device_limit}) — new devices are held back until you upgrade."
    if licensed and payload.account_limit and account_count > payload.account_limit:
        message += f" Account limit exceeded ({account_count} of {payload.account_limit})."
    return LicenseStatus(state=state, licensed=licensed, trial_available=False, edition=payload.edition,
                         edition_label=edition_label, license_type=payload.license_type, features=sorted(active),
                         restricted_features=sorted(PROFESSIONAL_FEATURES - active), expires_at=payload.expires_at,
                         grace_until=payload.grace_until, updates_until=payload.updates_until, days_remaining=days,
                         installation_id=install_id, last_verified_at=last_verified_at,
                         device_limit=payload.device_limit or 0, device_count=device_count,
                         account_limit=payload.account_limit or 0, account_count=account_count,
                         free_tier_available=free_tier_available, message=message)


class LicenseService:
    def __init__(self, database: Database):
        self.database = database

    def status(self) -> LicenseStatus:
        install_id = installation_id(self.database)
        record = self.database.license_record()
        payload = SignedLicensePayload.model_validate_json(record["payload_json"]) if record else None
        last_verified = datetime.fromisoformat(record["last_verified_at"]) if record and record["last_verified_at"] else None
        return evaluate(payload, install_id=install_id,
                        trial_consumed=self.database.setting("trial_consumed") == "1",
                        last_verified_at=last_verified,
                        device_count=self.database.device_count(),
                        account_count=self.database.user_count())

    def install_envelope(self, envelope: SignedLicenseEnvelope) -> LicenseStatus:
        from app.services.license_refresh import install_signed_license
        return install_signed_license(self, envelope)

    def activate_online(self, license_key: str, action: str = "activate") -> LicenseStatus:
        from app.services.license_refresh import activate_signed_license
        return activate_signed_license(self, license_key, action)

    def activate_free_home_lite(self) -> LicenseStatus:
        """Request the free Home Lite licence from the licensing server.
        The key is the appliance's own installation id, so every installation
        gets its own perpetual licence record the licensing host can manage."""
        key = FREE_HOME_LITE_PREFIX + installation_id(self.database)
        return self.activate_online(key, "activate")

    def refresh_online(self, force: bool = False) -> LicenseStatus | None:
        from app.services.license_refresh import refresh_online
        return refresh_online(self, force=force)

    def refresh_status(self) -> dict:
        from app.services.license_refresh import refresh_status
        return refresh_status(self)

    def deactivate(self) -> None:
        from app.services.license_refresh import deactivate_license
        deactivate_license(self)

    def development_trial(self) -> LicenseStatus:
        if os.environ.get("FIREWALL_LICENSE_DEVELOPMENT") != "1":
            raise RuntimeError("Development trial mode is disabled")
        if self.database.setting("trial_consumed") == "1":
            raise ValueError("Trial was already used on this installation")
        now = datetime.now(UTC)
        payload = SignedLicensePayload(license_id="trial_" + secrets.token_hex(8), installation_id=installation_id(self.database), license_type="trial", edition="full-trial", features=sorted(PROFESSIONAL_FEATURES), device_limit=EDITIONS["full-trial"]["device_limit"], account_limit=0, issued_at=now, expires_at=now + timedelta(days=TRIAL_DAYS))
        self.database.save_license(payload.model_dump_json(), "development-only", utcnow())
        self.database.set_setting("trial_consumed", "1")
        return self.status()
