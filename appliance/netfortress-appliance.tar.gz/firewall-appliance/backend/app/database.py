from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterator


SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'operator', 'viewer')),
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    last_login_at TEXT
);
CREATE TABLE IF NOT EXISTS api_tokens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    token_prefix TEXT NOT NULL UNIQUE,
    token_hash TEXT NOT NULL UNIQUE,
    scopes_json TEXT NOT NULL,
    expires_at TEXT,
    revoked_at TEXT,
    created_at TEXT NOT NULL,
    last_used_at TEXT
);
CREATE TABLE IF NOT EXISTS audit_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    occurred_at TEXT NOT NULL,
    actor_type TEXT NOT NULL,
    actor_id TEXT,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT,
    outcome TEXT NOT NULL,
    source_ip TEXT,
    details_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_audit_occurred_at ON audit_events(occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_tokens_user ON api_tokens(user_id);
CREATE TABLE IF NOT EXISTS system_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS license_state (
    singleton_id INTEGER PRIMARY KEY CHECK (singleton_id = 1),
    payload_json TEXT NOT NULL,
    signature TEXT NOT NULL,
    last_verified_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS license_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    occurred_at TEXT NOT NULL,
    event_type TEXT NOT NULL,
    state TEXT,
    details_json TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS discovered_devices (
    ip_address TEXT NOT NULL,
    mac_address TEXT NOT NULL DEFAULT '',
    hostname TEXT,
    interface TEXT,
    state TEXT NOT NULL,
    source TEXT NOT NULL,
    first_seen_at TEXT NOT NULL,
    last_seen_at TEXT NOT NULL,
    PRIMARY KEY (ip_address, mac_address)
);
CREATE INDEX IF NOT EXISTS idx_devices_last_seen ON discovered_devices(last_seen_at DESC);
CREATE TABLE IF NOT EXISTS device_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE COLLATE NOCASE,
    description TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS device_group_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL REFERENCES device_groups(id) ON DELETE CASCADE,
    target_type TEXT NOT NULL CHECK(target_type IN ('mac','ip','hostname')),
    target_value TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(group_id,target_type,target_value)
);
CREATE TABLE IF NOT EXISTS blocking_policies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    target_type TEXT NOT NULL CHECK(target_type IN ('mac','ip','hostname','group')),
    target_value TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    reason TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS blocklist_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE COLLATE NOCASE,
    url TEXT NOT NULL,
    format TEXT NOT NULL CHECK(format IN ('hosts','domains')),
    enabled INTEGER NOT NULL DEFAULT 1,
    update_hours INTEGER NOT NULL DEFAULT 24,
    status TEXT NOT NULL DEFAULT 'pending',
    domain_count INTEGER NOT NULL DEFAULT 0,
    content_sha256 TEXT,
    last_updated_at TEXT,
    last_error TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS local_domains (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    domain TEXT NOT NULL UNIQUE COLLATE NOCASE,
    action TEXT NOT NULL CHECK(action IN ('block','allow')),
    category TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS application_policies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application TEXT NOT NULL UNIQUE COLLATE NOCASE,
    enabled INTEGER NOT NULL DEFAULT 1,
    block_quic INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE COLLATE NOCASE,
    timezone TEXT NOT NULL,
    days_json TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS security_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    occurred_at TEXT NOT NULL,
    event_type TEXT NOT NULL,
    action TEXT NOT NULL,
    client_ip TEXT,
    hostname TEXT,
    destination TEXT,
    category TEXT,
    policy TEXT,
    details_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_security_events_time ON security_events(occurred_at DESC);
CREATE TABLE IF NOT EXISTS access_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    requested_host TEXT NOT NULL,
    client_ip TEXT NOT NULL,
    device_name TEXT,
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS firewall_zones (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE COLLATE NOCASE,interfaces_json TEXT NOT NULL,networks_json TEXT NOT NULL,default_action TEXT NOT NULL CHECK(default_action IN ('accept','drop')),created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS port_forwards (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,protocol TEXT NOT NULL CHECK(protocol IN ('tcp','udp')),external_port INTEGER NOT NULL,internal_ip TEXT NOT NULL,internal_port INTEGER NOT NULL,source_network TEXT,enabled INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,UNIQUE(protocol,external_port));
CREATE TABLE IF NOT EXISTS dhcp_reservations (id INTEGER PRIMARY KEY AUTOINCREMENT,mac_address TEXT NOT NULL UNIQUE COLLATE NOCASE,ip_address TEXT NOT NULL UNIQUE,hostname TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS local_dns_records (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL COLLATE NOCASE,record_type TEXT NOT NULL CHECK(record_type IN ('A','AAAA','CNAME')),value TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(name,record_type));
CREATE TABLE IF NOT EXISTS ip_pools (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,vlan_id INTEGER NOT NULL UNIQUE,subnet TEXT NOT NULL UNIQUE,pool_start TEXT NOT NULL,pool_end TEXT NOT NULL,router TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS portal_acceptances (id INTEGER PRIMARY KEY AUTOINCREMENT,mac_address TEXT NOT NULL UNIQUE COLLATE NOCASE,ip_address TEXT NOT NULL DEFAULT '',accepted_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS wireguard_peers (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'client' CHECK (kind IN ('client','site')),public_key TEXT NOT NULL UNIQUE,preshared_key TEXT DEFAULT '',allowed_ips TEXT NOT NULL,endpoint_host TEXT DEFAULT '',endpoint_port INTEGER DEFAULT 0,keepalive INTEGER DEFAULT 25,enabled INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS category_groups (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE COLLATE NOCASE,description TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS category_group_apps (id INTEGER PRIMARY KEY AUTOINCREMENT,group_id INTEGER NOT NULL REFERENCES category_groups(id) ON DELETE CASCADE,application TEXT NOT NULL,UNIQUE(group_id,application));
CREATE TABLE IF NOT EXISTS custom_services (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE COLLATE NOCASE,category TEXT NOT NULL COLLATE NOCASE,domains_json TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS service_extensions (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE COLLATE NOCASE,domains_json TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS user_groups (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE COLLATE NOCASE,description TEXT NOT NULL DEFAULT '',permissions_json TEXT NOT NULL,builtin INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
"""

SEED_GROUPS = {
    "Administrators": (["full_access"], "Full access to everything — the built-in administrator group"),
    "Operators": (["dashboard", "devices", "web_control", "access_requests", "reports", "modules", "operations"], "Day-to-day security work — no user management, no firewall rules"),
    "Viewers": (["dashboard", "reports"], "See the status and reports, change nothing"),
}


def utcnow() -> str:
    return datetime.now(UTC).isoformat()


class Database:
    def __init__(self, path: str | Path | None = None):
        configured = path or os.environ.get("FIREWALL_DB_PATH", "./firewall-appliance.db")
        self.path = Path(configured)

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as connection:
            connection.executescript(SCHEMA)
            columns = {row[1] for row in connection.execute("PRAGMA table_info(blocking_policies)")}
            if "schedule_id" not in columns:
                connection.execute("ALTER TABLE blocking_policies ADD COLUMN schedule_id INTEGER")
            access_columns = {row[1] for row in connection.execute("PRAGMA table_info(access_requests)")}
            for name, definition in {"reviewed_at": "TEXT", "reviewed_by": "TEXT", "review_note": "TEXT"}.items():
                if name not in access_columns:
                    connection.execute(f"ALTER TABLE access_requests ADD COLUMN {name} {definition}")
            local_columns = {row[1] for row in connection.execute("PRAGMA table_info(local_domains)")}
            if "expires_at" not in local_columns:
                connection.execute("ALTER TABLE local_domains ADD COLUMN expires_at TEXT")
            # Build 5 — user groups: seed the built-in groups once, and move
            # existing role-based accounts onto the matching group.
            user_columns = {row[1] for row in connection.execute("PRAGMA table_info(users)")}
            if "group_id" not in user_columns:
                connection.execute("ALTER TABLE users ADD COLUMN group_id INTEGER REFERENCES user_groups(id)")
            import json as json_module
            for name, (permissions, description) in SEED_GROUPS.items():
                existing = connection.execute("SELECT id FROM user_groups WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
                if not existing:
                    connection.execute("INSERT INTO user_groups (name,description,permissions_json,builtin,created_at) VALUES (?,?,?,1,?)", (name, description, json_module.dumps(permissions), utcnow()))
            role_map = {"admin": "Administrators", "operator": "Operators", "viewer": "Viewers"}
            for role, group_name in role_map.items():
                group = connection.execute("SELECT id FROM user_groups WHERE name = ? COLLATE NOCASE", (group_name,)).fetchone()
                if group:
                    connection.execute("UPDATE users SET group_id = ? WHERE group_id IS NULL AND role = ?", (group["id"], role))
            blocklist_columns = {row[1] for row in connection.execute("PRAGMA table_info(blocklist_sources)")}
            if "category" not in blocklist_columns:
                connection.execute("ALTER TABLE blocklist_sources ADD COLUMN category TEXT NOT NULL DEFAULT ''")
            connection.execute("UPDATE blocklist_sources SET category='ads-trackers' WHERE category='' AND url='https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts'")

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def has_users(self) -> bool:
        with self.connect() as connection:
            return bool(connection.execute("SELECT 1 FROM users LIMIT 1").fetchone())

    def create_user(self, username: str, password_hash: str, role: str = "admin", group_id: int | None = None) -> dict:
        now = utcnow()
        with self.connect() as connection:
            cursor = connection.execute(
                "INSERT INTO users(username,password_hash,role,group_id,created_at) VALUES(?,?,?,?,?)",
                (username, password_hash, role, group_id, now),
            )
            row = connection.execute("SELECT * FROM users WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    def user_by_username(self, username: str) -> dict | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
        return dict(row) if row else None

    def user_by_id(self, user_id: int) -> dict | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        return dict(row) if row else None

    def users(self) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT u.id,u.username,u.role,u.enabled,u.created_at,u.last_login_at,u.group_id,g.name AS group_name FROM users u LEFT JOIN user_groups g ON g.id = u.group_id ORDER BY u.username").fetchall()
        return [dict(row) | {"enabled": bool(row["enabled"])} for row in rows]

    def set_user_password(self, user_id: int, password_hash: str) -> None:
        with self.connect() as connection:
            connection.execute("UPDATE users SET password_hash=? WHERE id=?", (password_hash, user_id))

    def update_user(self, user_id: int, role: str, enabled: bool, group_id: int | None = None) -> dict | None:
        with self.connect() as connection:
            connection.execute("UPDATE users SET role=?,enabled=?,group_id=? WHERE id=?", (role, int(enabled), group_id, user_id))
            row = connection.execute("SELECT id,username,role,enabled,created_at,last_login_at FROM users WHERE id=?", (user_id,)).fetchone()
        return dict(row) | {"enabled": bool(row["enabled"])} if row else None

    def user_groups(self) -> list[dict]:
        import json as json_module

        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM user_groups ORDER BY builtin DESC, name").fetchall()
        groups = []
        for row in rows:
            group = dict(row) | {"builtin": bool(row["builtin"]), "permissions": json_module.loads(row["permissions_json"]), "member_count": self.group_member_count(row["id"]) }
            groups.append(group)
        return groups

    def group_member_count(self, group_id: int) -> int:
        with self.connect() as connection:
            return int(connection.execute("SELECT COUNT(*) AS n FROM users WHERE group_id=?", (group_id,)).fetchone()["n"])

    def user_group(self, group_id: int) -> dict | None:
        import json as json_module

        with self.connect() as connection:
            row = connection.execute("SELECT * FROM user_groups WHERE id=?", (group_id,)).fetchone()
        if not row:
            return None
        return dict(row) | {"builtin": bool(row["builtin"]), "permissions": json_module.loads(row["permissions_json"])}

    def user_group_by_name(self, name: str) -> dict | None:
        import json as json_module

        with self.connect() as connection:
            row = connection.execute("SELECT * FROM user_groups WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
        if not row:
            return None
        return dict(row) | {"builtin": bool(row["builtin"]), "permissions": json_module.loads(row["permissions_json"])}

    def create_user_group(self, name: str, description: str, permissions: list[str]) -> dict:
        import json as json_module

        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO user_groups (name,description,permissions_json,builtin,created_at) VALUES (?,?,?,0,?)", (name, description, json_module.dumps(sorted(set(permissions))), utcnow()))
            group_id = cursor.lastrowid
        return self.user_group(group_id)

    def update_user_group(self, group_id: int, name: str | None, description: str | None, permissions: list[str]) -> dict | None:
        import json as json_module

        with self.connect() as connection:
            current = connection.execute("SELECT * FROM user_groups WHERE id=?", (group_id,)).fetchone()
            if not current:
                return None
            connection.execute(
                "UPDATE user_groups SET name=?,description=?,permissions_json=? WHERE id=?",
                (name or current["name"], description if description is not None else current["description"], json_module.dumps(sorted(set(permissions))), group_id),
            )
        return self.user_group(group_id)

    def delete_user_group(self, group_id: int) -> bool:
        with self.connect() as connection:
            group = connection.execute("SELECT builtin FROM user_groups WHERE id=?", (group_id,)).fetchone()
            if not group or group["builtin"]:
                return False
            members = connection.execute("SELECT COUNT(*) AS n FROM users WHERE group_id=?", (group_id,)).fetchone()["n"]
            if members:
                return False
            return bool(connection.execute("DELETE FROM user_groups WHERE id=?", (group_id,)).rowcount)

    def enabled_full_access_count(self) -> int:
        """Enabled accounts that can administer (full-access group or legacy admin role)."""
        import json as json_module

        with self.connect() as connection:
            rows = connection.execute("SELECT u.enabled, u.role, u.group_id, g.permissions_json FROM users u LEFT JOIN user_groups g ON g.id = u.group_id").fetchall()
        count = 0
        for row in rows:
            if not row["enabled"]:
                continue
            if row["group_id"] and row["permissions_json"] and "full_access" in json_module.loads(row["permissions_json"]):
                count += 1
            elif not row["group_id"] and row["role"] == "admin":
                count += 1
        return count

    def user_has_full_access(self, user: dict) -> bool:
        """Whether this account can administer (used by the last-admin guard)."""
        import json as json_module

        if user.get("group_id"):
            group = self.user_group(int(user["group_id"]))
            return bool(group and "full_access" in group["permissions"])
        return user.get("role") == "admin"

    def delete_user(self, user_id: int) -> bool:
        with self.connect() as connection:
            return connection.execute("DELETE FROM users WHERE id=?", (user_id,)).rowcount == 1

    def enabled_admin_count(self) -> int:
        with self.connect() as connection:
            return int(connection.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND enabled=1").fetchone()[0])

    def mark_login(self, user_id: int) -> None:
        with self.connect() as connection:
            connection.execute("UPDATE users SET last_login_at=? WHERE id=?", (utcnow(), user_id))

    def store_api_token(self, user_id: int, name: str, prefix: str, token_hash: str, scopes: list[str], expires_at: str | None) -> dict:
        with self.connect() as connection:
            cursor = connection.execute(
                "INSERT INTO api_tokens(user_id,name,token_prefix,token_hash,scopes_json,expires_at,created_at) VALUES(?,?,?,?,?,?,?)",
                (user_id, name, prefix, token_hash, json.dumps(scopes), expires_at, utcnow()),
            )
            row = connection.execute("SELECT * FROM api_tokens WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    def api_tokens(self, user_id: int) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute(
                "SELECT id,name,token_prefix,scopes_json,created_at,expires_at,last_used_at,revoked_at FROM api_tokens WHERE user_id=? AND revoked_at IS NULL ORDER BY id DESC",
                (user_id,),
            ).fetchall()
            return [dict(row) for row in rows]

    def api_token_by_hash(self, token_hash: str) -> dict | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM api_tokens WHERE token_hash=?", (token_hash,)).fetchone()
            if row:
                connection.execute("UPDATE api_tokens SET last_used_at=? WHERE id=?", (utcnow(), row["id"]))
        return dict(row) if row else None

    def revoke_api_token(self, token_id: int, user_id: int) -> bool:
        with self.connect() as connection:
            cursor = connection.execute(
                "UPDATE api_tokens SET revoked_at=? WHERE id=? AND user_id=? AND revoked_at IS NULL",
                (utcnow(), token_id, user_id),
            )
        return cursor.rowcount == 1

    def audit(self, *, actor_type: str, actor_id: str | None, action: str, resource_type: str, resource_id: str | None = None, outcome: str = "success", source_ip: str | None = None, details: dict | None = None) -> None:
        with self.connect() as connection:
            connection.execute(
                "INSERT INTO audit_events(occurred_at,actor_type,actor_id,action,resource_type,resource_id,outcome,source_ip,details_json) VALUES(?,?,?,?,?,?,?,?,?)",
                (utcnow(), actor_type, actor_id, action, resource_type, resource_id, outcome, source_ip, json.dumps(details or {}, separators=(",", ":"))),
            )

    def audit_events(self, limit: int = 100) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM audit_events ORDER BY id DESC LIMIT ?", (min(max(limit, 1), 500),)).fetchall()
        return [dict(row) | {"details": json.loads(row["details_json"])} for row in rows]

    def setting(self, key: str) -> str | None:
        with self.connect() as connection:
            row = connection.execute("SELECT value FROM system_settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None

    def set_setting(self, key: str, value: str) -> None:
        with self.connect() as connection:
            connection.execute("INSERT INTO system_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at", (key, value, utcnow()))

    def license_record(self) -> dict | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM license_state WHERE singleton_id=1").fetchone()
        return dict(row) if row else None

    def save_license(self, payload_json: str, signature: str, verified_at: str) -> None:
        state = json.loads(payload_json)
        with self.connect() as connection:
            connection.execute("INSERT INTO license_state(singleton_id,payload_json,signature,last_verified_at) VALUES(1,?,?,?) ON CONFLICT(singleton_id) DO UPDATE SET payload_json=excluded.payload_json,signature=excluded.signature,last_verified_at=excluded.last_verified_at", (payload_json, signature, verified_at))
            connection.execute("INSERT INTO license_events(occurred_at,event_type,state,details_json) VALUES(?,?,?,?)", (utcnow(), "license.installed", state.get("license_type"), json.dumps({"license_id": state.get("license_id")})))

    def clear_license(self) -> None:
        with self.connect() as connection:
            connection.execute("DELETE FROM license_state WHERE singleton_id=1")
            connection.execute("INSERT INTO license_events(occurred_at,event_type,details_json) VALUES(?,?,?)", (utcnow(), "license.deactivated", "{}"))

    def license_events(self, limit: int = 100) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM license_events ORDER BY id DESC LIMIT ?", (min(max(limit, 1), 500),)).fetchall()
        return [dict(row) | {"details": json.loads(row["details_json"])} for row in rows]

    def record_devices(self, devices: list[dict]) -> list[dict]:
        now = utcnow()
        with self.connect() as connection:
            for device in devices:
                connection.execute(
                    """INSERT INTO discovered_devices(ip_address,mac_address,hostname,interface,state,source,first_seen_at,last_seen_at)
                    VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(ip_address,mac_address) DO UPDATE SET
                    hostname=COALESCE(excluded.hostname,discovered_devices.hostname),interface=excluded.interface,
                    state=excluded.state,source=excluded.source,last_seen_at=excluded.last_seen_at""",
                    (device["ip_address"], device.get("mac_address") or "", device.get("hostname"), device.get("interface"), device.get("state", "unknown"), device.get("source", "neighbour"), now, now),
                )
            # Honest lifecycle: a known device that answered the sweep last
            # time but is absent now (or its entry is failed/incomplete) was
            # switched off or left the network — it must not keep showing as
            # reachable forever.
            current = {(d["ip_address"], d.get("mac_address") or "") for d in devices}
            all_rows = connection.execute("SELECT ip_address, mac_address, state FROM discovered_devices").fetchall()
            for row in all_rows:
                if (row["ip_address"], row["mac_address"] or "") in current:
                    continue
                if row["state"] in ("reachable", "delay"):
                    connection.execute("UPDATE discovered_devices SET state='offline' WHERE ip_address=? AND mac_address=?", (row["ip_address"], row["mac_address"]))
            rows = connection.execute("SELECT * FROM discovered_devices ORDER BY last_seen_at DESC LIMIT 1000").fetchall()
        return [dict(row) | {"mac_address": row["mac_address"] or None} for row in rows]

    def device_count(self) -> int:
        """Distinct observed device identities (the licence device limit counts these)."""
        with self.connect() as connection:
            return connection.execute("SELECT COUNT(*) AS n FROM discovered_devices").fetchone()["n"]

    def user_count(self) -> int:
        with self.connect() as connection:
            return connection.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]

    def create_group(self, name: str, description: str) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO device_groups(name,description,created_at) VALUES(?,?,?)", (name, description, utcnow()))
            row = connection.execute("SELECT * FROM device_groups WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    def groups(self) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT g.*,COUNT(m.id) member_count FROM device_groups g LEFT JOIN device_group_members m ON m.group_id=g.id GROUP BY g.id ORDER BY g.name").fetchall()
        return [dict(row) for row in rows]

    def add_group_member(self, group_id: int, target_type: str, target_value: str) -> dict:
        with self.connect() as connection:
            if not connection.execute("SELECT 1 FROM device_groups WHERE id=?", (group_id,)).fetchone():
                raise KeyError("Device group not found")
            cursor = connection.execute("INSERT INTO device_group_members(group_id,target_type,target_value,created_at) VALUES(?,?,?,?)", (group_id, target_type, target_value, utcnow()))
            row = connection.execute("SELECT * FROM device_group_members WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    def delete_group(self, group_id: int) -> bool:
        with self.connect() as connection:
            cursor = connection.execute("DELETE FROM device_groups WHERE id=?", (group_id,))
        return cursor.rowcount == 1

    def create_policy(self, name: str, target_type: str, target_value: str, enabled: bool, reason: str, schedule_id: int | None = None) -> dict:
        now = utcnow()
        with self.connect() as connection:
            if schedule_id and not connection.execute("SELECT 1 FROM schedules WHERE id=?", (schedule_id,)).fetchone():
                raise KeyError("Schedule not found")
            cursor = connection.execute("INSERT INTO blocking_policies(name,target_type,target_value,enabled,reason,created_at,updated_at,schedule_id) VALUES(?,?,?,?,?,?,?,?)", (name, target_type, target_value, int(enabled), reason, now, now, schedule_id))
            row = connection.execute("SELECT * FROM blocking_policies WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row) | {"enabled": bool(row["enabled"])}

    def policies(self) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM blocking_policies ORDER BY id DESC").fetchall()
        return [dict(row) | {"enabled": bool(row["enabled"])} for row in rows]

    def delete_policy(self, policy_id: int) -> bool:
        with self.connect() as connection:
            cursor = connection.execute("DELETE FROM blocking_policies WHERE id=?", (policy_id,))
        return cursor.rowcount == 1

    def policy_sources(self) -> dict:
        with self.connect() as connection:
            policies = [dict(row) for row in connection.execute("SELECT * FROM blocking_policies WHERE enabled=1")]
            members = [dict(row) for row in connection.execute("SELECT * FROM device_group_members")]
            devices = [dict(row) for row in connection.execute("SELECT * FROM discovered_devices")]
            schedules = [dict(row) | {"days": json.loads(row["days_json"]), "enabled": bool(row["enabled"])} for row in connection.execute("SELECT * FROM schedules")]
        return {"policies": policies, "members": members, "devices": devices, "schedules": schedules}

    def create_blocklist(self, name: str, url: str, format_name: str, enabled: bool, update_hours: int, category: str = "") -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO blocklist_sources(name,url,format,enabled,update_hours,category,created_at) VALUES(?,?,?,?,?,?,?)", (name, url, format_name, int(enabled), update_hours, category.strip().lower(), utcnow()))
            row = connection.execute("SELECT * FROM blocklist_sources WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row) | {"enabled": bool(row["enabled"])}

    def blocklists(self) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM blocklist_sources ORDER BY name").fetchall()
        return [dict(row) | {"enabled": bool(row["enabled"])} for row in rows]

    def blocklist(self, source_id: int) -> dict | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM blocklist_sources WHERE id=?", (source_id,)).fetchone()
        return dict(row) if row else None

    def update_blocklist_status(self, source_id: int, *, status: str, domain_count: int = 0, digest: str | None = None, error: str | None = None) -> None:
        with self.connect() as connection:
            if status == "healthy":
                connection.execute("UPDATE blocklist_sources SET status=?,domain_count=?,content_sha256=?,last_updated_at=?,last_error=? WHERE id=?", (status, domain_count, digest, utcnow(), error, source_id))
            else:
                connection.execute("UPDATE blocklist_sources SET status=?,domain_count=?,content_sha256=?,last_error=? WHERE id=?", (status, domain_count, digest, error, source_id))

    def delete_blocklist(self, source_id: int) -> bool:
        with self.connect() as connection:
            cursor = connection.execute("DELETE FROM blocklist_sources WHERE id=?", (source_id,))
        return cursor.rowcount == 1

    def set_blocklist_enabled(self, source_id: int, enabled: bool) -> bool:
        with self.connect() as connection:
            cursor = connection.execute("UPDATE blocklist_sources SET enabled=? WHERE id=?", (int(enabled), source_id))
        return cursor.rowcount == 1

    def create_local_domain(self, domain: str, action: str, category: str, expires_at: str | None = None) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO local_domains(domain,action,category,created_at,expires_at) VALUES(?,?,?,?,?)", (domain, action, category, utcnow(), expires_at))
            row = connection.execute("SELECT * FROM local_domains WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    def delete_expired_local_domains(self, moment: str | None = None) -> int:
        """Remove local rules whose time ran out — the reconciler calls this each run."""
        with self.connect() as connection:
            return connection.execute("DELETE FROM local_domains WHERE expires_at IS NOT NULL AND expires_at <= ?", (moment or utcnow(),)).rowcount

    def local_domains(self) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM local_domains ORDER BY domain").fetchall()
        return [dict(row) for row in rows]

    def delete_local_domain(self, domain_id: int) -> bool:
        with self.connect() as connection:
            cursor = connection.execute("DELETE FROM local_domains WHERE id=?", (domain_id,))
        return cursor.rowcount == 1

    def save_application_policy(self, application: str, enabled: bool, block_quic: bool) -> dict:
        with self.connect() as connection:
            connection.execute("INSERT INTO application_policies(application,enabled,block_quic,updated_at) VALUES(?,?,?,?) ON CONFLICT(application) DO UPDATE SET enabled=excluded.enabled,block_quic=excluded.block_quic,updated_at=excluded.updated_at", (application, int(enabled), int(block_quic), utcnow()))
            row = connection.execute("SELECT * FROM application_policies WHERE application=? COLLATE NOCASE", (application,)).fetchone()
        return dict(row) | {"enabled": bool(row["enabled"]), "block_quic": bool(row["block_quic"])}

    def application_policies(self) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM application_policies ORDER BY application").fetchall()
        return [dict(row) | {"enabled": bool(row["enabled"]), "block_quic": bool(row["block_quic"])} for row in rows]

    def create_schedule(self, payload: dict) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO schedules(name,timezone,days_json,start_time,end_time,enabled,created_at) VALUES(?,?,?,?,?,?,?)", (payload["name"], payload["timezone"], json.dumps(payload["days"]), payload["start_time"], payload["end_time"], int(payload["enabled"]), utcnow()))
            row = connection.execute("SELECT * FROM schedules WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row) | {"days": json.loads(row["days_json"]), "enabled": bool(row["enabled"])}

    def schedules(self) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM schedules ORDER BY name").fetchall()
        return [dict(row) | {"days": json.loads(row["days_json"]), "enabled": bool(row["enabled"])} for row in rows]

    def delete_schedule(self, schedule_id: int) -> bool:
        with self.connect() as connection:
            return connection.execute("DELETE FROM schedules WHERE id=?", (schedule_id,)).rowcount == 1

    def security_events(self, limit: int = 100) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM security_events ORDER BY id DESC LIMIT ?", (min(max(limit, 1), 5000),)).fetchall()
        return [dict(row) | {"details": json.loads(row["details_json"])} for row in rows]

    def create_security_event(self, payload: dict) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO security_events(occurred_at,event_type,action,client_ip,hostname,destination,category,policy,details_json) VALUES(?,?,?,?,?,?,?,?,?)", (utcnow(), payload["event_type"], payload["action"], payload.get("client_ip"), payload.get("hostname"), payload.get("destination"), payload.get("category"), payload.get("policy"), json.dumps(payload.get("details", {}))))
            row = connection.execute("SELECT * FROM security_events WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row) | {"details": json.loads(row["details_json"])}

    def purge_operational_data(self, event_before: str, audit_before: str, access_before: str) -> dict:
        with self.connect() as connection:
            events = connection.execute("DELETE FROM security_events WHERE occurred_at < ?", (event_before,)).rowcount
            audit = connection.execute("DELETE FROM audit_events WHERE occurred_at < ?", (audit_before,)).rowcount
            access = connection.execute("DELETE FROM access_requests WHERE created_at < ?", (access_before,)).rowcount
        return {"security_events": events, "audit_events": audit, "access_requests": access}

    def create_access_request(self, payload: dict) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO access_requests(requested_host,client_ip,device_name,reason,created_at) VALUES(?,?,?,?,?)", (payload["requested_host"], payload["client_ip"], payload.get("device_name"), payload["reason"], utcnow()))
            row = connection.execute("SELECT * FROM access_requests WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    def access_requests(self) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM access_requests ORDER BY id DESC").fetchall()
        return [dict(row) for row in rows]

    def pending_access_request(self, client_ip: str, requested_host: str) -> dict | None:
        """The still-pending request for this client and site, if one exists."""
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM access_requests WHERE client_ip=? AND requested_host=? AND status='pending' ORDER BY id DESC LIMIT 1", (client_ip, requested_host)).fetchone()
        return dict(row) if row else None

    def latest_access_request(self, client_ip: str, requested_host: str) -> dict | None:
        """The newest request for this client and site, whatever its status."""
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM access_requests WHERE client_ip=? AND requested_host=? ORDER BY id DESC LIMIT 1", (client_ip, requested_host)).fetchone()
        return dict(row) if row else None

    def clear_reviewed_access_requests(self) -> int:
        """Delete every reviewed (approved/denied) request; pending ones stay."""
        with self.connect() as connection:
            return connection.execute("DELETE FROM access_requests WHERE status != 'pending'").rowcount

    def access_request(self, request_id: int) -> dict | None:
        with self.connect() as connection: row = connection.execute("SELECT * FROM access_requests WHERE id=?", (request_id,)).fetchone()
        return dict(row) if row else None

    def review_access_request(self, request_id: int, decision: str, reviewer: str, note: str) -> dict | None:
        with self.connect() as connection:
            connection.execute("UPDATE access_requests SET status=?,reviewed_at=?,reviewed_by=?,review_note=? WHERE id=? AND status='pending'", (decision, utcnow(), reviewer, note, request_id))
            row = connection.execute("SELECT * FROM access_requests WHERE id=?", (request_id,)).fetchone()
        return dict(row) if row else None

    def create_zone(self, payload: dict) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO firewall_zones(name,interfaces_json,networks_json,default_action,created_at) VALUES(?,?,?,?,?)", (payload["name"], json.dumps(payload["interfaces"]), json.dumps(payload["networks"]), payload["default_action"], utcnow()))
            row = connection.execute("SELECT * FROM firewall_zones WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row) | {"interfaces": json.loads(row["interfaces_json"]), "networks": json.loads(row["networks_json"])}

    def zones(self) -> list[dict]:
        with self.connect() as connection: rows = connection.execute("SELECT * FROM firewall_zones ORDER BY name").fetchall()
        return [dict(row) | {"interfaces": json.loads(row["interfaces_json"]), "networks": json.loads(row["networks_json"])} for row in rows]

    def delete_zone(self, item_id: int) -> bool:
        with self.connect() as connection: return connection.execute("DELETE FROM firewall_zones WHERE id=?", (item_id,)).rowcount == 1

    def create_port_forward(self, payload: dict) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO port_forwards(name,protocol,external_port,internal_ip,internal_port,source_network,enabled,created_at) VALUES(?,?,?,?,?,?,?,?)", (payload["name"], payload["protocol"], payload["external_port"], payload["internal_ip"], payload["internal_port"], payload.get("source_network"), int(payload["enabled"]), utcnow()))
            row = connection.execute("SELECT * FROM port_forwards WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row) | {"enabled": bool(row["enabled"])}

    def port_forwards(self) -> list[dict]:
        with self.connect() as connection: rows = connection.execute("SELECT * FROM port_forwards ORDER BY external_port").fetchall()
        return [dict(row) | {"enabled": bool(row["enabled"])} for row in rows]

    def delete_port_forward(self, item_id: int) -> bool:
        with self.connect() as connection: return connection.execute("DELETE FROM port_forwards WHERE id=?", (item_id,)).rowcount == 1

    def create_dhcp_reservation(self, payload: dict) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO dhcp_reservations(mac_address,ip_address,hostname,created_at) VALUES(?,?,?,?)", (payload["mac_address"].lower(), payload["ip_address"], payload["hostname"], utcnow()))
            row = connection.execute("SELECT * FROM dhcp_reservations WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    def dhcp_reservations(self) -> list[dict]:
        with self.connect() as connection: rows = connection.execute("SELECT * FROM dhcp_reservations ORDER BY ip_address").fetchall()
        return [dict(row) for row in rows]

    def ip_pools(self) -> list[dict]:
        with self.connect() as connection: rows = connection.execute("SELECT * FROM ip_pools ORDER BY vlan_id").fetchall()
        return [dict(row) for row in rows]

    def create_ip_pool(self, row: dict) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO ip_pools (name,vlan_id,subnet,pool_start,pool_end,router,enabled,created_at) VALUES (?,?,?,?,?,?,?,?)", (row["name"], row["vlan_id"], row["subnet"], row["pool_start"], row["pool_end"], row["router"], row["enabled"], row["created_at"]))
            return dict(connection.execute("SELECT * FROM ip_pools WHERE id = ?", (cursor.lastrowid,)).fetchone())

    def delete_ip_pool(self, item_id: int) -> bool:
        with self.connect() as connection:
            return bool(connection.execute("DELETE FROM ip_pools WHERE id = ?", (item_id,)).rowcount)

    def portal_acceptances(self) -> list[dict]:
        with self.connect() as connection: rows = connection.execute("SELECT * FROM portal_acceptances ORDER BY accepted_at DESC").fetchall()
        return [dict(row) for row in rows]

    def wireguard_peers(self) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM wireguard_peers ORDER BY id").fetchall()
        return [dict(row) for row in rows]

    def wireguard_peer(self, item_id: int) -> dict | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM wireguard_peers WHERE id = ?", (item_id,)).fetchone()
        return dict(row) if row else None

    def create_wireguard_peer(self, peer: dict) -> dict:
        with self.connect() as connection:
            cursor = connection.execute(
                "INSERT INTO wireguard_peers (name, kind, public_key, preshared_key, allowed_ips, "
                "endpoint_host, endpoint_port, keepalive, enabled) VALUES (?,?,?,?,?,?,?,?,?)",
                (peer["name"], peer["kind"], peer["public_key"], peer.get("preshared_key") or "",
                 peer["allowed_ips"], peer.get("endpoint_host") or "", int(peer.get("endpoint_port") or 0),
                 int(peer.get("keepalive") or 0), 1 if peer.get("enabled", True) else 0))
            return dict(connection.execute("SELECT * FROM wireguard_peers WHERE id = ?", (cursor.lastrowid,)).fetchone())

    def update_wireguard_peer(self, item_id: int, peer: dict) -> dict | None:
        with self.connect() as connection:
            existing = connection.execute("SELECT id FROM wireguard_peers WHERE id = ?", (item_id,)).fetchone()
            if not existing:
                return None
            connection.execute(
                "UPDATE wireguard_peers SET name=?, kind=?, public_key=?, preshared_key=?, allowed_ips=?, "
                "endpoint_host=?, endpoint_port=?, keepalive=?, enabled=? WHERE id=?",
                (peer["name"], peer["kind"], peer["public_key"], peer.get("preshared_key") or "",
                 peer["allowed_ips"], peer.get("endpoint_host") or "", int(peer.get("endpoint_port") or 0),
                 int(peer.get("keepalive") or 0), 1 if peer.get("enabled", True) else 0, item_id))
            return dict(connection.execute("SELECT * FROM wireguard_peers WHERE id = ?", (item_id,)).fetchone())

    def delete_wireguard_peer(self, item_id: int) -> bool:
        with self.connect() as connection:
            return bool(connection.execute("DELETE FROM wireguard_peers WHERE id = ?", (item_id,)).rowcount)

    def create_portal_acceptance(self, mac_address: str, ip_address: str = "") -> dict:
        with self.connect() as connection:
            connection.execute("INSERT OR REPLACE INTO portal_acceptances (mac_address,ip_address,accepted_at) VALUES (?,?,?)", (mac_address.lower(), ip_address, datetime.now(UTC).isoformat()))
            return dict(connection.execute("SELECT * FROM portal_acceptances WHERE mac_address = ?", (mac_address.lower(),)).fetchone())

    def delete_portal_acceptance(self, item_id: int) -> bool:
        with self.connect() as connection:
            return bool(connection.execute("DELETE FROM portal_acceptances WHERE id = ?", (item_id,)).rowcount)

    def category_groups(self) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM category_groups ORDER BY name COLLATE NOCASE").fetchall()
            apps = {row[0]: [item[0] for item in connection.execute("SELECT application FROM category_group_apps WHERE group_id = ? ORDER BY application", (row[0],)).fetchall()] for row in rows}
        return [dict(row) | {"applications": apps.get(row["id"], [])} for row in rows]

    def category_group_by_name(self, name: str) -> dict | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM category_groups WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
        return dict(row) if row else None

    def create_category_group(self, name: str, description: str) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO category_groups (name,description,created_at) VALUES (?,?,?)", (name, description, utcnow()))
            return dict(connection.execute("SELECT * FROM category_groups WHERE id = ?", (cursor.lastrowid,)).fetchone())

    def delete_category_group(self, group_id: int) -> bool:
        with self.connect() as connection:
            return bool(connection.execute("DELETE FROM category_groups WHERE id = ?", (group_id,)).rowcount)

    def category_group_add_app(self, group_id: int, application: str) -> None:
        with self.connect() as connection:
            connection.execute("INSERT OR IGNORE INTO category_group_apps (group_id,application) VALUES (?,?)", (group_id, application.lower()))

    def custom_services(self) -> list[dict]:
        import json as json_module

        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM custom_services ORDER BY name COLLATE NOCASE").fetchall()
        services = []
        for row in rows:
            service = dict(row)
            try:
                service["domains"] = json_module.loads(service.pop("domains_json"))
            except ValueError:
                service["domains"] = []
            services.append(service)
        return services

    def create_custom_service(self, name: str, category: str, domains: list[str]) -> dict:
        import json as json_module

        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO custom_services (name,category,domains_json,enabled,created_at) VALUES (?,?,?,?,?)", (name, category, json_module.dumps(sorted(set(domains))), 1, utcnow()))
            return dict(connection.execute("SELECT * FROM custom_services WHERE id = ?", (cursor.lastrowid,)).fetchone())

    def custom_service_by_name(self, name: str) -> dict | None:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM custom_services WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
        return dict(row) if row else None

    def service_extensions(self) -> list[dict]:
        """Extra domains added to curated services (for example threads.com onto
        instagram — the domains list is the administrator's, not the catalog's)."""
        import json as json_module

        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM service_extensions ORDER BY name").fetchall()
        return [{"name": row["name"], "domains": json_module.loads(row["domains_json"])} for row in rows]

    def add_service_extension(self, name: str, domains: list[str]) -> dict:
        """Add domains to a curated service's extras (merging with existing)."""
        import json as json_module

        with self.connect() as connection:
            row = connection.execute("SELECT domains_json FROM service_extensions WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
            merged = sorted(set(json_module.loads(row["domains_json"])) | set(domains)) if row else sorted(set(domains))
            if row:
                connection.execute("UPDATE service_extensions SET domains_json = ? WHERE name = ? COLLATE NOCASE", (json_module.dumps(merged), name))
            else:
                connection.execute("INSERT INTO service_extensions (name,domains_json,created_at) VALUES (?,?,?)", (name, json_module.dumps(merged), utcnow()))
        return {"name": name, "domains": merged}

    def remove_service_extension_domain(self, name: str, domain: str) -> list[str]:
        """Remove one domain from a service's extras; returns what remains."""
        import json as json_module

        with self.connect() as connection:
            row = connection.execute("SELECT domains_json FROM service_extensions WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
            if not row:
                return []
            remaining = sorted(set(json_module.loads(row["domains_json"])) - {domain})
            if remaining:
                connection.execute("UPDATE service_extensions SET domains_json = ? WHERE name = ? COLLATE NOCASE", (json_module.dumps(remaining), name))
            else:
                connection.execute("DELETE FROM service_extensions WHERE name = ? COLLATE NOCASE", (name,))
        return remaining

    def remove_custom_service_domain(self, name: str, domain: str) -> list[str]:
        """Remove one domain from a custom service; returns what remains."""
        import json as json_module

        with self.connect() as connection:
            row = connection.execute("SELECT domains_json FROM custom_services WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
            if not row:
                return []
            remaining = sorted(set(json_module.loads(row["domains_json"])) - {domain})
            if remaining:
                connection.execute("UPDATE custom_services SET domains_json = ? WHERE name = ? COLLATE NOCASE", (json_module.dumps(remaining), name))
        return remaining

    def add_custom_service_domains(self, name: str, domains: list[str]) -> dict:
        """Merge new domains into a custom service's own domain list."""
        import json as json_module

        with self.connect() as connection:
            row = connection.execute("SELECT * FROM custom_services WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
            if not row:
                return {"name": name, "domains": sorted(set(domains))}
            merged = sorted(set(json_module.loads(row["domains_json"])) | set(domains))
            connection.execute("UPDATE custom_services SET domains_json = ? WHERE name = ? COLLATE NOCASE", (json_module.dumps(merged), name))
            return {"name": name, "domains": merged}

    def delete_custom_service(self, item_id: int) -> bool:
        with self.connect() as connection:
            return bool(connection.execute("DELETE FROM custom_services WHERE id = ?", (item_id,)).rowcount)

    def category_group_remove_app(self, group_id: int, application: str) -> None:
        with self.connect() as connection:
            connection.execute("DELETE FROM category_group_apps WHERE group_id = ? AND application = ?", (group_id, application.lower()))

    def local_domains_in_category(self, category: str) -> list[dict]:
        with self.connect() as connection:
            rows = connection.execute("SELECT * FROM local_domains WHERE category = ? COLLATE NOCASE ORDER BY domain", (category,)).fetchall()
        return [dict(row) for row in rows]

    def set_domain_action(self, domain_id: int, action: str) -> None:
        with self.connect() as connection:
            connection.execute("UPDATE local_domains SET action = ? WHERE id = ?", (action, domain_id))

    def delete_dhcp_reservation(self, item_id: int) -> bool:
        with self.connect() as connection: return connection.execute("DELETE FROM dhcp_reservations WHERE id=?", (item_id,)).rowcount == 1

    def create_dns_record(self, payload: dict) -> dict:
        with self.connect() as connection:
            cursor = connection.execute("INSERT INTO local_dns_records(name,record_type,value,created_at) VALUES(?,?,?,?)", (payload["name"].lower().rstrip("."), payload["record_type"], payload["value"], utcnow()))
            row = connection.execute("SELECT * FROM local_dns_records WHERE id=?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    def dns_records(self) -> list[dict]:
        with self.connect() as connection: rows = connection.execute("SELECT * FROM local_dns_records ORDER BY name,record_type").fetchall()
        return [dict(row) for row in rows]

    def delete_dns_record(self, item_id: int) -> bool:
        with self.connect() as connection: return connection.execute("DELETE FROM local_dns_records WHERE id=?", (item_id,)).rowcount == 1
