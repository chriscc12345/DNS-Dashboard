from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import shutil
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class FirewallModule:
    key: str
    name: str
    description: str
    packages: tuple[str, ...] = ()
    kernel_modules: tuple[str, ...] = ()
    conflicts: tuple[str, ...] = ()
    requires: tuple[str, ...] = ()
    default_enabled: bool = False


MODULES = (
    FirewallModule("stateful", "Stateful firewall", "Connection tracking, invalid-packet rejection and default-deny chains.", kernel_modules=("nf_conntrack",), default_enabled=True),
    FirewallModule("nat", "NAT and routing", "IPv4 masquerading, destination NAT and controlled forwarding.", kernel_modules=("nf_nat", "iptable_nat"), requires=("stateful",), default_enabled=True),
    FirewallModule("port_forwarding", "Port forwarding", "Managed DNAT rules with source restrictions and matching return traffic.", requires=("nat",)),
    FirewallModule("ipset", "Large address sets", "Atomic IPv4/IPv6 sets for feeds, countries, applications and threat intelligence.", packages=("ipset",), kernel_modules=("ip_set",), default_enabled=True),
    FirewallModule("rate_limit", "Rate limiting", "SYN, ICMP and new-connection rate controls with burst thresholds.", kernel_modules=("xt_hashlimit",), default_enabled=True),
    FirewallModule("port_scan", "Port-scan protection", "Recent-list detection and temporary source quarantine.", kernel_modules=("xt_recent",), requires=("stateful",)),
    FirewallModule("anti_spoof", "Anti-spoofing", "Rejects invalid source ranges and enforces reverse-path filtering.", default_enabled=True),
    FirewallModule("mac_filter", "MAC filtering", "Layer-2 client allow/block controls on directly connected networks.", kernel_modules=("xt_mac",)),
    FirewallModule("geoip", "GeoIP policy", "Country address-set policy using locally maintained feeds.", packages=("ipset",), requires=("ipset",)),
    FirewallModule("dns_enforcement", "DNS enforcement", "Redirects client DNS to the appliance and blocks direct encrypted-DNS endpoints.", requires=("nat",)),
    FirewallModule("web_filter", "Web and application control", "Coordinates DNS, IP sets, QUIC blocking and optional proxy policy.", requires=("ipset",)),
    FirewallModule("ids_ips", "IDS/IPS integration", "Queues or mirrors selected traffic to Suricata.", packages=("suricata",), kernel_modules=("nfnetlink_queue",), requires=("stateful",)),
    FirewallModule("logging", "Firewall event logging", "Rate-limited NFLOG records for reporting and alerting.", packages=("ulogd2",), kernel_modules=("nfnetlink_log",), default_enabled=True),
    FirewallModule("ipv6", "IPv6 firewall", "Equivalent ip6tables default-deny and forwarding controls.", default_enabled=True),
    FirewallModule("bridge", "Transparent bridge filtering", "Bridge netfilter support for two-NIC transparent mode.", packages=("bridge-utils",), kernel_modules=("br_netfilter",)),
    FirewallModule("high_availability", "High availability", "Conntrack state synchronisation and VRRP integration.", packages=("conntrackd", "keepalived"), requires=("stateful",)),
)

MODULE_MAP = {module.key: module for module in MODULES}


def default_module_state() -> dict[str, bool]:
    return {module.key: module.default_enabled for module in MODULES}


def resolve_module_state(requested: dict[str, bool]) -> dict[str, bool]:
    unknown = sorted(set(requested) - set(MODULE_MAP))
    if unknown:
        raise ValueError(f"Unknown firewall modules: {', '.join(unknown)}")
    state = default_module_state() | requested
    changed = True
    while changed:
        changed = False
        for key, enabled in tuple(state.items()):
            if not enabled:
                continue
            module = MODULE_MAP[key]
            for required in module.requires:
                if not state[required]:
                    state[required] = True
                    changed = True
            for conflict in module.conflicts:
                if state.get(conflict):
                    raise ValueError(f"{module.name} conflicts with {MODULE_MAP[conflict].name}")
    return state


# Plain-language per-module explanations for the dashboard detail view.
# readiness answers "what happens when I switch this on":
#   enforced   - acts on traffic automatically as soon as it is on
#   configured - on, but needs rules you create elsewhere first
#   software   - needs extra software installed from the dashboard first
#   planned    - announced capability, not wired to live traffic yet (honest status)
MODULE_PLAIN = {
    "stateful": {"detail": "Tracks every connection so replies to your own devices are allowed in, while unrequested traffic from the internet is dropped.", "readiness": "enforced"},
    "nat": {"detail": "Lets all your devices share the one internet address of the firewall (this is how a standard gateway works).", "readiness": "enforced"},
    "port_forwarding": {"detail": "Opens doors from the internet to chosen internal servers, such as a camera or game server. Nothing is exposed until you add a forward in the Network section.", "readiness": "configured"},
    "ipset": {"detail": "Holds very large address lists (blocking feeds, threat intelligence) in the kernel so millions of addresses can be checked without slowing traffic.", "readiness": "enforced"},
    "rate_limit": {"detail": "Protects the firewall itself from floods — too many new connections from one source are dropped.", "readiness": "enforced"},
    "port_scan": {"detail": "Detects when someone probes your firewall for open doors and temporarily cuts their access completely.", "readiness": "enforced"},
    "anti_spoof": {"detail": "Drops packets pretending to come from impossible addresses (loopback, link-local, broadcast) — a common attack trick.", "readiness": "enforced"},
    "mac_filter": {"detail": "Blocks devices by hardware (MAC) address. Takes effect for the device blocks you create on the Devices page.", "readiness": "enforced"},
    "geoip": {"detail": "Planned: allow or block whole countries. This module has no effect on traffic yet — the country feed is not built.", "readiness": "planned"},
    "dns_enforcement": {"detail": "Every device on your network must use this firewall for name lookups, so blocked sites cannot be bypassed with a different DNS server.", "readiness": "enforced"},
    "web_filter": {"detail": "Applies your web rules: blocked domains, application controls and QUIC elimination so browsers stay filterable.", "readiness": "enforced"},
    "ids_ips": {"detail": "Deep packet inspection with Suricata: inspects traffic against thousands of known-attack signatures and stops attacks in real time. Requires the Suricata software, installed from this page.", "readiness": "software"},
    "logging": {"detail": "Records what the firewall drops, so the Reports page can show who tried what.", "readiness": "enforced"},
    "ipv6": {"detail": "The same protection for IPv6 traffic, so devices using the newer internet protocol cannot slip past the rules.", "readiness": "enforced"},
    "bridge": {"detail": "Planned: for the two-adapter inline (transparent) mode. No effect in the standard routed-gateway mode.", "readiness": "planned"},
    "high_availability": {"detail": "Planned: a second firewall unit takes over automatically if this one fails. Not yet wired to live traffic.", "readiness": "planned"},
}


def module_inventory(state: dict[str, bool] | None = None) -> list[dict]:
    resolved = resolve_module_state(state or {})
    loaded = set()
    try:
        loaded = {line.split()[0] for line in Path("/proc/modules").read_text().splitlines() if line}
    except OSError:
        pass
    return [asdict(module) | MODULE_PLAIN.get(module.key, {"detail": module.description, "readiness": "enforced"}) | {
        "enabled": resolved[module.key],
        "packages_available": all(shutil.which(pkg) for pkg in module.packages) if module.packages else True,
        "kernel_modules_loaded": all(item in loaded for item in module.kernel_modules) if module.kernel_modules else True,
    } for module in MODULES]


# Curated public DoH endpoints whose HTTPS service would bypass the appliance resolver.
DOH_ENDPOINTS = (
    "1.1.1.1", "1.0.0.1",          # Cloudflare
    "8.8.8.8", "8.8.4.4",          # Google
    "9.9.9.9", "149.112.112.112",  # Quad9
    "208.67.222.222", "208.67.220.220",  # Cisco OpenDNS
    "94.140.14.14", "94.140.15.15",  # AdGuard
)


def _safe_network(value: str) -> str:
    return str(ipaddress.ip_network(value, strict=False))


def render_iptables(state: dict[str, bool], settings: dict, network_rules: dict, block_targets: dict, controls: dict | None = None) -> str:
    state = resolve_module_state(state)
    controls = controls or {}
    # Management networks: comma-separated list is supported so several
    # trusted ranges (office LAN + management VLAN) can open the dashboard.
    management_networks = [item.strip() for item in str(settings.get("management_network", "192.168.0.0/16")).split(",") if item.strip()]
    # Admin dashboard port (set on the Operations page). The management UI is
    # served by nginx on this port; when it moves off 80 the new port must be
    # reachable everywhere the old one was, or the administrator is locked out.
    try:
        admin_port = int(settings.get("admin_port") or 80)
    except (TypeError, ValueError):
        admin_port = 80
    admin_port = min(max(admin_port, 1), 65535)
    mgmt_dports = "22,80,443,8080"
    if admin_port not in (22, 80, 443, 8080):
        mgmt_dports = f"{mgmt_dports},{admin_port}"
    lan_network = _safe_network(settings.get("lan_network", "192.168.10.0/24"))
    wan = settings.get("wan_interface", "eth0")
    lan = settings.get("lan_interface", "eth1")
    lines = [
        "*filter", ":INPUT DROP [0:0]", ":FORWARD DROP [0:0]", ":OUTPUT ACCEPT [0:0]",
        ":FW-INPUT - [0:0]", ":FW-FORWARD - [0:0]", ":FW-LOGDROP - [0:0]",
        "-A INPUT -i lo -j ACCEPT",
        "-A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT",
        "-A INPUT -m conntrack --ctstate INVALID -j DROP",
        *[f"-A INPUT -s {_safe_network(item)} -p tcp -m multiport --dports {mgmt_dports} -j ACCEPT" for item in management_networks],
        "-A INPUT -p icmp --icmp-type echo-request -m limit --limit 10/second --limit-burst 20 -j ACCEPT",
        "-A FORWARD -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT",
    ]
    if state["anti_spoof"]:
        for cidr in ("0.0.0.0/8", "127.0.0.0/8", "169.254.0.0/16", "224.0.0.0/4", "240.0.0.0/4"):
            lines.append(f"-A INPUT -i {wan} -s {cidr} -j DROP")
    # Port-scan quarantine, placed before every service accept: a quarantined
    # source loses all access (established sessions keep flowing). Probe SYNs to
    # closed ports are tracked; too many within the window triggers quarantine.
    # Ports the appliance itself answers (or politely rejects, like 443 for
    # blocked domains) are excluded so ordinary browsing never trips the detector.
    if state["port_scan"]:
        openish = "22,53,67,80,443,3128,8080"
        if admin_port not in (22, 53, 67, 80, 443, 3128, 8080):
            openish = f"{openish},{admin_port}"
        scan_verdict = "FW-LOGDROP" if state["logging"] else "DROP"
        lines += [
            f"-A INPUT -p tcp -m tcp --syn -m multiport ! --dports {openish} -m recent --name fwscan --set",
            f"-A INPUT -m recent --name fwscan --rcheck --seconds 60 --hitcount 8 -m recent --name fwscanblock --set",
            f"-A INPUT -m recent --name fwscanblock --rcheck --seconds 300 -j {scan_verdict}",
        ]
    if state["rate_limit"]:
        lines += ["-A INPUT -p tcp --syn -m hashlimit --hashlimit-above 50/second --hashlimit-burst 100 --hashlimit-mode srcip --hashlimit-name syn_rate -j DROP"]
    # Services the appliance itself offers to LAN clients (DNS, DHCP, block page, proxy).
    if lan:
        if state["dns_enforcement"] or controls.get("force_local_dns"):
            lines += [f"-A INPUT -i {lan} -p udp --dport 53 -j ACCEPT", f"-A INPUT -i {lan} -p tcp --dport 53 -j ACCEPT"]
        lines += [
            f"-A INPUT -i {lan} -p udp --dport 67 -j ACCEPT",
            f"-A INPUT -i {lan} -p tcp --dport 80 -j ACCEPT",
        ]
        if admin_port != 80:
            lines.append(f"-A INPUT -i {lan} -p tcp --dport {admin_port} -j ACCEPT")
        if state["web_filter"]:
            lines += [f"-A INPUT -i {lan} -p tcp --dport 3128 -j ACCEPT"]
        # Blocked HTTPS domains resolve to this appliance. With the CA block-page
        # service running, TCP 443 is accepted so it can present the branded page
        # over TLS; otherwise reject so browsers fail fast instead of hanging.
        if controls.get("tls_block"):
            lines += [f"-A INPUT -i {lan} -p tcp --dport 443 -j ACCEPT"]
        else:
            lines += [f"-A INPUT -i {lan} -p tcp --dport 443 -j REJECT --reject-with tcp-reset"]
        # Policy-acceptance portal: unaccepted devices reach the portal page on
        # this port (served by nginx) while everything else is held back.
        if controls.get("portal_enabled"):
            lines += [f"-A INPUT -i {lan} -p tcp --dport 8420 -j ACCEPT"]
    # Additional IP pools: each pool is a VLAN subinterface of the LAN adapter
    # (auto-created by the appliance). Same service set as the primary LAN.
    pools = [row for row in (network_rules or {}).get("pools", []) if row.get("enabled", 1)]
    portal_verdict = "FW-LOGDROP" if state["logging"] else "DROP"
    for pool in pools:
        iface = f"{lan}.{pool['vlan_id']}"
        if state["dns_enforcement"] or controls.get("force_local_dns"):
            lines += [f"-A INPUT -i {iface} -p udp --dport 53 -j ACCEPT", f"-A INPUT -i {iface} -p tcp --dport 53 -j ACCEPT"]
        lines += [f"-A INPUT -i {iface} -p udp --dport 67 -j ACCEPT", f"-A INPUT -i {iface} -p tcp --dport 80 -j ACCEPT"]
        if admin_port != 80:
            lines.append(f"-A INPUT -i {iface} -p tcp --dport {admin_port} -j ACCEPT")
        if state["web_filter"]:
            lines += [f"-A INPUT -i {iface} -p tcp --dport 3128 -j ACCEPT"]
        if controls.get("tls_block"):
            lines += [f"-A INPUT -i {iface} -p tcp --dport 443 -j ACCEPT"]
        else:
            lines += [f"-A INPUT -i {iface} -p tcp --dport 443 -j REJECT --reject-with tcp-reset"]
        if controls.get("portal_enabled"):
            lines += [f"-A INPUT -i {iface} -p tcp --dport 8420 -j ACCEPT"]
    for address in block_targets.get("ipv4", []):
        lines += [f"-A INPUT -s {address} -j DROP", f"-A FORWARD -s {address} -j DROP"]
    for address in block_targets.get("mac", []):
        lines.append(f"-A FORWARD -i {lan} -m mac --mac-source {address} -j DROP")
    # Portal hold: devices that have not accepted the network policy are held
    # back from the internet entirely (DNS stays local, the portal page itself
    # is served from the appliance via the INPUT accepts above).
    if lan and controls.get("portal_enabled"):
        lines += [f"-A FORWARD -i {lan} -m set ! --match-set fw-portal-accepted src -j {portal_verdict}"]
    for pool in pools:
        if controls.get("portal_enabled"):
            lines += [f"-A FORWARD -i {lan}.{pool['vlan_id']} -m set ! --match-set fw-portal-accepted src -j {portal_verdict}"]
    # Deep packet inspection: send every new client connection through Suricata
    # (NFQUEUE 1) before the allow. --queue-bypass keeps traffic flowing if the
    # Suricata service is not running, so inspection never becomes an outage.
    if lan and state["ids_ips"]:
        lines += [f"-A FORWARD -i {lan} -o {wan} -j NFQUEUE --queue-num 1 --queue-bypass"]
        for pool in pools:
            lines += [f"-A FORWARD -i {lan}.{pool['vlan_id']} -o {wan} -j NFQUEUE --queue-num 1 --queue-bypass"]
    # Controlled LAN to WAN forwarding (the gateway path for client internet access).
    if lan:
        lines += [f"-A FORWARD -i {lan} -s {lan_network} -o {wan} -j ACCEPT"]
        for pool in pools:
            lines += [f"-A FORWARD -i {lan}.{pool['vlan_id']} -s {pool['subnet']} -o {wan} -j ACCEPT"]
    # QUIC/HTTP3 elimination so browsers fall back to TCP where filtering applies.
    if state["web_filter"] and controls.get("block_quic"):
        lines += [f"-A FORWARD -i {lan} -p udp --dport 443 -j REJECT"]
    # Block encrypted-DNS bypasses: DNS-over-TLS and known DNS-over-HTTPS endpoints.
    if state["dns_enforcement"] and controls.get("block_dot"):
        lines += ["-A FORWARD -p tcp --dport 853 -j REJECT --reject-with tcp-reset", "-A FORWARD -p udp --dport 853 -j REJECT"]
    if state["dns_enforcement"] and controls.get("block_doh"):
        for address in DOH_ENDPOINTS:
            lines += [f"-A FORWARD -d {address} -p tcp --dport 443 -j REJECT", f"-A FORWARD -d {address} -p udp --dport 443 -j REJECT"]
    if state["logging"]:
        lines += ["-A FW-LOGDROP -m limit --limit 12/minute --limit-burst 20 -j NFLOG --nflog-prefix \"FW-DROP \"", "-A FW-LOGDROP -j DROP", "-A INPUT -j FW-LOGDROP", "-A FORWARD -j FW-LOGDROP"]
    else:
        lines += ["-A INPUT -j DROP", "-A FORWARD -j DROP"]
    lines += ["COMMIT"]
    if state["nat"]:
        lines += ["*nat", ":PREROUTING ACCEPT [0:0]", ":INPUT ACCEPT [0:0]", ":OUTPUT ACCEPT [0:0]", ":POSTROUTING ACCEPT [0:0]"]
        if settings.get("masquerade", True):
            lines.append(f"-A POSTROUTING -o {wan} -j MASQUERADE")
        if state["dns_enforcement"]:
            lines += [f"-A PREROUTING -i {lan} -p udp --dport 53 -j REDIRECT --to-ports 53", f"-A PREROUTING -i {lan} -p tcp --dport 53 -j REDIRECT --to-ports 53"]
            for pool in pools:
                iface = f"{lan}.{pool['vlan_id']}"
                lines += [f"-A PREROUTING -i {iface} -p udp --dport 53 -j REDIRECT --to-ports 53", f"-A PREROUTING -i {iface} -p tcp --dport 53 -j REDIRECT --to-ports 53"]
        if controls.get("portal_enabled"):
            for iface in [lan] + [f"{lan}.{pool['vlan_id']}" for pool in pools]:
                lines += [f"-A PREROUTING -i {iface} -p tcp --dport 80 -m set ! --match-set fw-portal-accepted src -j REDIRECT --to-ports 8420"]
        if state["port_forwarding"]:
            for rule in network_rules.get("port_forwards", []):
                if not rule.get("enabled", True):
                    continue
                source = f" -s {rule['source_network']}" if rule.get("source_network") else ""
                lines.append(f"-A PREROUTING -i {wan}{source} -p {rule['protocol']} --dport {rule['external_port']} -j DNAT --to-destination {rule['internal_ip']}:{rule['internal_port']}")
        lines.append("COMMIT")
    return "\n".join(lines) + "\n"


def render_ip6tables(state: dict[str, bool], settings: dict, block_targets: dict, controls: dict | None = None) -> str:
    """Equivalent IPv6 default-deny ruleset (ip6tables).

    Without this the v6 path is an unfiltered hole. ICMPv6 (neighbour
    discovery, router advertisement, PMTUD) is permitted for basic v6
    function; management stays on the v4 network by design. NAT is never
    used for v6 — only the DNS redirect is installed so hijacked v6
    queries reach the local resolver.
    """
    state = resolve_module_state(state)
    controls = controls or {}
    lan = settings.get("lan_interface", "")
    verdict = "FW-LOGDROP" if state["logging"] else "DROP"
    lines = [
        "*filter", ":INPUT DROP [0:0]", ":FORWARD DROP [0:0]", ":OUTPUT ACCEPT [0:0]",
        ":FW-LOGDROP - [0:0]",
        "-A INPUT -i lo -j ACCEPT",
        "-A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT",
        "-A INPUT -m conntrack --ctstate INVALID -j DROP",
        "-A INPUT -p ipv6-icmp -j ACCEPT",
    ]
    if state["port_scan"]:
        openish6 = "22,53,80,443,3128,8080"
        lines += [
            f"-A INPUT -p tcp -m tcp --syn -m multiport ! --dports {openish6} -m recent --name fwscan6 --set",
            f"-A INPUT -m recent --name fwscan6 --rcheck --seconds 60 --hitcount 8 -m recent --name fwscanblock6 --set",
            f"-A INPUT -m recent --name fwscanblock6 --rcheck --seconds 300 -j {verdict}",
        ]
    if lan:
        lines += [
            f"-A INPUT -i {lan} -p udp -m udp --dport 53 -j ACCEPT",
            f"-A INPUT -i {lan} -p tcp -m tcp --dport 53 -j ACCEPT",
            f"-A INPUT -i {lan} -p tcp -m tcp --dport 80 -j ACCEPT",
        ]
        if state["web_filter"]:
            lines.append(f"-A INPUT -i {lan} -p tcp -m tcp --dport 3128 -j ACCEPT")
        if controls.get("tls_block"):
            lines.append(f"-A INPUT -i {lan} -p tcp -m tcp --dport 443 -j ACCEPT")
    for address in block_targets.get("ipv6", []):
        lines += [f"-A INPUT -s {address} -j {verdict}", f"-A FORWARD -s {address} -j {verdict}"]
    if state["logging"]:
        lines += ["-A FW-LOGDROP -m limit --limit 12/minute --limit-burst 20 -j NFLOG --nflog-prefix \"FW6-DROP \"", "-A FW-LOGDROP -j DROP", f"-A INPUT -j FW-LOGDROP", f"-A FORWARD -j FW-LOGDROP"]
    else:
        lines += ["-A INPUT -j DROP", "-A FORWARD -j DROP"]
    lines += ["COMMIT"]
    if lan and state["dns_enforcement"]:
        lines += [
            "*nat", ":PREROUTING ACCEPT [0:0]", ":INPUT ACCEPT [0:0]", ":OUTPUT ACCEPT [0:0]", ":POSTROUTING ACCEPT [0:0]",
            f"-A PREROUTING -i {lan} -p udp -m udp --dport 53 -j REDIRECT --to-ports 53",
            f"-A PREROUTING -i {lan} -p tcp -m tcp --dport 53 -j REDIRECT --to-ports 53",
            "COMMIT",
        ]
    return "\n".join(lines) + "\n"


def validate_restore(text: str, ipv6: bool = False, state_dir: str | Path | None = None) -> dict:
    """Kernel-validate a candidate ruleset.

    iptables-restore --test requires CAP_NET_ADMIN, so the unprivileged API
    stages the rules under the state directory and validates them through the
    fixed firewall-iptables-validate root helper. Root callers (the policy
    reconciler) validate directly.
    """
    import secrets

    binary = "ip6tables-restore" if ipv6 else "iptables-restore"
    if not shutil.which(binary):
        return {"valid": False, "available": False, "message": f"{binary} is not installed"}
    if os.geteuid() == 0:
        result = subprocess.run([binary, "--test"], input=text, text=True, capture_output=True, timeout=10, check=False)
        return {"valid": result.returncode == 0, "available": True, "message": result.stderr.strip() or "Rules passed kernel validation"}
    root = Path(state_dir or os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance")) / "iptables-validate"
    try:
        root.mkdir(parents=True, exist_ok=True)
        ident = f"iptval_{secrets.token_hex(8)}"
        (root / ident).mkdir()
        (root / ident / "rules.v4").write_text(text)
    except OSError as exc:
        return {"valid": False, "available": False, "message": f"Could not stage candidate for validation: {exc}"}
    completed = subprocess.run(["sudo", "-n", "/usr/local/sbin/firewall-iptables-validate", "validate", ident], text=True, capture_output=True, timeout=30, check=False)
    shutil.rmtree(root / ident, ignore_errors=True)
    try:
        body = json.loads(completed.stdout)
    except json.JSONDecodeError:
        return {"valid": False, "available": False, "message": completed.stderr.strip() or "Validation helper returned invalid output"}
    return {"valid": bool(body.get("valid")), "available": True, "message": body.get("message") or "Rules passed kernel validation"}


def candidate_payload(state: dict[str, bool], settings: dict, network_rules: dict, block_targets: dict, controls: dict | None = None) -> dict:
    resolved = resolve_module_state(state)
    rules = render_iptables(resolved, settings, network_rules, block_targets, controls)
    rules6 = render_ip6tables(resolved, settings, block_targets, controls) if resolved.get("ipv6") else ""
    digest = hashlib.sha256((rules + "\x00" + rules6).encode()).hexdigest()
    validation = validate_restore(rules)
    if rules6:
        checked6 = validate_restore(rules6, ipv6=True)
        if not checked6.get("valid"):
            validation = {**checked6, "message": f"IPv6 ruleset rejected: {checked6.get('message', 'validation failed')}"}
    return {"rules": rules, "rules6": rules6, "sha256": digest, "validation": validation, "modules": resolved}
