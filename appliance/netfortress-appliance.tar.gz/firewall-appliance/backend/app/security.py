from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta


SCRYPT_N = 2**14
SCRYPT_R = 8
SCRYPT_P = 1


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def _unb64(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    derived = hashlib.scrypt(password.encode(), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32)
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${_b64(salt)}${_b64(derived)}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, n, r, p, salt, expected = encoded.split("$", 5)
        if algorithm != "scrypt":
            return False
        actual = hashlib.scrypt(password.encode(), salt=_unb64(salt), n=int(n), r=int(r), p=int(p), dklen=32)
        return hmac.compare_digest(actual, _unb64(expected))
    except (ValueError, TypeError):
        return False


def token_digest(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


# Every scope the API can require; token creation validates against this catalog.
KNOWN_SCOPES = frozenset({
    "users:read", "users:write", "tokens:write",
    "audit:read", "audit:write", "events:write",
    "licensing:read", "licensing:write",
    "deployment:read", "deployment:write",
    "policies:read", "policies:write",
    "dns:read", "dns:write",
    "proxy:read", "proxy:write",
})

# Role → scope matrix for interactive sessions. None means unrestricted (admin).
ROLE_SCOPES: dict[str, frozenset[str] | None] = {
    "admin": None,
    "operator": frozenset({"deployment:read", "deployment:write", "policies:read", "policies:write", "dns:read", "dns:write", "proxy:read", "proxy:write", "audit:read", "events:write"}),
    "viewer": frozenset({"deployment:read", "policies:read", "dns:read", "proxy:read", "audit:read"}),
}

# Build 5 — user groups: what each permission key lets its holders do, and
# the API scopes it maps to. The dashboard decides what the keys mean; the
# scopes are what the API actually enforces.
PERMISSION_CATALOG: dict[str, str] = {
    "full_access": "Everything — full system administration",
    "dashboard": "Dashboard and live status",
    "devices": "Connected devices — view and block",
    "web_control": "Web control — sites, groups and feeds",
    "access_requests": "Access requests — review client requests",
    "reports": "Security reports and events",
    "network": "Network — adapters, DHCP, objects",
    "firewall": "Firewall rules — guarded changes",
    "modules": "Security modules",
    "operations": "Operations — backup, restore and updates",
    "users": "Users, groups and API tokens",
}

PERMISSION_SCOPES: dict[str, frozenset[str]] = {
    "dashboard": frozenset({"deployment:read", "policies:read"}),
    "devices": frozenset({"deployment:read", "policies:read", "policies:write"}),
    "web_control": frozenset({"dns:read", "dns:write", "policies:read", "policies:write"}),
    "access_requests": frozenset({"policies:read", "policies:write"}),
    "reports": frozenset({"audit:read", "events:write"}),
    "network": frozenset({"deployment:read", "deployment:write"}),
    "firewall": frozenset({"deployment:read", "deployment:write"}),
    "modules": frozenset({"deployment:read", "deployment:write"}),
    "operations": frozenset({"deployment:read", "deployment:write"}),
    "users": frozenset({"users:read", "users:write", "tokens:write"}),
}


def group_scopes(permissions: list[str]) -> frozenset[str]:
    """The API scopes a group's permission keys add up to."""
    if "full_access" in permissions:
        return frozenset({"*"})
    scopes: set[str] = set()
    for key in permissions:
        scopes |= set(PERMISSION_SCOPES.get(key, frozenset()))
    return frozenset(scopes)


def session_scopes(role: str) -> frozenset[str]:
    """Interactive sessions are limited by role, so the API enforces the UI's promises."""
    scopes = ROLE_SCOPES.get(role)
    return frozenset({"*"}) if scopes is None else scopes


def token_scopes_allowed(requested: list[str], role: str, caller_scopes: frozenset[str]) -> bool:
    """Tokens may only hold real scopes their creator can already use.

    Only admins may mint wildcard tokens; nobody can grant scopes they lack
    or invent unknown scope names.
    """
    for scope in requested:
        if scope == "*":
            if role != "admin":
                return False
        elif scope not in KNOWN_SCOPES:
            return False
        elif role != "admin" and scope not in caller_scopes:
            return False
    return True


def generate_api_token() -> tuple[str, str]:
    prefix = secrets.token_hex(4)
    return f"fw_{prefix}_{secrets.token_urlsafe(32)}", prefix


def _signing_key() -> bytes:
    value = os.environ.get("FIREWALL_SIGNING_KEY")
    if not value:
        # Development fallback. The installer creates and persists a random key.
        value = "development-only-change-me"
    return value.encode()


def create_session_token(user_id: int, role: str, minutes: int = 480) -> str:
    now = datetime.now(UTC)
    payload = {"sub": user_id, "role": role, "iat": int(now.timestamp()), "exp": int((now + timedelta(minutes=minutes)).timestamp()), "type": "session"}
    body = _b64(json.dumps(payload, separators=(",", ":"), sort_keys=True).encode())
    signature = _b64(hmac.new(_signing_key(), body.encode(), hashlib.sha256).digest())
    return f"{body}.{signature}"


def decode_session_token(token: str) -> dict | None:
    try:
        body, signature = token.split(".", 1)
        expected = _b64(hmac.new(_signing_key(), body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(signature, expected):
            return None
        payload = json.loads(_unb64(body))
        if payload.get("type") != "session" or int(payload["exp"]) < int(datetime.now(UTC).timestamp()):
            return None
        return payload
    except (ValueError, KeyError, TypeError, json.JSONDecodeError):
        return None


@dataclass(frozen=True)
class Principal:
    user_id: int
    username: str
    role: str
    actor_type: str
    scopes: frozenset[str]
    actor_id: str

    def allows(self, scope: str) -> bool:
        if self.actor_type == "api_token":
            # API tokens are strictly bound to their granted scopes — even when
            # minted by an admin, the role shortcut must not widen them.
            return "*" in self.scopes or scope in self.scopes
        return self.role == "admin" or "*" in self.scopes or scope in self.scopes
