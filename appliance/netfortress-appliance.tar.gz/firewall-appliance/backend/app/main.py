from __future__ import annotations

from pathlib import Path

from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta
import json
import os

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles

from app.auth import current_principal, get_database, require_scope
from app.auth_models import AuthResponse, BootstrapRequest, LoginRequest, TokenCreateRequest
from app.database import Database
from app.license_models import ActivateRequest, LicenseState, LicenseStatus, OfflineLicenseRequest
from app.models import AccessRequestCreate, AccessRequestReview, AcmeSettings, AdminPortUpdate, ApplicationPolicyCreate, BlockingPolicyCreate, BlocklistSourceCreate, BlockPageSettings, CachePurgeRequest, CategoryPolicyCreate, DeploymentPlan, DeploymentRequest, DeviceGroupCreate, DeviceInfo, DhcpReservationCreate, DhcpSettings, DnsSettings, DomainDiscoveryRequest, GeoipSettings, ServiceDomainsAdd, FirewallModuleUpdate, FirewallZoneCreate, GroupMemberCreate, HostnameUpdate, IpPoolCreate, PasswordSetRequest, PortalSettings, CategoryGroupCreate, CategoryGroupMember, CustomServiceCreate, InterfaceInfo, InterfaceLabelSet, InterfaceLabels, IptablesSettings, LocalDnsRecordCreate, LocalDomainCreate, PortForwardCreate, ProxySettings, RestoreApplyRequest, RetentionSettings, ScheduleCreate, SecurityEventCreate, UpdateStageRequest, UserCreate, UserGroupCreate, UserGroupUpdate, UserUpdate, ValidationResult
from app.security import PERMISSION_CATALOG, Principal, create_session_token, generate_api_token, hash_password, token_digest, token_scopes_allowed, verify_password
from app.services.deployment import build_plan, validate_deployment
from app.services.interfaces import discover_interfaces
from app.services.devices import discover_devices, hostname_for_ip
from app.services.system_status import system_overview
from app.services.policies import compile_block_targets
from app.services.content_filter import (application_catalog, category_catalog, compiled_domains, discover_related_domains, normalize_domain, render_block_page, render_dns_config, render_dnsmasq_config, render_dnsmasq_with_overrides, render_squid_config, update_blocklist, update_due_blocklists, validate_dnsmasq_config, CATEGORY_FEEDS)
from app.services.licensing import LicenseService, clamped_for_licence, licensed_controls, licensed_modules
from app.services.license_refresh import LicenseRefreshWorker
from app.services.health import critical_health_passed, run_activation_health_checks
from app.services.network_engine import NetworkTransactionManager, render_nftables
from app.services.appliance_ops import backup_archive, cache_status, purge_cached_url, render_kea_config, support_bundle, system_services, validate_backup
from app.services.recovery_updates import apply_restore, stage_restore, stage_signed_update
from app.services.iptables_engine import candidate_payload, default_module_state, module_inventory, resolve_module_state

from .license_models import (
    FeatureCatalog,
    FeatureDefinition,
    EditionDefinition,
    EDITIONS,
    FREE_EDITION
)


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

@asynccontextmanager
async def lifespan(application: FastAPI):
    database = Database()
    database.initialize()
    application.state.database = database
    refresh_worker = LicenseRefreshWorker(database)
    application.state.license_refresh_worker = refresh_worker
    refresh_worker.start()
    try:
        yield
    finally:
        refresh_worker.stop()


app = FastAPI(
    title="NetFortress API",
    version="3.1",
    description="API-first deployment and policy controller for Debian and Ubuntu.",
    lifespan=lifespan,
)
app.mount("/assets", StaticFiles(directory=STATIC_DIR), name="assets")
_integration_origins = os.environ.get("FIREWALL_API_CORS_ORIGINS")
if _integration_origins:
    # Opt-in CORS for browser-based integrations (comma-separated origins).
    from fastapi.middleware.cors import CORSMiddleware

    app.add_middleware(CORSMiddleware, allow_origins=[origin.strip() for origin in _integration_origins.split(",") if origin.strip()], allow_credentials=False, allow_methods=["*"], allow_headers=["Authorization", "Content-Type"])


@app.get("/", include_in_schema=False)
def setup_wizard() -> FileResponse:
    # The dashboard shell must always revalidate so markup and asset versions stay in sync.
    return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-cache"})


@app.get("/api/v1/health")
def health() -> dict[str, str]:
    network_apply = os.environ.get("FIREWALL_ENABLE_NETWORK_APPLY") == "1"
    return {"status": "ok", "version": "3.1", "firewall_backend": "iptables", "apply_mode": "guarded-live" if os.environ.get("FIREWALL_ENABLE_LIVE_APPLY") == "1" else "candidate-only", "network_apply": "enabled" if network_apply else "disabled"}


def client_ip(request: Request) -> str | None:
    return request.client.host if request.client else None


def licensed_feature(database: Database, feature: str) -> None:
    status_result = LicenseService(database).status()
    if feature not in status_result.features:
        raise HTTPException(status_code=402, detail={"message": f"The {feature} feature requires an active trial or licence.", "license_state": status_result.state})


def json_setting(database: Database, key: str, model, default):
    raw = database.setting(key)
    return model.model_validate_json(raw) if raw else default


def rendered_service_configs(database: Database) -> dict[str, str]:
    compiled = compiled_domains(database.local_domains(), database.application_policies(), database.blocklists(), custom_services=database.custom_services())
    return {
        "dns.json": render_dns_config(json_setting(database, "dns_settings", DnsSettings, DnsSettings()), compiled["blocked"], database.dns_records()),
        "kea-dhcp4.conf": render_kea_config(json_setting(database, "dhcp_settings", DhcpSettings, DhcpSettings()), database.dhcp_reservations(), database.ip_pools()),
        "squid.conf": render_squid_config(json_setting(database, "proxy_settings", ProxySettings, ProxySettings())),
        "block-page.html": render_block_page(json_setting(database, "block_page_settings", BlockPageSettings, BlockPageSettings())),
    }


def compiled_security_controls(database: Database) -> dict:
    dns = json_setting(database, "dns_settings", DnsSettings, DnsSettings())
    block_page = json_setting(database, "block_page_settings", BlockPageSettings, BlockPageSettings())
    portal = json_setting(database, "portal_settings", PortalSettings, PortalSettings())
    applications = database.application_policies()
    geoip = json_setting(database, "geoip_settings", GeoipSettings, GeoipSettings())
    # The engine only references the country ipsets after the feed updater
    # has built them at least once (status file written on first success).
    geoip_ready = (Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance")) / "geoip-status.json").is_file()
    controls = {"block_quic": any(row["enabled"] and row["block_quic"] for row in applications), "block_dot": dns.block_dot, "block_doh": dns.block_doh, "force_local_dns": dns.enabled, "tls_block": block_page.https_block, "portal_enabled": portal.enabled, "geoip_enabled": geoip.enabled and geoip_ready and bool(geoip.countries), "geoip_mode": geoip.mode, "geoip_unmet": geoip.enabled and (not geoip_ready or not geoip.countries)}
    # Licence clamp: corporate enforcement never renders on an edition that
    # does not include it (e.g. trial expiring to the free Home Lite licence).
    return licensed_controls(database, controls)


def compiled_network_rules(database: Database) -> dict:
    return {"zones": database.zones(), "port_forwards": database.port_forwards(), "pools": database.ip_pools()}


@app.get("/api/v1/auth/status")
def auth_status(database: Database = Depends(get_database)) -> dict:
    return {"bootstrap_required": not database.has_users(), "authentication_enabled": database.has_users()}


# --------------------------------------------------------------------- licence gate ----
# The honest firewall: when a licence lapses, filtering and client-facing
# services keep running untouched, but every configuration write is locked
# until the licence is restored. Feature gating then maps admin paths to the
# edition feature that owns them.
LAPSED_STATES = {LicenseState.UNLICENSED, LicenseState.TRIAL_EXPIRED, LicenseState.SUBSCRIPTION_EXPIRED, LicenseState.SUSPENDED}

# Client-facing and identity paths are never licence-gated: blocked clients
# cannot log in, and the block page, portal and access requests must keep
# working no matter what the licence state is.
ALWAYS_OPEN_PREFIXES = (
    "/api/v1/auth", "/api/v1/licensing", "/api/v1/health",
    "/api/v1/block-page/", "/api/v1/portal/accept",
    "/api/v1/access-requests", "/api/v1/system/docs",
    "/api/v1/dns/status", "/api/v1/dhcp/leases",
)

FEATURE_PATHS = (
    ("/api/v1/geoip", "geoip"),
    ("/api/v1/auth/tokens", "api_automation"),
    ("/api/v1/reports", "reporting"),
    ("/api/v1/events", "reporting"),
    ("/api/v1/audit", "reporting"),
    ("/api/v1/firewall/modules/ids_ips", "ids_ips"),
    ("/api/v1/portal", "portal"),
    ("/api/v1/dhcp/pools", "ip_pools"),
    ("/api/v1/proxy", "web_cache"),
    ("/api/v1/system/acme", "public_tls"),
    ("/api/v1/restore", "backup_restore"),
)


@app.middleware("http")
async def license_gate(request: Request, call_next):
    path = request.url.path
    if not path.startswith("/api/"):
        return await call_next(request)
    status_result = None
    database: Database = request.app.state.database
    # Feature gating first (the token mint lives under the open /auth prefix).
    for prefix, feature in FEATURE_PATHS:
        if path.startswith(prefix):
            status_result = LicenseService(database).status()
            if feature not in status_result.features:
                return JSONResponse({"detail": f"{feature.replace('_', ' ')} is not part of your licence edition ({status_result.edition_label}). Upgrade to unlock it."}, status_code=403)
            break
    # Lapse freeze: configuration writes are locked while unlicensed.
    if request.method not in {"GET", "HEAD", "OPTIONS"}:
        if status_result is None:
            status_result = LicenseService(database).status()
        if status_result.state in LAPSED_STATES and not path.startswith(ALWAYS_OPEN_PREFIXES):
            return JSONResponse({"detail": "Licence is not active. Filtering continues to protect the network, but configuration is locked until a licence is activated or renewed."}, status_code=403)
    return await call_next(request)


@app.post("/api/v1/auth/bootstrap", response_model=AuthResponse, status_code=201)
def bootstrap(payload: BootstrapRequest, request: Request, database: Database = Depends(get_database)) -> AuthResponse:
    if database.has_users():
        raise HTTPException(status_code=409, detail="Initial administrator already exists")
    user = database.create_user(payload.username, hash_password(payload.password), "admin")
    database.audit(actor_type="system", actor_id=None, action="auth.bootstrap", resource_type="user", resource_id=str(user["id"]), source_ip=client_ip(request))
    token = create_session_token(user["id"], user["role"])
    return AuthResponse(access_token=token, expires_in=28800, user={"id": user["id"], "username": user["username"], "role": user["role"]})


@app.post("/api/v1/auth/login", response_model=AuthResponse)
def login(payload: LoginRequest, request: Request, database: Database = Depends(get_database)) -> AuthResponse:
    user = database.user_by_username(payload.username)
    if not user or not user["enabled"] or not verify_password(payload.password, user["password_hash"]):
        database.audit(actor_type="anonymous", actor_id=None, action="auth.login", resource_type="session", outcome="failure", source_ip=client_ip(request), details={"username": payload.username})
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username or password")
    database.mark_login(user["id"])
    database.audit(actor_type="user", actor_id=str(user["id"]), action="auth.login", resource_type="session", source_ip=client_ip(request))
    token = create_session_token(user["id"], user["role"])
    return AuthResponse(access_token=token, expires_in=28800, user={"id": user["id"], "username": user["username"], "role": user["role"]})


@app.get("/api/v1/auth/me")
def me(principal: Principal = Depends(current_principal)) -> dict:
    return {"id": principal.user_id, "username": principal.username, "role": principal.role, "actor_type": principal.actor_type, "scopes": sorted(principal.scopes)}


@app.get("/api/v1/permissions")
def permissions_catalog(principal: Principal = Depends(require_scope("users:read"))) -> dict:
    """The permission catalog the Users page renders as checkboxes."""
    return {"permissions": [{"key": key, "label": label} for key, label in PERMISSION_CATALOG.items()]}


@app.get("/api/v1/user-groups")
def list_user_groups(principal: Principal = Depends(require_scope("users:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.user_groups()


@app.post("/api/v1/user-groups", status_code=201)
def create_user_group(payload: UserGroupCreate, request: Request, principal: Principal = Depends(require_scope("users:write")), database: Database = Depends(get_database)) -> dict:
    """A named permission set — what its members may see and do."""
    for key in payload.permissions:
        if key not in PERMISSION_CATALOG:
            raise HTTPException(status_code=422, detail=f"Unknown permission: {key}")
    if database.user_group_by_name(payload.name.strip()):
        raise HTTPException(status_code=409, detail="A group with that name already exists")
    result = database.create_user_group(payload.name.strip(), payload.description.strip(), payload.permissions)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="user_group.create", resource_type="user_group", resource_id=str(result["id"]), source_ip=client_ip(request), details=payload.model_dump())
    return result


@app.put("/api/v1/user-groups/{group_id}")
def update_user_group(group_id: int, payload: UserGroupUpdate, request: Request, principal: Principal = Depends(require_scope("users:write")), database: Database = Depends(get_database)) -> dict:
    for key in payload.permissions:
        if key not in PERMISSION_CATALOG:
            raise HTTPException(status_code=422, detail=f"Unknown permission: {key}")
    current = database.user_group(group_id)
    if not current:
        raise HTTPException(status_code=404, detail="Group not found")
    if current["builtin"] and "full_access" in current["permissions"] and "full_access" not in payload.permissions:
        raise HTTPException(status_code=409, detail="The Administrators group cannot lose full access")
    result = database.update_user_group(group_id, payload.name.strip() if payload.name else None, payload.description, payload.permissions)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="user_group.update", resource_type="user_group", resource_id=str(group_id), source_ip=client_ip(request), details=payload.model_dump())
    return result


@app.delete("/api/v1/user-groups/{group_id}", status_code=204)
def delete_user_group(group_id: int, request: Request, principal: Principal = Depends(require_scope("users:write")), database: Database = Depends(get_database)) -> None:
    current = database.user_group(group_id)
    if not current:
        raise HTTPException(status_code=404, detail="Group not found")
    if current["builtin"]:
        raise HTTPException(status_code=409, detail="Built-in groups cannot be deleted — remove the members instead")
    if current.get("member_count") or database.group_member_count(group_id):
        raise HTTPException(status_code=409, detail="Move the members to another group first")
    database.delete_user_group(group_id)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="user_group.delete", resource_type="user_group", resource_id=str(group_id), source_ip=client_ip(request))


@app.get("/api/v1/users")
def list_users(principal: Principal = Depends(require_scope("users:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.users()


@app.post("/api/v1/users", status_code=201)
def create_user_account(payload: UserCreate, request: Request, principal: Principal = Depends(require_scope("users:write")), database: Database = Depends(get_database)) -> dict:
    license_status = LicenseService(database).status()
    if license_status.licensed and license_status.account_limit and database.user_count() >= license_status.account_limit:
        raise HTTPException(status_code=409, detail=f"Your licence ({license_status.edition_label}) allows {license_status.account_limit} dashboard account{'s' if license_status.account_limit != 1 else ''}. Upgrade to add more.")
    group = None
    if payload.group_id is not None:
        group = database.user_group(payload.group_id)
        if not group:
            raise HTTPException(status_code=404, detail="Group not found")
    role = "admin" if group and "full_access" in group["permissions"] else ("viewer" if group else payload.role)
    try:
        result = database.create_user(payload.username, hash_password(payload.password), role, payload.group_id)
    except Exception as exc:
        raise HTTPException(status_code=409, detail="Username already exists") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="user.create", resource_type="user", resource_id=str(result["id"]), source_ip=client_ip(request), details={"username": result["username"], "role": result["role"], "group": group["name"] if group else None})
    return {key: result[key] for key in ("id", "username", "role", "enabled", "created_at", "last_login_at")}


@app.put("/api/v1/users/{user_id}")
def update_user_account(user_id: int, payload: UserUpdate, request: Request, principal: Principal = Depends(require_scope("users:write")), database: Database = Depends(get_database)) -> dict:
    current = database.user_by_id(user_id)
    if not current:
        raise HTTPException(status_code=404, detail="User not found")
    # Absent group_id keeps the account where it is — legacy updates must not wipe it.
    group_id = payload.group_id if payload.group_id is not None else (int(current["group_id"]) if current.get("group_id") else None)
    group = database.user_group(group_id) if group_id else None
    if group_id and not group:
        raise HTTPException(status_code=404, detail="Group not found")
    role = "admin" if group and "full_access" in group["permissions"] else ("viewer" if group else payload.role)
    still_full_access = bool(group and "full_access" in group["permissions"]) or (not group and role == "admin")
    if current["enabled"] and database.user_has_full_access(current) and (not payload.enabled or not still_full_access) and database.enabled_full_access_count() <= 1:
        raise HTTPException(status_code=409, detail="The final enabled full-access account cannot be disabled or demoted")
    result = database.update_user(user_id, role, payload.enabled, group_id)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="user.update", resource_type="user", resource_id=str(user_id), source_ip=client_ip(request), details=payload.model_dump() | {"group": group["name"] if group else None})
    return result


@app.put("/api/v1/users/{user_id}/password")
def set_user_password(user_id: int, payload: PasswordSetRequest, request: Request, principal: Principal = Depends(require_scope("users:write")), database: Database = Depends(get_database)) -> dict:
    """An administrator (or a users:write token) sets any account's
    password. Used by the portal's initial setup to configure the
    appliance administrator from the Portal setup page."""
    if not database.user_by_id(user_id):
        raise HTTPException(status_code=404, detail="User not found")
    database.set_user_password(user_id, hash_password(payload.new_password))
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="user.password_set", resource_type="user", resource_id=str(user_id), source_ip=client_ip(request))
    return {"ok": True}


@app.delete("/api/v1/users/{user_id}", status_code=204)
def delete_user_account(user_id: int, request: Request, principal: Principal = Depends(require_scope("users:write")), database: Database = Depends(get_database)) -> None:
    current = database.user_by_id(user_id)
    if not current:
        raise HTTPException(status_code=404, detail="User not found")
    if user_id == principal.user_id and principal.actor_type == "user":
        raise HTTPException(status_code=409, detail="You cannot delete your current account")
    if current["enabled"] and database.user_has_full_access(current) and database.enabled_full_access_count() <= 1:
        raise HTTPException(status_code=409, detail="The final enabled full-access account cannot be deleted")
    database.delete_user(user_id)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="user.delete", resource_type="user", resource_id=str(user_id), source_ip=client_ip(request))


@app.get("/api/v1/auth/tokens")
def list_tokens(principal: Principal = Depends(require_scope("tokens:write")), database: Database = Depends(get_database)) -> list[dict]:
    return database.api_tokens(principal.user_id)


@app.post("/api/v1/auth/tokens", status_code=201)
def create_token(payload: TokenCreateRequest, request: Request, principal: Principal = Depends(require_scope("tokens:write")), database: Database = Depends(get_database)) -> dict:
    if payload.expires_at and payload.expires_at <= datetime.now(UTC):
        raise HTTPException(status_code=422, detail="Token expiry must be in the future")
    if not token_scopes_allowed(payload.scopes, principal.role, principal.scopes):
        raise HTTPException(status_code=422, detail="Requested scopes must be known and within your own access")
    raw_token, prefix = generate_api_token()
    record = database.store_api_token(principal.user_id, payload.name, prefix, token_digest(raw_token), payload.scopes, payload.expires_at.isoformat() if payload.expires_at else None)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="token.create", resource_type="api_token", resource_id=str(record["id"]), source_ip=client_ip(request), details={"name": payload.name, "scopes": payload.scopes})
    return {"id": record["id"], "name": record["name"], "token": raw_token, "prefix": prefix, "scopes": payload.scopes, "expires_at": record["expires_at"], "warning": "Copy this token now. It will not be shown again."}


@app.delete("/api/v1/auth/tokens/{token_id}", status_code=204)
def revoke_token(token_id: int, request: Request, principal: Principal = Depends(require_scope("tokens:write")), database: Database = Depends(get_database)) -> None:
    if not database.revoke_api_token(token_id, principal.user_id):
        raise HTTPException(status_code=404, detail="Token not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="token.revoke", resource_type="api_token", resource_id=str(token_id), source_ip=client_ip(request))


@app.get("/api/v1/audit")
def audit_log(limit: int = 100, principal: Principal = Depends(require_scope("audit:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.audit_events(limit)


@app.get("/api/v1/licensing/status", response_model=LicenseStatus)
def license_status(principal: Principal = Depends(current_principal), database: Database = Depends(get_database)) -> LicenseStatus:
    return LicenseService(database).status()


@app.post("/api/v1/licensing/trial", response_model=LicenseStatus)
def start_trial(request: Request, principal: Principal = Depends(require_scope("licensing:write")), database: Database = Depends(get_database)) -> LicenseStatus:
    service = LicenseService(database)
    try:
        status_result = service.development_trial() if os.environ.get("FIREWALL_LICENSE_DEVELOPMENT") == "1" else service.activate_online("TRIAL", "start_trial")
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=409 if isinstance(exc, ValueError) else 503, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="licensing.trial.start", resource_type="license", source_ip=client_ip(request), details={"state": status_result.state})
    return status_result


@app.post("/api/v1/licensing/activate", response_model=LicenseStatus)
def activate_license(payload: ActivateRequest, request: Request, principal: Principal = Depends(require_scope("licensing:write")), database: Database = Depends(get_database)) -> LicenseStatus:
    try:
        status_result = LicenseService(database).activate_online(payload.license_key)
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="licensing.activate", resource_type="license", source_ip=client_ip(request), details={"state": status_result.state})
    return status_result


@app.post("/api/v1/licensing/free-home-lite", response_model=LicenseStatus)
def request_free_home_lite(request: Request, principal: Principal = Depends(require_scope("licensing:write")), database: Database = Depends(get_database)) -> LicenseStatus:
    """Claim the free Home Lite edition from the licensing server: full
    protection, 10 devices, one account, perpetual — free. Offered once the
    full trial is used up; a still-active trial or paid licence is never
    silently downgraded, it must be deactivated first."""
    service = LicenseService(database)
    current = service.status()
    if current.licensed and current.edition == FREE_EDITION:
        return current
    if not current.free_tier_available:
        raise HTTPException(status_code=409, detail="A trial or paid licence is still active. It is never replaced automatically — deactivate it first if you want the free Home Lite edition.")
    try:
        status_result = service.activate_free_home_lite()
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=409 if isinstance(exc, ValueError) else 503, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="licensing.free_home_lite", resource_type="license", source_ip=client_ip(request), details={"state": status_result.state, "edition": status_result.edition})
    return status_result


@app.post("/api/v1/licensing/activate-offline", response_model=LicenseStatus)
def activate_license_offline(payload: OfflineLicenseRequest, request: Request, principal: Principal = Depends(require_scope("licensing:write")), database: Database = Depends(get_database)) -> LicenseStatus:
    """Offline activation: upload the signed licence file downloaded from the
    licensing host. Works on sites with no internet connection."""
    try:
        status_result = LicenseService(database).install_envelope(payload.envelope)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="licensing.activate.offline", resource_type="license", source_ip=client_ip(request), details={"state": status_result.state, "edition": status_result.edition})
    return status_result


@app.post("/api/v1/licensing/deactivate", status_code=204)
def deactivate_license(request: Request, principal: Principal = Depends(require_scope("licensing:write")), database: Database = Depends(get_database)) -> None:
    LicenseService(database).deactivate()
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="licensing.deactivate", resource_type="license", source_ip=client_ip(request))


@app.get("/api/v1/licensing/refresh")
def license_refresh_status(principal: Principal = Depends(require_scope("licensing:read")), database: Database = Depends(get_database)) -> dict:
    return LicenseService(database).refresh_status()


@app.post("/api/v1/licensing/refresh", response_model=LicenseStatus)
def refresh_license(request: Request, principal: Principal = Depends(require_scope("licensing:write")), database: Database = Depends(get_database)) -> LicenseStatus:
    try:
        result = LicenseService(database).refresh_online(force=True)
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="licensing.refresh", resource_type="license", source_ip=client_ip(request), details={"state": result.state})
    return result


@app.get("/api/v1/licensing/history")
def license_history(limit: int = 100, principal: Principal = Depends(require_scope("licensing:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.license_events(limit)


@app.get("/api/v1/system/interfaces", response_model=list[InterfaceInfo])
def interfaces(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> list[InterfaceInfo]:
    labels = json_setting(database, "interface_labels", InterfaceLabels, InterfaceLabels())
    result = discover_interfaces()
    for item in result:
        item.label = labels.labels.get(item.name)
    return result


@app.put("/api/v1/system/interfaces/labels")
def save_interface_label(payload: InterfaceLabelSet, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    if payload.interface not in {item.name for item in discover_interfaces()}:
        raise HTTPException(status_code=404, detail="Interface does not exist")
    labels = json_setting(database, "interface_labels", InterfaceLabels, InterfaceLabels())
    merged = labels.labels | {payload.interface: payload.label.strip()}
    if not payload.label.strip():
        merged.pop(payload.interface, None)
    updated = InterfaceLabels(labels=merged)
    database.set_setting("interface_labels", updated.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="interface.label.update", resource_type="interface", resource_id=payload.interface, source_ip=client_ip(request), details={"label": payload.label.strip()})
    return {"interface": payload.interface, "label": payload.label.strip() or None}


@app.get("/api/v1/system/hostname")
def get_hostname(principal: Principal = Depends(require_scope("deployment:read"))) -> dict:
    import platform
    return {"hostname": platform.node()}


def appliance_hosts_address(database: Database) -> str | None:
    """The address the appliance hostname should resolve to for network clients.

    dnsmasq serves /etc/hosts to every client, so the machine name must map to a
    reachable address (the block-page/LAN identity), never a loopback one.
    """
    dns = json_setting(database, "dns_settings", DnsSettings, DnsSettings())
    if dns.block_page_ipv4:
        return dns.block_page_ipv4
    engine = json_setting(database, "iptables_settings", IptablesSettings, IptablesSettings())
    for info in discover_interfaces():
        if info.name == engine.lan_interface:
            for address in info.addresses:
                if ":" not in str(address):
                    return str(address).split("/")[0]
    return None


@app.put("/api/v1/system/hostname")
def save_hostname(payload: HostnameUpdate, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    import hashlib, json as json_module, secrets, subprocess, time
    candidate = f"host_{secrets.token_hex(8)}"
    base = Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance")) / "hostname-candidates" / candidate
    base.mkdir(parents=True, mode=0o750, exist_ok=False)
    (base / "hostname.txt").write_text(payload.hostname + "\n")
    (base / "manifest.json").write_text(json_module.dumps({"transaction_id": candidate, "sha256": hashlib.sha256(payload.hostname.encode()).hexdigest(), "hosts_address": appliance_hosts_address(database), "created_at": time.time()}, sort_keys=True))
    completed = subprocess.run(["sudo", "/usr/local/sbin/firewall-hostname-transaction", "apply", candidate], capture_output=True, text=True, timeout=60, check=False)
    try:
        body = json_module.loads(completed.stdout)
    except json_module.JSONDecodeError:
        body = {"ok": False, "message": completed.stderr.strip() or "Hostname helper returned invalid output"}
    if completed.returncode or not body.get("ok"):
        raise HTTPException(status_code=409, detail=body)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="system.hostname.update", resource_type="system", resource_id=payload.hostname, source_ip=client_ip(request))
    return {"hostname": payload.hostname, "transaction": body}


@app.get("/api/v1/system/overview")
def overview(principal: Principal = Depends(require_scope("deployment:read"))) -> dict:
    return system_overview()


@app.get("/api/v1/devices", response_model=list[DeviceInfo])
def devices(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> list[dict]:
    dhcp = json_setting(database, "dhcp_settings", DhcpSettings, DhcpSettings())
    observed = [item.model_dump() for item in discover_devices(dhcp.subnet if dhcp.enabled else None)]
    return database.record_devices(observed)


@app.get("/api/v1/device-groups")
def list_device_groups(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.groups()


@app.post("/api/v1/device-groups", status_code=201)
def create_device_group(payload: DeviceGroupCreate, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    try:
        result = database.create_group(payload.name.strip(), payload.description.strip())
    except Exception as exc:
        raise HTTPException(status_code=409, detail="A device group with this name already exists") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="device_group.create", resource_type="device_group", resource_id=str(result["id"]), source_ip=client_ip(request))
    return result


@app.post("/api/v1/device-groups/{group_id}/members", status_code=201)
def add_device_group_member(group_id: int, payload: GroupMemberCreate, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    try:
        result = database.add_group_member(group_id, payload.target_type, payload.target_value.strip())
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=409, detail="This member already exists in the group") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="device_group.member.add", resource_type="device_group", resource_id=str(group_id), source_ip=client_ip(request), details=payload.model_dump())
    return result


@app.delete("/api/v1/device-groups/{group_id}", status_code=204)
def delete_device_group(group_id: int, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_group(group_id):
        raise HTTPException(status_code=404, detail="Device group not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="device_group.delete", resource_type="device_group", resource_id=str(group_id), source_ip=client_ip(request))


@app.get("/api/v1/policies")
def list_policies(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.policies()


@app.post("/api/v1/policies", status_code=201)
def create_policy(payload: BlockingPolicyCreate, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    try:
        compile_block_targets({"policies": [{"target_type": payload.target_type, "target_value": payload.target_value}], "members": [], "devices": []})
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    try:
        result = database.create_policy(payload.name.strip(), payload.target_type, payload.target_value.strip(), payload.enabled, payload.reason.strip(), payload.schedule_id)
    except KeyError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="policy.create", resource_type="blocking_policy", resource_id=str(result["id"]), source_ip=client_ip(request), details={"target_type": payload.target_type, "target_value": payload.target_value})
    return result


@app.delete("/api/v1/policies/{policy_id}", status_code=204)
def delete_policy(policy_id: int, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_policy(policy_id):
        raise HTTPException(status_code=404, detail="Policy not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="policy.delete", resource_type="blocking_policy", resource_id=str(policy_id), source_ip=client_ip(request))


@app.get("/api/v1/policy-compiler")
def compiled_policies(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> dict:
    return compile_block_targets(database.policy_sources())


@app.get("/api/v1/dns/settings", response_model=DnsSettings)
def dns_settings(principal: Principal = Depends(require_scope("dns:read")), database: Database = Depends(get_database)) -> DnsSettings:
    return json_setting(database, "dns_settings", DnsSettings, DnsSettings())


@app.put("/api/v1/dns/settings", response_model=DnsSettings)
def save_dns_settings(payload: DnsSettings, request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> DnsSettings:
    licensed_feature(database, "dns")
    database.set_setting("dns_settings", payload.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="dns.settings.update", resource_type="dns", source_ip=client_ip(request))
    return payload


@app.get("/api/v1/dns/render", response_class=PlainTextResponse)
def dns_render(principal: Principal = Depends(require_scope("dns:read")), database: Database = Depends(get_database)) -> str:
    settings = json_setting(database, "dns_settings", DnsSettings, DnsSettings())
    compiled = compiled_domains(database.local_domains(), database.application_policies(), database.blocklists(), custom_services=database.custom_services())
    return render_dnsmasq_with_overrides(settings, compiled, database.dns_records())


@app.post("/api/v1/dns/candidates", status_code=201)
def prepare_dns_candidate(request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> dict:
    import secrets, time
    licensed_feature(database, "dns")
    settings = json_setting(database, "dns_settings", DnsSettings, DnsSettings())
    compiled = compiled_domains(database.local_domains(), database.application_policies(), database.blocklists(), custom_services=database.custom_services())
    config = render_dnsmasq_with_overrides(settings, compiled, database.dns_records())
    transaction_id = f"dns_{secrets.token_hex(8)}"
    base = Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance")) / "dns-candidates" / transaction_id
    base.mkdir(parents=True, mode=0o750, exist_ok=False)
    (base / "dnsmasq.conf").write_text(config)
    validation = validate_dnsmasq_config(str(base / "dnsmasq.conf"))
    manifest = {"transaction_id": transaction_id, "sha256": __import__("hashlib").sha256(config.encode()).hexdigest(), "created_at": time.time(), "domain_count": compiled["blocked_count"], "validation": validation}
    (base / "manifest.json").write_text(__import__("json").dumps(manifest, sort_keys=True))
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="dns.candidate.prepare", resource_type="dns_candidate", resource_id=transaction_id, source_ip=client_ip(request), details={"domain_count": compiled["blocked_count"], "sha256": manifest["sha256"], "valid": validation["valid"]})
    if not validation["valid"] and validation["available"]:
        raise HTTPException(status_code=422, detail=validation)
    return {"transaction_id": transaction_id, "sha256": manifest["sha256"], "domain_count": compiled["blocked_count"], "validation": validation, "next": f"POST /api/v1/dns/transactions/{transaction_id}/activate"}


def enforce_dns_now(database: Database) -> dict:
    """Prepare and activate a guarded DNS transaction immediately — used by
    access-request approvals so an allowed site works within seconds instead
    of at the next reconciler tick. Failures are non-fatal: the reconciler
    still applies the same state within the minute."""
    import secrets, time, hashlib
    settings = json_setting(database, "dns_settings", DnsSettings, DnsSettings())
    compiled = compiled_domains(database.local_domains(), database.application_policies(), database.blocklists(), custom_services=database.custom_services())
    config = render_dnsmasq_with_overrides(settings, compiled, database.dns_records())
    transaction_id = f"dns_{secrets.token_hex(8)}"
    base = Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance")) / "dns-candidates" / transaction_id
    base.mkdir(parents=True, mode=0o750, exist_ok=False)
    (base / "dnsmasq.conf").write_text(config)
    (base / "manifest.json").write_text(json.dumps({"transaction_id": transaction_id, "sha256": hashlib.sha256(config.encode()).hexdigest(), "created_at": time.time(), "domain_count": compiled["blocked_count"]}, sort_keys=True))
    return dns_transaction_action(transaction_id, "activate")


def dns_transaction_action(transaction_id: str, action: str) -> dict:
    import json as json_module, re as re_module, subprocess
    if action not in {"activate", "rollback", "status"} or not re_module.fullmatch(r"dns_[0-9a-f]{16}", transaction_id):
        raise HTTPException(status_code=422, detail="Invalid transaction request")
    if action == "activate" and os.environ.get("FIREWALL_ENABLE_DNS_APPLY") != "1":
        raise HTTPException(status_code=423, detail="Live DNS apply is disabled. Candidate was not activated.")
    completed = subprocess.run(["sudo", "/usr/local/sbin/firewall-dns-transaction", action, transaction_id], capture_output=True, text=True, timeout=120, check=False)
    try:
        body = json_module.loads(completed.stdout)
    except json_module.JSONDecodeError:
        body = {"ok": False, "message": completed.stderr.strip() or "Transaction helper returned invalid output"}
    if completed.returncode:
        raise HTTPException(status_code=409, detail=body)
    return body


@app.post("/api/v1/dns/transactions/{transaction_id}/{action}")
def manage_dns_transaction(transaction_id: str, action: str, request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> dict:
    result = dns_transaction_action(transaction_id, action)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action=f"dns.transaction.{action}", resource_type="dns_transaction", resource_id=transaction_id, source_ip=client_ip(request), details={"state": result.get("state")})
    return result


@app.get("/api/v1/dns/status")
def dns_status(principal: Principal = Depends(require_scope("dns:read")), database: Database = Depends(get_database)) -> dict:
    import shutil, subprocess
    compiled = compiled_domains(database.local_domains(), database.application_policies(), database.blocklists(), custom_services=database.custom_services())
    status: dict = {"dns_service": "unknown", "installed": shutil.which("dnsmasq") is not None, "blocked_domains": compiled["blocked_count"], "active": False, "transaction": None}
    if shutil.which("systemctl"):
        service = subprocess.run(["systemctl", "is-active", "dnsmasq"], capture_output=True, text=True, timeout=10, check=False)
        status["dns_service"] = service.stdout.strip()
        status["active"] = service.stdout.strip() == "active"
    record = Path("/var/lib/firewall-appliance/dns-active.json")
    if record.is_file():
        try:
            import json as json_module
            status["transaction"] = json_module.loads(record.read_text())
        except (OSError, ValueError):
            status["transaction"] = None
    return status


@app.get("/api/v1/blocklists")
def list_blocklists(principal: Principal = Depends(require_scope("dns:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.blocklists()


@app.post("/api/v1/blocklists", status_code=201)
def create_blocklist(payload: BlocklistSourceCreate, request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "dns_filtering")
    category = payload.category.strip().lower()
    if category and category not in CATEGORY_FEEDS:
        raise HTTPException(status_code=422, detail=f"Unknown category: {category}")
    try:
        result = database.create_blocklist(payload.name.strip(), payload.url.strip(), payload.format, payload.enabled, payload.update_hours, category)
    except Exception as exc:
        raise HTTPException(status_code=409, detail="A blocklist with this name already exists") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="blocklist.create", resource_type="blocklist", resource_id=str(result["id"]), source_ip=client_ip(request))
    return result


@app.post("/api/v1/blocklists/stevenblack", status_code=201)
def create_stevenblack(request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "dns_filtering")
    try:
        result = database.create_blocklist("StevenBlack Unified Hosts", "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts", "hosts", True, 24, "ads-trackers")
    except Exception as exc:
        raise HTTPException(status_code=409, detail="StevenBlack source already exists") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="blocklist.create.stevenblack", resource_type="blocklist", resource_id=str(result["id"]), source_ip=client_ip(request))
    return result


@app.post("/api/v1/blocklists/category-feeds", status_code=201)
def register_category_feeds(request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> dict:
    """Register every curated StevenBlack category feed that is not present yet."""
    licensed_feature(database, "dns_filtering")
    existing = {row["url"] for row in database.blocklists()}
    existing_names = {row["name"].strip().lower() for row in database.blocklists()}
    registered: list[dict] = []
    for category, feed in CATEGORY_FEEDS.items():
        if feed["url"] in existing or feed["name"].strip().lower() in existing_names:
            continue
        registered.append(database.create_blocklist(feed["name"], feed["url"], "hosts", True, 24, category))
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="blocklist.create.category_feeds", resource_type="blocklist", source_ip=client_ip(request), details={"registered": [row["id"] for row in registered], "categories": [row["category"] for row in registered]})
    return {"registered": registered, "skipped": len(CATEGORY_FEEDS) - len(registered)}


@app.post("/api/v1/blocklists/{source_id}/update")
def refresh_blocklist(source_id: int, request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "dns_filtering")
    source = database.blocklist(source_id)
    if not source:
        raise HTTPException(status_code=404, detail="Blocklist source not found")
    try:
        result = update_blocklist(source)
        database.update_blocklist_status(source_id, status="healthy", domain_count=result["domain_count"], digest=result["sha256"])
    except Exception as exc:
        database.update_blocklist_status(source_id, status="failed", error=str(exc))
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="blocklist.update", resource_type="blocklist", resource_id=str(source_id), source_ip=client_ip(request), details={"domain_count": result["domain_count"], "sha256": result["sha256"]})
    return result


@app.delete("/api/v1/blocklists/{source_id}", status_code=204)
def delete_blocklist(source_id: int, request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_blocklist(source_id):
        raise HTTPException(status_code=404, detail="Blocklist source not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="blocklist.delete", resource_type="blocklist", resource_id=str(source_id), source_ip=client_ip(request))


@app.post("/api/v1/blocklists/update-due")
def refresh_due_blocklists(force: bool = False, request: Request = None, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "dns_filtering")
    result = update_due_blocklists(database, force=force)
    failed = sum(item["status"] == "failed" for item in result["sources"])
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="blocklist.batch_update", resource_type="blocklist", outcome="failure" if failed else "success", source_ip=client_ip(request), details={"force": force, "source_count": len(result["sources"]), "failed": failed})
    return result


@app.get("/api/v1/domains")
def list_local_domains(principal: Principal = Depends(require_scope("dns:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.local_domains()


@app.post("/api/v1/domains", status_code=201)
def create_local_domain(payload: LocalDomainCreate, request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "dns_filtering")
    try:
        result = database.create_local_domain(normalize_domain(payload.domain), payload.action, payload.category.strip().lower(), payload.expires_at)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=409, detail="Domain entry already exists") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="domain.create", resource_type="domain", resource_id=str(result["id"]), source_ip=client_ip(request), details={"domain": result["domain"], "action": result["action"]})
    return result


@app.delete("/api/v1/domains/{domain_id}", status_code=204)
def delete_local_domain(domain_id: int, request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_local_domain(domain_id):
        raise HTTPException(status_code=404, detail="Domain entry not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="domain.delete", resource_type="domain", resource_id=str(domain_id), source_ip=client_ip(request))


@app.get("/api/v1/applications")
def applications(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> list[dict]:
    return application_catalog(database.application_policies(), database.custom_services(), database.service_extensions())


@app.post("/api/v1/applications/{application}/domains", status_code=201)
def add_application_domains(application: str, payload: ServiceDomainsAdd, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    """Add domains to an existing service — curated or custom. The practical
    case: threads.com belongs to instagram, because Threads lives on
    Instagram's CDNs; one service, all its domains."""
    licensed_feature(database, "web_filtering")
    from app.services.content_filter import DOMAIN_RE

    name = application.strip().lower()
    if name not in {item["name"] for item in application_catalog([], database.custom_services())}:
        raise HTTPException(status_code=404, detail="Unknown service")
    domains = sorted({normalize_domain(item) for item in payload.domains})
    for item in domains:
        if not DOMAIN_RE.fullmatch(item):
            raise HTTPException(status_code=422, detail=f"{item} is not a valid domain.")
    if database.custom_service_by_name(name):
        result = database.add_custom_service_domains(name, domains)
    else:
        result = database.add_service_extension(name, domains)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="application.domains.add", resource_type="application", resource_id=name, source_ip=client_ip(request), details={"added": domains})
    return result


@app.delete("/api/v1/applications/{application}/domains/{domain}")
def remove_application_domain(application: str, domain: str, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    """Remove a domain that was added to a service. Curated base domains stay
    (switch the service off instead); a custom service must keep at least one."""
    licensed_feature(database, "web_filtering")
    from app.services.content_filter import APPLICATIONS

    name = application.strip().lower()
    target = normalize_domain(domain)
    if name in APPLICATIONS and target in APPLICATIONS[name]["domains"]:
        raise HTTPException(status_code=409, detail="That is a built-in domain of the service — switch the service off instead of removing it.")
    if database.custom_service_by_name(name):
        remaining = database.remove_custom_service_domain(name, target)
        if not remaining:
            raise HTTPException(status_code=409, detail="A service must keep at least one domain — delete the service instead.")
    else:
        remaining = database.remove_service_extension_domain(name, target)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="application.domains.remove", resource_type="application", resource_id=name, source_ip=client_ip(request), details={"removed": target, "remaining": remaining})
    return {"name": name, "domains": remaining}


@app.post("/api/v1/applications", status_code=201)
def create_custom_application(payload: CustomServiceCreate, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    """Create your own service (name + the domains it lives on). It appears in
    the given group, is toggled like any curated service, and its domains are
    enforced through DNS when on."""
    licensed_feature(database, "web_filtering")
    from app.services.content_filter import category_names

    name = payload.name.strip().lower()
    if name in {item["name"] for item in application_catalog([], [])}:
        raise HTTPException(status_code=409, detail="That name is already a built-in service — choose another name.")
    if database.custom_service_by_name(name):
        raise HTTPException(status_code=409, detail="A service with that name already exists.")
    valid_categories = set(category_names()) | {row["name"] for row in database.category_groups()}
    if payload.category not in valid_categories:
        raise HTTPException(status_code=422, detail="Choose an existing group for the service (create the group first if needed).")
    service = database.create_custom_service(name, payload.category, payload.domains)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="application.custom.create", resource_type="application", resource_id=name, source_ip=client_ip(request), details={"category": payload.category, "domains": payload.domains})
    return service | {"message": "Service created — find it inside the group, and switch it on."}


@app.delete("/api/v1/applications/{application}", status_code=204)
def delete_custom_application(application: str, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    service = database.custom_service_by_name(application)
    if not service:
        raise HTTPException(status_code=404, detail="Only custom services can be deleted — built-in curated services are switched off instead.")
    database.delete_custom_service(service["id"])
    for group in database.category_groups():
        database.category_group_remove_app(group["id"], application.lower())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="application.custom.delete", resource_type="application", resource_id=application.lower(), source_ip=client_ip(request))


def custom_group_cards(database: Database, applications: list[dict]) -> list[dict]:
    """Custom groups as category cards (group membership = apps + its domains)."""
    from app.services.content_filter import category_names

    apps = {row["name"]: row for row in applications}
    reserved = set(category_names()) | {"custom", "uncategorized"}
    cards: list[dict] = []
    for group in database.category_groups():
        if group["name"].lower() in reserved:
            continue
        members = [apps[name] for name in group["applications"] if name in apps]
        domains = database.local_domains_in_category(group["name"])
        blocked = [row for row in domains if row["action"] == "block"]
        enforced_members = len(members) + len(blocked)
        apps_on = sum(1 for item in members if item["enabled"])
        enabled = enforced_members > 0 and all(item["enabled"] for item in members)
        state = "blocking" if enabled else ("partial" if apps_on > 0 else "off")
        cards.append({"name": group["name"], "description": group["description"], "custom": True, "applications": [item["name"] for item in members], "app_count": len(members), "feed": None, "feed_registered": False, "feed_domain_count": len(blocked), "feed_status": None, "apps_enabled_count": apps_on, "enabled": enabled, "state": state, "domains": [{"id": row["id"], "domain": row["domain"], "action": row["action"]} for row in domains]})
    return cards


@app.get("/api/v1/categories")
def categories(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> list[dict]:
    policies = database.application_policies()
    return category_catalog(policies, database.blocklists(), database.custom_services(), database.service_extensions()) + custom_group_cards(database, application_catalog(policies, database.custom_services(), database.service_extensions()))


@app.post("/api/v1/categories", status_code=201)
def create_category_group(payload: CategoryGroupCreate, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "web_filtering")
    from app.services.content_filter import category_names

    if payload.name.lower() in set(category_names()) | {"custom", "uncategorized"} or database.category_group_by_name(payload.name):
        raise HTTPException(status_code=409, detail="That name is already used by a built-in category or another group.")
    group = database.create_category_group(payload.name.strip(), payload.description.strip())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="category.group.create", resource_type="category_group", resource_id=str(group["id"]), source_ip=client_ip(request), details=payload.model_dump())
    return group


@app.delete("/api/v1/categories/{category}", status_code=204)
def delete_category_group(category: str, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    licensed_feature(database, "web_filtering")
    group = database.category_group_by_name(category)
    if not group:
        raise HTTPException(status_code=404, detail="Only custom groups can be deleted.")
    database.delete_category_group(group["id"])
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="category.group.delete", resource_type="category_group", resource_id=str(group["id"]), source_ip=client_ip(request), details={"name": category})


@app.post("/api/v1/categories/{category}/members", status_code=201)
def add_group_member(category: str, payload: CategoryGroupMember, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "web_filtering")
    group = database.category_group_by_name(category)
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")
    if payload.application.lower() not in {item["name"] for item in application_catalog([], database.custom_services())}:
        raise HTTPException(status_code=404, detail="Unknown application")
    database.category_group_add_app(group["id"], payload.application.lower())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="category.group.member.add", resource_type="category_group", resource_id=str(group["id"]), source_ip=client_ip(request), details=payload.model_dump())
    return {"group": category, "application": payload.application.lower()}


@app.delete("/api/v1/categories/{category}/members/{application}", status_code=204)
def remove_group_member(category: str, application: str, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    group = database.category_group_by_name(category)
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")
    database.category_group_remove_app(group["id"], application.lower())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="category.group.member.remove", resource_type="category_group", resource_id=str(group["id"]), source_ip=client_ip(request), details={"application": application.lower()})


@app.put("/api/v1/categories/{category}")
def save_category(category: str, payload: CategoryPolicyCreate, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "web_filtering")
    group = database.category_group_by_name(category)
    if group and category.lower() == payload.category.lower():
        # Custom group: toggle = every member app on/off + its domains block/allow.
        members = next(row for row in database.category_groups() if row["id"] == group["id"])["applications"]
        for application in members:
            database.save_application_policy(application, payload.enabled, payload.block_quic)
        for row in database.local_domains_in_category(category):
            database.set_domain_action(row["id"], "block" if payload.enabled else "allow")
        database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="category.group.update", resource_type="category_group", resource_id=str(group["id"]), source_ip=client_ip(request), details={"enabled": payload.enabled, "applications": members})
        return {"name": category, "applications": members, "feed_source_id": None, "enabled": payload.enabled, "block_quic": payload.block_quic, "custom": True}
    catalog = {item["name"]: item for item in category_catalog(database.application_policies(), database.blocklists(), database.custom_services())}
    if category != payload.category or category not in catalog:
        raise HTTPException(status_code=404, detail="Unknown category")
    item = catalog[category]
    applications = item["applications"]
    for application in applications:
        database.save_application_policy(application, payload.enabled, payload.block_quic)
    if item["feed_source_id"] is not None:
        database.set_blocklist_enabled(item["feed_source_id"], payload.enabled)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="category.policy.update", resource_type="category", resource_id=category, source_ip=client_ip(request), details=payload.model_dump() | {"applications": applications, "feed_source_id": item["feed_source_id"]})
    return {"name": category, "applications": applications, "feed_source_id": item["feed_source_id"], "enabled": payload.enabled, "block_quic": payload.block_quic}


@app.put("/api/v1/applications/{application}")
def save_application(application: str, payload: ApplicationPolicyCreate, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "web_filtering")
    if application.lower() != payload.application.lower() or application.lower() not in {item["name"] for item in application_catalog([], database.custom_services())}:
        raise HTTPException(status_code=404, detail="Unknown application definition")
    result = database.save_application_policy(application.lower(), payload.enabled, payload.block_quic)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="application.policy.update", resource_type="application", resource_id=application.lower(), source_ip=client_ip(request), details=payload.model_dump())
    return result


@app.get("/api/v1/block-page/client-info")
def block_page_client_info(request: Request, host: str = "", database: Database = Depends(get_database)) -> dict:
    """PUBLIC: the live block page fills its client, hostname and policy fields
    from here. The client device cannot know its own address — the appliance does."""
    address = (client_ip(request) or "").split("%")[0]
    hostname = hostname_for_ip(address)
    policy = "Web control policy"
    target = normalize_domain(host or "")
    if target:
        for item in application_catalog(database.application_policies(), database.custom_services(), database.service_extensions()):
            if not item.get("enabled"):
                continue
            for domain in item.get("domains") or []:
                domain = normalize_domain(domain)
                if target == domain or target.endswith("." + domain):
                    policy = f"{item['category']} group — {item['name']}"
                    break
            if policy != "Web control policy":
                break
        if policy == "Web control policy":
            for row in database.local_domains():
                if row.get("action") != "block":
                    continue
                domain = normalize_domain(row["domain"])
                if target == domain or target.endswith("." + domain):
                    policy = "Custom blocked-domain rule"
                    break
    return {"client_ip": address or "unknown", "hostname": hostname or "unknown", "policy": policy}


@app.post("/api/v1/applications/discover")
def discover_service_domains(payload: DomainDiscoveryRequest, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    """Scan a public site and list every hostname it depends on (CDNs, assets),
    so a new service covers the whole service — not just its front door."""
    licensed_feature(database, "web_filtering")
    try:
        found = discover_related_domains(payload.domain)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"The scan could not complete: {str(exc)[:200]}") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="application.domain_discovery", resource_type="application", resource_id=normalize_domain(payload.domain), source_ip=client_ip(request), details={"found": found[:50]})
    return {"domain": normalize_domain(payload.domain), "found": found}


@app.get("/api/v1/content-filter/compiled")
def content_filter_compiled(principal: Principal = Depends(require_scope("dns:read")), database: Database = Depends(get_database)) -> dict:
    return compiled_domains(database.local_domains(), database.application_policies(), database.blocklists(), custom_services=database.custom_services(), service_extensions=database.service_extensions())


def block_page_logo_path() -> Path:
    return Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance")) / "block-page-logo"


@app.get("/api/v1/block-page/logo")
def block_page_logo() -> FileResponse:
    """Public by design: client devices render the block page with this logo."""
    path = block_page_logo_path()
    if not path.is_file():
        # Fresh deployments serve the bundled NetFortress logo until the client
        # uploads their own - the block page stays fully customizable per client.
        path = STATIC_DIR / "logo.svg"
    if not path.is_file():
        raise HTTPException(status_code=404, detail="No logo has been uploaded")
    media = "image/svg+xml" if path.read_bytes()[:5].startswith(b"<svg") or path.suffix == ".svg" else "image/png"
    if path.read_bytes()[:3] == b"\xff\xd8\xff":
        media = "image/jpeg"
    return FileResponse(path, media_type=media)


@app.post("/api/v1/block-page/logo")
async def upload_block_page_logo(request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    body = await request.body()
    if not body:
        raise HTTPException(status_code=422, detail="Choose an image file first")
    if len(body) > 262144:
        raise HTTPException(status_code=422, detail="Logo must be under 256 KB")
    content_type = (request.headers.get("content-type") or "").split(";")[0].strip().lower()
    allowed = {"image/png", "image/jpeg", "image/svg+xml"}
    if content_type not in allowed and not (body[:8].startswith(b"\x89PNG") or body[:3] == b"\xff\xd8\xff" or body[:5].lstrip().startswith(b"<svg")):
        raise HTTPException(status_code=422, detail="Only PNG, JPEG or SVG images are supported")
    path = block_page_logo_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(body)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="block_page.logo.upload", resource_type="block_page", source_ip=client_ip(request), details={"size": len(body), "content_type": content_type or "sniffed"})
    return {"uploaded": True, "size": len(body), "url": "/api/v1/block-page/logo"}


@app.delete("/api/v1/block-page/logo", status_code=204)
def delete_block_page_logo(request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    block_page_logo_path().unlink(missing_ok=True)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="block_page.logo.delete", resource_type="block_page", source_ip=client_ip(request))


@app.get("/api/v1/block-page/settings", response_model=BlockPageSettings)
def block_page_settings(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> BlockPageSettings:
    return json_setting(database, "block_page_settings", BlockPageSettings, BlockPageSettings())


@app.put("/api/v1/block-page/settings", response_model=BlockPageSettings)
def save_block_page(payload: BlockPageSettings, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> BlockPageSettings:
    licensed_feature(database, "block_page")
    database.set_setting("block_page_settings", payload.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="block_page.update", resource_type="block_page", source_ip=client_ip(request))
    return payload


@app.get("/api/v1/system/acme")
def acme_settings(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> dict:
    import json as json_module

    settings = json_setting(database, "acme_settings", AcmeSettings, AcmeSettings())
    data = settings.model_dump()
    data["api_token"] = "set" if settings.api_token else ""
    import subprocess as acme_subprocess

    try:
        completed = acme_subprocess.run(["sudo", "-n", "/usr/local/sbin/firewall-acme", "status"], capture_output=True, text=True, timeout=30, check=False)
        body = json_module.loads(completed.stdout) if completed.stdout.strip() else {}
        data["issued"] = body.get("issued", False)
        data["expires_at"] = body.get("expires_at")
        data["certificate_names"] = body.get("names")
    except (OSError, ValueError, json_module.JSONDecodeError):
        data["issued"] = False
    return data


@app.put("/api/v1/system/acme")
def save_acme_settings(payload: AcmeSettings, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    existing = json_setting(database, "acme_settings", AcmeSettings, AcmeSettings())
    merged = payload.model_copy(update={"api_token": payload.api_token or existing.api_token})
    database.set_setting("acme_settings", merged.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="acme.settings.update", resource_type="system", resource_id="acme", source_ip=client_ip(request), details={"enabled": merged.enabled, "appliance_fqdn": merged.appliance_fqdn, "block_fqdn": merged.block_fqdn})
    return {"enabled": merged.enabled, "appliance_fqdn": merged.appliance_fqdn, "block_fqdn": merged.block_fqdn, "api_token": "set" if merged.api_token else ""}


@app.post("/api/v1/system/acme/request")
def request_acme_certificate(request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    import json as json_module
    import subprocess as acme_subprocess

    completed = acme_subprocess.run(["sudo", "-n", "/usr/local/sbin/firewall-acme", "request"], capture_output=True, text=True, timeout=300, check=False)
    try:
        body = json_module.loads(completed.stdout)
    except json_module.JSONDecodeError:
        body = {"ok": False, "message": completed.stderr.strip()[:400] or "The certificate helper returned no result"}
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="acme.certificate.request", resource_type="system", resource_id="acme", outcome="success" if body.get("ok") else "failure", source_ip=client_ip(request), details={"message": str(body.get("message", ""))[:400]})
    if completed.returncode or not body.get("ok"):
        raise HTTPException(status_code=502, detail=body.get("message") or "Certificate request failed")
    return body


ENROLL_PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Network certificate — Firewall Appliance</title>
<style>body{font-family:system-ui,sans-serif;background:#141a22;color:#eef;padding:2.5rem;line-height:1.5}
.card{max-width:44rem;margin:auto;background:#1d2530;border-radius:14px;padding:2rem}
.btn{display:inline-block;margin:.4rem .6rem .4rem 0;padding:.7rem 1.2rem;border-radius:9px;background:#a68e17;color:#141a22;font-weight:700;text-decoration:none}
.btn.alt{background:#2c3542;color:#eef;border:1px solid #3b4756}
small{color:#9aa6b5}
h1{margin-top:0}</style></head><body><div class="card">
<h1>Install the network certificate</h1>
<p>This network shows a branded page when a site is blocked. To see that page on
<b>https://</b> sites too, install this network's certificate once per device.</p>
<p><a class="btn" href="/enroll/windows">⬇ Windows installer (one click)</a>
<a class="btn alt" href="/enroll/apple">⬇ Mac / iPhone / iPad profile</a>
<a class="btn alt" href="/api/v1/block-page/ca">⬇ Certificate file (Android / manual)</a></p>
<p><b>Windows:</b> open the downloaded file, click <i>Open</i>, accept the Windows
security prompt, then restart your browser.<br>
<b>Mac / iPhone / iPad:</b> open the profile, allow it in Settings if asked, then install it.<br>
<b>Android:</b> open the certificate file and follow your device's CA installation flow
(Settings → Security → Install from storage; name it anything).</p>
<p><small>Allowed websites are never intercepted. This certificate only lets this network show
its block page instead of a browser certificate error on sites that are already blocked.</small></p>
</div></body></html>"""


@app.get("/enroll", response_class=HTMLResponse, include_in_schema=False)
def enroll_page() -> str:
    return ENROLL_PAGE


@app.get("/enroll/windows", include_in_schema=False)
def enroll_windows(request: Request) -> Response:
    """One-click Windows installer: downloads the CA from this appliance and
    imports it into the machine trusted-root store (UAC prompt, then done)."""
    host = request.url.hostname or request.client.host if request.client else "192.168.100.2"
    batch = (
        "@echo off\r\n"
        "echo Firewall Appliance network certificate installer\r\n"
        "echo A Windows security prompt will appear - choose Yes to install.\r\n"
        "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Start-Process powershell -Verb RunAs -ArgumentList "
        "'-NoProfile','-ExecutionPolicy','Bypass','-Command','& {Invoke-WebRequest http://" + host + "/api/v1/block-page/ca -OutFile $env:TEMP\\firewall-ca.cer; "
        "Import-Certificate -FilePath $env:TEMP\\firewall-ca.cer -CertStoreLocation Cert:\\LocalMachine\\Root; "
        "Write-Host Installed -ForegroundColor Green; Start-Sleep 3}'\"\r\n"
        "pause\r\n"
    )
    return Response(content=batch, media_type="application/octet-stream", headers={"Content-Disposition": "attachment; filename=install-network-certificate.bat"})


@app.get("/enroll/apple", include_in_schema=False)
def enroll_apple() -> Response:
    """Configuration profile embedding the appliance CA for macOS/iOS one-tap install."""
    import base64
    import uuid

    from cryptography import x509
    from cryptography.hazmat.primitives import serialization

    ca_path = Path(os.environ.get("FIREWALL_TLS_STATE", "/var/lib/firewall-appliance/tls-block")) / "ca.crt"
    if not ca_path.is_file():
        raise HTTPException(status_code=404, detail="The HTTPS block service has not generated a certificate yet")
    certificate = x509.load_pem_x509_certificate(ca_path.read_bytes())
    payload_uuid, top_uuid = str(uuid.uuid4()), str(uuid.uuid4())
    profile = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>PayloadContent</key><array><dict>
<key>PayloadContent</key><data>{base64.b64encode(certificate.public_bytes(serialization.Encoding.DER)).decode()}</data>
<key>PayloadDisplayName</key><string>Firewall Appliance Root CA</string>
<key>PayloadIdentifier</key><string>firewall-appliance.ca</string>
<key>PayloadType</key><string>com.apple.security.root</string>
<key>PayloadUUID</key><string>{payload_uuid}</string>
<key>PayloadVersion</key><integer>1</integer>
</dict></array>
<key>PayloadDisplayName</key><string>Firewall Appliance Certificate</string>
<key>PayloadIdentifier</key><string>firewall-appliance.enroll</string>
<key>PayloadRemovalDisallowed</key><false/>
<key>PayloadType</key><string>Configuration</string>
<key>PayloadUUID</key><string>{top_uuid}</string>
<key>PayloadVersion</key><integer>1</integer>
</dict></plist>'''
    return Response(content=profile, media_type="application/x-apple-aspen-config", headers={"Content-Disposition": "attachment; filename=firewall-appliance.mobileconfig"})


@app.get("/api/v1/block-page/ca")
def block_page_ca() -> FileResponse:
    """The appliance CA certificate — public by design; clients install it to see
    the branded block page on HTTPS sites. Import into the trusted root store."""
    path = Path(os.environ.get("FIREWALL_TLS_STATE", "/var/lib/firewall-appliance/tls-block")) / "ca.crt"
    if not path.is_file():
        raise HTTPException(status_code=404, detail="The HTTPS block service has not generated a certificate yet")
    return FileResponse(path, media_type="application/x-x509-ca-cert", filename="firewall-appliance-ca.crt")


@app.post("/api/v1/block-page/custom", status_code=201)
async def upload_block_page_custom(request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    """Upload your own fully-designed block page (HTML). It is served exactly
    as uploaded; the placeholders {{REQUESTED_HOST}}, {{CLIENT_IP}}, {{HOSTNAME}}
    and {{POLICY}} are filled live."""
    body = (await request.body()).decode("utf-8", errors="replace")
    if not body.strip():
        raise HTTPException(status_code=422, detail="Choose an HTML file first")
    if len(body) > 200000:
        raise HTTPException(status_code=422, detail="The page must be under 200 KB")
    lowered = body.lower()
    if "<script" in lowered and "</script" not in lowered:
        raise HTTPException(status_code=422, detail="The HTML looks truncated — a <script> tag is never closed")
    settings = json_setting(database, "block_page_settings", BlockPageSettings, BlockPageSettings())
    settings = settings.model_copy(update={"custom_html": body, "custom_html_active": True})
    database.set_setting("block_page_settings", settings.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="block_page.custom.upload", resource_type="block_page", source_ip=client_ip(request), details={"size": len(body), "active": True})
    return {"uploaded": True, "size": len(body), "active": True, "message": "Your custom page is live — it applies at the next refresh (usually within a minute)."}


@app.delete("/api/v1/block-page/custom", status_code=204)
def delete_block_page_custom(request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    settings = json_setting(database, "block_page_settings", BlockPageSettings, BlockPageSettings())
    settings = settings.model_copy(update={"custom_html": "", "custom_html_active": False})
    database.set_setting("block_page_settings", settings.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="block_page.custom.delete", resource_type="block_page", source_ip=client_ip(request))


@app.get("/api/v1/block-page/preview", response_class=HTMLResponse)
def block_page_preview(database: Database = Depends(get_database)) -> str:
    """Public by design: the exact page blocked clients see, in whichever mode
    is active (generated, custom upload, or external redirect)."""
    from app.services.content_filter import render_block_page_live

    return render_block_page_live(json_setting(database, "block_page_settings", BlockPageSettings, BlockPageSettings()))


@app.get("/api/v1/proxy/settings", response_model=ProxySettings)
def proxy_settings(principal: Principal = Depends(require_scope("proxy:read")), database: Database = Depends(get_database)) -> ProxySettings:
    return json_setting(database, "proxy_settings", ProxySettings, ProxySettings())


@app.put("/api/v1/proxy/settings", response_model=ProxySettings)
def save_proxy_settings(payload: ProxySettings, request: Request, principal: Principal = Depends(require_scope("proxy:write")), database: Database = Depends(get_database)) -> ProxySettings:
    licensed_feature(database, "web_cache")
    if payload.tls_inspection:
        raise HTTPException(status_code=409, detail="TLS inspection requires managed CA provisioning and is not enabled by this release")
    database.set_setting("proxy_settings", payload.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="proxy.settings.update", resource_type="proxy", source_ip=client_ip(request))
    return payload


@app.get("/api/v1/proxy/render", response_class=PlainTextResponse)
def proxy_render(principal: Principal = Depends(require_scope("proxy:read")), database: Database = Depends(get_database)) -> str:
    return render_squid_config(json_setting(database, "proxy_settings", ProxySettings, ProxySettings()))


@app.get("/api/v1/cache/status")
def get_cache_status(principal: Principal = Depends(require_scope("proxy:read"))) -> dict:
    return cache_status()


@app.post("/api/v1/cache/purge")
def purge_cache(payload: CachePurgeRequest, request: Request, principal: Principal = Depends(require_scope("proxy:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "web_cache")
    proxy = json_setting(database, "proxy_settings", ProxySettings, ProxySettings())
    try:
        result = purge_cached_url(payload.url, proxy.listen_port)
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="cache.purge", resource_type="cache", source_ip=client_ip(request), details={"url": payload.url})
    return result


@app.get("/api/v1/dhcp/settings", response_model=DhcpSettings)
def dhcp_settings(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> DhcpSettings:
    return json_setting(database, "dhcp_settings", DhcpSettings, DhcpSettings())


@app.put("/api/v1/dhcp/settings", response_model=DhcpSettings)
def save_dhcp_settings(payload: DhcpSettings, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> DhcpSettings:
    licensed_feature(database, "routing")
    database.set_setting("dhcp_settings", payload.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="dhcp.settings.update", resource_type="dhcp", source_ip=client_ip(request))
    return payload


@app.get("/api/v1/dhcp/leases")
def dhcp_leases(principal: Principal = Depends(require_scope("deployment:read"))) -> dict:
    """Active Kea leases: live pool usage for the DHCP panel."""
    import csv as csv_module
    import time as time_module
    from datetime import UTC, datetime

    path = Path("/var/lib/kea/kea-leases4.csv")
    rows: list[dict] = []
    now = time_module.time()
    if path.is_file():
        with path.open(newline="", encoding="utf-8") as handle:
            for row in csv_module.DictReader(handle):
                if (row.get("state") or "0") not in {"0", ""}:
                    continue
                expire_epoch = int(row.get("expire") or 0)
                if expire_epoch and expire_epoch <= now:
                    continue  # superseded or expired entry
                expires = None
                try:
                    if expire_epoch > 0:
                        expires = datetime.fromtimestamp(expire_epoch, UTC).isoformat()
                except (ValueError, OSError):
                    pass
                rows.append({"ip_address": row.get("address"), "mac_address": row.get("hwaddr"), "hostname": (row.get("hostname") or "").rstrip("."), "expires_at": expires, "_expire": expire_epoch})
    # Kea keeps the previous row for a renewed lease until it expires;
    # keep only the newest row per address so each device is counted once.
    latest: dict[str, dict] = {}
    for row in rows:
        key = row["ip_address"] or row["mac_address"] or ""
        current = latest.get(key)
        if current is None or (row["_expire"] or 0) >= (current["_expire"] or 0):
            latest[key] = row
    rows = sorted(latest.values(), key=lambda row: row["ip_address"] or "")
    for row in rows:
        row.pop("_expire", None)
    return {"active": len(rows), "leases": rows[:200]}


@app.get("/api/v1/dhcp/render", response_class=PlainTextResponse)
def dhcp_render(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> str:
    return render_kea_config(json_setting(database, "dhcp_settings", DhcpSettings, DhcpSettings()), database.dhcp_reservations(), database.ip_pools())


def pools_sync_now() -> dict:
    """Immediate pools/portal reconcile through the fixed root helper (best effort)."""
    import json as json_module
    import subprocess as pools_subprocess

    completed = pools_subprocess.run(["sudo", "-n", "/usr/local/sbin/firewall-pools-sync", "sync"], capture_output=True, text=True, timeout=180, check=False)
    try:
        body = json_module.loads(completed.stdout)
    except json_module.JSONDecodeError:
        body = {"ok": False, "message": (completed.stderr.strip() or "Pools sync helper returned no result")[:400]}
    body["returncode"] = completed.returncode
    return body


@app.get("/api/v1/dhcp/pools")
def list_ip_pools(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.ip_pools()


@app.post("/api/v1/dhcp/pools", status_code=201)
def create_ip_pool(payload: IpPoolCreate, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "routing")
    import ipaddress
    from datetime import UTC, datetime

    network = ipaddress.ip_network(payload.subnet, strict=False)
    start, end = ipaddress.ip_address(payload.pool_start), ipaddress.ip_address(payload.pool_end)
    if start not in network or end not in network or int(start) > int(end):
        raise HTTPException(status_code=422, detail="Pool addresses must sit inside the subnet and the start must not exceed the end.")
    primary = json_setting(database, "dhcp_settings", DhcpSettings, DhcpSettings())
    if primary.enabled and ipaddress.ip_network(primary.subnet, strict=False).overlaps(network):
        raise HTTPException(status_code=409, detail="This subnet overlaps the primary LAN network.")
    for row in database.ip_pools():
        if ipaddress.ip_network(row["subnet"], strict=False).overlaps(network):
            raise HTTPException(status_code=409, detail=f"This subnet overlaps the existing pool “{row['name']}” ({row['subnet']}).")
    router = str(ipaddress.ip_network(network).network_address + 1)
    created = database.create_ip_pool({**payload.model_dump(), "router": router, "created_at": datetime.now(UTC).isoformat()})
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="dhcp.pool.create", resource_type="ip_pool", resource_id=str(created["id"]), source_ip=client_ip(request), details={"name": payload.name, "vlan_id": payload.vlan_id, "subnet": payload.subnet})
    sync = pools_sync_now()
    return {"pool": created, "applied": sync.get("ok", False), "apply_detail": sync}


@app.delete("/api/v1/dhcp/pools/{item_id}", status_code=204)
def delete_ip_pool(item_id: int, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_ip_pool(item_id):
        raise HTTPException(status_code=404, detail="IP pool not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="dhcp.pool.delete", resource_type="ip_pool", resource_id=str(item_id), source_ip=client_ip(request))
    pools_sync_now()


@app.get("/api/v1/portal/settings", response_model=PortalSettings)
def portal_settings(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> PortalSettings:
    return json_setting(database, "portal_settings", PortalSettings, PortalSettings())


@app.put("/api/v1/portal/settings", response_model=PortalSettings)
def save_portal_settings(payload: PortalSettings, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> PortalSettings:
    database.set_setting("portal_settings", payload.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="portal.settings.update", resource_type="portal", source_ip=client_ip(request), details={"enabled": payload.enabled})
    pools_sync_now()  # instant: portal page, set and kernel rules within seconds
    return payload


@app.get("/api/v1/portal/accepted")
def portal_accepted(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.portal_acceptances()


@app.delete("/api/v1/portal/accepted/{item_id}", status_code=204)
def revoke_portal_acceptance(item_id: int, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_portal_acceptance(item_id):
        raise HTTPException(status_code=404, detail="Acceptance not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="portal.acceptance.revoke", resource_type="portal", resource_id=str(item_id), source_ip=client_ip(request))
    pools_sync_now()


def _mac_for_ip(address: str) -> str | None:
    """Resolve a client IP to its MAC (ARP/neighbour table; readable unprivileged)."""
    import re as re_module
    import subprocess as neigh_subprocess

    try:
        completed = neigh_subprocess.run(["ip", "neigh", "show", address], text=True, capture_output=True, timeout=5, check=False)
        match = re_module.search(r"([0-9a-fA-F:]{17})", completed.stdout)
        return match.group(1).lower() if match else None
    except OSError:
        return None


@app.post("/api/v1/portal/accept")
def portal_accept(request: Request, database: Database = Depends(get_database)) -> dict:
    """PUBLIC: a device accepts the network policy. The client IP comes from
    nginx (X-Real-IP); the MAC is resolved from the neighbour table, and the
    acceptance is enforced instantly through the fixed root helper."""
    import secrets
    import subprocess as portal_subprocess

    portal = json_setting(database, "portal_settings", PortalSettings, PortalSettings())
    if not portal.enabled:
        raise HTTPException(status_code=423, detail="The policy acceptance page is not enabled on this network.")
    address = (request.headers.get("x-real-ip") or request.client.host if request.client else "").split("%")[0]
    mac = _mac_for_ip(address) if address else None
    if not mac:
        return {"ok": False, "message": "Could not identify this device yet. Refresh this page once, then try again."}
    database.create_portal_acceptance(mac, address)
    transaction = f"portal_{secrets.token_hex(8)}"
    base = Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance")) / "portal-candidates" / transaction
    base.mkdir(parents=True, mode=0o750, exist_ok=False)
    (base / "accept.json").write_text(json.dumps({"mac": mac, "ip": address}))
    completed = portal_subprocess.run(["sudo", "-n", "/usr/local/sbin/firewall-pools-sync", "portal-accept", transaction], capture_output=True, text=True, timeout=60, check=False)
    import shutil as shutil_module

    shutil_module.rmtree(base, ignore_errors=True)
    try:
        body = json.loads(completed.stdout)
    except json.JSONDecodeError:
        body = {"ok": False, "message": "Enforcement helper returned no result"}
    database.create_security_event({"event_type": "portal", "action": "accepted" if body.get("ok") else "failed", "policy": "portal-accept", "details": {"mac_address": mac, "ip_address": address}})
    if not body.get("ok"):
        raise HTTPException(status_code=502, detail=body.get("message") or "Could not register this device")
    return {"ok": True, "message": "Accepted. This device now has internet access.", "mac_address": mac}


@app.get("/api/v1/system/services")
def services(principal: Principal = Depends(require_scope("deployment:read"))) -> list[dict]:
    return system_services()


@app.get("/api/v1/schedules")
def schedules(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.schedules()


@app.post("/api/v1/schedules", status_code=201)
def create_schedule(payload: ScheduleCreate, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "schedules")
    try:
        result = database.create_schedule(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=409, detail="A schedule with this name already exists") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="schedule.create", resource_type="schedule", resource_id=str(result["id"]), source_ip=client_ip(request))
    return result


@app.delete("/api/v1/schedules/{schedule_id}", status_code=204)
def delete_schedule(schedule_id: int, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_schedule(schedule_id):
        raise HTTPException(status_code=404, detail="Schedule not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="schedule.delete", resource_type="schedule", resource_id=str(schedule_id), source_ip=client_ip(request))


@app.get("/api/v1/events")
def security_events(limit: int = 100, principal: Principal = Depends(require_scope("audit:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.security_events(limit)


@app.post("/api/v1/events", status_code=201)
def ingest_security_event(payload: SecurityEventCreate, request: Request, principal: Principal = Depends(require_scope("events:write")), database: Database = Depends(get_database)) -> dict:
    result = database.create_security_event(payload.model_dump())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="event.ingest", resource_type="security_event", resource_id=str(result["id"]), source_ip=client_ip(request), details={"event_type": payload.event_type, "action": payload.action})
    return result


@app.get("/api/v1/reports/summary")
def report_summary(principal: Principal = Depends(require_scope("audit:read")), database: Database = Depends(get_database)) -> dict:
    events = database.security_events(5000)
    blocked = [row for row in events if row["action"] == "blocked"]
    categories: dict[str, int] = {}
    destinations: dict[str, int] = {}
    for row in blocked:
        categories[row.get("category") or "uncategorized"] = categories.get(row.get("category") or "uncategorized", 0) + 1
        destinations[row.get("destination") or "unknown"] = destinations.get(row.get("destination") or "unknown", 0) + 1
    return {"generated_at": datetime.now(UTC), "event_count": len(events), "blocked_count": len(blocked), "top_categories": sorted(categories.items(), key=lambda item: item[1], reverse=True)[:10], "top_destinations": sorted(destinations.items(), key=lambda item: item[1], reverse=True)[:10]}


@app.get("/api/v1/reports/events.csv")
def report_csv(limit: int = 5000, principal: Principal = Depends(require_scope("audit:read")), database: Database = Depends(get_database)) -> Response:
    import csv, io
    rows = database.security_events(limit)
    output = io.StringIO(); writer = csv.writer(output); writer.writerow(["occurred_at", "event_type", "action", "client_ip", "hostname", "destination", "category", "policy"])
    for row in reversed(rows): writer.writerow([row.get(key) or "" for key in ["occurred_at", "event_type", "action", "client_ip", "hostname", "destination", "category", "policy"]])
    return Response(output.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=firewall-events.csv"})


@app.post("/api/v1/access-requests", status_code=201)
def create_access_request(payload: AccessRequestCreate, request: Request, database: Database = Depends(get_database)) -> dict:
    """PUBLIC: submitted from the block page's request-access form. The client
    device cannot know its own address, so the appliance records it."""
    source_ip = payload.client_ip or client_ip(request) or "unknown"
    payload = payload.model_copy(update={"client_ip": source_ip, "device_name": payload.device_name or hostname_for_ip(source_ip)})
    # One pending request per device+site: pressing the button twice must not
    # stack duplicates for the administrator to review.
    existing = database.pending_access_request(source_ip, payload.requested_host)
    if existing:
        return existing | {"already_pending": True}
    result = database.create_access_request(payload.model_dump())
    database.audit(actor_type="client", actor_id=payload.device_name, action="access_request.create", resource_type="access_request", resource_id=str(result["id"]), source_ip=client_ip(request), details={"requested_host": payload.requested_host})
    return result


@app.get("/api/v1/access-requests")
def access_requests(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> list[dict]:
    return database.access_requests()


@app.get("/api/v1/access-requests/status")
def access_request_status(request: Request, host: str = "", database: Database = Depends(get_database)) -> dict:
    """PUBLIC: the waiting client's block page polls this for the decision on
    its own request — matched by the appliance's view of the client's address."""
    source_ip = (client_ip(request) or "").split("%")[0]
    row = database.latest_access_request(source_ip, normalize_domain(host or "")) if source_ip else None
    if not row:
        return {"status": "none"}
    return {"status": row["status"], "reviewed_by": row.get("reviewed_by"), "review_note": row.get("review_note")}


@app.delete("/api/v1/access-requests/reviewed")
def clear_reviewed_access_requests(request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    """Tidy-up: reviewed decisions are removed; pending requests are kept."""
    removed = database.clear_reviewed_access_requests()
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="access_request.clear_reviewed", resource_type="access_request", resource_id="reviewed", source_ip=client_ip(request), details={"removed": removed})
    return {"removed": removed, "pending": len(database.access_requests())}


@app.post("/api/v1/access-requests/{request_id}/review")
def review_access_request(request_id: int, payload: AccessRequestReview, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    current = database.access_request(request_id)
    if not current: raise HTTPException(status_code=404, detail="Access request not found")
    if current["status"] != "pending": raise HTTPException(status_code=409, detail="Access request was already reviewed")
    allow_rule = None
    allow_rules = []
    if payload.decision == "approved" and payload.create_allow_rule:
        # Blocking is service-level (facebook.com blocks its fbcdn.net assets
        # too), so allowing must be too — a single-host allow would leave the
        # site loading half-broken. Allow the whole known service, or when the
        # site is unknown, the host plus its bare domain.
        target = normalize_domain(current["requested_host"])
        allow_domains = {target}
        if target.startswith("www."):
            allow_domains.add(target[4:])
        duration_map = {"1h": timedelta(hours=1), "4h": timedelta(hours=4), "8h": timedelta(hours=8), "24h": timedelta(hours=24), "3d": timedelta(days=3), "7d": timedelta(days=7), "30d": timedelta(days=30)}
        expires_at = (datetime.now(UTC) + duration_map[payload.duration]).isoformat() if payload.duration in duration_map else None
        service = next((item for item in application_catalog(database.application_policies(), database.custom_services(), database.service_extensions())
                        if any(target == normalize_domain(d) or target.endswith("." + normalize_domain(d)) for d in item.get("domains") or [])), None)
        if service:
            allow_domains |= {normalize_domain(d) for d in service.get("domains") or []}
        for domain in sorted(allow_domains):
            try:
                allow_rules.append(database.create_local_domain(domain, "allow", "access-request", expires_at))
            except Exception:
                pass  # an allow rule already covers this domain
        allow_rule = allow_rules[0] if allow_rules else None  # empty simply means the site is already allowed
        if allow_rules:
            try:
                enforce_dns_now(database)
            except Exception:
                pass  # the reconciler applies the same state within the minute
    result = database.review_access_request(request_id, payload.decision, principal.username, payload.note)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="access_request.review", resource_type="access_request", resource_id=str(request_id), source_ip=client_ip(request), details=payload.model_dump() | {"allow_rule_id": allow_rule["id"] if allow_rule else None, "expires_at": expires_at})
    return result | {"allow_rule": allow_rule, "expires_at": expires_at}


@app.get("/api/v1/retention/settings", response_model=RetentionSettings)
def retention_settings(principal: Principal = Depends(require_scope("audit:read")), database: Database = Depends(get_database)) -> RetentionSettings:
    return json_setting(database, "retention_settings", RetentionSettings, RetentionSettings())


@app.put("/api/v1/retention/settings", response_model=RetentionSettings)
def save_retention(payload: RetentionSettings, request: Request, principal: Principal = Depends(require_scope("audit:write")), database: Database = Depends(get_database)) -> RetentionSettings:
    database.set_setting("retention_settings", payload.model_dump_json()); database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="retention.update", resource_type="retention", source_ip=client_ip(request), details=payload.model_dump()); return payload


@app.post("/api/v1/retention/purge")
def purge_retention(request: Request, principal: Principal = Depends(require_scope("audit:write")), database: Database = Depends(get_database)) -> dict:
    settings = json_setting(database, "retention_settings", RetentionSettings, RetentionSettings()); now = datetime.now(UTC)
    result = database.purge_operational_data((now-timedelta(days=settings.security_event_days)).isoformat(), (now-timedelta(days=settings.audit_days)).isoformat(), (now-timedelta(days=settings.access_request_days)).isoformat())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="retention.purge", resource_type="retention", source_ip=client_ip(request), details=result); return result


@app.get("/api/v1/support/bundle")
def download_support_bundle(principal: Principal = Depends(require_scope("audit:read")), database: Database = Depends(get_database)) -> Response:
    data = support_bundle(str(database.path), os.environ.get("FIREWALL_STATE_DIR", "./state"))
    return Response(data, media_type="application/gzip", headers={"Content-Disposition": "attachment; filename=firewall-support-bundle.tar.gz"})


@app.post("/api/v1/operations/backup")
def operations_backup_now(request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    """One click: a timestamped backup saved on the appliance (plus the same
    archive available for download from Backup export), and the status of any
    pending signed update packages. Update packages are still applied through
    the guarded Updates flow — a one-click auto-apply of signed code is not
    something we do silently."""
    from datetime import UTC as _UTC

    data = backup_archive(str(database.path), os.environ.get("FIREWALL_STATE_DIR", "./state"))
    target = Path(os.environ.get("FIREWALL_STATE_DIR", "./state")) / "backups"
    target.mkdir(parents=True, exist_ok=True)
    name = f"backup-{datetime.now(_UTC).strftime('%Y%m%d-%H%M%S')}.tar.gz"
    (target / name).write_bytes(data)
    pending: list[dict] = []
    updates = Path(os.environ.get("FIREWALL_STATE_DIR", "./state")) / "updates"
    if updates.is_dir():
        for metadata in sorted(updates.glob("*/metadata.json")):
            try:
                pending.append(json.loads(metadata.read_text()))
            except ValueError:
                continue
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="operations.backup", resource_type="backup", source_ip=client_ip(request), details={"file": name, "size": len(data), "pending_updates": len(pending)})
    return {"saved": name, "size": len(data), "download": "/api/v1/backup/export", "pending_updates": [item.get("manifest", {}).get("version") for item in pending]}


@app.get("/api/v1/backup/export")
def export_backup(request: Request, principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> Response:
    data = backup_archive(str(database.path), os.environ.get("FIREWALL_STATE_DIR", "./state"))
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="backup.export", resource_type="backup", source_ip=client_ip(request), details={"size": len(data), "secrets_included": False})
    return Response(data, media_type="application/gzip", headers={"Content-Disposition": "attachment; filename=firewall-appliance-backup.tar.gz"})


@app.post("/api/v1/backup/validate")
async def backup_validate(request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    try:
        result = validate_backup(await request.body())
    except (ValueError, KeyError, OSError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="backup.validate", resource_type="backup", source_ip=client_ip(request), details=result)
    return result


@app.post("/api/v1/restore/stage", status_code=201)
async def restore_stage(request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "backup_restore")
    try:
        result = stage_restore(await request.body(), os.environ.get("FIREWALL_STATE_DIR", "./state"))
    except (ValueError, KeyError, OSError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="restore.stage", resource_type="restore", resource_id=result["candidate_id"], source_ip=client_ip(request), details=result["validation"])
    return result


@app.post("/api/v1/restore/apply")
def restore_apply(payload: RestoreApplyRequest, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "backup_restore")
    required = f"RESTORE {payload.candidate_id}"
    if payload.confirmation != required:
        raise HTTPException(status_code=422, detail=f"Confirmation must exactly match: {required}")
    try:
        result = apply_restore(payload.candidate_id, database.path, os.environ.get("FIREWALL_STATE_DIR", "./state"))
        database.initialize()
    except (ValueError, FileNotFoundError, OSError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="restore.apply", resource_type="restore", resource_id=payload.candidate_id, source_ip=client_ip(request), details={"safety_copy": result["safety_copy"]})
    return result


@app.post("/api/v1/updates/stage", status_code=201)
def update_stage(payload: UpdateStageRequest, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "updates")
    try:
        result = stage_signed_update(payload.manifest, payload.signature, payload.package_base64, os.environ.get("FIREWALL_STATE_DIR", "./state"))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except (ValueError, OSError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="update.stage", resource_type="update", resource_id=result["update_id"], source_ip=client_ip(request), details={"version": result["manifest"]["version"], "sha256": result["manifest"]["sha256"]})
    return result


@app.get("/api/v1/firewall/zones")
def list_zones(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> list[dict]: return database.zones()

@app.post("/api/v1/firewall/zones", status_code=201)
def create_zone(payload: FirewallZoneCreate, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "firewall")
    try: result = database.create_zone(payload.model_dump())
    except Exception as exc: raise HTTPException(status_code=409, detail="Zone name already exists") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="zone.create", resource_type="zone", resource_id=str(result["id"]), source_ip=client_ip(request)); return result

@app.delete("/api/v1/firewall/zones/{item_id}", status_code=204)
def delete_zone(item_id: int, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_zone(item_id): raise HTTPException(status_code=404, detail="Zone not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="zone.delete", resource_type="zone", resource_id=str(item_id), source_ip=client_ip(request))

@app.get("/api/v1/firewall/port-forwards")
def list_port_forwards(principal: Principal = Depends(require_scope("policies:read")), database: Database = Depends(get_database)) -> list[dict]: return database.port_forwards()

@app.post("/api/v1/firewall/port-forwards", status_code=201)
def create_port_forward(payload: PortForwardCreate, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "nat")
    try: result = database.create_port_forward(payload.model_dump())
    except Exception as exc: raise HTTPException(status_code=409, detail="Protocol and external port already exist") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="port_forward.create", resource_type="port_forward", resource_id=str(result["id"]), source_ip=client_ip(request)); return result

@app.delete("/api/v1/firewall/port-forwards/{item_id}", status_code=204)
def delete_port_forward(item_id: int, request: Request, principal: Principal = Depends(require_scope("policies:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_port_forward(item_id): raise HTTPException(status_code=404, detail="Port forward not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="port_forward.delete", resource_type="port_forward", resource_id=str(item_id), source_ip=client_ip(request))

@app.get("/api/v1/dhcp/reservations")
def list_reservations(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> list[dict]: return database.dhcp_reservations()

@app.post("/api/v1/dhcp/reservations", status_code=201)
def create_reservation(payload: DhcpReservationCreate, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "routing")
    try: result = database.create_dhcp_reservation(payload.model_dump())
    except Exception as exc: raise HTTPException(status_code=409, detail="MAC or IP reservation already exists") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="dhcp.reservation.create", resource_type="dhcp_reservation", resource_id=str(result["id"]), source_ip=client_ip(request)); return result

@app.delete("/api/v1/dhcp/reservations/{item_id}", status_code=204)
def delete_reservation(item_id: int, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_dhcp_reservation(item_id): raise HTTPException(status_code=404, detail="Reservation not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="dhcp.reservation.delete", resource_type="dhcp_reservation", resource_id=str(item_id), source_ip=client_ip(request))

@app.get("/api/v1/dns/records")
def list_dns_records(principal: Principal = Depends(require_scope("dns:read")), database: Database = Depends(get_database)) -> list[dict]: return database.dns_records()

@app.post("/api/v1/dns/records", status_code=201)
def create_dns_record(payload: LocalDnsRecordCreate, request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> dict:
    licensed_feature(database, "dns")
    try: result = database.create_dns_record(payload.model_dump())
    except Exception as exc: raise HTTPException(status_code=409, detail="DNS name and record type already exist") from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="dns.record.create", resource_type="dns_record", resource_id=str(result["id"]), source_ip=client_ip(request)); return result

@app.delete("/api/v1/dns/records/{item_id}", status_code=204)
def delete_dns_record(item_id: int, request: Request, principal: Principal = Depends(require_scope("dns:write")), database: Database = Depends(get_database)) -> None:
    if not database.delete_dns_record(item_id): raise HTTPException(status_code=404, detail="DNS record not found")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="dns.record.delete", resource_type="dns_record", resource_id=str(item_id), source_ip=client_ip(request))


def iptables_module_state(database: Database) -> dict[str, bool]:
    raw = database.setting("iptables_modules")
    resolved = resolve_module_state(__import__("json").loads(raw) if raw else default_module_state())
    # Licence clamp: modules whose feature is not licensed render as off.
    return licensed_modules(database, resolved)


@app.get("/api/v1/firewall/engine")
def firewall_engine(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> dict:
    settings = json_setting(database, "iptables_settings", IptablesSettings, IptablesSettings())
    return {"backend": "iptables", "legacy_binary": "iptables-nft or iptables-legacy", "settings": settings.model_dump(), "live_apply_enabled": os.environ.get("FIREWALL_ENABLE_LIVE_APPLY") == "1"}


@app.put("/api/v1/firewall/engine/settings")
def update_firewall_engine(payload: IptablesSettings, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    database.set_setting("iptables_settings", payload.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="iptables.settings.update", resource_type="firewall_engine", source_ip=client_ip(request), details=payload.model_dump())
    return payload.model_dump()


@app.get("/api/v1/firewall/modules")
def firewall_modules(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> list[dict]:
    return module_inventory(iptables_module_state(database))


@app.put("/api/v1/firewall/modules/{module_key}")
def update_firewall_module(module_key: str, payload: FirewallModuleUpdate, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    current = iptables_module_state(database)
    if module_key == "ids_ips" and payload.enabled and not ids_helper("status").get("installed"):
        raise HTTPException(status_code=409, detail="Install the IDS/IPS software first — use the Install button on the Modules page.")
    try:
        resolved = resolve_module_state(current | {module_key: payload.enabled})
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if not payload.enabled:
        dependants = [row["name"] for row in module_inventory(resolved) if row["enabled"] and module_key in row["requires"]]
        if dependants:
            raise HTTPException(status_code=409, detail=f"Disable dependent modules first: {', '.join(dependants)}")
    database.set_setting("iptables_modules", __import__("json").dumps(resolved, sort_keys=True))
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="iptables.module.update", resource_type="firewall_module", resource_id=module_key, source_ip=client_ip(request), details={"enabled": payload.enabled, "resolved_state": resolved})
    return {"module": module_key, "enabled": resolved[module_key], "state": resolved, "note": "Saved to desired state. Prepare and activate a candidate to change live enforcement."}


def ids_helper(action: str) -> dict:
    """Call the fixed firewall-ids root helper (install|status|uninstall)."""
    import json as json_module
    import subprocess as ids_subprocess

    completed = ids_subprocess.run(["sudo", "-n", "/usr/local/sbin/firewall-ids", action], capture_output=True, text=True, timeout=900 if action in {"install", "rules-update"} else 120, check=False)
    try:
        body = json_module.loads(completed.stdout)
    except json_module.JSONDecodeError:
        body = {"ok": False, "message": (completed.stderr.strip() or "IDS/IPS helper returned no result")[:400]}
    body["returncode"] = completed.returncode
    return body


@app.post("/api/v1/firewall/modules/ids_ips/rules/update")
def ids_ips_rules_update(request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    """Download the ET Open attack-signature feed, validate it, live-reload Suricata."""
    body = ids_helper("rules-update")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="ids_ips.rules_update", resource_type="firewall_module", resource_id="ids_ips", outcome="success" if body.get("ok") else "failure", source_ip=client_ip(request), details={"message": str(body.get("message", ""))[:400], "rules_count": body.get("rules_count")})
    if body.get("returncode") or not body.get("ok"):
        raise HTTPException(status_code=502, detail=body.get("message") or "IDS/IPS rules update failed")
    return body


GEOIP_STATUS_FILE = Path("/var/lib/firewall-appliance/geoip-status.json")


def geoip_status(database: Database) -> dict:
    settings = json_setting(database, "geoip_settings", GeoipSettings, GeoipSettings())
    feed = {}
    if GEOIP_STATUS_FILE.is_file():
        try:
            feed = json.loads(GEOIP_STATUS_FILE.read_text())
        except ValueError:
            feed = {}
    return {"enabled": settings.enabled, "mode": settings.mode, "countries": settings.countries,
            "sets_built": bool(feed), "feed": feed or None,
            "ready": settings.enabled and bool(feed) and bool(settings.countries)}


@app.get("/api/v1/geoip/settings")
def get_geoip_settings(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> dict:
    return geoip_status(database)


@app.put("/api/v1/geoip/settings")
def put_geoip_settings(payload: GeoipSettings, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    database.set_setting("geoip_settings", payload.model_dump_json())
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="geoip.settings", resource_type="geoip", source_ip=client_ip(request), details={"enabled": payload.enabled, "mode": payload.mode, "countries": payload.countries})
    return geoip_status(database)


@app.post("/api/v1/geoip/update")
def geoip_update_now(request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    """Runs the country-set feed updater once. The updater keeps the last
    good sets when a download fails — enforcement never goes blank."""
    import subprocess
    completed = subprocess.run(["sudo", "-n", "/usr/bin/systemctl", "start", "firewall-geoip.service"], capture_output=True, text=True, timeout=300, check=False)
    if completed.returncode != 0:
        raise HTTPException(status_code=503, detail="The country set updater could not be started: " + (completed.stderr.strip()[:200] or "unknown error"))
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="geoip.update", resource_type="geoip", source_ip=client_ip(request), details={"triggered": True})
    return geoip_status(database)


@app.get("/api/v1/geoip/status")
def get_geoip_status(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> dict:
    return geoip_status(database)


@app.get("/api/v1/firewall/modules/ids_ips/status")
def ids_ips_status(principal: Principal = Depends(require_scope("deployment:read"))) -> dict:
    return ids_helper("status")


@app.post("/api/v1/firewall/modules/ids_ips/install")
def ids_ips_install(request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    body = ids_helper("install")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="ids_ips.install", resource_type="firewall_module", resource_id="ids_ips", outcome="success" if body.get("ok") and body.get("installed") else "failure", source_ip=client_ip(request), details={"installed": body.get("installed"), "running": body.get("running"), "message": str(body.get("message", ""))[:400]})
    if body.get("returncode") or not body.get("ok"):
        raise HTTPException(status_code=502, detail=body.get("message") or "IDS/IPS installation failed")
    return body


@app.post("/api/v1/firewall/modules/ids_ips/uninstall")
def ids_ips_uninstall(request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    body = ids_helper("uninstall")
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="ids_ips.uninstall", resource_type="firewall_module", resource_id="ids_ips", outcome="success" if body.get("ok") else "failure", source_ip=client_ip(request), details={"message": str(body.get("message", ""))[:400]})
    if body.get("returncode") or not body.get("ok"):
        raise HTTPException(status_code=502, detail=body.get("message") or "IDS/IPS removal failed")
    try:
        resolved = resolve_module_state(iptables_module_state(database) | {"ids_ips": False})
        database.set_setting("iptables_modules", __import__("json").dumps(resolved, sort_keys=True))
    except ValueError:
        pass
    return body


def iptables_settings_payload(database: Database) -> dict:
    """Iptables settings plus the admin-page port from system settings."""
    settings = json_setting(database, "iptables_settings", IptablesSettings, IptablesSettings())
    return settings.model_dump() | {"admin_port": int(database.setting("admin_port") or 80)}


@app.post("/api/v1/firewall/iptables/render")
def render_iptables_candidate(request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    result = candidate_payload(iptables_module_state(database), iptables_settings_payload(database), compiled_network_rules(database), compile_block_targets(database.policy_sources()), compiled_security_controls(database))
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="iptables.candidate.render", resource_type="firewall_candidate", resource_id=result["sha256"][:16], source_ip=client_ip(request), details={"valid": result["validation"]["valid"]})
    return result


@app.post("/api/v1/firewall/iptables/candidates", status_code=201)
def prepare_iptables_candidate(request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    import json, secrets, time
    result = candidate_payload(iptables_module_state(database), iptables_settings_payload(database), compiled_network_rules(database), compile_block_targets(database.policy_sources()), compiled_security_controls(database))
    if not result["validation"]["valid"]:
        raise HTTPException(status_code=422, detail=result["validation"])
    transaction_id = f"ipt_{secrets.token_hex(8)}"
    base = Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance")) / "iptables-candidates" / transaction_id
    base.mkdir(parents=True, mode=0o750, exist_ok=False)
    (base / "rules.v4").write_text(result["rules"])
    # The helper verifies the manifest hash over BOTH stacks; the v6 file must be
    # staged whenever the payload contains a v6 ruleset or activation fails.
    if result.get("rules6"):
        (base / "rules.v6").write_text(result["rules6"])
    manifest = {"transaction_id": transaction_id, "sha256": result["sha256"], "created_at": time.time(), "expires_at": time.time() + 900, "rollback_seconds": settings.rollback_seconds, "modules": result["modules"]}
    (base / "manifest.json").write_text(json.dumps(manifest, sort_keys=True))
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="iptables.candidate.prepare", resource_type="firewall_candidate", resource_id=transaction_id, source_ip=client_ip(request), details={"sha256": result["sha256"], "rollback_seconds": settings.rollback_seconds})
    return {"transaction_id": transaction_id, "sha256": result["sha256"], "expires_at": manifest["expires_at"], "rollback_seconds": settings.rollback_seconds, "validation": result["validation"], "next": f"POST /api/v1/firewall/iptables/transactions/{transaction_id}/activate"}


def iptables_transaction_action(transaction_id: str, action: str) -> dict:
    import json, re, subprocess
    if action not in {"activate", "confirm", "rollback", "status"} or not re.fullmatch(r"ipt_[0-9a-f]{16}", transaction_id):
        raise HTTPException(status_code=422, detail="Invalid transaction request")
    if action == "activate" and os.environ.get("FIREWALL_ENABLE_LIVE_APPLY") != "1":
        raise HTTPException(status_code=423, detail="Live apply is disabled. Candidate was not activated.")
    completed = subprocess.run(["sudo", "/usr/local/sbin/firewall-iptables-transaction", action, transaction_id], capture_output=True, text=True, timeout=40, check=False)
    try:
        body = json.loads(completed.stdout)
    except json.JSONDecodeError:
        body = {"ok": False, "message": completed.stderr.strip() or "Transaction helper returned invalid output"}
    if completed.returncode:
        raise HTTPException(status_code=409, detail=body)
    return body


@app.post("/api/v1/firewall/iptables/transactions/{transaction_id}/{action}")
def manage_iptables_transaction(transaction_id: str, action: str, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    result = iptables_transaction_action(transaction_id, action)
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action=f"iptables.transaction.{action}", resource_type="firewall_transaction", resource_id=transaction_id, source_ip=client_ip(request), details={"state": result.get("state")})
    return result


@app.get("/api/v1/firewall/iptables/transactions/{transaction_id}")
def get_iptables_transaction(transaction_id: str, principal: Principal = Depends(require_scope("deployment:read"))) -> dict:
    return iptables_transaction_action(transaction_id, "status")


@app.get("/api/v1/firewall/iptables/live")
def live_iptables(principal: Principal = Depends(require_scope("deployment:read"))) -> dict:
    import shutil, subprocess
    binary = shutil.which("iptables-save")
    if not binary:
        return {"available": False, "rules": "", "message": "iptables-save is not installed"}
    completed = subprocess.run([binary, "-c"], capture_output=True, text=True, timeout=10, check=False)
    return {"available": True, "rules": completed.stdout, "message": completed.stderr.strip(), "return_code": completed.returncode}


# Ports owned by other appliance services; the admin page may never take them.
ADMIN_PORT_RESERVED = {22, 53, 67, 68, 443, 3128, 8080, 8420}


@app.get("/api/v1/system/docs/{filename}")
def get_documentation(filename: str) -> FileResponse:
    """Downloadable manuals from the appliance (dashboard link targets)."""
    import re
    if not re.fullmatch(r"[A-Za-z0-9._-]+\.pdf", filename):
        raise HTTPException(status_code=422, detail="Invalid document name")
    path = Path(__file__).resolve().parents[2] / "output" / "pdf" / filename
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Document not found")
    return FileResponse(path, media_type="application/pdf", filename=filename)


@app.get("/api/v1/system/admin-port")
def get_admin_port(principal: Principal = Depends(require_scope("deployment:read")), database: Database = Depends(get_database)) -> dict:
    """The TCP port the admin dashboard (nginx) answers on."""
    try:
        port = int(database.setting("admin_port") or 80)
    except ValueError:
        port = 80
    return {"port": port, "reserved": sorted(ADMIN_PORT_RESERVED)}


@app.put("/api/v1/system/admin-port")
def set_admin_port(payload: AdminPortUpdate, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    """Move the admin dashboard to another port, safely:
    1. save the setting, 2. re-apply the firewall rules so the new port is
    reachable everywhere the old one was, 3. switch nginx last — the current
    session keeps working until the very last step."""
    import json, secrets, subprocess, time
    port = payload.port
    if port in ADMIN_PORT_RESERVED:
        raise HTTPException(status_code=422, detail=f"Port {port} is used by an appliance service — choose another.")
    try:
        previous = int(database.setting("admin_port") or 80)
    except ValueError:
        previous = 80
    if port == previous:
        return {"port": port, "previous_port": previous, "changed": False, "message": f"The admin page already answers on port {port}."}

    database.set_setting("admin_port", str(port))

    # 1) Firewall first: stage, activate and confirm a ruleset that allows the
    # new port from the management networks, the LAN and every pool.
    result = candidate_payload(iptables_module_state(database), iptables_settings_payload(database), compiled_network_rules(database), compile_block_targets(database.policy_sources()), compiled_security_controls(database))
    if not result["validation"]["valid"]:
        database.set_setting("admin_port", str(previous))
        raise HTTPException(status_code=422, detail=result["validation"])
    transaction_id = f"ipt_{secrets.token_hex(8)}"
    base = Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance")) / "iptables-candidates" / transaction_id
    base.mkdir(parents=True, mode=0o750, exist_ok=False)
    (base / "rules.v4").write_text(result["rules"])
    if result.get("rules6"):
        (base / "rules.v6").write_text(result["rules6"])
    manifest = {"transaction_id": transaction_id, "sha256": result["sha256"], "created_at": time.time(), "expires_at": time.time() + 900, "rollback_seconds": 30, "modules": result["modules"]}
    (base / "manifest.json").write_text(json.dumps(manifest, sort_keys=True))
    try:
        activate_result = iptables_transaction_action(transaction_id, "activate")
        confirm_result = iptables_transaction_action(transaction_id, "confirm")
    except HTTPException as exc:
        database.set_setting("admin_port", str(previous))
        detail = exc.detail if isinstance(exc.detail, str) else "The firewall rules could not be applied — the port was not changed."
        raise HTTPException(status_code=exc.status_code, detail=detail) from exc

    # 2) nginx last: the dashboard switches to the new port only after the
    # firewall already allows it. Failure here leaves the old port answering.
    # systemd-run escapes the API service's mount sandbox (ProtectSystem=strict
    # makes /run read-only, which nginx's config test cannot tolerate).
    completed = subprocess.run(["sudo", "-n", "/usr/bin/systemd-run", "--quiet", "--wait", "--pipe", "/usr/local/sbin/firewall-admin-port", "set", str(port)], capture_output=True, text=True, timeout=90, check=False)
    try:
        body = json.loads(completed.stdout)
    except json.JSONDecodeError:
        body = {"ok": False, "message": completed.stderr.strip() or "The port helper returned invalid output"}
    if completed.returncode or not body.get("ok"):
        # The web server did not move: put the setting back so the dashboard's
        # reported port always matches where the page really answers.
        database.set_setting("admin_port", str(previous))
        database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="system.admin_port", resource_type="system", resource_id=str(port), outcome="failure", source_ip=client_ip(request), details={"stage": "nginx", "message": body.get("message", "")})
        raise HTTPException(status_code=409, detail=f"The firewall now allows port {port}, but the web server could not be switched: {body.get('message', 'unknown error')}. The dashboard is still on port {previous} — nothing was lost.")

    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="system.admin_port", resource_type="system", resource_id=str(port), outcome="success", source_ip=client_ip(request), details={"previous_port": previous, "transaction_id": transaction_id, "activated": activate_result.get("state"), "confirmed": confirm_result.get("state")})
    return {"port": port, "previous_port": previous, "changed": True, "message": f"The admin page now answers on port {port}. Open http://<appliance>:{port}/ — the old address stops answering."}


@app.post("/api/v1/deployment/validate", response_model=ValidationResult)
def validate(request: DeploymentRequest) -> ValidationResult:
    return validate_deployment(request, discover_interfaces())


@app.post("/api/v1/deployment/plan", response_model=DeploymentPlan)
def plan(request: DeploymentRequest) -> DeploymentPlan:
    return build_plan(request, discover_interfaces())


@app.post("/api/v1/deployment/render")
def render_candidate(payload: DeploymentRequest, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    license_result = LicenseService(database).status()
    if "firewall" not in license_result.features:
        raise HTTPException(status_code=402, detail={"message": "A trial or purchased licence is required.", "license_state": license_result.state})
    deployment_plan = build_plan(payload, discover_interfaces())
    if not deployment_plan.validation.valid:
        raise HTTPException(status_code=422, detail=deployment_plan.validation.model_dump())
    block_targets = compile_block_targets(database.policy_sources())
    controls = compiled_security_controls(database)
    network_rules = compiled_network_rules(database)
    candidate = NetworkTransactionManager().prepare(payload, block_targets, rendered_service_configs(database), controls, network_rules)
    return {"transaction_id": candidate.transaction_id, "sha256": candidate.sha256, "nftables_valid": candidate.nftables_valid, "validation_message": candidate.validation_message, "rules_preview": render_nftables(payload, block_targets, controls, network_rules), "network_plan": candidate.network_plan, "blocking_targets": block_targets, "security_controls": controls, "network_rules": network_rules, "service_configurations": candidate.service_configurations}


@app.post("/api/v1/deployment/apply")
def apply(payload: DeploymentRequest, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    license_result = LicenseService(database).status()
    if "firewall" not in license_result.features:
        raise HTTPException(status_code=402, detail={"message": "A trial or purchased licence is required.", "license_state": license_result.state})
    deployment_plan = build_plan(payload, discover_interfaces())
    if not deployment_plan.validation.valid:
        database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="deployment.simulate", resource_type="deployment", outcome="failure", source_ip=client_ip(request), details={"mode": payload.mode})
        raise HTTPException(status_code=422, detail=deployment_plan.validation.model_dump())
    block_targets = compile_block_targets(database.policy_sources())
    controls = compiled_security_controls(database)
    candidate = NetworkTransactionManager().prepare(payload, block_targets, rendered_service_configs(database), controls, compiled_network_rules(database))
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="deployment.candidate.prepare", resource_type="deployment", resource_id=candidate.transaction_id, source_ip=client_ip(request), details={"mode": payload.mode, "sha256": candidate.sha256})
    return {
        "status": "candidate_prepared",
        "message": "Candidate generated and validated. Live activation requires the guarded transaction endpoint.",
        "transaction": candidate,
        "plan": deployment_plan,
    }


@app.get("/api/v1/deployment/transactions/{transaction_id}")
def transaction_status(transaction_id: str, principal: Principal = Depends(require_scope("deployment:read"))) -> dict:
    try:
        return NetworkTransactionManager().transaction(transaction_id)
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/api/v1/deployment/transactions/{transaction_id}/activate")
def activate_transaction(transaction_id: str, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    manager = NetworkTransactionManager()
    license_result = LicenseService(database).status()
    if "firewall" not in license_result.features:
        raise HTTPException(status_code=402, detail="A trial or purchased licence is required")
    try:
        activated = manager.privileged_action("activate", transaction_id)
        transaction = manager.transaction(transaction_id)
        checks = run_activation_health_checks(transaction["deployment"], transaction.get("transaction_id"))
        if not critical_health_passed(checks):
            rolled_back = manager.privileged_action("rollback", transaction_id)
            database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="deployment.activate", resource_type="deployment", resource_id=transaction_id, outcome="failure", source_ip=client_ip(request), details={"health_checks": checks, "rollback": rolled_back})
            raise HTTPException(status_code=409, detail={"message": "Critical health check failed; configuration was rolled back.", "health_checks": checks})
    except PermissionError as exc:
        raise HTTPException(status_code=423, detail=str(exc)) from exc
    except (RuntimeError, ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="deployment.activate", resource_type="deployment", resource_id=transaction_id, source_ip=client_ip(request), details={"health_checks": checks})
    return {"transaction": activated, "health_checks": checks, "confirmation_required": True, "rollback_seconds": 120}


@app.post("/api/v1/deployment/transactions/{transaction_id}/confirm")
def confirm_transaction(transaction_id: str, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    try:
        result = NetworkTransactionManager().privileged_action("confirm", transaction_id)
    except (RuntimeError, ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="deployment.confirm", resource_type="deployment", resource_id=transaction_id, source_ip=client_ip(request))
    return result


@app.post("/api/v1/deployment/transactions/{transaction_id}/rollback")
def rollback_transaction(transaction_id: str, request: Request, principal: Principal = Depends(require_scope("deployment:write")), database: Database = Depends(get_database)) -> dict:
    try:
        result = NetworkTransactionManager().privileged_action("rollback", transaction_id)
    except (RuntimeError, ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    database.audit(actor_type=principal.actor_type, actor_id=principal.actor_id, action="deployment.rollback", resource_type="deployment", resource_id=transaction_id, source_ip=client_ip(request))
    return result


@app.get("/api/v1/deployment/status")
def deployment_status(principal: Principal = Depends(require_scope("deployment:read"))) -> dict:
    """The appliance counts as deployed once an enforcement transaction is committed."""
    import json as json_module

    def committed_state(filename: str) -> str | None:
        record = Path(os.environ.get("FIREWALL_STATE_DIR", "/var/lib/firewall-appliance")) / filename
        try:
            return json_module.loads(record.read_text()).get("state") if record.is_file() else None
        except (OSError, ValueError):
            return None

    iptables_state = committed_state("iptables-active.json")
    dns_state = committed_state("dns-active.json")
    return {
        "deployed": iptables_state == "committed" or dns_state == "committed",
        "enforcement": {"iptables": iptables_state, "dns": dns_state},
    }

@app.get(
    "/api/v1/licensing/features",
    response_model=FeatureCatalog
)

def licensing_features() -> FeatureCatalog:

    features = set()

    for edition in EDITIONS.values():
        features.update(edition["features"])

    return FeatureCatalog(
        features=[
            FeatureDefinition(
                code=f,
                name=f.replace("_", " ").title()
            )
            for f in sorted(features)
        ],
        editions=[
            EditionDefinition(
                code=code,
                name=data["label"],
                features=data["features"]
            )
            for code, data in EDITIONS.items()
        ]
    )